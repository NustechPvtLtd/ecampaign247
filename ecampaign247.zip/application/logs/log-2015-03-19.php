<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-19 12:25:34 --> Config Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:25:34 --> URI Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Router Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Output Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Security Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Input Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:25:34 --> Language Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Language Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Config Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Loader Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:25:34 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Session Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:25:34 --> Session routines successfully run
DEBUG - 2015-03-19 12:25:34 --> Controller Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Customer MX_Controller Initialized
DEBUG - 2015-03-19 12:25:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:25:34 --> Email Class Initialized
DEBUG - 2015-03-19 12:25:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:25:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:27:41 --> Config Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:27:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:27:41 --> URI Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Router Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Output Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Security Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Input Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:27:41 --> Language Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Language Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Config Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Loader Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:27:41 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Session Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:27:41 --> Session routines successfully run
DEBUG - 2015-03-19 12:27:41 --> Controller Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Customer MX_Controller Initialized
DEBUG - 2015-03-19 12:27:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:27:41 --> Email Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:27:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:27:41 --> Model Class Initialized
DEBUG - 2015-03-19 12:27:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 12:27:41 --> Model Class Initialized
DEBUG - 2015-03-19 12:27:41 --> Form Validation Class Initialized
DEBUG - 2015-03-19 12:27:41 --> File loaded: application/views/../modules_core/customer/views/index.php
DEBUG - 2015-03-19 12:27:41 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-19 12:27:41 --> Final output sent to browser
DEBUG - 2015-03-19 12:27:41 --> Total execution time: 0.5100
DEBUG - 2015-03-19 12:27:42 --> Config Class Initialized
DEBUG - 2015-03-19 12:27:42 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:27:42 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:27:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:27:42 --> URI Class Initialized
DEBUG - 2015-03-19 12:27:42 --> Router Class Initialized
ERROR - 2015-03-19 12:27:42 --> 404 Page Not Found --> 
DEBUG - 2015-03-19 12:46:52 --> Config Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:46:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:46:52 --> URI Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Router Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Output Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Security Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Input Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:46:52 --> Language Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Language Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Config Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Loader Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:46:52 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Session Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:46:52 --> Session routines successfully run
DEBUG - 2015-03-19 12:46:52 --> Controller Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 12:46:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:46:52 --> Email Class Initialized
DEBUG - 2015-03-19 12:46:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:46:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:46:53 --> Model Class Initialized
DEBUG - 2015-03-19 12:46:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 12:46:53 --> Model Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Form Validation Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 12:46:53 --> Config Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:46:53 --> URI Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Router Class Initialized
DEBUG - 2015-03-19 12:46:53 --> No URI present. Default controller set.
DEBUG - 2015-03-19 12:46:53 --> Output Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Security Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Input Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:46:53 --> Language Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Language Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Config Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Loader Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:46:53 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Session Class Initialized
DEBUG - 2015-03-19 12:46:53 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:46:53 --> Session routines successfully run
DEBUG - 2015-03-19 12:46:53 --> Controller Class Initialized
DEBUG - 2015-03-19 12:46:54 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 12:46:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:46:54 --> Email Class Initialized
DEBUG - 2015-03-19 12:46:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:46:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:46:54 --> Model Class Initialized
DEBUG - 2015-03-19 12:46:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 12:46:54 --> Model Class Initialized
DEBUG - 2015-03-19 12:46:54 --> Form Validation Class Initialized
DEBUG - 2015-03-19 12:46:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 12:46:54 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-19 12:46:54 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-19 12:46:54 --> Final output sent to browser
DEBUG - 2015-03-19 12:46:54 --> Total execution time: 0.7050
DEBUG - 2015-03-19 12:47:06 --> Config Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:47:06 --> URI Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Router Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Output Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Security Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Input Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:47:06 --> Language Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Language Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Config Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Loader Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:47:06 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Session Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:47:06 --> Session routines successfully run
DEBUG - 2015-03-19 12:47:06 --> Controller Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 12:47:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:47:06 --> Email Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:47:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:47:06 --> Model Class Initialized
DEBUG - 2015-03-19 12:47:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 12:47:06 --> Model Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Form Validation Class Initialized
DEBUG - 2015-03-19 12:47:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 12:47:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-19 12:47:07 --> Config Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:47:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:47:07 --> URI Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Router Class Initialized
DEBUG - 2015-03-19 12:47:07 --> No URI present. Default controller set.
DEBUG - 2015-03-19 12:47:07 --> Output Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Security Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Input Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 12:47:07 --> Language Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Language Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Config Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Loader Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: url_helper
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: form_helper
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: language_helper
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: user_helper
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: date_helper
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 12:47:07 --> Database Driver Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Session Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: string_helper
DEBUG - 2015-03-19 12:47:07 --> Session routines successfully run
DEBUG - 2015-03-19 12:47:07 --> Controller Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 12:47:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 12:47:07 --> Email Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 12:47:07 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 12:47:07 --> Model Class Initialized
DEBUG - 2015-03-19 12:47:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 12:47:07 --> Model Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Form Validation Class Initialized
DEBUG - 2015-03-19 12:47:07 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 12:47:07 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-03-19 12:47:07 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-19 12:47:07 --> Final output sent to browser
DEBUG - 2015-03-19 12:47:07 --> Total execution time: 0.7150
DEBUG - 2015-03-19 12:47:08 --> Config Class Initialized
DEBUG - 2015-03-19 12:47:08 --> Hooks Class Initialized
DEBUG - 2015-03-19 12:47:08 --> Utf8 Class Initialized
DEBUG - 2015-03-19 12:47:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 12:47:08 --> URI Class Initialized
DEBUG - 2015-03-19 12:47:08 --> Router Class Initialized
ERROR - 2015-03-19 12:47:08 --> 404 Page Not Found --> 
DEBUG - 2015-03-19 13:37:25 --> Config Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Hooks Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Utf8 Class Initialized
DEBUG - 2015-03-19 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 13:37:25 --> URI Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Router Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Output Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Security Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Input Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 13:37:25 --> Language Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Language Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Config Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Loader Class Initialized
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: url_helper
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: form_helper
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: language_helper
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: user_helper
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: date_helper
DEBUG - 2015-03-19 13:37:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 13:37:25 --> Database Driver Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Session Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Helper loaded: string_helper
DEBUG - 2015-03-19 13:37:26 --> Session routines successfully run
DEBUG - 2015-03-19 13:37:26 --> Controller Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 13:37:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 13:37:26 --> Email Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 13:37:26 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 13:37:26 --> Model Class Initialized
DEBUG - 2015-03-19 13:37:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 13:37:26 --> Model Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Form Validation Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 13:37:26 --> Config Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Hooks Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Utf8 Class Initialized
DEBUG - 2015-03-19 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-19 13:37:26 --> URI Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Router Class Initialized
DEBUG - 2015-03-19 13:37:26 --> No URI present. Default controller set.
DEBUG - 2015-03-19 13:37:26 --> Output Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Security Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Input Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-19 13:37:26 --> Language Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Language Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Config Class Initialized
DEBUG - 2015-03-19 13:37:26 --> Loader Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: url_helper
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: form_helper
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: language_helper
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: user_helper
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: date_helper
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-19 13:37:27 --> Database Driver Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Session Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: string_helper
DEBUG - 2015-03-19 13:37:27 --> Session routines successfully run
DEBUG - 2015-03-19 13:37:27 --> Controller Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Login MX_Controller Initialized
DEBUG - 2015-03-19 13:37:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-19 13:37:27 --> Email Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-19 13:37:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-19 13:37:27 --> Model Class Initialized
DEBUG - 2015-03-19 13:37:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-19 13:37:27 --> Model Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Form Validation Class Initialized
DEBUG - 2015-03-19 13:37:27 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-19 13:37:27 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-19 13:37:27 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-19 13:37:27 --> Final output sent to browser
DEBUG - 2015-03-19 13:37:27 --> Total execution time: 0.6840
