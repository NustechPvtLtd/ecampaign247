<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-20 04:40:14 --> Config Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Hooks Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Utf8 Class Initialized
DEBUG - 2015-03-20 04:40:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 04:40:14 --> URI Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Router Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Output Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Security Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Input Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 04:40:14 --> Language Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Language Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Config Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Loader Class Initialized
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: url_helper
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: form_helper
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: language_helper
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: user_helper
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: date_helper
DEBUG - 2015-03-20 04:40:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 04:40:14 --> Database Driver Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Session Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: string_helper
DEBUG - 2015-03-20 04:40:16 --> A session cookie was not found.
DEBUG - 2015-03-20 04:40:16 --> Session routines successfully run
DEBUG - 2015-03-20 04:40:16 --> Controller Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 04:40:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 04:40:16 --> Email Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 04:40:16 --> Model Class Initialized
DEBUG - 2015-03-20 04:40:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 04:40:16 --> Model Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Form Validation Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Config Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Hooks Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Utf8 Class Initialized
DEBUG - 2015-03-20 04:40:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 04:40:16 --> URI Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Router Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Output Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Security Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Input Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 04:40:16 --> Language Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Language Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Config Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Loader Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: url_helper
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: form_helper
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: language_helper
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: user_helper
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: date_helper
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 04:40:16 --> Database Driver Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Session Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: string_helper
DEBUG - 2015-03-20 04:40:16 --> Session routines successfully run
DEBUG - 2015-03-20 04:40:16 --> Controller Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 04:40:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 04:40:16 --> Email Class Initialized
DEBUG - 2015-03-20 04:40:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 04:40:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 04:40:16 --> Model Class Initialized
DEBUG - 2015-03-20 04:40:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 04:40:17 --> Model Class Initialized
DEBUG - 2015-03-20 04:40:17 --> Form Validation Class Initialized
DEBUG - 2015-03-20 04:40:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 04:40:17 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 04:40:17 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 04:40:17 --> Final output sent to browser
DEBUG - 2015-03-20 04:40:17 --> Total execution time: 0.6520
DEBUG - 2015-03-20 05:14:49 --> Config Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Hooks Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Utf8 Class Initialized
DEBUG - 2015-03-20 05:14:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 05:14:49 --> URI Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Router Class Initialized
DEBUG - 2015-03-20 05:14:49 --> No URI present. Default controller set.
DEBUG - 2015-03-20 05:14:49 --> Output Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Security Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Input Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 05:14:49 --> Language Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Language Class Initialized
DEBUG - 2015-03-20 05:14:49 --> Config Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Loader Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: url_helper
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: form_helper
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: language_helper
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: user_helper
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: date_helper
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 05:14:50 --> Database Driver Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Session Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: string_helper
DEBUG - 2015-03-20 05:14:50 --> Session routines successfully run
DEBUG - 2015-03-20 05:14:50 --> Controller Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 05:14:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 05:14:50 --> Email Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 05:14:50 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 05:14:50 --> Model Class Initialized
DEBUG - 2015-03-20 05:14:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 05:14:50 --> Model Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Form Validation Class Initialized
DEBUG - 2015-03-20 05:14:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 05:14:50 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 05:14:50 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 05:14:50 --> Final output sent to browser
DEBUG - 2015-03-20 05:14:50 --> Total execution time: 1.2220
DEBUG - 2015-03-20 07:14:14 --> Config Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:14:14 --> URI Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Router Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Output Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Security Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Input Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:14:14 --> Language Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Language Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Config Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Loader Class Initialized
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:14:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:14:14 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Session Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:14:15 --> Session routines successfully run
DEBUG - 2015-03-20 07:14:15 --> Controller Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:14:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:14:15 --> Email Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:14:15 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:14:15 --> Model Class Initialized
DEBUG - 2015-03-20 07:14:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:14:15 --> Model Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:14:15 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:14:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-20 07:14:16 --> Config Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:14:16 --> URI Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Router Class Initialized
DEBUG - 2015-03-20 07:14:16 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:14:16 --> Output Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Security Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Input Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:14:16 --> Language Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Language Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Config Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Loader Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:14:16 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Session Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:14:16 --> Session routines successfully run
DEBUG - 2015-03-20 07:14:16 --> Controller Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:14:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:14:16 --> Email Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:14:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:14:16 --> Model Class Initialized
DEBUG - 2015-03-20 07:14:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:14:16 --> Model Class Initialized
DEBUG - 2015-03-20 07:14:16 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:23:15 --> URI Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Router Class Initialized
DEBUG - 2015-03-20 07:23:15 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:23:15 --> Output Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Security Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Input Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:23:15 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Loader Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:23:15 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Session Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:23:15 --> Session routines successfully run
DEBUG - 2015-03-20 07:23:15 --> Controller Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:23:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:23:15 --> Email Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:23:15 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:23:15 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:23:15 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:15 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:23:15 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 07:23:15 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:23:15 --> Final output sent to browser
DEBUG - 2015-03-20 07:23:15 --> Total execution time: 0.7740
DEBUG - 2015-03-20 07:23:16 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:16 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:23:16 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:23:16 --> URI Class Initialized
DEBUG - 2015-03-20 07:23:16 --> Router Class Initialized
ERROR - 2015-03-20 07:23:16 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 07:23:44 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:23:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:23:44 --> URI Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Router Class Initialized
DEBUG - 2015-03-20 07:23:44 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:23:44 --> Output Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Security Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Input Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:23:44 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Loader Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:23:44 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Session Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:23:44 --> Session routines successfully run
DEBUG - 2015-03-20 07:23:44 --> Controller Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:23:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:23:44 --> Email Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:23:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:23:44 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:23:44 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:44 --> Form Validation Class Initialized
ERROR - 2015-03-20 07:23:44 --> 404 Page Not Found --> customer/user
DEBUG - 2015-03-20 07:23:57 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:57 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:23:57 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:23:57 --> URI Class Initialized
DEBUG - 2015-03-20 07:23:57 --> Router Class Initialized
DEBUG - 2015-03-20 07:23:57 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:23:58 --> Output Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Security Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Input Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:23:58 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Loader Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:23:58 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Session Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:23:58 --> Session routines successfully run
DEBUG - 2015-03-20 07:23:58 --> Controller Class Initialized
DEBUG - 2015-03-20 07:23:58 --> User MX_Controller Initialized
DEBUG - 2015-03-20 07:23:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:23:58 --> Email Class Initialized
DEBUG - 2015-03-20 07:23:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:23:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:23:58 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:23:59 --> Model Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:23:59 --> File loaded: application/views/../modules_core/customer/views/user/index.php
DEBUG - 2015-03-20 07:23:59 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:23:59 --> Final output sent to browser
DEBUG - 2015-03-20 07:23:59 --> Total execution time: 1.5891
DEBUG - 2015-03-20 07:23:59 --> Config Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:23:59 --> URI Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Router Class Initialized
DEBUG - 2015-03-20 07:23:59 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:23:59 --> Output Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Security Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Input Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:23:59 --> Language Class Initialized
DEBUG - 2015-03-20 07:23:59 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Loader Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:24:00 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Session Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:24:00 --> Session routines successfully run
DEBUG - 2015-03-20 07:24:00 --> Controller Class Initialized
DEBUG - 2015-03-20 07:24:00 --> User MX_Controller Initialized
DEBUG - 2015-03-20 07:24:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:24:00 --> Email Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:24:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:24:00 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:24:00 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:00 --> Form Validation Class Initialized
ERROR - 2015-03-20 07:24:00 --> 404 Page Not Found --> user/avatar
DEBUG - 2015-03-20 07:24:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:24:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:24:46 --> URI Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Router Class Initialized
DEBUG - 2015-03-20 07:24:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:24:46 --> Output Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Security Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Input Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:24:46 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Loader Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:24:46 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Session Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:24:46 --> Session routines successfully run
DEBUG - 2015-03-20 07:24:46 --> Controller Class Initialized
DEBUG - 2015-03-20 07:24:46 --> User MX_Controller Initialized
DEBUG - 2015-03-20 07:24:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:24:46 --> Email Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:24:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:24:46 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:24:46 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:24:46 --> File loaded: application/views/../modules_core/customer/views/user/index.php
DEBUG - 2015-03-20 07:24:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:24:46 --> Final output sent to browser
DEBUG - 2015-03-20 07:24:46 --> Total execution time: 0.6140
DEBUG - 2015-03-20 07:24:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:24:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:24:46 --> URI Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Router Class Initialized
DEBUG - 2015-03-20 07:24:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:24:46 --> Output Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Security Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Input Class Initialized
DEBUG - 2015-03-20 07:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:24:47 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Loader Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:24:47 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Session Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:24:47 --> Session routines successfully run
DEBUG - 2015-03-20 07:24:47 --> Controller Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:24:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:24:47 --> Email Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:24:47 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:24:47 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:24:47 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:47 --> Form Validation Class Initialized
ERROR - 2015-03-20 07:24:47 --> 404 Page Not Found --> customer/avatar
DEBUG - 2015-03-20 07:24:50 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:24:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:24:50 --> URI Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Router Class Initialized
DEBUG - 2015-03-20 07:24:50 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:24:50 --> Output Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Security Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Input Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:24:50 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:50 --> Loader Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:24:51 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Session Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:24:51 --> Session routines successfully run
DEBUG - 2015-03-20 07:24:51 --> Controller Class Initialized
DEBUG - 2015-03-20 07:24:51 --> User MX_Controller Initialized
DEBUG - 2015-03-20 07:24:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:24:51 --> Email Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:24:51 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:24:51 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:24:51 --> File loaded: application/views/../modules_core/customer/views/user/index.php
DEBUG - 2015-03-20 07:24:51 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:24:51 --> Final output sent to browser
DEBUG - 2015-03-20 07:24:51 --> Total execution time: 0.7870
DEBUG - 2015-03-20 07:24:51 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:24:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:24:51 --> URI Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Router Class Initialized
DEBUG - 2015-03-20 07:24:51 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:24:51 --> Output Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Security Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Input Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:24:51 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Language Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Config Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Loader Class Initialized
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:24:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:24:51 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:24:52 --> Session Class Initialized
DEBUG - 2015-03-20 07:24:52 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:24:52 --> Session routines successfully run
DEBUG - 2015-03-20 07:24:52 --> Controller Class Initialized
DEBUG - 2015-03-20 07:24:52 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:24:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:24:52 --> Email Class Initialized
DEBUG - 2015-03-20 07:24:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:24:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:24:52 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:24:52 --> Model Class Initialized
DEBUG - 2015-03-20 07:24:52 --> Form Validation Class Initialized
ERROR - 2015-03-20 07:24:52 --> 404 Page Not Found --> customer/avatar
DEBUG - 2015-03-20 07:25:13 --> Config Class Initialized
DEBUG - 2015-03-20 07:25:13 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:25:13 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:25:13 --> URI Class Initialized
DEBUG - 2015-03-20 07:25:13 --> Router Class Initialized
ERROR - 2015-03-20 07:25:13 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 07:25:22 --> Config Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:25:22 --> URI Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Router Class Initialized
DEBUG - 2015-03-20 07:25:22 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:25:22 --> Output Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Security Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Input Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:25:22 --> Language Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Language Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Config Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Loader Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:25:22 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Session Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:25:22 --> Session routines successfully run
DEBUG - 2015-03-20 07:25:22 --> Controller Class Initialized
DEBUG - 2015-03-20 07:25:22 --> User MX_Controller Initialized
DEBUG - 2015-03-20 07:25:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:25:22 --> Email Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:25:22 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:25:22 --> Model Class Initialized
DEBUG - 2015-03-20 07:25:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:25:22 --> Model Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:25:22 --> File loaded: application/views/../modules_core/customer/views/user/index.php
DEBUG - 2015-03-20 07:25:22 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:25:22 --> Final output sent to browser
DEBUG - 2015-03-20 07:25:22 --> Total execution time: 0.6100
DEBUG - 2015-03-20 07:25:22 --> Config Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:25:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:25:22 --> URI Class Initialized
DEBUG - 2015-03-20 07:25:22 --> Router Class Initialized
DEBUG - 2015-03-20 07:25:22 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:25:22 --> Output Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Security Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Input Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:25:23 --> Language Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Language Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Config Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Loader Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:25:23 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Session Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:25:23 --> Session routines successfully run
DEBUG - 2015-03-20 07:25:23 --> Controller Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:25:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:25:23 --> Email Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:25:23 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:25:23 --> Model Class Initialized
DEBUG - 2015-03-20 07:25:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:25:23 --> Model Class Initialized
DEBUG - 2015-03-20 07:25:23 --> Form Validation Class Initialized
ERROR - 2015-03-20 07:25:23 --> 404 Page Not Found --> customer/avatar
DEBUG - 2015-03-20 07:26:10 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:10 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:10 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:10 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:11 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:11 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:26:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:11 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:11 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:11 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:26:12 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:12 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:12 --> No URI present. Default controller set.
DEBUG - 2015-03-20 07:26:12 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:12 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:12 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:12 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:12 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:26:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:12 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:12 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:12 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:12 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:26:12 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 07:26:12 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 07:26:12 --> Final output sent to browser
DEBUG - 2015-03-20 07:26:12 --> Total execution time: 0.7870
DEBUG - 2015-03-20 07:26:32 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:32 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:32 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:32 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:33 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:33 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:33 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:26:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:33 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:33 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:33 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:26:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-20 07:26:33 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:33 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:33 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:33 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:33 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:34 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:34 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:34 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:26:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:34 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:34 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:34 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:34 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:26:34 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 07:26:34 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 07:26:34 --> Final output sent to browser
DEBUG - 2015-03-20 07:26:34 --> Total execution time: 0.5940
DEBUG - 2015-03-20 07:26:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:46 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:46 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:46 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:46 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:46 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:26:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:46 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:46 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:46 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:26:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-20 07:26:47 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:47 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Router Class Initialized
DEBUG - 2015-03-20 07:26:47 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:26:47 --> Output Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Security Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Input Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:26:47 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Language Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Loader Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:26:47 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Session Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:26:47 --> Session routines successfully run
DEBUG - 2015-03-20 07:26:47 --> Controller Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:26:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:26:47 --> Email Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:26:47 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:26:47 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:26:47 --> Model Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:26:47 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 07:26:47 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:26:47 --> Final output sent to browser
DEBUG - 2015-03-20 07:26:47 --> Total execution time: 0.6180
DEBUG - 2015-03-20 07:26:47 --> Config Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:26:47 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:26:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:26:48 --> URI Class Initialized
DEBUG - 2015-03-20 07:26:48 --> Router Class Initialized
ERROR - 2015-03-20 07:26:48 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 07:28:44 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:28:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:28:44 --> URI Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Router Class Initialized
DEBUG - 2015-03-20 07:28:44 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:28:44 --> Output Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Security Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Input Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:28:44 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Loader Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:28:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:28:44 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:28:44 --> Session Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:28:45 --> Session routines successfully run
DEBUG - 2015-03-20 07:28:45 --> Controller Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:28:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:28:45 --> Email Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:28:45 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:28:45 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:28:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:28:45 --> URI Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Router Class Initialized
DEBUG - 2015-03-20 07:28:45 --> No URI present. Default controller set.
DEBUG - 2015-03-20 07:28:45 --> Output Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Security Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Input Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:28:45 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Loader Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:28:45 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Session Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:28:45 --> Session routines successfully run
DEBUG - 2015-03-20 07:28:45 --> Controller Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:28:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:28:45 --> Email Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:28:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:28:45 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:28:45 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:28:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:28:46 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-03-20 07:28:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:28:46 --> Final output sent to browser
DEBUG - 2015-03-20 07:28:46 --> Total execution time: 0.7680
DEBUG - 2015-03-20 07:28:46 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:46 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:28:46 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:28:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:28:46 --> URI Class Initialized
DEBUG - 2015-03-20 07:28:46 --> Router Class Initialized
ERROR - 2015-03-20 07:28:46 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 07:28:58 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:28:58 --> URI Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Router Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Output Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Security Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Input Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:28:58 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Loader Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:28:58 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Session Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:28:58 --> Session routines successfully run
DEBUG - 2015-03-20 07:28:58 --> Controller Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:28:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:28:58 --> Email Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:28:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:28:58 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:28:58 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:28:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:28:58 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:28:59 --> URI Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Router Class Initialized
DEBUG - 2015-03-20 07:28:59 --> No URI present. Default controller set.
DEBUG - 2015-03-20 07:28:59 --> Output Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Security Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Input Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:28:59 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Language Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Config Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Loader Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:28:59 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Session Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:28:59 --> Session routines successfully run
DEBUG - 2015-03-20 07:28:59 --> Controller Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:28:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:28:59 --> Email Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:28:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:28:59 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:28:59 --> Model Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:28:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:28:59 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 07:28:59 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 07:28:59 --> Final output sent to browser
DEBUG - 2015-03-20 07:28:59 --> Total execution time: 0.6080
DEBUG - 2015-03-20 07:29:48 --> Config Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:29:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:29:48 --> URI Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Router Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Output Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Security Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Input Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:29:48 --> Language Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Language Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Config Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Loader Class Initialized
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:29:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:29:48 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Session Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:29:49 --> Session routines successfully run
DEBUG - 2015-03-20 07:29:49 --> Controller Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:29:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:29:49 --> Email Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:29:49 --> Model Class Initialized
DEBUG - 2015-03-20 07:29:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:29:49 --> Model Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:29:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-20 07:29:49 --> Config Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:29:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:29:49 --> URI Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Router Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Output Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Security Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Input Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:29:49 --> Language Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Language Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Config Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Loader Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:29:49 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Session Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:29:49 --> Session routines successfully run
DEBUG - 2015-03-20 07:29:49 --> Controller Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:29:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:29:49 --> Email Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:29:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:29:49 --> Model Class Initialized
DEBUG - 2015-03-20 07:29:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:29:49 --> Model Class Initialized
DEBUG - 2015-03-20 07:29:49 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:29:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:29:50 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 07:29:50 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 07:29:50 --> Final output sent to browser
DEBUG - 2015-03-20 07:29:50 --> Total execution time: 0.6260
DEBUG - 2015-03-20 07:56:04 --> Config Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:56:05 --> URI Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Router Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Output Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Security Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Input Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:56:05 --> Language Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Language Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Config Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Loader Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:56:05 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Session Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:56:05 --> Session routines successfully run
DEBUG - 2015-03-20 07:56:05 --> Controller Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 07:56:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:56:05 --> Email Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:56:05 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:56:05 --> Model Class Initialized
DEBUG - 2015-03-20 07:56:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:56:05 --> Model Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 07:56:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-20 07:56:05 --> Config Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:56:05 --> URI Class Initialized
DEBUG - 2015-03-20 07:56:05 --> Router Class Initialized
DEBUG - 2015-03-20 07:56:05 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 07:56:06 --> Output Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Security Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Input Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 07:56:06 --> Language Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Language Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Config Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Loader Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: url_helper
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: form_helper
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: language_helper
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: user_helper
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: date_helper
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 07:56:06 --> Database Driver Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Session Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: string_helper
DEBUG - 2015-03-20 07:56:06 --> Session routines successfully run
DEBUG - 2015-03-20 07:56:06 --> Controller Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 07:56:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 07:56:06 --> Email Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 07:56:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 07:56:06 --> Model Class Initialized
DEBUG - 2015-03-20 07:56:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 07:56:06 --> Model Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Form Validation Class Initialized
DEBUG - 2015-03-20 07:56:06 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 07:56:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 07:56:06 --> Final output sent to browser
DEBUG - 2015-03-20 07:56:06 --> Total execution time: 0.6500
DEBUG - 2015-03-20 07:56:06 --> Config Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Hooks Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Utf8 Class Initialized
DEBUG - 2015-03-20 07:56:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 07:56:06 --> URI Class Initialized
DEBUG - 2015-03-20 07:56:06 --> Router Class Initialized
ERROR - 2015-03-20 07:56:06 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 09:42:40 --> Config Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:42:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:42:40 --> URI Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Router Class Initialized
DEBUG - 2015-03-20 09:42:40 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 09:42:40 --> Output Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Security Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Input Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 09:42:40 --> Language Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Language Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Config Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Loader Class Initialized
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: url_helper
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: form_helper
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: language_helper
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: user_helper
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: date_helper
DEBUG - 2015-03-20 09:42:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 09:42:40 --> Database Driver Class Initialized
DEBUG - 2015-03-20 09:42:41 --> Session Class Initialized
DEBUG - 2015-03-20 09:42:41 --> Helper loaded: string_helper
DEBUG - 2015-03-20 09:42:41 --> Session routines successfully run
DEBUG - 2015-03-20 09:42:41 --> Controller Class Initialized
DEBUG - 2015-03-20 09:42:41 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 09:42:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 09:42:41 --> Email Class Initialized
DEBUG - 2015-03-20 09:42:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 09:42:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 09:42:41 --> Model Class Initialized
DEBUG - 2015-03-20 09:42:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 09:42:41 --> Model Class Initialized
DEBUG - 2015-03-20 09:42:41 --> Form Validation Class Initialized
DEBUG - 2015-03-20 09:42:41 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 09:42:41 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 09:42:41 --> Final output sent to browser
DEBUG - 2015-03-20 09:42:41 --> Total execution time: 0.7830
DEBUG - 2015-03-20 09:42:44 --> Config Class Initialized
DEBUG - 2015-03-20 09:42:44 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:42:44 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:42:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:42:44 --> URI Class Initialized
DEBUG - 2015-03-20 09:42:45 --> Router Class Initialized
ERROR - 2015-03-20 09:42:45 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 09:45:15 --> Config Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:45:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:45:16 --> URI Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Router Class Initialized
DEBUG - 2015-03-20 09:45:16 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 09:45:16 --> Output Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Security Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Input Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 09:45:16 --> Language Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Language Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Config Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Loader Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: url_helper
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: form_helper
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: language_helper
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: user_helper
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: date_helper
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 09:45:16 --> Database Driver Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Session Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: string_helper
DEBUG - 2015-03-20 09:45:16 --> Session routines successfully run
DEBUG - 2015-03-20 09:45:16 --> Controller Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 09:45:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 09:45:16 --> Email Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 09:45:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 09:45:16 --> Model Class Initialized
DEBUG - 2015-03-20 09:45:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 09:45:16 --> Model Class Initialized
DEBUG - 2015-03-20 09:45:16 --> Form Validation Class Initialized
DEBUG - 2015-03-20 09:45:16 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 09:45:16 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 09:45:16 --> Final output sent to browser
DEBUG - 2015-03-20 09:45:16 --> Total execution time: 0.6570
DEBUG - 2015-03-20 09:45:27 --> Config Class Initialized
DEBUG - 2015-03-20 09:45:27 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:45:27 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:45:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:45:27 --> URI Class Initialized
DEBUG - 2015-03-20 09:45:27 --> Router Class Initialized
ERROR - 2015-03-20 09:45:27 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 09:51:05 --> Config Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:51:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:51:05 --> URI Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Router Class Initialized
DEBUG - 2015-03-20 09:51:05 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 09:51:05 --> Output Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Security Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Input Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 09:51:05 --> Language Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Language Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Config Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Loader Class Initialized
DEBUG - 2015-03-20 09:51:05 --> Helper loaded: url_helper
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: form_helper
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: language_helper
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: user_helper
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: date_helper
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 09:51:06 --> Database Driver Class Initialized
DEBUG - 2015-03-20 09:51:06 --> Session Class Initialized
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: string_helper
DEBUG - 2015-03-20 09:51:06 --> Session routines successfully run
DEBUG - 2015-03-20 09:51:06 --> Controller Class Initialized
DEBUG - 2015-03-20 09:51:06 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 09:51:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 09:51:06 --> Email Class Initialized
DEBUG - 2015-03-20 09:51:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 09:51:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 09:51:06 --> Model Class Initialized
DEBUG - 2015-03-20 09:51:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 09:51:06 --> Model Class Initialized
DEBUG - 2015-03-20 09:51:06 --> Form Validation Class Initialized
DEBUG - 2015-03-20 09:51:06 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 09:51:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 09:51:06 --> Final output sent to browser
DEBUG - 2015-03-20 09:51:06 --> Total execution time: 0.6640
DEBUG - 2015-03-20 09:51:07 --> Config Class Initialized
DEBUG - 2015-03-20 09:51:07 --> Hooks Class Initialized
DEBUG - 2015-03-20 09:51:07 --> Utf8 Class Initialized
DEBUG - 2015-03-20 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 09:51:07 --> URI Class Initialized
DEBUG - 2015-03-20 09:51:08 --> Router Class Initialized
ERROR - 2015-03-20 09:51:08 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 10:05:14 --> Config Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:05:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:05:14 --> URI Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Router Class Initialized
DEBUG - 2015-03-20 10:05:14 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 10:05:14 --> Output Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Security Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Input Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 10:05:14 --> Language Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Language Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Config Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Loader Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: url_helper
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: form_helper
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: language_helper
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: user_helper
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: date_helper
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 10:05:14 --> Database Driver Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Session Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: string_helper
DEBUG - 2015-03-20 10:05:14 --> Session routines successfully run
DEBUG - 2015-03-20 10:05:14 --> Controller Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 10:05:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 10:05:14 --> Email Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 10:05:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 10:05:14 --> Model Class Initialized
DEBUG - 2015-03-20 10:05:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 10:05:14 --> Model Class Initialized
DEBUG - 2015-03-20 10:05:14 --> Form Validation Class Initialized
DEBUG - 2015-03-20 10:05:14 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 10:05:14 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 10:05:14 --> Final output sent to browser
DEBUG - 2015-03-20 10:05:14 --> Total execution time: 0.6440
DEBUG - 2015-03-20 10:05:15 --> Config Class Initialized
DEBUG - 2015-03-20 10:05:15 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:05:15 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:05:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:05:15 --> URI Class Initialized
DEBUG - 2015-03-20 10:05:15 --> Router Class Initialized
ERROR - 2015-03-20 10:05:16 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 10:09:01 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:01 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:09:01 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:09:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:09:01 --> URI Class Initialized
DEBUG - 2015-03-20 10:09:01 --> Router Class Initialized
DEBUG - 2015-03-20 10:09:01 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 10:09:01 --> Output Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Security Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Input Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 10:09:02 --> Language Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Language Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Loader Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: url_helper
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: form_helper
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: language_helper
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: user_helper
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: date_helper
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 10:09:02 --> Database Driver Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Session Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: string_helper
DEBUG - 2015-03-20 10:09:02 --> Session routines successfully run
DEBUG - 2015-03-20 10:09:02 --> Controller Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 10:09:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 10:09:02 --> Email Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 10:09:02 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 10:09:02 --> Model Class Initialized
DEBUG - 2015-03-20 10:09:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 10:09:02 --> Model Class Initialized
DEBUG - 2015-03-20 10:09:02 --> Form Validation Class Initialized
DEBUG - 2015-03-20 10:09:02 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 10:09:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 10:09:02 --> Final output sent to browser
DEBUG - 2015-03-20 10:09:02 --> Total execution time: 1.0271
DEBUG - 2015-03-20 10:09:04 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:04 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:09:04 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:09:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:09:04 --> URI Class Initialized
DEBUG - 2015-03-20 10:09:04 --> Router Class Initialized
ERROR - 2015-03-20 10:09:04 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 10:09:41 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:09:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:09:41 --> URI Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Router Class Initialized
DEBUG - 2015-03-20 10:09:41 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-20 10:09:41 --> Output Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Security Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Input Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 10:09:41 --> Language Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Language Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Loader Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: url_helper
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: form_helper
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: language_helper
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: user_helper
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: date_helper
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 10:09:41 --> Database Driver Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Session Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: string_helper
DEBUG - 2015-03-20 10:09:41 --> Session routines successfully run
DEBUG - 2015-03-20 10:09:41 --> Controller Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Customer MX_Controller Initialized
DEBUG - 2015-03-20 10:09:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 10:09:41 --> Email Class Initialized
DEBUG - 2015-03-20 10:09:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 10:09:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 10:09:41 --> Model Class Initialized
DEBUG - 2015-03-20 10:09:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 10:09:42 --> Model Class Initialized
DEBUG - 2015-03-20 10:09:42 --> Form Validation Class Initialized
DEBUG - 2015-03-20 10:09:42 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-20 10:09:42 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-20 10:09:42 --> Final output sent to browser
DEBUG - 2015-03-20 10:09:42 --> Total execution time: 0.6570
DEBUG - 2015-03-20 10:09:43 --> Config Class Initialized
DEBUG - 2015-03-20 10:09:43 --> Hooks Class Initialized
DEBUG - 2015-03-20 10:09:43 --> Utf8 Class Initialized
DEBUG - 2015-03-20 10:09:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 10:09:43 --> URI Class Initialized
DEBUG - 2015-03-20 10:09:43 --> Router Class Initialized
ERROR - 2015-03-20 10:09:43 --> 404 Page Not Found --> 
DEBUG - 2015-03-20 13:13:29 --> Config Class Initialized
DEBUG - 2015-03-20 13:13:29 --> Hooks Class Initialized
DEBUG - 2015-03-20 13:13:29 --> Utf8 Class Initialized
DEBUG - 2015-03-20 13:13:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 13:13:29 --> URI Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Router Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Output Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Security Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Input Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 13:13:30 --> Language Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Language Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Config Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Loader Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: url_helper
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: form_helper
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: language_helper
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: user_helper
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: date_helper
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 13:13:30 --> Database Driver Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Session Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: string_helper
DEBUG - 2015-03-20 13:13:30 --> A session cookie was not found.
DEBUG - 2015-03-20 13:13:30 --> Session routines successfully run
DEBUG - 2015-03-20 13:13:30 --> Controller Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 13:13:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 13:13:30 --> Email Class Initialized
DEBUG - 2015-03-20 13:13:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 13:13:30 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 13:13:30 --> Model Class Initialized
DEBUG - 2015-03-20 13:13:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 13:13:30 --> Model Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Form Validation Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 13:13:31 --> Config Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Hooks Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Utf8 Class Initialized
DEBUG - 2015-03-20 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2015-03-20 13:13:31 --> URI Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Router Class Initialized
DEBUG - 2015-03-20 13:13:31 --> No URI present. Default controller set.
DEBUG - 2015-03-20 13:13:31 --> Output Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Security Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Input Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-20 13:13:31 --> Language Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Language Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Config Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Loader Class Initialized
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: url_helper
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: form_helper
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: language_helper
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: user_helper
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: date_helper
DEBUG - 2015-03-20 13:13:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-20 13:13:31 --> Database Driver Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Session Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Helper loaded: string_helper
DEBUG - 2015-03-20 13:13:32 --> Session routines successfully run
DEBUG - 2015-03-20 13:13:32 --> Controller Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Login MX_Controller Initialized
DEBUG - 2015-03-20 13:13:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-20 13:13:32 --> Email Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-20 13:13:32 --> Helper loaded: cookie_helper
DEBUG - 2015-03-20 13:13:32 --> Model Class Initialized
DEBUG - 2015-03-20 13:13:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-20 13:13:32 --> Model Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Form Validation Class Initialized
DEBUG - 2015-03-20 13:13:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-20 13:13:32 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-20 13:13:32 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-20 13:13:32 --> Final output sent to browser
DEBUG - 2015-03-20 13:13:32 --> Total execution time: 1.2701
