<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-21 04:31:56 --> Config Class Initialized
DEBUG - 2015-03-21 04:31:56 --> Hooks Class Initialized
DEBUG - 2015-03-21 04:31:56 --> Utf8 Class Initialized
DEBUG - 2015-03-21 04:31:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-21 04:31:57 --> URI Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Router Class Initialized
DEBUG - 2015-03-21 04:31:57 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-21 04:31:57 --> Output Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Security Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Input Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-21 04:31:57 --> Language Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Language Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Config Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Loader Class Initialized
DEBUG - 2015-03-21 04:31:57 --> Helper loaded: url_helper
DEBUG - 2015-03-21 04:31:57 --> Helper loaded: form_helper
DEBUG - 2015-03-21 04:31:57 --> Helper loaded: language_helper
DEBUG - 2015-03-21 04:31:57 --> Helper loaded: user_helper
DEBUG - 2015-03-21 04:31:57 --> Helper loaded: date_helper
DEBUG - 2015-03-21 04:31:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-21 04:31:58 --> Database Driver Class Initialized
DEBUG - 2015-03-21 04:31:59 --> Session Class Initialized
DEBUG - 2015-03-21 04:31:59 --> Helper loaded: string_helper
DEBUG - 2015-03-21 04:31:59 --> A session cookie was not found.
DEBUG - 2015-03-21 04:31:59 --> Session routines successfully run
DEBUG - 2015-03-21 04:31:59 --> Controller Class Initialized
DEBUG - 2015-03-21 04:31:59 --> User MX_Controller Initialized
DEBUG - 2015-03-21 04:31:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-21 04:31:59 --> Email Class Initialized
DEBUG - 2015-03-21 04:31:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-21 04:31:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-21 04:31:59 --> Model Class Initialized
DEBUG - 2015-03-21 04:31:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-21 04:31:59 --> Model Class Initialized
DEBUG - 2015-03-21 04:31:59 --> Form Validation Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Config Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Hooks Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Utf8 Class Initialized
DEBUG - 2015-03-21 04:32:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-21 04:32:00 --> URI Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Router Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Output Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Security Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Input Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-21 04:32:00 --> Language Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Language Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Config Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Loader Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: url_helper
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: form_helper
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: language_helper
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: user_helper
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: date_helper
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-21 04:32:00 --> Database Driver Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Session Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: string_helper
DEBUG - 2015-03-21 04:32:00 --> Session routines successfully run
DEBUG - 2015-03-21 04:32:00 --> Controller Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Login MX_Controller Initialized
DEBUG - 2015-03-21 04:32:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-21 04:32:00 --> Email Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-21 04:32:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-21 04:32:00 --> Model Class Initialized
DEBUG - 2015-03-21 04:32:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-21 04:32:00 --> Model Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Form Validation Class Initialized
DEBUG - 2015-03-21 04:32:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-21 04:32:00 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-21 04:32:00 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-21 04:32:00 --> Final output sent to browser
DEBUG - 2015-03-21 04:32:00 --> Total execution time: 0.7120
