<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-23 04:38:45 --> Config Class Initialized
DEBUG - 2015-03-23 04:38:45 --> Hooks Class Initialized
DEBUG - 2015-03-23 04:38:45 --> Utf8 Class Initialized
DEBUG - 2015-03-23 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 04:38:45 --> URI Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Router Class Initialized
DEBUG - 2015-03-23 04:38:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 04:38:46 --> Output Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Security Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Input Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 04:38:46 --> Language Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Language Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Config Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Loader Class Initialized
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: url_helper
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: form_helper
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: language_helper
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: user_helper
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: date_helper
DEBUG - 2015-03-23 04:38:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 04:38:47 --> Database Driver Class Initialized
DEBUG - 2015-03-23 04:38:48 --> Session Class Initialized
DEBUG - 2015-03-23 04:38:48 --> Helper loaded: string_helper
DEBUG - 2015-03-23 04:38:48 --> A session cookie was not found.
DEBUG - 2015-03-23 04:38:48 --> Session routines successfully run
DEBUG - 2015-03-23 04:38:48 --> Controller Class Initialized
DEBUG - 2015-03-23 04:38:48 --> User MX_Controller Initialized
DEBUG - 2015-03-23 04:38:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 04:38:48 --> Email Class Initialized
DEBUG - 2015-03-23 04:38:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 04:38:48 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 04:38:48 --> Model Class Initialized
DEBUG - 2015-03-23 04:38:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 04:38:48 --> Model Class Initialized
DEBUG - 2015-03-23 04:38:48 --> Form Validation Class Initialized
DEBUG - 2015-03-23 04:38:48 --> Config Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Hooks Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Utf8 Class Initialized
DEBUG - 2015-03-23 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 04:38:49 --> URI Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Router Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Output Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Security Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Input Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 04:38:49 --> Language Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Language Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Config Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Loader Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: url_helper
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: form_helper
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: language_helper
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: user_helper
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: date_helper
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 04:38:49 --> Database Driver Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Session Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: string_helper
DEBUG - 2015-03-23 04:38:49 --> Session routines successfully run
DEBUG - 2015-03-23 04:38:49 --> Controller Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Login MX_Controller Initialized
DEBUG - 2015-03-23 04:38:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 04:38:49 --> Email Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 04:38:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 04:38:49 --> Model Class Initialized
DEBUG - 2015-03-23 04:38:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 04:38:49 --> Model Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Form Validation Class Initialized
DEBUG - 2015-03-23 04:38:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-23 04:38:49 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-23 04:38:49 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-23 04:38:49 --> Final output sent to browser
DEBUG - 2015-03-23 04:38:49 --> Total execution time: 0.8210
DEBUG - 2015-03-23 06:19:07 --> Config Class Initialized
DEBUG - 2015-03-23 06:19:07 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:19:07 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:19:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:19:07 --> URI Class Initialized
DEBUG - 2015-03-23 06:19:07 --> Router Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Output Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Security Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Input Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 06:19:08 --> Language Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Language Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Config Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Loader Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: url_helper
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: form_helper
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: language_helper
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: user_helper
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: date_helper
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 06:19:08 --> Database Driver Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Session Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: string_helper
DEBUG - 2015-03-23 06:19:08 --> Session routines successfully run
DEBUG - 2015-03-23 06:19:08 --> Controller Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Login MX_Controller Initialized
DEBUG - 2015-03-23 06:19:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 06:19:08 --> Email Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 06:19:08 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 06:19:08 --> Model Class Initialized
DEBUG - 2015-03-23 06:19:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 06:19:08 --> Model Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Form Validation Class Initialized
DEBUG - 2015-03-23 06:19:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-23 06:19:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-23 06:19:09 --> Config Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:19:09 --> URI Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Router Class Initialized
DEBUG - 2015-03-23 06:19:09 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 06:19:09 --> Output Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Security Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Input Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 06:19:09 --> Language Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Language Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Config Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Loader Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: url_helper
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: form_helper
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: language_helper
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: user_helper
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: date_helper
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 06:19:09 --> Database Driver Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Session Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: string_helper
DEBUG - 2015-03-23 06:19:09 --> Session routines successfully run
DEBUG - 2015-03-23 06:19:09 --> Controller Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 06:19:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 06:19:09 --> Email Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 06:19:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 06:19:09 --> Model Class Initialized
DEBUG - 2015-03-23 06:19:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 06:19:09 --> Model Class Initialized
DEBUG - 2015-03-23 06:19:09 --> Form Validation Class Initialized
DEBUG - 2015-03-23 06:19:10 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 06:19:10 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 06:19:10 --> Final output sent to browser
DEBUG - 2015-03-23 06:19:10 --> Total execution time: 0.6400
DEBUG - 2015-03-23 06:19:10 --> Config Class Initialized
DEBUG - 2015-03-23 06:19:10 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:19:10 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:19:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:19:10 --> URI Class Initialized
DEBUG - 2015-03-23 06:19:10 --> Router Class Initialized
ERROR - 2015-03-23 06:19:10 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 06:48:03 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:48:03 --> URI Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Router Class Initialized
DEBUG - 2015-03-23 06:48:03 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 06:48:03 --> Output Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Security Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Input Class Initialized
DEBUG - 2015-03-23 06:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 06:48:03 --> Language Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Language Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Loader Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: url_helper
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: form_helper
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: language_helper
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: user_helper
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: date_helper
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 06:48:04 --> Database Driver Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Session Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: string_helper
DEBUG - 2015-03-23 06:48:04 --> Session routines successfully run
DEBUG - 2015-03-23 06:48:04 --> Controller Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 06:48:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 06:48:04 --> Email Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 06:48:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 06:48:04 --> Model Class Initialized
DEBUG - 2015-03-23 06:48:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 06:48:04 --> Model Class Initialized
DEBUG - 2015-03-23 06:48:04 --> Form Validation Class Initialized
DEBUG - 2015-03-23 06:48:04 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
ERROR - 2015-03-23 06:48:04 --> Severity: Warning  --> include_once(user_menu): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 91
ERROR - 2015-03-23 06:48:04 --> Severity: Warning  --> include_once(): Failed opening 'user_menu' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 91
DEBUG - 2015-03-23 06:48:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 06:48:04 --> Final output sent to browser
DEBUG - 2015-03-23 06:48:04 --> Total execution time: 0.6690
DEBUG - 2015-03-23 06:48:08 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:08 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:48:08 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:48:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:48:08 --> URI Class Initialized
DEBUG - 2015-03-23 06:48:08 --> Router Class Initialized
ERROR - 2015-03-23 06:48:08 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 06:48:35 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:48:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:48:35 --> URI Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Router Class Initialized
DEBUG - 2015-03-23 06:48:35 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 06:48:35 --> Output Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Security Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Input Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 06:48:35 --> Language Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Language Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Loader Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: url_helper
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: form_helper
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: language_helper
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: user_helper
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: date_helper
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 06:48:35 --> Database Driver Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Session Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: string_helper
DEBUG - 2015-03-23 06:48:35 --> Session routines successfully run
DEBUG - 2015-03-23 06:48:35 --> Controller Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 06:48:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 06:48:35 --> Email Class Initialized
DEBUG - 2015-03-23 06:48:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 06:48:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 06:48:35 --> Model Class Initialized
DEBUG - 2015-03-23 06:48:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 06:48:35 --> Model Class Initialized
DEBUG - 2015-03-23 06:48:36 --> Form Validation Class Initialized
DEBUG - 2015-03-23 06:48:36 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 06:48:36 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 06:48:36 --> Final output sent to browser
DEBUG - 2015-03-23 06:48:36 --> Total execution time: 0.9291
DEBUG - 2015-03-23 06:48:37 --> Config Class Initialized
DEBUG - 2015-03-23 06:48:37 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:48:37 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:48:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:48:37 --> URI Class Initialized
DEBUG - 2015-03-23 06:48:37 --> Router Class Initialized
ERROR - 2015-03-23 06:48:37 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 06:51:17 --> Config Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:51:17 --> URI Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Router Class Initialized
DEBUG - 2015-03-23 06:51:17 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 06:51:17 --> Output Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Security Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Input Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 06:51:17 --> Language Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Language Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Config Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Loader Class Initialized
DEBUG - 2015-03-23 06:51:17 --> Helper loaded: url_helper
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: form_helper
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: language_helper
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: user_helper
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: date_helper
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 06:51:18 --> Database Driver Class Initialized
DEBUG - 2015-03-23 06:51:18 --> Session Class Initialized
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: string_helper
DEBUG - 2015-03-23 06:51:18 --> Session routines successfully run
DEBUG - 2015-03-23 06:51:18 --> Controller Class Initialized
DEBUG - 2015-03-23 06:51:18 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 06:51:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 06:51:18 --> Email Class Initialized
DEBUG - 2015-03-23 06:51:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 06:51:18 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 06:51:18 --> Model Class Initialized
DEBUG - 2015-03-23 06:51:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 06:51:18 --> Model Class Initialized
DEBUG - 2015-03-23 06:51:18 --> Form Validation Class Initialized
DEBUG - 2015-03-23 06:51:18 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 06:51:18 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 06:51:18 --> Final output sent to browser
DEBUG - 2015-03-23 06:51:18 --> Total execution time: 0.5920
DEBUG - 2015-03-23 06:51:19 --> Config Class Initialized
DEBUG - 2015-03-23 06:51:19 --> Hooks Class Initialized
DEBUG - 2015-03-23 06:51:19 --> Utf8 Class Initialized
DEBUG - 2015-03-23 06:51:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 06:51:19 --> URI Class Initialized
DEBUG - 2015-03-23 06:51:19 --> Router Class Initialized
ERROR - 2015-03-23 06:51:19 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 09:22:46 --> Config Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:22:46 --> URI Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Router Class Initialized
DEBUG - 2015-03-23 09:22:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 09:22:46 --> Output Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Security Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Input Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:22:46 --> Language Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Language Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Config Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Loader Class Initialized
DEBUG - 2015-03-23 09:22:46 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:22:47 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:22:47 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:22:47 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:22:47 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:22:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:22:47 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:22:48 --> Session Class Initialized
DEBUG - 2015-03-23 09:22:48 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:22:48 --> A session cookie was not found.
DEBUG - 2015-03-23 09:22:48 --> Session routines successfully run
DEBUG - 2015-03-23 09:22:48 --> Controller Class Initialized
DEBUG - 2015-03-23 09:22:48 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 09:22:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:22:48 --> Email Class Initialized
DEBUG - 2015-03-23 09:22:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:22:48 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:22:48 --> Model Class Initialized
DEBUG - 2015-03-23 09:22:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:22:48 --> Model Class Initialized
DEBUG - 2015-03-23 09:22:48 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Config Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:22:49 --> URI Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Router Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Output Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Security Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Input Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:22:49 --> Language Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Language Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Config Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Loader Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:22:49 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Session Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:22:49 --> Session routines successfully run
DEBUG - 2015-03-23 09:22:49 --> Controller Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Login MX_Controller Initialized
DEBUG - 2015-03-23 09:22:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:22:49 --> Email Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:22:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:22:49 --> Model Class Initialized
DEBUG - 2015-03-23 09:22:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:22:49 --> Model Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:22:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-23 09:22:49 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-23 09:22:49 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-23 09:22:49 --> Final output sent to browser
DEBUG - 2015-03-23 09:22:49 --> Total execution time: 0.6740
DEBUG - 2015-03-23 09:23:12 --> Config Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:23:12 --> URI Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Router Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Output Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Security Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Input Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:23:12 --> Language Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Language Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Config Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Loader Class Initialized
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:23:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:23:13 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Session Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:23:13 --> Session routines successfully run
DEBUG - 2015-03-23 09:23:13 --> Controller Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Login MX_Controller Initialized
DEBUG - 2015-03-23 09:23:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:23:13 --> Email Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:23:13 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:23:13 --> Model Class Initialized
DEBUG - 2015-03-23 09:23:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:23:13 --> Model Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:23:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-23 09:23:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-23 09:23:14 --> Config Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:23:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:23:14 --> URI Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Router Class Initialized
DEBUG - 2015-03-23 09:23:14 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 09:23:14 --> Output Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Security Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Input Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:23:14 --> Language Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Language Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Config Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Loader Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:23:14 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Session Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:23:14 --> Session routines successfully run
DEBUG - 2015-03-23 09:23:14 --> Controller Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 09:23:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:23:14 --> Email Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:23:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:23:14 --> Model Class Initialized
DEBUG - 2015-03-23 09:23:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:23:14 --> Model Class Initialized
DEBUG - 2015-03-23 09:23:14 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:23:14 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 09:23:14 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 09:23:14 --> Final output sent to browser
DEBUG - 2015-03-23 09:23:14 --> Total execution time: 0.6460
DEBUG - 2015-03-23 09:23:15 --> Config Class Initialized
DEBUG - 2015-03-23 09:23:15 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:23:15 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:23:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:23:15 --> URI Class Initialized
DEBUG - 2015-03-23 09:23:15 --> Router Class Initialized
ERROR - 2015-03-23 09:23:15 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 09:24:42 --> Config Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:24:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:24:42 --> URI Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Router Class Initialized
DEBUG - 2015-03-23 09:24:42 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 09:24:42 --> Output Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Security Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Input Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:24:42 --> Language Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Language Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Config Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Loader Class Initialized
DEBUG - 2015-03-23 09:24:42 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:24:42 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:24:43 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:24:43 --> Session Class Initialized
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:24:43 --> Session routines successfully run
DEBUG - 2015-03-23 09:24:43 --> Controller Class Initialized
DEBUG - 2015-03-23 09:24:43 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 09:24:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:24:43 --> Email Class Initialized
DEBUG - 2015-03-23 09:24:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:24:43 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:24:43 --> Model Class Initialized
DEBUG - 2015-03-23 09:24:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:24:43 --> Model Class Initialized
DEBUG - 2015-03-23 09:24:43 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:24:43 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 09:24:43 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 09:24:43 --> Final output sent to browser
DEBUG - 2015-03-23 09:24:43 --> Total execution time: 0.6470
DEBUG - 2015-03-23 09:24:45 --> Config Class Initialized
DEBUG - 2015-03-23 09:24:45 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:24:45 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:24:45 --> URI Class Initialized
DEBUG - 2015-03-23 09:24:45 --> Router Class Initialized
ERROR - 2015-03-23 09:24:45 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 09:25:00 --> Config Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:25:00 --> URI Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Router Class Initialized
DEBUG - 2015-03-23 09:25:00 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 09:25:00 --> Output Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Security Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Input Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:25:00 --> Language Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Language Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Config Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Loader Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:25:00 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Session Class Initialized
DEBUG - 2015-03-23 09:25:00 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:25:00 --> Session routines successfully run
DEBUG - 2015-03-23 09:25:01 --> Controller Class Initialized
DEBUG - 2015-03-23 09:25:01 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 09:25:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:25:01 --> Email Class Initialized
DEBUG - 2015-03-23 09:25:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:25:01 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:25:01 --> Model Class Initialized
DEBUG - 2015-03-23 09:25:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:25:01 --> Model Class Initialized
DEBUG - 2015-03-23 09:25:01 --> Form Validation Class Initialized
ERROR - 2015-03-23 09:25:01 --> 404 Page Not Found --> customer/campaigns
DEBUG - 2015-03-23 09:25:03 --> Config Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:25:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:25:03 --> URI Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Router Class Initialized
DEBUG - 2015-03-23 09:25:03 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 09:25:03 --> Output Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Security Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Input Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 09:25:03 --> Language Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Language Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Config Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Loader Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: url_helper
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: form_helper
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: language_helper
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: user_helper
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: date_helper
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 09:25:03 --> Database Driver Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Session Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: string_helper
DEBUG - 2015-03-23 09:25:03 --> Session routines successfully run
DEBUG - 2015-03-23 09:25:03 --> Controller Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 09:25:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 09:25:03 --> Email Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 09:25:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 09:25:03 --> Model Class Initialized
DEBUG - 2015-03-23 09:25:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 09:25:03 --> Model Class Initialized
DEBUG - 2015-03-23 09:25:03 --> Form Validation Class Initialized
DEBUG - 2015-03-23 09:25:03 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-23 09:25:03 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-23 09:25:03 --> Final output sent to browser
DEBUG - 2015-03-23 09:25:04 --> Total execution time: 0.6330
DEBUG - 2015-03-23 09:25:04 --> Config Class Initialized
DEBUG - 2015-03-23 09:25:04 --> Hooks Class Initialized
DEBUG - 2015-03-23 09:25:04 --> Utf8 Class Initialized
DEBUG - 2015-03-23 09:25:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 09:25:04 --> URI Class Initialized
DEBUG - 2015-03-23 09:25:04 --> Router Class Initialized
ERROR - 2015-03-23 09:25:04 --> 404 Page Not Found --> 
DEBUG - 2015-03-23 12:47:45 --> Config Class Initialized
DEBUG - 2015-03-23 12:47:45 --> Hooks Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Utf8 Class Initialized
DEBUG - 2015-03-23 12:47:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 12:47:46 --> URI Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Router Class Initialized
DEBUG - 2015-03-23 12:47:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-23 12:47:46 --> Output Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Security Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Input Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 12:47:46 --> Language Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Language Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Config Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Loader Class Initialized
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: url_helper
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: form_helper
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: language_helper
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: user_helper
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: date_helper
DEBUG - 2015-03-23 12:47:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 12:47:46 --> Database Driver Class Initialized
DEBUG - 2015-03-23 12:47:47 --> Session Class Initialized
DEBUG - 2015-03-23 12:47:47 --> Helper loaded: string_helper
DEBUG - 2015-03-23 12:47:47 --> A session cookie was not found.
DEBUG - 2015-03-23 12:47:47 --> Session routines successfully run
DEBUG - 2015-03-23 12:47:47 --> Controller Class Initialized
DEBUG - 2015-03-23 12:47:47 --> Customer MX_Controller Initialized
DEBUG - 2015-03-23 12:47:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 12:47:47 --> Email Class Initialized
DEBUG - 2015-03-23 12:47:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 12:47:47 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 12:47:47 --> Model Class Initialized
DEBUG - 2015-03-23 12:47:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 12:47:47 --> Model Class Initialized
DEBUG - 2015-03-23 12:47:48 --> Form Validation Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Config Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Hooks Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Utf8 Class Initialized
DEBUG - 2015-03-23 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-23 12:47:49 --> URI Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Router Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Output Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Security Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Input Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-23 12:47:49 --> Language Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Language Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Config Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Loader Class Initialized
DEBUG - 2015-03-23 12:47:49 --> Helper loaded: url_helper
DEBUG - 2015-03-23 12:47:49 --> Helper loaded: form_helper
DEBUG - 2015-03-23 12:47:49 --> Helper loaded: language_helper
DEBUG - 2015-03-23 12:47:50 --> Helper loaded: user_helper
DEBUG - 2015-03-23 12:47:50 --> Helper loaded: date_helper
DEBUG - 2015-03-23 12:47:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-23 12:47:50 --> Database Driver Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Session Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Helper loaded: string_helper
DEBUG - 2015-03-23 12:47:51 --> Session routines successfully run
DEBUG - 2015-03-23 12:47:51 --> Controller Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Login MX_Controller Initialized
DEBUG - 2015-03-23 12:47:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-23 12:47:51 --> Email Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-23 12:47:51 --> Helper loaded: cookie_helper
DEBUG - 2015-03-23 12:47:51 --> Model Class Initialized
DEBUG - 2015-03-23 12:47:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-23 12:47:51 --> Model Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Form Validation Class Initialized
DEBUG - 2015-03-23 12:47:51 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-23 12:47:51 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-23 12:47:51 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-23 12:47:51 --> Final output sent to browser
DEBUG - 2015-03-23 12:47:51 --> Total execution time: 2.4651
