<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-24 05:27:46 --> Config Class Initialized
DEBUG - 2015-03-24 05:27:46 --> Hooks Class Initialized
DEBUG - 2015-03-24 05:27:46 --> Utf8 Class Initialized
DEBUG - 2015-03-24 05:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-24 05:27:46 --> URI Class Initialized
DEBUG - 2015-03-24 05:27:46 --> Router Class Initialized
DEBUG - 2015-03-24 05:27:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-24 05:27:46 --> Output Class Initialized
DEBUG - 2015-03-24 05:27:46 --> Security Class Initialized
DEBUG - 2015-03-24 05:27:46 --> Input Class Initialized
DEBUG - 2015-03-24 05:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-24 05:27:47 --> Language Class Initialized
DEBUG - 2015-03-24 05:27:47 --> Language Class Initialized
DEBUG - 2015-03-24 05:27:47 --> Config Class Initialized
DEBUG - 2015-03-24 05:27:47 --> Loader Class Initialized
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: url_helper
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: form_helper
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: language_helper
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: user_helper
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: date_helper
DEBUG - 2015-03-24 05:27:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-24 05:27:47 --> Database Driver Class Initialized
DEBUG - 2015-03-24 05:27:48 --> Session Class Initialized
DEBUG - 2015-03-24 05:27:48 --> Helper loaded: string_helper
DEBUG - 2015-03-24 05:27:48 --> A session cookie was not found.
DEBUG - 2015-03-24 05:27:48 --> Session routines successfully run
DEBUG - 2015-03-24 05:27:48 --> Controller Class Initialized
DEBUG - 2015-03-24 05:27:48 --> User MX_Controller Initialized
DEBUG - 2015-03-24 05:27:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-24 05:27:49 --> Email Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-24 05:27:49 --> Model Class Initialized
DEBUG - 2015-03-24 05:27:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-24 05:27:49 --> Model Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Form Validation Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Config Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Hooks Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Utf8 Class Initialized
DEBUG - 2015-03-24 05:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-24 05:27:49 --> URI Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Router Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Output Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Security Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Input Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-24 05:27:49 --> Language Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Language Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Config Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Loader Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: url_helper
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: form_helper
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: language_helper
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: user_helper
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: date_helper
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-24 05:27:49 --> Database Driver Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Session Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Helper loaded: string_helper
DEBUG - 2015-03-24 05:27:49 --> Session routines successfully run
DEBUG - 2015-03-24 05:27:49 --> Controller Class Initialized
DEBUG - 2015-03-24 05:27:49 --> Login MX_Controller Initialized
DEBUG - 2015-03-24 05:27:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-24 05:27:50 --> Email Class Initialized
DEBUG - 2015-03-24 05:27:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-24 05:27:50 --> Helper loaded: cookie_helper
DEBUG - 2015-03-24 05:27:50 --> Model Class Initialized
DEBUG - 2015-03-24 05:27:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-24 05:27:50 --> Model Class Initialized
DEBUG - 2015-03-24 05:27:50 --> Form Validation Class Initialized
DEBUG - 2015-03-24 05:27:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-24 05:27:50 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-24 05:27:50 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-24 05:27:50 --> Final output sent to browser
DEBUG - 2015-03-24 05:27:50 --> Total execution time: 0.7350
