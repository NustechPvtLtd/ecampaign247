<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-25 04:38:50 --> Config Class Initialized
DEBUG - 2015-03-25 04:38:50 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:38:51 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:38:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:38:51 --> URI Class Initialized
DEBUG - 2015-03-25 04:38:51 --> Router Class Initialized
DEBUG - 2015-03-25 04:38:51 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-25 04:38:51 --> Output Class Initialized
DEBUG - 2015-03-25 04:38:51 --> Security Class Initialized
DEBUG - 2015-03-25 04:38:51 --> Input Class Initialized
DEBUG - 2015-03-25 04:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 04:38:51 --> Language Class Initialized
DEBUG - 2015-03-25 04:38:52 --> Language Class Initialized
DEBUG - 2015-03-25 04:38:52 --> Config Class Initialized
DEBUG - 2015-03-25 04:38:52 --> Loader Class Initialized
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: url_helper
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: form_helper
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: language_helper
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: user_helper
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: date_helper
DEBUG - 2015-03-25 04:38:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 04:38:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 04:38:54 --> Database Driver Class Initialized
DEBUG - 2015-03-25 04:38:55 --> Session Class Initialized
DEBUG - 2015-03-25 04:38:55 --> Helper loaded: string_helper
DEBUG - 2015-03-25 04:38:55 --> A session cookie was not found.
DEBUG - 2015-03-25 04:38:55 --> Session routines successfully run
DEBUG - 2015-03-25 04:38:55 --> Controller Class Initialized
DEBUG - 2015-03-25 04:38:55 --> User MX_Controller Initialized
DEBUG - 2015-03-25 04:38:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 04:38:56 --> Email Class Initialized
DEBUG - 2015-03-25 04:38:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 04:38:56 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 04:38:56 --> Model Class Initialized
DEBUG - 2015-03-25 04:38:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 04:38:56 --> Model Class Initialized
DEBUG - 2015-03-25 04:38:56 --> Form Validation Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Config Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:38:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:38:57 --> URI Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Router Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Output Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Security Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Input Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 04:38:57 --> Language Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Language Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Config Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Loader Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: url_helper
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: form_helper
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: language_helper
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: user_helper
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: date_helper
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 04:38:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 04:38:57 --> Database Driver Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Session Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: string_helper
DEBUG - 2015-03-25 04:38:57 --> Session routines successfully run
DEBUG - 2015-03-25 04:38:57 --> Controller Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 04:38:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 04:38:57 --> Email Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 04:38:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 04:38:57 --> Model Class Initialized
DEBUG - 2015-03-25 04:38:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 04:38:57 --> Model Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Form Validation Class Initialized
DEBUG - 2015-03-25 04:38:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 04:38:57 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-25 04:38:58 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-25 04:38:58 --> Final output sent to browser
DEBUG - 2015-03-25 04:38:58 --> Total execution time: 1.0210
DEBUG - 2015-03-25 04:57:44 --> Config Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:57:44 --> URI Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Router Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Output Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Security Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Input Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 04:57:44 --> Language Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Language Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Config Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Loader Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: url_helper
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: form_helper
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: language_helper
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: user_helper
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: date_helper
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 04:57:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 04:57:44 --> Database Driver Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Session Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: string_helper
DEBUG - 2015-03-25 04:57:44 --> Session routines successfully run
DEBUG - 2015-03-25 04:57:44 --> Controller Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 04:57:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 04:57:44 --> Email Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 04:57:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 04:57:44 --> Model Class Initialized
DEBUG - 2015-03-25 04:57:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 04:57:44 --> Model Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Form Validation Class Initialized
DEBUG - 2015-03-25 04:57:44 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 04:57:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-25 04:57:45 --> Config Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:57:45 --> URI Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Router Class Initialized
DEBUG - 2015-03-25 04:57:45 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-25 04:57:45 --> Output Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Security Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Input Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 04:57:45 --> Language Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Language Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Config Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Loader Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: url_helper
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: form_helper
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: language_helper
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: user_helper
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: date_helper
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 04:57:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 04:57:45 --> Database Driver Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Session Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: string_helper
DEBUG - 2015-03-25 04:57:45 --> Session routines successfully run
DEBUG - 2015-03-25 04:57:45 --> Controller Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Customer MX_Controller Initialized
DEBUG - 2015-03-25 04:57:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 04:57:45 --> Email Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 04:57:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 04:57:45 --> Model Class Initialized
DEBUG - 2015-03-25 04:57:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 04:57:45 --> Model Class Initialized
DEBUG - 2015-03-25 04:57:45 --> Form Validation Class Initialized
DEBUG - 2015-03-25 04:57:45 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-25 04:57:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-25 04:57:46 --> Final output sent to browser
DEBUG - 2015-03-25 04:57:46 --> Total execution time: 0.7460
DEBUG - 2015-03-25 04:57:46 --> Config Class Initialized
DEBUG - 2015-03-25 04:57:46 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:57:46 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:57:46 --> URI Class Initialized
DEBUG - 2015-03-25 04:57:46 --> Router Class Initialized
ERROR - 2015-03-25 04:57:46 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 04:58:39 --> Config Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Hooks Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Utf8 Class Initialized
DEBUG - 2015-03-25 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 04:58:39 --> URI Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Router Class Initialized
DEBUG - 2015-03-25 04:58:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 04:58:39 --> Output Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Security Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Input Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 04:58:39 --> Language Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Language Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Config Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Loader Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: url_helper
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: form_helper
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: language_helper
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: user_helper
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: date_helper
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 04:58:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 04:58:39 --> Database Driver Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Session Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: string_helper
DEBUG - 2015-03-25 04:58:39 --> Session routines successfully run
DEBUG - 2015-03-25 04:58:39 --> Controller Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 04:58:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 04:58:39 --> Email Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 04:58:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 04:58:39 --> Model Class Initialized
DEBUG - 2015-03-25 04:58:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 04:58:39 --> Model Class Initialized
DEBUG - 2015-03-25 04:58:39 --> Form Validation Class Initialized
DEBUG - 2015-03-25 04:58:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 04:58:39 --> Model Class Initialized
DEBUG - 2015-03-25 04:58:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 04:58:39 --> Model Class Initialized
DEBUG - 2015-03-25 04:58:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 04:58:39 --> Model Class Initialized
ERROR - 2015-03-25 04:58:39 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 04:58:39 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 13
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 34
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 37
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 39
ERROR - 2015-03-25 04:58:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
DEBUG - 2015-03-25 05:07:59 --> Config Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:07:59 --> URI Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Router Class Initialized
DEBUG - 2015-03-25 05:07:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:07:59 --> Output Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Security Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Input Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:07:59 --> Language Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Language Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Config Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Loader Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:07:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:07:59 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Session Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:07:59 --> Session routines successfully run
DEBUG - 2015-03-25 05:07:59 --> Controller Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:07:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:07:59 --> Email Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:07:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:07:59 --> Model Class Initialized
DEBUG - 2015-03-25 05:07:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:07:59 --> Model Class Initialized
DEBUG - 2015-03-25 05:07:59 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:07:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:07:59 --> Model Class Initialized
DEBUG - 2015-03-25 05:07:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:07:59 --> Model Class Initialized
DEBUG - 2015-03-25 05:07:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:07:59 --> Model Class Initialized
ERROR - 2015-03-25 05:07:59 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 05:07:59 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 13
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 34
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 37
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Indirect modification of overloaded property Sites::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 39
ERROR - 2015-03-25 05:08:00 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
DEBUG - 2015-03-25 05:08:29 --> Config Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:08:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:08:29 --> URI Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Router Class Initialized
DEBUG - 2015-03-25 05:08:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:08:29 --> Output Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Security Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Input Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:08:29 --> Language Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Language Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Config Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Loader Class Initialized
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:08:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:08:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:08:30 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:08:30 --> Session Class Initialized
DEBUG - 2015-03-25 05:08:30 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:08:30 --> Session routines successfully run
DEBUG - 2015-03-25 05:08:30 --> Controller Class Initialized
DEBUG - 2015-03-25 05:08:30 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:08:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:08:30 --> Email Class Initialized
DEBUG - 2015-03-25 05:08:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:08:30 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:08:30 --> Model Class Initialized
DEBUG - 2015-03-25 05:08:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:08:30 --> Model Class Initialized
DEBUG - 2015-03-25 05:08:30 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:08:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:08:30 --> Model Class Initialized
DEBUG - 2015-03-25 05:08:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:08:30 --> Model Class Initialized
DEBUG - 2015-03-25 05:08:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:08:30 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Config Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:09:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:09:43 --> URI Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Router Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:09:43 --> Output Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Security Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Input Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:09:43 --> Language Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Language Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Config Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Loader Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:09:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:09:43 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Session Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:09:43 --> Session routines successfully run
DEBUG - 2015-03-25 05:09:43 --> Controller Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:09:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:09:43 --> Email Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:09:43 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:09:43 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:09:43 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:09:43 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:09:43 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:09:43 --> Model Class Initialized
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
ERROR - 2015-03-25 05:09:43 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 5
ERROR - 2015-03-25 05:09:43 --> Severity: Notice  --> Undefined variable: pageMetaDescription C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 7
DEBUG - 2015-03-25 05:09:43 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-25 05:09:43 --> Final output sent to browser
DEBUG - 2015-03-25 05:09:43 --> Total execution time: 0.8790
DEBUG - 2015-03-25 05:09:46 --> Config Class Initialized
DEBUG - 2015-03-25 05:09:46 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:09:46 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:09:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:09:46 --> URI Class Initialized
DEBUG - 2015-03-25 05:09:46 --> Router Class Initialized
ERROR - 2015-03-25 05:09:46 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 05:53:59 --> Config Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:53:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:53:59 --> URI Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Router Class Initialized
DEBUG - 2015-03-25 05:53:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:53:59 --> Output Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Security Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Input Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:53:59 --> Language Class Initialized
DEBUG - 2015-03-25 05:53:59 --> Language Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Config Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Loader Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:54:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:54:00 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Session Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:54:00 --> Session routines successfully run
DEBUG - 2015-03-25 05:54:00 --> Controller Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:54:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:54:00 --> Email Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:54:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:54:00 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:54:00 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:00 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:54:00 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:54:00 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:54:00 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
ERROR - 2015-03-25 05:54:00 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 5
ERROR - 2015-03-25 05:54:00 --> Severity: Notice  --> Undefined variable: pageMetaDescription C:\xampp\htdocs\ecampaign247\application\views\templates\main.php 7
DEBUG - 2015-03-25 05:54:00 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-25 05:54:00 --> Final output sent to browser
DEBUG - 2015-03-25 05:54:00 --> Total execution time: 1.1331
DEBUG - 2015-03-25 05:54:01 --> Config Class Initialized
DEBUG - 2015-03-25 05:54:01 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:54:01 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:54:01 --> URI Class Initialized
DEBUG - 2015-03-25 05:54:01 --> Router Class Initialized
ERROR - 2015-03-25 05:54:01 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 05:54:49 --> Config Class Initialized
DEBUG - 2015-03-25 05:54:49 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:54:49 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:54:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:54:49 --> URI Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Router Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:54:50 --> Output Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Security Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Input Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:54:50 --> Language Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Language Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Config Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Loader Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:54:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:54:50 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Session Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:54:50 --> Session routines successfully run
DEBUG - 2015-03-25 05:54:50 --> Controller Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:54:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:54:50 --> Email Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:54:50 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:54:50 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:54:50 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:50 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:54:50 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:54:50 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:54:50 --> Model Class Initialized
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 05:54:50 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 05:54:50 --> Final output sent to browser
DEBUG - 2015-03-25 05:54:51 --> Total execution time: 1.1711
DEBUG - 2015-03-25 05:54:51 --> Config Class Initialized
DEBUG - 2015-03-25 05:54:51 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:54:51 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:54:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:54:51 --> URI Class Initialized
DEBUG - 2015-03-25 05:54:51 --> Router Class Initialized
ERROR - 2015-03-25 05:54:51 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 05:55:29 --> Config Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:55:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:55:29 --> URI Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Router Class Initialized
DEBUG - 2015-03-25 05:55:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:55:29 --> Output Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Security Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Input Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:55:29 --> Language Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Language Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Config Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Loader Class Initialized
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:55:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:55:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:55:29 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:55:30 --> Session Class Initialized
DEBUG - 2015-03-25 05:55:30 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:55:30 --> Session routines successfully run
DEBUG - 2015-03-25 05:55:30 --> Controller Class Initialized
DEBUG - 2015-03-25 05:55:30 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:55:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:55:31 --> Email Class Initialized
DEBUG - 2015-03-25 05:55:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:55:31 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:55:31 --> Model Class Initialized
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:55:31 --> Model Class Initialized
DEBUG - 2015-03-25 05:55:31 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:55:31 --> Model Class Initialized
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:55:31 --> Model Class Initialized
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:55:31 --> Model Class Initialized
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 05:55:31 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 05:55:31 --> Final output sent to browser
DEBUG - 2015-03-25 05:55:31 --> Total execution time: 1.8481
DEBUG - 2015-03-25 05:55:32 --> Config Class Initialized
DEBUG - 2015-03-25 05:55:32 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:55:32 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:55:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:55:32 --> URI Class Initialized
DEBUG - 2015-03-25 05:55:32 --> Router Class Initialized
ERROR - 2015-03-25 05:55:32 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 05:57:17 --> Config Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:57:17 --> URI Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Router Class Initialized
DEBUG - 2015-03-25 05:57:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:57:17 --> Output Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Security Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Input Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:57:17 --> Language Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Language Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Config Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Loader Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:57:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:57:17 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Session Class Initialized
DEBUG - 2015-03-25 05:57:17 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:57:17 --> Session routines successfully run
DEBUG - 2015-03-25 05:57:17 --> Controller Class Initialized
DEBUG - 2015-03-25 05:57:18 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:57:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:57:18 --> Email Class Initialized
DEBUG - 2015-03-25 05:57:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:57:18 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:57:18 --> Model Class Initialized
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:57:18 --> Model Class Initialized
DEBUG - 2015-03-25 05:57:18 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:57:18 --> Model Class Initialized
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:57:18 --> Model Class Initialized
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:57:18 --> Model Class Initialized
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 05:57:18 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 05:57:18 --> Final output sent to browser
DEBUG - 2015-03-25 05:57:18 --> Total execution time: 0.8590
DEBUG - 2015-03-25 05:57:19 --> Config Class Initialized
DEBUG - 2015-03-25 05:57:19 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:57:19 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:57:19 --> URI Class Initialized
DEBUG - 2015-03-25 05:57:19 --> Router Class Initialized
ERROR - 2015-03-25 05:57:19 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 05:58:09 --> Config Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:58:09 --> URI Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Router Class Initialized
DEBUG - 2015-03-25 05:58:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 05:58:09 --> Output Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Security Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Input Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 05:58:09 --> Language Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Language Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Config Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Loader Class Initialized
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: url_helper
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: form_helper
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: language_helper
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: user_helper
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: date_helper
DEBUG - 2015-03-25 05:58:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 05:58:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 05:58:09 --> Database Driver Class Initialized
DEBUG - 2015-03-25 05:58:10 --> Session Class Initialized
DEBUG - 2015-03-25 05:58:10 --> Helper loaded: string_helper
DEBUG - 2015-03-25 05:58:10 --> Session routines successfully run
DEBUG - 2015-03-25 05:58:10 --> Controller Class Initialized
DEBUG - 2015-03-25 05:58:10 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 05:58:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 05:58:10 --> Email Class Initialized
DEBUG - 2015-03-25 05:58:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 05:58:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 05:58:10 --> Model Class Initialized
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-03-25 05:58:11 --> Form Validation Class Initialized
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 05:58:11 --> Model Class Initialized
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 05:58:11 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 05:58:11 --> Final output sent to browser
DEBUG - 2015-03-25 05:58:11 --> Total execution time: 1.9070
DEBUG - 2015-03-25 05:58:15 --> Config Class Initialized
DEBUG - 2015-03-25 05:58:15 --> Hooks Class Initialized
DEBUG - 2015-03-25 05:58:15 --> Utf8 Class Initialized
DEBUG - 2015-03-25 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 05:58:15 --> URI Class Initialized
DEBUG - 2015-03-25 05:58:15 --> Router Class Initialized
ERROR - 2015-03-25 05:58:15 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 06:02:42 --> Config Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:02:42 --> URI Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Router Class Initialized
DEBUG - 2015-03-25 06:02:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:02:42 --> Output Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Security Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Input Class Initialized
DEBUG - 2015-03-25 06:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:02:43 --> Language Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Language Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Config Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Loader Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:02:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:02:43 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Session Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:02:43 --> Session routines successfully run
DEBUG - 2015-03-25 06:02:43 --> Controller Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:02:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:02:43 --> Email Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:02:43 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:02:43 --> Model Class Initialized
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:02:43 --> Model Class Initialized
DEBUG - 2015-03-25 06:02:43 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:02:43 --> Model Class Initialized
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:02:43 --> Model Class Initialized
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:02:43 --> Model Class Initialized
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 06:02:43 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 06:02:43 --> Final output sent to browser
DEBUG - 2015-03-25 06:02:43 --> Total execution time: 0.9760
DEBUG - 2015-03-25 06:05:53 --> Config Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:05:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:05:53 --> URI Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Router Class Initialized
DEBUG - 2015-03-25 06:05:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:05:53 --> Output Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Security Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Input Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:05:53 --> Language Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Language Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Config Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Loader Class Initialized
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:05:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:05:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:05:53 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:05:54 --> Session Class Initialized
DEBUG - 2015-03-25 06:05:54 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:05:54 --> Session routines successfully run
DEBUG - 2015-03-25 06:05:54 --> Controller Class Initialized
DEBUG - 2015-03-25 06:05:54 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:05:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:05:54 --> Email Class Initialized
DEBUG - 2015-03-25 06:05:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:05:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:05:54 --> Model Class Initialized
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:05:54 --> Model Class Initialized
DEBUG - 2015-03-25 06:05:54 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:05:54 --> Model Class Initialized
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:05:54 --> Model Class Initialized
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:05:54 --> Model Class Initialized
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 06:05:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 06:05:55 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 06:05:55 --> Final output sent to browser
DEBUG - 2015-03-25 06:05:55 --> Total execution time: 1.8940
DEBUG - 2015-03-25 06:20:28 --> Config Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:20:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:20:28 --> URI Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Router Class Initialized
DEBUG - 2015-03-25 06:20:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:20:28 --> Output Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Security Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Input Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:20:28 --> Language Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Language Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Config Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Loader Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:20:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:20:28 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Session Class Initialized
DEBUG - 2015-03-25 06:20:28 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:20:28 --> Session routines successfully run
DEBUG - 2015-03-25 06:20:28 --> Controller Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:20:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:20:29 --> Email Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:20:29 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:20:29 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:20:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:20:29 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:20:29 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:20:29 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Config Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:20:29 --> URI Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Router Class Initialized
DEBUG - 2015-03-25 06:20:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:20:29 --> Output Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Security Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Input Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:20:29 --> Language Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Language Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Config Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Loader Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:20:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:20:29 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Session Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:20:29 --> Session routines successfully run
DEBUG - 2015-03-25 06:20:29 --> Controller Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:20:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:20:29 --> Email Class Initialized
DEBUG - 2015-03-25 06:20:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:20:29 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:20:30 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:20:30 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:30 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:20:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:20:30 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:20:30 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:20:30 --> Model Class Initialized
DEBUG - 2015-03-25 06:20:30 --> Helper loaded: directory_helper
DEBUG - 2015-03-25 06:23:38 --> Config Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:23:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:23:38 --> URI Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Router Class Initialized
DEBUG - 2015-03-25 06:23:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:23:38 --> Output Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Security Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Input Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:23:38 --> Language Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Language Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Config Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Loader Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:23:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:23:38 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Session Class Initialized
DEBUG - 2015-03-25 06:23:38 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:23:38 --> Session routines successfully run
DEBUG - 2015-03-25 06:23:39 --> Controller Class Initialized
DEBUG - 2015-03-25 06:23:39 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:23:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:23:39 --> Email Class Initialized
DEBUG - 2015-03-25 06:23:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:23:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:23:39 --> Model Class Initialized
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:23:39 --> Model Class Initialized
DEBUG - 2015-03-25 06:23:39 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:23:39 --> Model Class Initialized
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:23:39 --> Model Class Initialized
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:23:39 --> Model Class Initialized
DEBUG - 2015-03-25 06:23:39 --> Helper loaded: directory_helper
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-25 06:23:39 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 06:23:39 --> Final output sent to browser
DEBUG - 2015-03-25 06:23:39 --> Total execution time: 1.1251
DEBUG - 2015-03-25 06:23:41 --> Config Class Initialized
DEBUG - 2015-03-25 06:23:41 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:23:41 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:23:41 --> URI Class Initialized
DEBUG - 2015-03-25 06:23:41 --> Router Class Initialized
ERROR - 2015-03-25 06:23:41 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 06:23:46 --> Config Class Initialized
DEBUG - 2015-03-25 06:23:46 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:23:46 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:23:46 --> URI Class Initialized
DEBUG - 2015-03-25 06:23:46 --> Router Class Initialized
ERROR - 2015-03-25 06:23:46 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 06:25:05 --> Config Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:25:05 --> URI Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Router Class Initialized
DEBUG - 2015-03-25 06:25:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 06:25:05 --> Output Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Security Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Input Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 06:25:05 --> Language Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Language Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Config Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Loader Class Initialized
DEBUG - 2015-03-25 06:25:05 --> Helper loaded: url_helper
DEBUG - 2015-03-25 06:25:05 --> Helper loaded: form_helper
DEBUG - 2015-03-25 06:25:05 --> Helper loaded: language_helper
DEBUG - 2015-03-25 06:25:05 --> Helper loaded: user_helper
DEBUG - 2015-03-25 06:25:06 --> Helper loaded: date_helper
DEBUG - 2015-03-25 06:25:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 06:25:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 06:25:06 --> Database Driver Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Session Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Helper loaded: string_helper
DEBUG - 2015-03-25 06:25:07 --> Session routines successfully run
DEBUG - 2015-03-25 06:25:07 --> Controller Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 06:25:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 06:25:07 --> Email Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 06:25:07 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 06:25:07 --> Model Class Initialized
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 06:25:07 --> Model Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Form Validation Class Initialized
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 06:25:07 --> Model Class Initialized
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 06:25:07 --> Model Class Initialized
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 06:25:07 --> Model Class Initialized
DEBUG - 2015-03-25 06:25:07 --> Helper loaded: directory_helper
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-25 06:25:07 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-25 06:25:08 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 06:25:08 --> Final output sent to browser
DEBUG - 2015-03-25 06:25:08 --> Total execution time: 2.4751
DEBUG - 2015-03-25 06:25:10 --> Config Class Initialized
DEBUG - 2015-03-25 06:25:10 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:25:11 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:25:11 --> URI Class Initialized
DEBUG - 2015-03-25 06:25:11 --> Router Class Initialized
ERROR - 2015-03-25 06:25:11 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 06:25:13 --> Config Class Initialized
DEBUG - 2015-03-25 06:25:13 --> Hooks Class Initialized
DEBUG - 2015-03-25 06:25:13 --> Utf8 Class Initialized
DEBUG - 2015-03-25 06:25:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 06:25:13 --> URI Class Initialized
DEBUG - 2015-03-25 06:25:13 --> Router Class Initialized
ERROR - 2015-03-25 06:25:13 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:31:35 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:31:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:31:35 --> URI Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Router Class Initialized
DEBUG - 2015-03-25 08:31:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 08:31:35 --> Output Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Security Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Input Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:31:35 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Loader Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:31:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:31:35 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Session Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: string_helper
ERROR - 2015-03-25 08:31:35 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-03-25 08:31:35 --> Session routines successfully run
DEBUG - 2015-03-25 08:31:35 --> Controller Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 08:31:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:31:35 --> Email Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:31:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:31:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:31:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:35 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:31:36 --> URI Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Router Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Output Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Security Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Input Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:31:36 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Loader Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:31:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:31:36 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Session Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:31:36 --> Session routines successfully run
DEBUG - 2015-03-25 08:31:36 --> Controller Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 08:31:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:31:36 --> Email Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:31:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:31:36 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:31:36 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:31:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 08:31:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-25 08:31:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-25 08:31:36 --> Final output sent to browser
DEBUG - 2015-03-25 08:31:37 --> Total execution time: 0.7220
DEBUG - 2015-03-25 08:31:52 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:52 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:31:52 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:31:52 --> URI Class Initialized
DEBUG - 2015-03-25 08:31:52 --> Router Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Output Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Security Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Input Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:31:53 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Loader Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:31:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:31:53 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Session Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:31:53 --> Session routines successfully run
DEBUG - 2015-03-25 08:31:53 --> Controller Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 08:31:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:31:53 --> Email Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:31:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:31:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:31:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:31:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 08:31:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-25 08:31:54 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:31:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:31:54 --> URI Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Router Class Initialized
DEBUG - 2015-03-25 08:31:54 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-25 08:31:54 --> Output Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Security Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Input Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:31:54 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Language Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Loader Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:31:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:31:54 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Session Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:31:54 --> Session routines successfully run
DEBUG - 2015-03-25 08:31:54 --> Controller Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Customer MX_Controller Initialized
DEBUG - 2015-03-25 08:31:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:31:54 --> Email Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:31:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:31:54 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:31:54 --> Model Class Initialized
DEBUG - 2015-03-25 08:31:54 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:31:54 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-25 08:31:54 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-25 08:31:54 --> Final output sent to browser
DEBUG - 2015-03-25 08:31:54 --> Total execution time: 0.6830
DEBUG - 2015-03-25 08:31:55 --> Config Class Initialized
DEBUG - 2015-03-25 08:31:55 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:31:55 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:31:55 --> URI Class Initialized
DEBUG - 2015-03-25 08:31:55 --> Router Class Initialized
ERROR - 2015-03-25 08:31:55 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:32:02 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:02 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:32:02 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:32:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:32:02 --> URI Class Initialized
DEBUG - 2015-03-25 08:32:02 --> Router Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 08:32:03 --> Output Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Security Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Input Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:32:03 --> Language Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Language Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Loader Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:32:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:32:03 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Session Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:32:03 --> Session routines successfully run
DEBUG - 2015-03-25 08:32:03 --> Controller Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 08:32:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:32:03 --> Email Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:32:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:32:03 --> Model Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:32:03 --> Model Class Initialized
DEBUG - 2015-03-25 08:32:03 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 08:32:03 --> Model Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 08:32:03 --> Model Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 08:32:03 --> Model Class Initialized
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 08:32:03 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 08:32:03 --> Final output sent to browser
DEBUG - 2015-03-25 08:32:03 --> Total execution time: 0.9961
DEBUG - 2015-03-25 08:32:04 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:32:04 --> URI Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Router Class Initialized
ERROR - 2015-03-25 08:32:04 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:32:04 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:32:04 --> URI Class Initialized
DEBUG - 2015-03-25 08:32:04 --> Router Class Initialized
ERROR - 2015-03-25 08:32:04 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:32:05 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:32:05 --> URI Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Config Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Router Class Initialized
DEBUG - 2015-03-25 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:32:05 --> URI Class Initialized
DEBUG - 2015-03-25 08:32:05 --> Router Class Initialized
ERROR - 2015-03-25 08:32:05 --> 404 Page Not Found --> 
ERROR - 2015-03-25 08:32:06 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:33:34 --> Config Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:33:34 --> URI Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Router Class Initialized
DEBUG - 2015-03-25 08:33:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 08:33:34 --> Output Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Security Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Input Class Initialized
DEBUG - 2015-03-25 08:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:33:34 --> Language Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Language Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Config Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Loader Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:33:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:33:35 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Session Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:33:35 --> Session routines successfully run
DEBUG - 2015-03-25 08:33:35 --> Controller Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 08:33:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:33:35 --> Email Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:33:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:33:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:33:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:33:35 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 08:33:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 08:33:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 08:33:35 --> Model Class Initialized
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 08:33:35 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 08:33:35 --> Final output sent to browser
DEBUG - 2015-03-25 08:33:35 --> Total execution time: 0.8720
DEBUG - 2015-03-25 08:33:53 --> Config Class Initialized
DEBUG - 2015-03-25 08:33:53 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:33:53 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:33:53 --> URI Class Initialized
DEBUG - 2015-03-25 08:33:53 --> Router Class Initialized
ERROR - 2015-03-25 08:33:53 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 08:36:53 --> Config Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:36:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:36:53 --> URI Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Router Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 08:36:53 --> Output Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Security Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Input Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 08:36:53 --> Language Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Language Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Config Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Loader Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: url_helper
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: form_helper
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: language_helper
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: user_helper
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: date_helper
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 08:36:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 08:36:53 --> Database Driver Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Session Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: string_helper
DEBUG - 2015-03-25 08:36:53 --> Session routines successfully run
DEBUG - 2015-03-25 08:36:53 --> Controller Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 08:36:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 08:36:53 --> Email Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 08:36:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 08:36:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 08:36:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:36:53 --> Form Validation Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 08:36:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 08:36:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 08:36:53 --> Model Class Initialized
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 08:36:53 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 08:36:54 --> Final output sent to browser
DEBUG - 2015-03-25 08:36:54 --> Total execution time: 0.9701
DEBUG - 2015-03-25 08:37:05 --> Config Class Initialized
DEBUG - 2015-03-25 08:37:05 --> Hooks Class Initialized
DEBUG - 2015-03-25 08:37:05 --> Utf8 Class Initialized
DEBUG - 2015-03-25 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 08:37:05 --> URI Class Initialized
DEBUG - 2015-03-25 08:37:05 --> Router Class Initialized
ERROR - 2015-03-25 08:37:05 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:22:19 --> Config Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:22:19 --> URI Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Router Class Initialized
DEBUG - 2015-03-25 09:22:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:22:19 --> Output Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Security Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Input Class Initialized
DEBUG - 2015-03-25 09:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:22:19 --> Language Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Language Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Config Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Loader Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:22:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:22:20 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Session Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:22:20 --> Session routines successfully run
DEBUG - 2015-03-25 09:22:20 --> Controller Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:22:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:22:20 --> Email Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:22:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:22:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:22:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:22:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:22:20 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:22:21 --> Model Class Initialized
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:22:21 --> Model Class Initialized
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:22:21 --> Model Class Initialized
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:22:21 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:22:21 --> Final output sent to browser
DEBUG - 2015-03-25 09:22:21 --> Total execution time: 2.2451
DEBUG - 2015-03-25 09:22:21 --> Config Class Initialized
DEBUG - 2015-03-25 09:22:21 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:22:21 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:22:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:22:21 --> URI Class Initialized
DEBUG - 2015-03-25 09:22:21 --> Router Class Initialized
ERROR - 2015-03-25 09:22:21 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:22:22 --> Config Class Initialized
DEBUG - 2015-03-25 09:22:22 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:22:22 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:22:22 --> URI Class Initialized
DEBUG - 2015-03-25 09:22:22 --> Router Class Initialized
ERROR - 2015-03-25 09:22:22 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:23:20 --> Config Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:23:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:23:20 --> URI Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Router Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:23:20 --> Output Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Security Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Input Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:23:20 --> Language Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Language Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Config Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Loader Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:23:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:23:20 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Session Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:23:20 --> Session routines successfully run
DEBUG - 2015-03-25 09:23:20 --> Controller Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:23:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:23:20 --> Email Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:23:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:23:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:23:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:23:20 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:23:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:23:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:23:20 --> Model Class Initialized
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:23:20 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:23:20 --> Final output sent to browser
DEBUG - 2015-03-25 09:23:20 --> Total execution time: 0.8791
DEBUG - 2015-03-25 09:23:23 --> Config Class Initialized
DEBUG - 2015-03-25 09:23:23 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:23:23 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:23:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:23:23 --> URI Class Initialized
DEBUG - 2015-03-25 09:23:23 --> Router Class Initialized
ERROR - 2015-03-25 09:23:23 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:32:47 --> Config Class Initialized
DEBUG - 2015-03-25 09:32:47 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:32:47 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:32:47 --> URI Class Initialized
DEBUG - 2015-03-25 09:32:47 --> Router Class Initialized
DEBUG - 2015-03-25 09:32:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:32:47 --> Output Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Security Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Input Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:32:48 --> Language Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Language Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Config Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Loader Class Initialized
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:32:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:32:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:32:48 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:32:49 --> Session Class Initialized
DEBUG - 2015-03-25 09:32:49 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:32:49 --> Session routines successfully run
DEBUG - 2015-03-25 09:32:49 --> Controller Class Initialized
DEBUG - 2015-03-25 09:32:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:32:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:32:49 --> Email Class Initialized
DEBUG - 2015-03-25 09:32:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:32:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:32:49 --> Model Class Initialized
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:32:49 --> Model Class Initialized
DEBUG - 2015-03-25 09:32:49 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:32:49 --> Model Class Initialized
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:32:49 --> Model Class Initialized
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:32:49 --> Model Class Initialized
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:32:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:32:50 --> Final output sent to browser
DEBUG - 2015-03-25 09:32:50 --> Total execution time: 2.1081
DEBUG - 2015-03-25 09:33:47 --> Config Class Initialized
DEBUG - 2015-03-25 09:33:47 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:33:47 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:33:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:33:47 --> URI Class Initialized
DEBUG - 2015-03-25 09:33:47 --> Router Class Initialized
ERROR - 2015-03-25 09:33:47 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:38:04 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:04 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Router Class Initialized
DEBUG - 2015-03-25 09:38:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:38:04 --> Output Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Security Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Input Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:38:04 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Loader Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:38:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:38:04 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Session Class Initialized
DEBUG - 2015-03-25 09:38:04 --> Helper loaded: string_helper
ERROR - 2015-03-25 09:38:04 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-03-25 09:38:04 --> Session routines successfully run
DEBUG - 2015-03-25 09:38:04 --> Controller Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:38:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:38:05 --> Email Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:38:05 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:38:05 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:05 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Router Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Output Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Security Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Input Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:38:05 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Loader Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:38:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:38:05 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Session Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:38:05 --> Session routines successfully run
DEBUG - 2015-03-25 09:38:05 --> Controller Class Initialized
DEBUG - 2015-03-25 09:38:05 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 09:38:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:38:05 --> Email Class Initialized
DEBUG - 2015-03-25 09:38:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:38:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:38:06 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:38:06 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:06 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:38:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 09:38:06 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-25 09:38:06 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-25 09:38:06 --> Final output sent to browser
DEBUG - 2015-03-25 09:38:06 --> Total execution time: 0.7020
DEBUG - 2015-03-25 09:38:28 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:28 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Router Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Output Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Security Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Input Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:38:28 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Loader Class Initialized
DEBUG - 2015-03-25 09:38:28 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:38:28 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:38:28 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:38:28 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:38:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:38:29 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Session Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:38:29 --> Session routines successfully run
DEBUG - 2015-03-25 09:38:29 --> Controller Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Login MX_Controller Initialized
DEBUG - 2015-03-25 09:38:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:38:29 --> Email Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:38:29 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:38:29 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-25 09:38:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-25 09:38:29 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:29 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Router Class Initialized
DEBUG - 2015-03-25 09:38:29 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-25 09:38:29 --> Output Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Security Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Input Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:38:29 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Loader Class Initialized
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:38:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:38:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:38:29 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Session Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:38:30 --> Session routines successfully run
DEBUG - 2015-03-25 09:38:30 --> Controller Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Customer MX_Controller Initialized
DEBUG - 2015-03-25 09:38:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:38:30 --> Email Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:38:30 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:38:30 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:38:30 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:38:30 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-25 09:38:30 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-25 09:38:30 --> Final output sent to browser
DEBUG - 2015-03-25 09:38:30 --> Total execution time: 0.7370
DEBUG - 2015-03-25 09:38:30 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:30 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:30 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:30 --> Router Class Initialized
ERROR - 2015-03-25 09:38:30 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:38:37 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:37 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Router Class Initialized
DEBUG - 2015-03-25 09:38:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:38:37 --> Output Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Security Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Input Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:38:37 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Language Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Loader Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:38:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:38:37 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Session Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:38:37 --> Session routines successfully run
DEBUG - 2015-03-25 09:38:37 --> Controller Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:38:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:38:37 --> Email Class Initialized
DEBUG - 2015-03-25 09:38:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:38:37 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:38:37 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:38:37 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:38 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:38:38 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:38:38 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:38:38 --> Model Class Initialized
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:38:38 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:38:38 --> Final output sent to browser
DEBUG - 2015-03-25 09:38:38 --> Total execution time: 0.9721
DEBUG - 2015-03-25 09:38:38 --> Config Class Initialized
DEBUG - 2015-03-25 09:38:38 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:38:38 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:38:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:38:38 --> URI Class Initialized
DEBUG - 2015-03-25 09:38:38 --> Router Class Initialized
ERROR - 2015-03-25 09:38:38 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:44:21 --> Config Class Initialized
DEBUG - 2015-03-25 09:44:21 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:44:21 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:44:22 --> URI Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Router Class Initialized
DEBUG - 2015-03-25 09:44:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:44:22 --> Output Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Security Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Input Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:44:22 --> Language Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Language Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Config Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Loader Class Initialized
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:44:22 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:44:23 --> Session Class Initialized
DEBUG - 2015-03-25 09:44:23 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:44:23 --> Session routines successfully run
DEBUG - 2015-03-25 09:44:23 --> Controller Class Initialized
DEBUG - 2015-03-25 09:44:23 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:44:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:44:23 --> Email Class Initialized
DEBUG - 2015-03-25 09:44:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:44:23 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:44:23 --> Model Class Initialized
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:44:23 --> Model Class Initialized
DEBUG - 2015-03-25 09:44:23 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:44:23 --> Model Class Initialized
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:44:23 --> Model Class Initialized
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:44:23 --> Model Class Initialized
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:44:23 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:44:23 --> Final output sent to browser
DEBUG - 2015-03-25 09:44:23 --> Total execution time: 1.6921
DEBUG - 2015-03-25 09:44:27 --> Config Class Initialized
DEBUG - 2015-03-25 09:44:27 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:44:27 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:44:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:44:27 --> URI Class Initialized
DEBUG - 2015-03-25 09:44:27 --> Router Class Initialized
ERROR - 2015-03-25 09:44:27 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:48:25 --> Config Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:48:25 --> URI Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Router Class Initialized
DEBUG - 2015-03-25 09:48:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:48:25 --> Output Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Security Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Input Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:48:25 --> Language Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Language Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Config Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Loader Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:48:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:48:25 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Session Class Initialized
DEBUG - 2015-03-25 09:48:25 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:48:25 --> Session routines successfully run
DEBUG - 2015-03-25 09:48:25 --> Controller Class Initialized
DEBUG - 2015-03-25 09:48:26 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:48:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:48:26 --> Email Class Initialized
DEBUG - 2015-03-25 09:48:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:48:26 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:48:26 --> Model Class Initialized
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:48:26 --> Model Class Initialized
DEBUG - 2015-03-25 09:48:26 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:48:26 --> Model Class Initialized
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:48:26 --> Model Class Initialized
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:48:26 --> Model Class Initialized
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:48:26 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:48:26 --> Final output sent to browser
DEBUG - 2015-03-25 09:48:26 --> Total execution time: 0.7330
DEBUG - 2015-03-25 09:48:29 --> Config Class Initialized
DEBUG - 2015-03-25 09:48:29 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:48:29 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:48:29 --> URI Class Initialized
DEBUG - 2015-03-25 09:48:29 --> Router Class Initialized
ERROR - 2015-03-25 09:48:29 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:51:22 --> Config Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:51:22 --> URI Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Router Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:51:22 --> Output Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Security Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Input Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:51:22 --> Language Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Language Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Config Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Loader Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:51:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:51:22 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Session Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:51:22 --> Session routines successfully run
DEBUG - 2015-03-25 09:51:22 --> Controller Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:51:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:51:22 --> Email Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:51:22 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:51:22 --> Model Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:51:22 --> Model Class Initialized
DEBUG - 2015-03-25 09:51:22 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:51:22 --> Model Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:51:22 --> Model Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:51:22 --> Model Class Initialized
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Undefined variable: u C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 75
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 75
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Undefined variable: u C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 75
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 75
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Undefined variable: u C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 81
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 81
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Undefined variable: u C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 81
ERROR - 2015-03-25 09:51:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\views\templates\sites.php 81
DEBUG - 2015-03-25 09:51:22 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:51:22 --> Final output sent to browser
DEBUG - 2015-03-25 09:51:22 --> Total execution time: 0.6230
DEBUG - 2015-03-25 09:51:24 --> Config Class Initialized
DEBUG - 2015-03-25 09:51:24 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:51:24 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:51:24 --> URI Class Initialized
DEBUG - 2015-03-25 09:51:24 --> Router Class Initialized
ERROR - 2015-03-25 09:51:24 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 09:53:32 --> Config Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:53:32 --> URI Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Router Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 09:53:32 --> Output Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Security Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Input Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 09:53:32 --> Language Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Language Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Config Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Loader Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: url_helper
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: form_helper
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: language_helper
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: user_helper
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: date_helper
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 09:53:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 09:53:32 --> Database Driver Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Session Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: string_helper
DEBUG - 2015-03-25 09:53:32 --> Session routines successfully run
DEBUG - 2015-03-25 09:53:32 --> Controller Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 09:53:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 09:53:32 --> Email Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 09:53:32 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 09:53:32 --> Model Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 09:53:32 --> Model Class Initialized
DEBUG - 2015-03-25 09:53:32 --> Form Validation Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 09:53:32 --> Model Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 09:53:32 --> Model Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 09:53:32 --> Model Class Initialized
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 09:53:32 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 09:53:32 --> Final output sent to browser
DEBUG - 2015-03-25 09:53:32 --> Total execution time: 0.5900
DEBUG - 2015-03-25 09:53:37 --> Config Class Initialized
DEBUG - 2015-03-25 09:53:37 --> Hooks Class Initialized
DEBUG - 2015-03-25 09:53:37 --> Utf8 Class Initialized
DEBUG - 2015-03-25 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 09:53:37 --> URI Class Initialized
DEBUG - 2015-03-25 09:53:37 --> Router Class Initialized
ERROR - 2015-03-25 09:53:37 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 10:00:16 --> Config Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:00:16 --> URI Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Router Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 10:00:16 --> Output Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Security Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Input Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 10:00:16 --> Language Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Language Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Config Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Loader Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: url_helper
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: form_helper
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: language_helper
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: user_helper
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: date_helper
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 10:00:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 10:00:16 --> Database Driver Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Session Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: string_helper
DEBUG - 2015-03-25 10:00:16 --> Session routines successfully run
DEBUG - 2015-03-25 10:00:16 --> Controller Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 10:00:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 10:00:16 --> Email Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 10:00:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 10:00:16 --> Model Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 10:00:16 --> Model Class Initialized
DEBUG - 2015-03-25 10:00:16 --> Form Validation Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 10:00:16 --> Model Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 10:00:16 --> Model Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 10:00:16 --> Model Class Initialized
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 10:00:16 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 10:00:16 --> Final output sent to browser
DEBUG - 2015-03-25 10:00:16 --> Total execution time: 0.6530
DEBUG - 2015-03-25 10:00:20 --> Config Class Initialized
DEBUG - 2015-03-25 10:00:20 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:00:20 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:00:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:00:20 --> URI Class Initialized
DEBUG - 2015-03-25 10:00:20 --> Router Class Initialized
ERROR - 2015-03-25 10:00:20 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 10:03:40 --> Config Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:03:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:03:40 --> URI Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Router Class Initialized
DEBUG - 2015-03-25 10:03:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 10:03:40 --> Output Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Security Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Input Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 10:03:40 --> Language Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Language Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Config Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Loader Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: url_helper
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: form_helper
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: language_helper
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: user_helper
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: date_helper
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 10:03:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 10:03:40 --> Database Driver Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Session Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: string_helper
DEBUG - 2015-03-25 10:03:40 --> Session routines successfully run
DEBUG - 2015-03-25 10:03:40 --> Controller Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 10:03:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 10:03:40 --> Email Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 10:03:40 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 10:03:40 --> Model Class Initialized
DEBUG - 2015-03-25 10:03:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 10:03:40 --> Model Class Initialized
DEBUG - 2015-03-25 10:03:40 --> Form Validation Class Initialized
DEBUG - 2015-03-25 10:03:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 10:03:40 --> Model Class Initialized
DEBUG - 2015-03-25 10:03:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 10:03:40 --> Model Class Initialized
DEBUG - 2015-03-25 10:03:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 10:03:40 --> Model Class Initialized
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 10:03:41 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 10:03:41 --> Final output sent to browser
DEBUG - 2015-03-25 10:03:41 --> Total execution time: 0.5680
DEBUG - 2015-03-25 10:03:43 --> Config Class Initialized
DEBUG - 2015-03-25 10:03:43 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:03:43 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:03:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:03:43 --> URI Class Initialized
DEBUG - 2015-03-25 10:03:43 --> Router Class Initialized
ERROR - 2015-03-25 10:03:43 --> 404 Page Not Found --> 
DEBUG - 2015-03-25 10:05:57 --> Config Class Initialized
DEBUG - 2015-03-25 10:05:57 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:05:57 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:05:57 --> URI Class Initialized
DEBUG - 2015-03-25 10:05:57 --> Router Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-25 10:05:58 --> Output Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Security Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Input Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-25 10:05:58 --> Language Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Language Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Config Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Loader Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: url_helper
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: form_helper
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: language_helper
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: user_helper
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: date_helper
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-25 10:05:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-25 10:05:58 --> Database Driver Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Session Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: string_helper
DEBUG - 2015-03-25 10:05:58 --> Session routines successfully run
DEBUG - 2015-03-25 10:05:58 --> Controller Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Sites MX_Controller Initialized
DEBUG - 2015-03-25 10:05:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-25 10:05:58 --> Email Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-25 10:05:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-25 10:05:58 --> Model Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-25 10:05:58 --> Model Class Initialized
DEBUG - 2015-03-25 10:05:58 --> Form Validation Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-25 10:05:58 --> Model Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-25 10:05:58 --> Model Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-25 10:05:58 --> Model Class Initialized
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-25 10:05:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-25 10:05:58 --> Final output sent to browser
DEBUG - 2015-03-25 10:05:58 --> Total execution time: 0.6000
DEBUG - 2015-03-25 10:06:08 --> Config Class Initialized
DEBUG - 2015-03-25 10:06:08 --> Hooks Class Initialized
DEBUG - 2015-03-25 10:06:08 --> Utf8 Class Initialized
DEBUG - 2015-03-25 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-25 10:06:08 --> URI Class Initialized
DEBUG - 2015-03-25 10:06:08 --> Router Class Initialized
ERROR - 2015-03-25 10:06:08 --> 404 Page Not Found --> 
