<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-26 04:40:09 --> Config Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Hooks Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Utf8 Class Initialized
DEBUG - 2015-03-26 04:40:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 04:40:09 --> URI Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Router Class Initialized
DEBUG - 2015-03-26 04:40:09 --> No URI present. Default controller set.
DEBUG - 2015-03-26 04:40:09 --> Output Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Security Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Input Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 04:40:09 --> Language Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Language Class Initialized
DEBUG - 2015-03-26 04:40:09 --> Config Class Initialized
DEBUG - 2015-03-26 04:40:10 --> Loader Class Initialized
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: url_helper
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: form_helper
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: language_helper
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: user_helper
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: date_helper
DEBUG - 2015-03-26 04:40:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 04:40:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 04:40:10 --> Database Driver Class Initialized
DEBUG - 2015-03-26 04:40:11 --> Session Class Initialized
DEBUG - 2015-03-26 04:40:11 --> Helper loaded: string_helper
DEBUG - 2015-03-26 04:40:11 --> A session cookie was not found.
DEBUG - 2015-03-26 04:40:11 --> Session routines successfully run
DEBUG - 2015-03-26 04:40:11 --> Controller Class Initialized
DEBUG - 2015-03-26 04:40:11 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 04:40:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 04:40:11 --> Email Class Initialized
DEBUG - 2015-03-26 04:40:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 04:40:12 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 04:40:12 --> Model Class Initialized
DEBUG - 2015-03-26 04:40:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 04:40:12 --> Model Class Initialized
DEBUG - 2015-03-26 04:40:12 --> Form Validation Class Initialized
DEBUG - 2015-03-26 04:40:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 04:40:12 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-26 04:40:12 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-26 04:40:12 --> Final output sent to browser
DEBUG - 2015-03-26 04:40:12 --> Total execution time: 3.1830
DEBUG - 2015-03-26 05:15:33 --> Config Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:15:33 --> URI Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Router Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Output Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Security Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Input Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 05:15:33 --> Language Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Language Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Config Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Loader Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: url_helper
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: form_helper
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: language_helper
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: user_helper
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: date_helper
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 05:15:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 05:15:33 --> Database Driver Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Session Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: string_helper
DEBUG - 2015-03-26 05:15:33 --> Session routines successfully run
DEBUG - 2015-03-26 05:15:33 --> Controller Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 05:15:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 05:15:33 --> Email Class Initialized
DEBUG - 2015-03-26 05:15:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 05:15:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 05:15:33 --> Model Class Initialized
DEBUG - 2015-03-26 05:15:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 05:15:34 --> Model Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Form Validation Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 05:15:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-26 05:15:34 --> Config Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:15:34 --> URI Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Router Class Initialized
DEBUG - 2015-03-26 05:15:34 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-26 05:15:34 --> Output Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Security Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Input Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 05:15:34 --> Language Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Language Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Config Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Loader Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: url_helper
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: form_helper
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: language_helper
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: user_helper
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: date_helper
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 05:15:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 05:15:34 --> Database Driver Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Session Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: string_helper
DEBUG - 2015-03-26 05:15:34 --> Session routines successfully run
DEBUG - 2015-03-26 05:15:34 --> Controller Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Customer MX_Controller Initialized
DEBUG - 2015-03-26 05:15:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 05:15:34 --> Email Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 05:15:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 05:15:34 --> Model Class Initialized
DEBUG - 2015-03-26 05:15:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 05:15:34 --> Model Class Initialized
DEBUG - 2015-03-26 05:15:34 --> Form Validation Class Initialized
DEBUG - 2015-03-26 05:15:34 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-26 05:15:35 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-26 05:15:35 --> Final output sent to browser
DEBUG - 2015-03-26 05:15:35 --> Total execution time: 0.4730
DEBUG - 2015-03-26 05:15:35 --> Config Class Initialized
DEBUG - 2015-03-26 05:15:35 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:15:35 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:15:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:15:35 --> URI Class Initialized
DEBUG - 2015-03-26 05:15:35 --> Router Class Initialized
ERROR - 2015-03-26 05:15:35 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 05:17:51 --> Config Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:17:51 --> URI Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Router Class Initialized
DEBUG - 2015-03-26 05:17:51 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-26 05:17:51 --> Output Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Security Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Input Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 05:17:51 --> Language Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Language Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Config Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Loader Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: url_helper
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: form_helper
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: language_helper
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: user_helper
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: date_helper
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 05:17:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 05:17:51 --> Database Driver Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Session Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: string_helper
DEBUG - 2015-03-26 05:17:51 --> Session routines successfully run
DEBUG - 2015-03-26 05:17:51 --> Controller Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Customer MX_Controller Initialized
DEBUG - 2015-03-26 05:17:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 05:17:51 --> Email Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 05:17:51 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 05:17:51 --> Model Class Initialized
DEBUG - 2015-03-26 05:17:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 05:17:51 --> Model Class Initialized
DEBUG - 2015-03-26 05:17:51 --> Form Validation Class Initialized
DEBUG - 2015-03-26 05:17:52 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-26 05:17:52 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-26 05:17:52 --> Final output sent to browser
DEBUG - 2015-03-26 05:17:52 --> Total execution time: 0.4030
DEBUG - 2015-03-26 05:17:54 --> Config Class Initialized
DEBUG - 2015-03-26 05:17:54 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:17:54 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:17:54 --> URI Class Initialized
DEBUG - 2015-03-26 05:17:54 --> Router Class Initialized
ERROR - 2015-03-26 05:17:54 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 05:18:04 --> Config Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:18:04 --> URI Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Router Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 05:18:04 --> Output Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Security Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Input Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 05:18:04 --> Language Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Language Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Config Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Loader Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: url_helper
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: form_helper
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: language_helper
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: user_helper
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: date_helper
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 05:18:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 05:18:04 --> Database Driver Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Session Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: string_helper
DEBUG - 2015-03-26 05:18:04 --> Session routines successfully run
DEBUG - 2015-03-26 05:18:04 --> Controller Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 05:18:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 05:18:04 --> Email Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 05:18:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 05:18:04 --> Model Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 05:18:04 --> Model Class Initialized
DEBUG - 2015-03-26 05:18:04 --> Form Validation Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 05:18:04 --> Model Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 05:18:04 --> Model Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 05:18:04 --> Model Class Initialized
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-26 05:18:04 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 05:18:04 --> Final output sent to browser
DEBUG - 2015-03-26 05:18:04 --> Total execution time: 0.7220
DEBUG - 2015-03-26 05:18:05 --> Config Class Initialized
DEBUG - 2015-03-26 05:18:05 --> Hooks Class Initialized
DEBUG - 2015-03-26 05:18:05 --> Utf8 Class Initialized
DEBUG - 2015-03-26 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 05:18:05 --> URI Class Initialized
DEBUG - 2015-03-26 05:18:05 --> Router Class Initialized
ERROR - 2015-03-26 05:18:05 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 06:06:25 --> Config Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:06:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:06:25 --> URI Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Router Class Initialized
DEBUG - 2015-03-26 06:06:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:06:25 --> Output Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Security Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Input Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:06:25 --> Language Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Language Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Config Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Loader Class Initialized
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:06:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:06:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:06:25 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Session Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:06:27 --> Session routines successfully run
DEBUG - 2015-03-26 06:06:27 --> Controller Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:06:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:06:27 --> Email Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:06:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:06:27 --> Model Class Initialized
DEBUG - 2015-03-26 06:06:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:06:27 --> Model Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:06:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:06:27 --> Model Class Initialized
DEBUG - 2015-03-26 06:06:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:06:27 --> Model Class Initialized
DEBUG - 2015-03-26 06:06:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:06:27 --> Model Class Initialized
DEBUG - 2015-03-26 06:06:27 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 06:06:27 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-03-26 06:06:27 --> Final output sent to browser
DEBUG - 2015-03-26 06:06:27 --> Total execution time: 2.1611
DEBUG - 2015-03-26 06:14:20 --> Config Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:14:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:14:20 --> URI Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Router Class Initialized
DEBUG - 2015-03-26 06:14:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:14:20 --> Output Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Security Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Input Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:14:20 --> Language Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Language Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Config Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Loader Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:14:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:14:20 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Session Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:14:20 --> Session routines successfully run
DEBUG - 2015-03-26 06:14:20 --> Controller Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:14:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:14:20 --> Email Class Initialized
DEBUG - 2015-03-26 06:14:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:14:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:14:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:14:21 --> Model Class Initialized
DEBUG - 2015-03-26 06:14:21 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:14:21 --> Model Class Initialized
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:14:21 --> Model Class Initialized
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:14:21 --> Model Class Initialized
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-26 06:14:21 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 06:14:21 --> Final output sent to browser
DEBUG - 2015-03-26 06:14:21 --> Total execution time: 0.6130
DEBUG - 2015-03-26 06:14:23 --> Config Class Initialized
DEBUG - 2015-03-26 06:14:23 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:14:23 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:14:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:14:23 --> URI Class Initialized
DEBUG - 2015-03-26 06:14:24 --> Router Class Initialized
ERROR - 2015-03-26 06:14:24 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 06:16:19 --> Config Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:16:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:16:19 --> URI Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Router Class Initialized
DEBUG - 2015-03-26 06:16:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:16:19 --> Output Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Security Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Input Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:16:19 --> Language Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Language Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Config Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Loader Class Initialized
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:16:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:16:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:16:19 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:16:20 --> Session Class Initialized
DEBUG - 2015-03-26 06:16:20 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:16:20 --> Session routines successfully run
DEBUG - 2015-03-26 06:16:20 --> Controller Class Initialized
DEBUG - 2015-03-26 06:16:20 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:16:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:16:20 --> Email Class Initialized
DEBUG - 2015-03-26 06:16:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:16:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:16:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:16:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:16:20 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:16:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:16:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:16:20 --> Model Class Initialized
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-26 06:16:20 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 06:16:20 --> Final output sent to browser
DEBUG - 2015-03-26 06:16:20 --> Total execution time: 1.5881
DEBUG - 2015-03-26 06:16:26 --> Config Class Initialized
DEBUG - 2015-03-26 06:16:26 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:16:26 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:16:26 --> URI Class Initialized
DEBUG - 2015-03-26 06:16:26 --> Router Class Initialized
ERROR - 2015-03-26 06:16:26 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 06:18:51 --> Config Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:18:51 --> URI Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Router Class Initialized
DEBUG - 2015-03-26 06:18:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:18:51 --> Output Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Security Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Input Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:18:51 --> Language Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Language Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Config Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Loader Class Initialized
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:18:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:18:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:18:52 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Session Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:18:52 --> Session routines successfully run
DEBUG - 2015-03-26 06:18:52 --> Controller Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:18:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:18:52 --> Email Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:18:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:18:52 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:18:52 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:18:52 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:18:52 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:18:52 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:52 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-26 06:18:52 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 06:18:52 --> Final output sent to browser
DEBUG - 2015-03-26 06:18:52 --> Total execution time: 1.0551
DEBUG - 2015-03-26 06:18:53 --> Config Class Initialized
DEBUG - 2015-03-26 06:18:53 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:18:53 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:18:53 --> URI Class Initialized
DEBUG - 2015-03-26 06:18:53 --> Router Class Initialized
DEBUG - 2015-03-26 06:18:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:18:53 --> Output Class Initialized
DEBUG - 2015-03-26 06:18:53 --> Security Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Config Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Input Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:18:56 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:18:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:18:56 --> Language Class Initialized
DEBUG - 2015-03-26 06:18:56 --> URI Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Language Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Router Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Config Class Initialized
ERROR - 2015-03-26 06:18:56 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 06:18:56 --> Loader Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:18:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:18:56 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Session Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:18:56 --> Session routines successfully run
DEBUG - 2015-03-26 06:18:56 --> Controller Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:18:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:18:56 --> Email Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:18:56 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:18:56 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:18:56 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:56 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:18:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:18:57 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:18:57 --> Model Class Initialized
DEBUG - 2015-03-26 06:18:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:18:57 --> Model Class Initialized
ERROR - 2015-03-26 06:18:57 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-26 06:19:11 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:11 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:19:12 --> URI Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Router Class Initialized
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:19:12 --> Output Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Security Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Input Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:19:12 --> Language Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Language Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Loader Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:19:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:19:12 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Session Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:19:12 --> Session routines successfully run
DEBUG - 2015-03-26 06:19:12 --> Controller Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:19:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:19:12 --> Email Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:19:12 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:19:12 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:19:12 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:19:12 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:19:12 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:12 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-26 06:19:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 06:19:12 --> Final output sent to browser
DEBUG - 2015-03-26 06:19:12 --> Total execution time: 0.8080
DEBUG - 2015-03-26 06:19:13 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:19:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:19:13 --> URI Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Router Class Initialized
DEBUG - 2015-03-26 06:19:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 06:19:13 --> Output Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Security Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Input Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 06:19:13 --> Language Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Language Class Initialized
DEBUG - 2015-03-26 06:19:13 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:14 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:14 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:19:14 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:19:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:19:14 --> URI Class Initialized
DEBUG - 2015-03-26 06:19:14 --> Router Class Initialized
ERROR - 2015-03-26 06:19:14 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 06:19:14 --> Loader Class Initialized
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: url_helper
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: form_helper
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: language_helper
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: user_helper
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: date_helper
DEBUG - 2015-03-26 06:19:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 06:19:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 06:19:14 --> Database Driver Class Initialized
DEBUG - 2015-03-26 06:19:15 --> Session Class Initialized
DEBUG - 2015-03-26 06:19:15 --> Helper loaded: string_helper
DEBUG - 2015-03-26 06:19:15 --> Session routines successfully run
DEBUG - 2015-03-26 06:19:15 --> Controller Class Initialized
DEBUG - 2015-03-26 06:19:15 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 06:19:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 06:19:15 --> Email Class Initialized
DEBUG - 2015-03-26 06:19:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 06:19:15 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 06:19:15 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 06:19:15 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:15 --> Form Validation Class Initialized
DEBUG - 2015-03-26 06:19:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 06:19:15 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 06:19:15 --> Model Class Initialized
DEBUG - 2015-03-26 06:19:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 06:19:15 --> Model Class Initialized
ERROR - 2015-03-26 06:19:15 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-26 06:19:17 --> Config Class Initialized
DEBUG - 2015-03-26 06:19:17 --> Hooks Class Initialized
DEBUG - 2015-03-26 06:19:17 --> Utf8 Class Initialized
DEBUG - 2015-03-26 06:19:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 06:19:17 --> URI Class Initialized
DEBUG - 2015-03-26 06:19:17 --> Router Class Initialized
ERROR - 2015-03-26 06:19:17 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:20:03 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:03 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:20:03 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:03 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:03 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:03 --> A session cookie was not found.
DEBUG - 2015-03-26 08:20:03 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:03 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:20:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:03 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:03 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:03 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:03 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:04 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:04 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:04 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:04 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:04 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 08:20:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:04 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:04 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:04 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 08:20:04 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-26 08:20:04 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-26 08:20:04 --> Final output sent to browser
DEBUG - 2015-03-26 08:20:04 --> Total execution time: 0.4450
DEBUG - 2015-03-26 08:20:24 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:24 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:24 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:24 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:24 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:24 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 08:20:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:24 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:24 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:24 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 08:20:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-26 08:20:25 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:25 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:25 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-26 08:20:25 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:25 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:25 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:25 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:25 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Customer MX_Controller Initialized
DEBUG - 2015-03-26 08:20:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:25 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:25 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:25 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:25 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:25 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-26 08:20:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-26 08:20:25 --> Final output sent to browser
DEBUG - 2015-03-26 08:20:25 --> Total execution time: 0.4860
DEBUG - 2015-03-26 08:20:25 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:25 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:25 --> Router Class Initialized
ERROR - 2015-03-26 08:20:25 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:20:34 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:34 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:20:34 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:34 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:34 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:34 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:34 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:20:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:34 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:34 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:34 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:34 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 08:20:34 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 08:20:34 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 08:20:34 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-26 08:20:34 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 08:20:34 --> Final output sent to browser
DEBUG - 2015-03-26 08:20:34 --> Total execution time: 0.6090
DEBUG - 2015-03-26 08:20:35 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:35 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:35 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:35 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:35 --> Router Class Initialized
ERROR - 2015-03-26 08:20:35 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:20:36 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:36 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:36 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:36 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:36 --> Router Class Initialized
ERROR - 2015-03-26 08:20:36 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:20:43 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:43 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:20:43 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:43 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:43 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:43 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:44 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:44 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:44 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:20:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:44 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:44 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 08:20:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 08:20:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 08:20:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:44 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-26 08:20:44 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 08:20:44 --> Final output sent to browser
DEBUG - 2015-03-26 08:20:44 --> Total execution time: 0.8991
DEBUG - 2015-03-26 08:20:45 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:45 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:45 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:45 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Router Class Initialized
DEBUG - 2015-03-26 08:20:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:20:45 --> Output Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Security Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Input Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:20:45 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Language Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Config Class Initialized
ERROR - 2015-03-26 08:20:45 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:20:45 --> Loader Class Initialized
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:20:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:20:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:20:45 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:20:46 --> Session Class Initialized
DEBUG - 2015-03-26 08:20:46 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:20:46 --> Session routines successfully run
DEBUG - 2015-03-26 08:20:46 --> Controller Class Initialized
DEBUG - 2015-03-26 08:20:46 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:20:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:20:46 --> Email Class Initialized
DEBUG - 2015-03-26 08:20:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:20:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:20:46 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:20:46 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:46 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:20:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 08:20:46 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 08:20:47 --> Model Class Initialized
DEBUG - 2015-03-26 08:20:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 08:20:47 --> Model Class Initialized
ERROR - 2015-03-26 08:20:47 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-26 08:20:47 --> Config Class Initialized
DEBUG - 2015-03-26 08:20:47 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:20:47 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:20:47 --> URI Class Initialized
DEBUG - 2015-03-26 08:20:47 --> Router Class Initialized
ERROR - 2015-03-26 08:20:47 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 08:23:42 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:23:42 --> URI Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Router Class Initialized
DEBUG - 2015-03-26 08:23:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:23:42 --> Output Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Security Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Input Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:23:42 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Loader Class Initialized
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:23:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:23:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:23:42 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Session Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:23:44 --> Session routines successfully run
DEBUG - 2015-03-26 08:23:44 --> Controller Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:23:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:23:44 --> Email Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:23:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:23:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:23:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 08:23:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 08:23:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 08:23:44 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:44 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-26 08:23:44 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 08:23:44 --> Final output sent to browser
DEBUG - 2015-03-26 08:23:44 --> Total execution time: 1.8400
DEBUG - 2015-03-26 08:23:46 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:23:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:23:46 --> URI Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Router Class Initialized
DEBUG - 2015-03-26 08:23:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:23:46 --> Output Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Security Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Input Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:23:46 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Loader Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:23:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:23:46 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Session Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:23:46 --> Session routines successfully run
DEBUG - 2015-03-26 08:23:46 --> Controller Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-26 08:23:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:23:46 --> Email Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:23:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:23:46 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:23:46 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:23:46 --> Final output sent to browser
DEBUG - 2015-03-26 08:23:46 --> Total execution time: 0.4780
DEBUG - 2015-03-26 08:23:52 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Hooks Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Utf8 Class Initialized
DEBUG - 2015-03-26 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 08:23:52 --> URI Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Router Class Initialized
DEBUG - 2015-03-26 08:23:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 08:23:52 --> Output Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Security Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Input Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 08:23:52 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Language Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Config Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Loader Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: url_helper
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: form_helper
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: language_helper
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: user_helper
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: date_helper
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 08:23:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 08:23:52 --> Database Driver Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Session Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: string_helper
DEBUG - 2015-03-26 08:23:52 --> Session routines successfully run
DEBUG - 2015-03-26 08:23:52 --> Controller Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 08:23:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 08:23:52 --> Email Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 08:23:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 08:23:52 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 08:23:52 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:52 --> Form Validation Class Initialized
DEBUG - 2015-03-26 08:23:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 08:23:52 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 08:23:52 --> Model Class Initialized
DEBUG - 2015-03-26 08:23:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 08:23:53 --> Model Class Initialized
ERROR - 2015-03-26 08:23:53 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-26 09:21:20 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:20 --> Hooks Class Initialized
DEBUG - 2015-03-26 09:21:20 --> Utf8 Class Initialized
DEBUG - 2015-03-26 09:21:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 09:21:20 --> URI Class Initialized
DEBUG - 2015-03-26 09:21:20 --> Router Class Initialized
DEBUG - 2015-03-26 09:21:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 09:21:20 --> Output Class Initialized
DEBUG - 2015-03-26 09:21:20 --> Security Class Initialized
DEBUG - 2015-03-26 09:21:20 --> Input Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 09:21:21 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Loader Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: url_helper
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: form_helper
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: language_helper
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: user_helper
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: date_helper
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 09:21:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 09:21:21 --> Database Driver Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Session Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: string_helper
DEBUG - 2015-03-26 09:21:21 --> Session routines successfully run
DEBUG - 2015-03-26 09:21:21 --> Controller Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 09:21:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 09:21:21 --> Email Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 09:21:21 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 09:21:21 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Form Validation Class Initialized
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 09:21:21 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 09:21:21 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 09:21:21 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:21 --> Helper loaded: directory_helper
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-26 09:21:21 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 09:21:21 --> Final output sent to browser
DEBUG - 2015-03-26 09:21:21 --> Total execution time: 0.7900
DEBUG - 2015-03-26 09:21:23 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Hooks Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Utf8 Class Initialized
DEBUG - 2015-03-26 09:21:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 09:21:23 --> URI Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Router Class Initialized
DEBUG - 2015-03-26 09:21:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 09:21:23 --> Output Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Security Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Input Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 09:21:23 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:23 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Hooks Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Loader Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: url_helper
DEBUG - 2015-03-26 09:21:24 --> Utf8 Class Initialized
DEBUG - 2015-03-26 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: form_helper
DEBUG - 2015-03-26 09:21:24 --> URI Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: language_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: user_helper
DEBUG - 2015-03-26 09:21:24 --> Router Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: date_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 09:21:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 09:21:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 09:21:24 --> Output Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Database Driver Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Session Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: string_helper
DEBUG - 2015-03-26 09:21:24 --> Session routines successfully run
DEBUG - 2015-03-26 09:21:24 --> Controller Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-26 09:21:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 09:21:24 --> Security Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Email Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Input Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 09:21:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 09:21:24 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 09:21:24 --> Language Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 09:21:24 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Form Validation Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Final output sent to browser
DEBUG - 2015-03-26 09:21:24 --> Total execution time: 1.1101
DEBUG - 2015-03-26 09:21:24 --> Config Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Loader Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: url_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: form_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: language_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: user_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: date_helper
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 09:21:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 09:21:24 --> Database Driver Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Session Class Initialized
DEBUG - 2015-03-26 09:21:24 --> Helper loaded: string_helper
DEBUG - 2015-03-26 09:21:24 --> Session routines successfully run
DEBUG - 2015-03-26 09:21:25 --> Controller Class Initialized
DEBUG - 2015-03-26 09:21:25 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 09:21:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 09:21:25 --> Email Class Initialized
DEBUG - 2015-03-26 09:21:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 09:21:25 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 09:21:25 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 09:21:25 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:25 --> Form Validation Class Initialized
DEBUG - 2015-03-26 09:21:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 09:21:25 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 09:21:25 --> Model Class Initialized
DEBUG - 2015-03-26 09:21:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 09:21:25 --> Model Class Initialized
ERROR - 2015-03-26 09:21:25 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-26 12:06:45 --> Config Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Hooks Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Utf8 Class Initialized
DEBUG - 2015-03-26 12:06:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 12:06:45 --> URI Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Router Class Initialized
DEBUG - 2015-03-26 12:06:45 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-26 12:06:45 --> Output Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Security Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Input Class Initialized
DEBUG - 2015-03-26 12:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 12:06:46 --> Language Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Language Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Config Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Loader Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: url_helper
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: form_helper
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: language_helper
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: user_helper
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: date_helper
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 12:06:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 12:06:46 --> Database Driver Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Session Class Initialized
DEBUG - 2015-03-26 12:06:46 --> Helper loaded: string_helper
DEBUG - 2015-03-26 12:06:46 --> A session cookie was not found.
DEBUG - 2015-03-26 12:06:46 --> Session routines successfully run
DEBUG - 2015-03-26 12:06:46 --> Controller Class Initialized
DEBUG - 2015-03-26 12:06:46 --> User MX_Controller Initialized
DEBUG - 2015-03-26 12:06:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 12:06:47 --> Email Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 12:06:47 --> Model Class Initialized
DEBUG - 2015-03-26 12:06:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 12:06:47 --> Model Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Form Validation Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Config Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Hooks Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Utf8 Class Initialized
DEBUG - 2015-03-26 12:06:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 12:06:47 --> URI Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Router Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Output Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Security Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Input Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 12:06:47 --> Language Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Language Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Config Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Loader Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: url_helper
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: form_helper
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: language_helper
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: user_helper
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: date_helper
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 12:06:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 12:06:47 --> Database Driver Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Session Class Initialized
DEBUG - 2015-03-26 12:06:47 --> Helper loaded: string_helper
DEBUG - 2015-03-26 12:06:47 --> Session routines successfully run
DEBUG - 2015-03-26 12:06:47 --> Controller Class Initialized
DEBUG - 2015-03-26 12:06:48 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 12:06:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 12:06:48 --> Email Class Initialized
DEBUG - 2015-03-26 12:06:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 12:06:48 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 12:06:48 --> Model Class Initialized
DEBUG - 2015-03-26 12:06:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 12:06:48 --> Model Class Initialized
DEBUG - 2015-03-26 12:06:48 --> Form Validation Class Initialized
DEBUG - 2015-03-26 12:06:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 12:06:48 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-26 12:06:48 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-26 12:06:48 --> Final output sent to browser
DEBUG - 2015-03-26 12:06:48 --> Total execution time: 0.6590
DEBUG - 2015-03-26 12:14:55 --> Config Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Hooks Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Utf8 Class Initialized
DEBUG - 2015-03-26 12:14:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 12:14:55 --> URI Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Router Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Output Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Security Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Input Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 12:14:55 --> Language Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Language Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Config Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Loader Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: url_helper
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: form_helper
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: language_helper
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: user_helper
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: date_helper
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 12:14:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 12:14:55 --> Database Driver Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Session Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: string_helper
DEBUG - 2015-03-26 12:14:55 --> Session routines successfully run
DEBUG - 2015-03-26 12:14:55 --> Controller Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Login MX_Controller Initialized
DEBUG - 2015-03-26 12:14:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 12:14:55 --> Email Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 12:14:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 12:14:55 --> Model Class Initialized
DEBUG - 2015-03-26 12:14:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 12:14:55 --> Model Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Form Validation Class Initialized
DEBUG - 2015-03-26 12:14:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-26 12:14:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-26 12:14:56 --> Config Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Hooks Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Utf8 Class Initialized
DEBUG - 2015-03-26 12:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 12:14:56 --> URI Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Router Class Initialized
DEBUG - 2015-03-26 12:14:56 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-26 12:14:56 --> Output Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Security Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Input Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 12:14:56 --> Language Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Language Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Config Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Loader Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: url_helper
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: form_helper
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: language_helper
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: user_helper
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: date_helper
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 12:14:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 12:14:56 --> Database Driver Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Session Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: string_helper
DEBUG - 2015-03-26 12:14:56 --> Session routines successfully run
DEBUG - 2015-03-26 12:14:56 --> Controller Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Customer MX_Controller Initialized
DEBUG - 2015-03-26 12:14:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 12:14:56 --> Email Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 12:14:56 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 12:14:56 --> Model Class Initialized
DEBUG - 2015-03-26 12:14:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 12:14:56 --> Model Class Initialized
DEBUG - 2015-03-26 12:14:56 --> Form Validation Class Initialized
DEBUG - 2015-03-26 12:14:56 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-26 12:14:57 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-26 12:14:57 --> Final output sent to browser
DEBUG - 2015-03-26 12:14:57 --> Total execution time: 0.6310
DEBUG - 2015-03-26 12:14:57 --> Config Class Initialized
DEBUG - 2015-03-26 12:14:57 --> Hooks Class Initialized
DEBUG - 2015-03-26 12:14:57 --> Utf8 Class Initialized
DEBUG - 2015-03-26 12:14:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 12:14:57 --> URI Class Initialized
DEBUG - 2015-03-26 12:14:57 --> Router Class Initialized
ERROR - 2015-03-26 12:14:57 --> 404 Page Not Found --> 
DEBUG - 2015-03-26 13:01:38 --> Config Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Hooks Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Utf8 Class Initialized
DEBUG - 2015-03-26 13:01:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 13:01:38 --> URI Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Router Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-26 13:01:38 --> Output Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Security Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Input Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-26 13:01:38 --> Language Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Language Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Config Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Loader Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: url_helper
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: form_helper
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: language_helper
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: user_helper
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: date_helper
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-26 13:01:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-26 13:01:38 --> Database Driver Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Session Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: string_helper
DEBUG - 2015-03-26 13:01:38 --> Session routines successfully run
DEBUG - 2015-03-26 13:01:38 --> Controller Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Sites MX_Controller Initialized
DEBUG - 2015-03-26 13:01:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-26 13:01:38 --> Email Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-26 13:01:38 --> Helper loaded: cookie_helper
DEBUG - 2015-03-26 13:01:38 --> Model Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-26 13:01:38 --> Model Class Initialized
DEBUG - 2015-03-26 13:01:38 --> Form Validation Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-26 13:01:38 --> Model Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-26 13:01:38 --> Model Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-26 13:01:38 --> Model Class Initialized
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-26 13:01:38 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-26 13:01:38 --> Final output sent to browser
DEBUG - 2015-03-26 13:01:38 --> Total execution time: 0.6630
DEBUG - 2015-03-26 13:01:39 --> Config Class Initialized
DEBUG - 2015-03-26 13:01:39 --> Hooks Class Initialized
DEBUG - 2015-03-26 13:01:39 --> Utf8 Class Initialized
DEBUG - 2015-03-26 13:01:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-26 13:01:39 --> URI Class Initialized
DEBUG - 2015-03-26 13:01:39 --> Router Class Initialized
ERROR - 2015-03-26 13:01:39 --> 404 Page Not Found --> 
