<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-03-30 06:01:34 --> Config Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Hooks Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Utf8 Class Initialized
DEBUG - 2015-03-30 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 06:01:34 --> URI Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Router Class Initialized
DEBUG - 2015-03-30 06:01:34 --> No URI present. Default controller set.
DEBUG - 2015-03-30 06:01:34 --> Output Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Security Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Input Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 06:01:34 --> Language Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Language Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Config Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Loader Class Initialized
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: url_helper
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: form_helper
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: language_helper
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: user_helper
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: date_helper
DEBUG - 2015-03-30 06:01:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 06:01:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 06:01:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Session Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Helper loaded: string_helper
DEBUG - 2015-03-30 06:01:36 --> A session cookie was not found.
DEBUG - 2015-03-30 06:01:36 --> Session routines successfully run
DEBUG - 2015-03-30 06:01:36 --> Controller Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 06:01:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 06:01:36 --> Email Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 06:01:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 06:01:36 --> Model Class Initialized
DEBUG - 2015-03-30 06:01:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 06:01:36 --> Model Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 06:01:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 06:01:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 06:01:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 06:01:36 --> Final output sent to browser
DEBUG - 2015-03-30 06:01:36 --> Total execution time: 2.3041
DEBUG - 2015-03-30 07:23:40 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:40 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Router Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Output Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Security Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Input Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:23:40 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Loader Class Initialized
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:23:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:23:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:23:40 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Session Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:23:41 --> Session routines successfully run
DEBUG - 2015-03-30 07:23:41 --> Controller Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 07:23:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:23:41 --> Email Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:23:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:23:41 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:23:41 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:23:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 07:23:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-30 07:23:42 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:42 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Router Class Initialized
DEBUG - 2015-03-30 07:23:42 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-30 07:23:42 --> Output Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Security Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Input Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:23:42 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Loader Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:23:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:23:42 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Session Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:23:42 --> Session routines successfully run
DEBUG - 2015-03-30 07:23:42 --> Controller Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Customer MX_Controller Initialized
DEBUG - 2015-03-30 07:23:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:23:42 --> Email Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:23:42 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:23:42 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:23:42 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:42 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:23:42 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-30 07:23:42 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-30 07:23:42 --> Final output sent to browser
DEBUG - 2015-03-30 07:23:42 --> Total execution time: 0.5240
DEBUG - 2015-03-30 07:23:43 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:43 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:43 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:43 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:43 --> Router Class Initialized
ERROR - 2015-03-30 07:23:43 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 07:23:55 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:55 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Router Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:23:55 --> Output Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Security Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Input Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:23:55 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Language Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Loader Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:23:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:23:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Session Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:23:55 --> Session routines successfully run
DEBUG - 2015-03-30 07:23:55 --> Controller Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:23:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:23:55 --> Email Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:23:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:23:55 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:23:55 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:23:55 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:23:55 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:23:55 --> Model Class Initialized
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-30 07:23:55 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 07:23:55 --> Final output sent to browser
DEBUG - 2015-03-30 07:23:55 --> Total execution time: 0.8360
DEBUG - 2015-03-30 07:23:56 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:56 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Router Class Initialized
ERROR - 2015-03-30 07:23:56 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 07:23:56 --> Config Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:23:56 --> URI Class Initialized
DEBUG - 2015-03-30 07:23:56 --> Router Class Initialized
ERROR - 2015-03-30 07:23:56 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 07:24:16 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:16 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:16 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:16 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:16 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:16 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:24:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:16 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:24:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:24:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:24:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:16 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 07:24:16 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 07:24:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 07:24:17 --> Final output sent to browser
DEBUG - 2015-03-30 07:24:17 --> Total execution time: 0.9081
DEBUG - 2015-03-30 07:24:17 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:17 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:17 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:17 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:17 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:17 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:17 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:17 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:17 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:17 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:17 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:24:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:17 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:17 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:17 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:17 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:24:18 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:24:18 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:24:18 --> Model Class Initialized
ERROR - 2015-03-30 07:24:18 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 07:24:18 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:18 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:18 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 07:24:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:18 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:18 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:18 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:18 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:18 --> Final output sent to browser
DEBUG - 2015-03-30 07:24:18 --> Total execution time: 1.8001
DEBUG - 2015-03-30 07:24:32 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:32 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:32 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:32 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:32 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:32 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:32 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:24:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:32 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:32 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:32 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:24:32 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:24:32 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:24:32 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:32 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 07:24:32 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 07:24:33 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 07:24:33 --> Final output sent to browser
DEBUG - 2015-03-30 07:24:33 --> Total execution time: 0.8070
DEBUG - 2015-03-30 07:24:33 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:33 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:33 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:33 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:34 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:34 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:34 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:34 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:34 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:34 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:34 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:34 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:34 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:24:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:34 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:34 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:34 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:34 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:24:34 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:24:34 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:24:34 --> Model Class Initialized
ERROR - 2015-03-30 07:24:34 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 07:24:35 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:35 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:35 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:35 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 07:24:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:35 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:35 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:35 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:35 --> Final output sent to browser
DEBUG - 2015-03-30 07:24:36 --> Total execution time: 2.1861
DEBUG - 2015-03-30 07:24:39 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:24:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:24:39 --> URI Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Router Class Initialized
DEBUG - 2015-03-30 07:24:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:24:39 --> Output Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Security Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Input Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:24:39 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Language Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Config Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Loader Class Initialized
DEBUG - 2015-03-30 07:24:39 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:24:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:24:40 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:24:40 --> Session Class Initialized
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:24:40 --> Session routines successfully run
DEBUG - 2015-03-30 07:24:40 --> Controller Class Initialized
DEBUG - 2015-03-30 07:24:40 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:24:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:24:40 --> Email Class Initialized
DEBUG - 2015-03-30 07:24:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:24:40 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:24:40 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:24:40 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:40 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:24:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:24:40 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:24:40 --> Model Class Initialized
DEBUG - 2015-03-30 07:24:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:24:40 --> Model Class Initialized
ERROR - 2015-03-30 07:24:40 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 07:53:16 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:53:16 --> URI Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Router Class Initialized
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:53:16 --> Output Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Security Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Input Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:53:16 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Loader Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:53:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:53:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Session Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:53:16 --> Session routines successfully run
DEBUG - 2015-03-30 07:53:16 --> Controller Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:53:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:53:16 --> Email Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:53:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:53:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:53:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:53:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:53:16 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:16 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 07:53:16 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 07:53:16 --> Final output sent to browser
DEBUG - 2015-03-30 07:53:16 --> Total execution time: 0.8240
DEBUG - 2015-03-30 07:53:18 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:53:18 --> URI Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Router Class Initialized
DEBUG - 2015-03-30 07:53:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:53:18 --> Output Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Security Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Input Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:53:18 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Loader Class Initialized
DEBUG - 2015-03-30 07:53:18 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:53:19 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:53:19 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:53:19 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:53:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:53:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:53:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:53:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Session Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:53:20 --> Session routines successfully run
DEBUG - 2015-03-30 07:53:20 --> Controller Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 07:53:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:53:20 --> Email Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:53:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:53:20 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:53:20 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:53:20 --> Final output sent to browser
DEBUG - 2015-03-30 07:53:20 --> Total execution time: 2.2561
DEBUG - 2015-03-30 07:53:24 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:24 --> Hooks Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Utf8 Class Initialized
DEBUG - 2015-03-30 07:53:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 07:53:25 --> URI Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Router Class Initialized
DEBUG - 2015-03-30 07:53:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 07:53:25 --> Output Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Security Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Input Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 07:53:25 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Language Class Initialized
DEBUG - 2015-03-30 07:53:25 --> Config Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Loader Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: url_helper
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: form_helper
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: language_helper
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: user_helper
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: date_helper
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 07:53:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 07:53:26 --> Database Driver Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Session Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: string_helper
DEBUG - 2015-03-30 07:53:26 --> Session routines successfully run
DEBUG - 2015-03-30 07:53:26 --> Controller Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 07:53:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 07:53:26 --> Email Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 07:53:26 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 07:53:26 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 07:53:26 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:26 --> Form Validation Class Initialized
DEBUG - 2015-03-30 07:53:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 07:53:26 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 07:53:26 --> Model Class Initialized
DEBUG - 2015-03-30 07:53:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 07:53:26 --> Model Class Initialized
ERROR - 2015-03-30 07:53:26 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 08:39:38 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:38 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:39:38 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:39:38 --> URI Class Initialized
DEBUG - 2015-03-30 08:39:38 --> Router Class Initialized
DEBUG - 2015-03-30 08:39:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:39:38 --> Output Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Security Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Input Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:39:39 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Loader Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:39:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:39:39 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Session Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:39:39 --> Session routines successfully run
DEBUG - 2015-03-30 08:39:39 --> Controller Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:39:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:39:39 --> Email Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:39:39 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:39:39 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:39:39 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:39:39 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:39:39 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:39 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 08:39:39 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 08:39:39 --> Final output sent to browser
DEBUG - 2015-03-30 08:39:39 --> Total execution time: 0.9320
DEBUG - 2015-03-30 08:39:41 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:39:41 --> URI Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Router Class Initialized
DEBUG - 2015-03-30 08:39:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:39:41 --> Output Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Security Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Input Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:39:41 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Loader Class Initialized
DEBUG - 2015-03-30 08:39:41 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:39:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:39:42 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Session Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:39:42 --> Session routines successfully run
DEBUG - 2015-03-30 08:39:42 --> Controller Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 08:39:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:39:42 --> Email Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:39:42 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:39:42 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:39:42 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:39:42 --> Final output sent to browser
DEBUG - 2015-03-30 08:39:42 --> Total execution time: 1.0200
DEBUG - 2015-03-30 08:39:56 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:39:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:39:56 --> URI Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Router Class Initialized
DEBUG - 2015-03-30 08:39:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:39:56 --> Output Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Security Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Input Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:39:56 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Language Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Config Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Loader Class Initialized
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:39:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:39:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:39:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:39:57 --> Session Class Initialized
DEBUG - 2015-03-30 08:39:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:39:57 --> Session routines successfully run
DEBUG - 2015-03-30 08:39:57 --> Controller Class Initialized
DEBUG - 2015-03-30 08:39:57 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:39:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:39:57 --> Email Class Initialized
DEBUG - 2015-03-30 08:39:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:39:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:39:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:39:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:39:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:39:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:39:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:39:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:39:57 --> Model Class Initialized
ERROR - 2015-03-30 08:39:57 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 08:41:49 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:41:49 --> URI Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Router Class Initialized
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:41:49 --> Output Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Security Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Input Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:41:49 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Loader Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:41:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:41:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Session Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:41:49 --> Session routines successfully run
DEBUG - 2015-03-30 08:41:49 --> Controller Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:41:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:41:49 --> Email Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:41:49 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:41:49 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:41:49 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:41:49 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:41:49 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:49 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 08:41:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 08:41:49 --> Final output sent to browser
DEBUG - 2015-03-30 08:41:49 --> Total execution time: 0.7920
DEBUG - 2015-03-30 08:41:51 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:41:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:41:51 --> URI Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Router Class Initialized
DEBUG - 2015-03-30 08:41:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:41:51 --> Output Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Security Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Input Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:41:51 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Loader Class Initialized
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:41:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:41:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:41:51 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Session Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:41:53 --> Session routines successfully run
DEBUG - 2015-03-30 08:41:53 --> Controller Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 08:41:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:41:53 --> Email Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:41:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:41:53 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:41:53 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:41:53 --> Final output sent to browser
DEBUG - 2015-03-30 08:41:53 --> Total execution time: 1.9371
DEBUG - 2015-03-30 08:41:55 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:55 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:41:55 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:41:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:41:55 --> URI Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Router Class Initialized
DEBUG - 2015-03-30 08:41:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:41:56 --> Output Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Security Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Input Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:41:56 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Language Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Config Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Loader Class Initialized
DEBUG - 2015-03-30 08:41:56 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:41:56 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:41:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:41:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:41:57 --> Session Class Initialized
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:41:57 --> Session routines successfully run
DEBUG - 2015-03-30 08:41:57 --> Controller Class Initialized
DEBUG - 2015-03-30 08:41:57 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:41:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:41:57 --> Email Class Initialized
DEBUG - 2015-03-30 08:41:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:41:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:41:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:41:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:41:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:41:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:41:57 --> Model Class Initialized
DEBUG - 2015-03-30 08:41:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:41:57 --> Model Class Initialized
ERROR - 2015-03-30 08:41:57 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 08:42:26 --> Config Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:42:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:42:26 --> URI Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Router Class Initialized
DEBUG - 2015-03-30 08:42:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:42:26 --> Output Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Security Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Input Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:42:26 --> Language Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Language Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Config Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Loader Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:42:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:42:26 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Session Class Initialized
DEBUG - 2015-03-30 08:42:26 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:42:26 --> Session routines successfully run
DEBUG - 2015-03-30 08:42:26 --> Controller Class Initialized
DEBUG - 2015-03-30 08:42:27 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:42:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:42:27 --> Email Class Initialized
DEBUG - 2015-03-30 08:42:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:42:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:42:27 --> Model Class Initialized
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:42:27 --> Model Class Initialized
DEBUG - 2015-03-30 08:42:27 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:42:27 --> Model Class Initialized
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:42:27 --> Model Class Initialized
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:42:27 --> Model Class Initialized
DEBUG - 2015-03-30 08:42:27 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 08:42:27 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 08:42:27 --> Final output sent to browser
DEBUG - 2015-03-30 08:42:27 --> Total execution time: 0.7890
DEBUG - 2015-03-30 08:51:57 --> Config Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:51:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:51:57 --> URI Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Router Class Initialized
DEBUG - 2015-03-30 08:51:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:51:57 --> Output Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Security Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Input Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:51:57 --> Language Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Language Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Config Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Loader Class Initialized
DEBUG - 2015-03-30 08:51:57 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:51:57 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:51:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:51:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:51:58 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Session Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:51:58 --> Session routines successfully run
DEBUG - 2015-03-30 08:51:58 --> Controller Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:51:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:51:58 --> Email Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:51:58 --> Model Class Initialized
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:51:58 --> Model Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:51:58 --> Model Class Initialized
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:51:58 --> Model Class Initialized
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:51:58 --> Model Class Initialized
DEBUG - 2015-03-30 08:51:58 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 08:51:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 08:51:58 --> Final output sent to browser
DEBUG - 2015-03-30 08:51:58 --> Total execution time: 0.9500
DEBUG - 2015-03-30 08:51:59 --> Config Class Initialized
DEBUG - 2015-03-30 08:51:59 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:51:59 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:51:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:51:59 --> URI Class Initialized
DEBUG - 2015-03-30 08:51:59 --> Router Class Initialized
DEBUG - 2015-03-30 08:52:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:52:00 --> Output Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Security Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Input Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:52:00 --> Language Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Language Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Config Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Loader Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:52:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:52:00 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Session Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:52:00 --> Session routines successfully run
DEBUG - 2015-03-30 08:52:00 --> Controller Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 08:52:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:52:00 --> Email Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:52:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:52:00 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:52:00 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:52:00 --> Final output sent to browser
DEBUG - 2015-03-30 08:52:00 --> Total execution time: 1.2221
DEBUG - 2015-03-30 08:52:20 --> Config Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Hooks Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Utf8 Class Initialized
DEBUG - 2015-03-30 08:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 08:52:20 --> URI Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Router Class Initialized
DEBUG - 2015-03-30 08:52:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 08:52:20 --> Output Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Security Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Input Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 08:52:20 --> Language Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Language Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Config Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Loader Class Initialized
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: url_helper
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: form_helper
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: language_helper
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: user_helper
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: date_helper
DEBUG - 2015-03-30 08:52:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 08:52:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 08:52:20 --> Database Driver Class Initialized
DEBUG - 2015-03-30 08:52:22 --> Session Class Initialized
DEBUG - 2015-03-30 08:52:22 --> Helper loaded: string_helper
DEBUG - 2015-03-30 08:52:22 --> Session routines successfully run
DEBUG - 2015-03-30 08:52:22 --> Controller Class Initialized
DEBUG - 2015-03-30 08:52:22 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 08:52:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 08:52:22 --> Email Class Initialized
DEBUG - 2015-03-30 08:52:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 08:52:22 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 08:52:22 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 08:52:22 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:22 --> Form Validation Class Initialized
DEBUG - 2015-03-30 08:52:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 08:52:22 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 08:52:22 --> Model Class Initialized
DEBUG - 2015-03-30 08:52:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 08:52:22 --> Model Class Initialized
ERROR - 2015-03-30 08:52:22 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:05:53 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:05:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:05:53 --> URI Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Router Class Initialized
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:05:53 --> Output Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Security Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Input Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:05:53 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Loader Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:05:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:05:53 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Session Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:05:53 --> Session routines successfully run
DEBUG - 2015-03-30 09:05:53 --> Controller Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:05:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:05:53 --> Email Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:05:53 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:05:53 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:05:53 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:05:53 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:05:53 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:53 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:05:53 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:05:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:05:54 --> Final output sent to browser
DEBUG - 2015-03-30 09:05:54 --> Total execution time: 0.7720
DEBUG - 2015-03-30 09:05:55 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:05:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:05:55 --> URI Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Router Class Initialized
DEBUG - 2015-03-30 09:05:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:05:55 --> Output Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Security Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Input Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:05:55 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Loader Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:05:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:05:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Session Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:05:55 --> Session routines successfully run
DEBUG - 2015-03-30 09:05:55 --> Controller Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:05:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:05:55 --> Email Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:05:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:05:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:05:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:05:55 --> Final output sent to browser
DEBUG - 2015-03-30 09:05:55 --> Total execution time: 0.5810
DEBUG - 2015-03-30 09:05:58 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:58 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:05:58 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:05:58 --> URI Class Initialized
DEBUG - 2015-03-30 09:05:58 --> Router Class Initialized
DEBUG - 2015-03-30 09:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:05:59 --> Output Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Security Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Input Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:05:59 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Language Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Config Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Loader Class Initialized
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:05:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:05:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:05:59 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:06:01 --> Session Class Initialized
DEBUG - 2015-03-30 09:06:01 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:06:01 --> Session routines successfully run
DEBUG - 2015-03-30 09:06:01 --> Controller Class Initialized
DEBUG - 2015-03-30 09:06:01 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:06:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:06:01 --> Email Class Initialized
DEBUG - 2015-03-30 09:06:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:06:01 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:06:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:06:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:06:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:06:01 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:06:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:06:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:06:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:06:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:06:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:06:01 --> Model Class Initialized
ERROR - 2015-03-30 09:06:01 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:07:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:07:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:07:09 --> URI Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Router Class Initialized
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:07:09 --> Output Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Security Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Input Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:07:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Loader Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:07:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:07:09 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Session Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:07:09 --> Session routines successfully run
DEBUG - 2015-03-30 09:07:09 --> Controller Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:07:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:07:09 --> Email Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:07:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:07:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:07:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:07:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:07:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:09 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:07:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:07:09 --> Final output sent to browser
DEBUG - 2015-03-30 09:07:09 --> Total execution time: 0.7390
DEBUG - 2015-03-30 09:07:11 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:07:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:07:11 --> URI Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Router Class Initialized
DEBUG - 2015-03-30 09:07:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:07:11 --> Output Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Security Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Input Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:07:11 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Loader Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:07:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:07:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Session Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:07:11 --> Session routines successfully run
DEBUG - 2015-03-30 09:07:11 --> Controller Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:07:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:07:11 --> Email Class Initialized
DEBUG - 2015-03-30 09:07:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:07:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:07:11 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:07:11 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:12 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:07:12 --> Final output sent to browser
DEBUG - 2015-03-30 09:07:12 --> Total execution time: 0.6840
DEBUG - 2015-03-30 09:07:13 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:07:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:07:13 --> URI Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Router Class Initialized
DEBUG - 2015-03-30 09:07:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:07:13 --> Output Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Security Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Input Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:07:13 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Language Class Initialized
DEBUG - 2015-03-30 09:07:13 --> Config Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Loader Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:07:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:07:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Session Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:07:14 --> Session routines successfully run
DEBUG - 2015-03-30 09:07:14 --> Controller Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:07:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:07:14 --> Email Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:07:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:07:14 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:07:14 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:07:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:07:14 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:07:14 --> Model Class Initialized
DEBUG - 2015-03-30 09:07:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:07:14 --> Model Class Initialized
ERROR - 2015-03-30 09:07:14 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:13:14 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:13:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:13:14 --> URI Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Router Class Initialized
DEBUG - 2015-03-30 09:13:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:13:14 --> Output Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Security Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Input Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:13:14 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Loader Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:13:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:13:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Session Class Initialized
DEBUG - 2015-03-30 09:13:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:13:15 --> Session routines successfully run
DEBUG - 2015-03-30 09:13:15 --> Controller Class Initialized
DEBUG - 2015-03-30 09:13:15 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:13:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:13:15 --> Email Class Initialized
DEBUG - 2015-03-30 09:13:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:13:15 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:13:15 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:13:15 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:15 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:13:15 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:13:15 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:13:15 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:15 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:13:15 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:13:15 --> Final output sent to browser
DEBUG - 2015-03-30 09:13:15 --> Total execution time: 0.7620
DEBUG - 2015-03-30 09:13:16 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:13:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:13:16 --> URI Class Initialized
DEBUG - 2015-03-30 09:13:16 --> Router Class Initialized
DEBUG - 2015-03-30 09:13:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:13:17 --> Output Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Security Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Input Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:13:17 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Loader Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:13:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:13:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Session Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:13:17 --> Session routines successfully run
DEBUG - 2015-03-30 09:13:17 --> Controller Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:13:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:13:17 --> Email Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:13:17 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:13:17 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:13:17 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:13:17 --> Final output sent to browser
DEBUG - 2015-03-30 09:13:17 --> Total execution time: 1.1131
DEBUG - 2015-03-30 09:13:23 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:13:23 --> URI Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Router Class Initialized
DEBUG - 2015-03-30 09:13:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:13:23 --> Output Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Security Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Input Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:13:23 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Language Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Config Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Loader Class Initialized
DEBUG - 2015-03-30 09:13:23 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:13:23 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:13:23 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:13:23 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:13:23 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:13:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:13:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:13:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:13:24 --> Session Class Initialized
DEBUG - 2015-03-30 09:13:24 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:13:24 --> Session routines successfully run
DEBUG - 2015-03-30 09:13:24 --> Controller Class Initialized
DEBUG - 2015-03-30 09:13:24 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:13:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:13:24 --> Email Class Initialized
DEBUG - 2015-03-30 09:13:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:13:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:13:24 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:13:24 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:24 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:13:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:13:25 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:13:25 --> Model Class Initialized
DEBUG - 2015-03-30 09:13:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:13:25 --> Model Class Initialized
ERROR - 2015-03-30 09:13:25 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:17:05 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:17:05 --> URI Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Router Class Initialized
DEBUG - 2015-03-30 09:17:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:17:05 --> Output Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Security Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Input Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:17:05 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Loader Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:17:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:17:05 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Session Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:17:05 --> Session routines successfully run
DEBUG - 2015-03-30 09:17:05 --> Controller Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:17:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:17:05 --> Email Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:17:05 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:17:05 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:17:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:17:05 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:17:05 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:17:05 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:05 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:17:06 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:17:06 --> Final output sent to browser
DEBUG - 2015-03-30 09:17:06 --> Total execution time: 0.7520
DEBUG - 2015-03-30 09:17:07 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:17:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:17:07 --> URI Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Router Class Initialized
DEBUG - 2015-03-30 09:17:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:17:07 --> Output Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Security Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Input Class Initialized
DEBUG - 2015-03-30 09:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:17:08 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Loader Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:17:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:17:08 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Session Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:17:08 --> Session routines successfully run
DEBUG - 2015-03-30 09:17:08 --> Controller Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:17:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:17:08 --> Email Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:17:08 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:17:08 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:17:08 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:17:08 --> Final output sent to browser
DEBUG - 2015-03-30 09:17:08 --> Total execution time: 1.0251
DEBUG - 2015-03-30 09:17:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:17:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:17:09 --> URI Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Router Class Initialized
DEBUG - 2015-03-30 09:17:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:17:09 --> Output Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Security Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Input Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:17:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:17:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Loader Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:17:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:17:10 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Session Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:17:10 --> Session routines successfully run
DEBUG - 2015-03-30 09:17:10 --> Controller Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:17:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:17:10 --> Email Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:17:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:17:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:17:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:10 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:17:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:17:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:17:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:17:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:17:10 --> Model Class Initialized
ERROR - 2015-03-30 09:17:10 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:22:08 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:08 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:22:09 --> URI Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Router Class Initialized
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:22:09 --> Output Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Security Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Input Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:22:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Loader Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:22:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:22:09 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Session Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:22:09 --> Session routines successfully run
DEBUG - 2015-03-30 09:22:09 --> Controller Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:22:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:22:09 --> Email Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:22:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:22:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:22:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:22:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:22:09 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:09 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:22:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:22:09 --> Final output sent to browser
DEBUG - 2015-03-30 09:22:09 --> Total execution time: 0.8180
DEBUG - 2015-03-30 09:22:10 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:10 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:22:10 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:22:10 --> URI Class Initialized
DEBUG - 2015-03-30 09:22:10 --> Router Class Initialized
DEBUG - 2015-03-30 09:22:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:22:11 --> Output Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Security Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Input Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:22:11 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Loader Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:22:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:22:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Session Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:22:11 --> Session routines successfully run
DEBUG - 2015-03-30 09:22:11 --> Controller Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:22:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:22:11 --> Email Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:22:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:22:11 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:22:11 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:22:11 --> Final output sent to browser
DEBUG - 2015-03-30 09:22:11 --> Total execution time: 0.9871
DEBUG - 2015-03-30 09:22:27 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:22:27 --> URI Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Router Class Initialized
DEBUG - 2015-03-30 09:22:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:22:27 --> Output Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Security Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Input Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:22:27 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Language Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Config Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Loader Class Initialized
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:22:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:22:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:22:28 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:22:28 --> Session Class Initialized
DEBUG - 2015-03-30 09:22:28 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:22:28 --> Session routines successfully run
DEBUG - 2015-03-30 09:22:28 --> Controller Class Initialized
DEBUG - 2015-03-30 09:22:28 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:22:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:22:28 --> Email Class Initialized
DEBUG - 2015-03-30 09:22:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:22:28 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:22:28 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:22:28 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:28 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:22:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:22:29 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:22:29 --> Model Class Initialized
DEBUG - 2015-03-30 09:22:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:22:29 --> Model Class Initialized
ERROR - 2015-03-30 09:22:29 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:27:01 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:27:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:27:01 --> URI Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Router Class Initialized
DEBUG - 2015-03-30 09:27:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:27:01 --> Output Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Security Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Input Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:27:01 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Loader Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:27:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:27:01 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Session Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:27:01 --> Session routines successfully run
DEBUG - 2015-03-30 09:27:01 --> Controller Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:27:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:27:01 --> Email Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:27:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:27:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:27:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:27:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:27:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:27:01 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:01 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:27:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:27:02 --> Final output sent to browser
DEBUG - 2015-03-30 09:27:02 --> Total execution time: 0.8010
DEBUG - 2015-03-30 09:27:02 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:02 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:27:02 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:27:03 --> URI Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Router Class Initialized
DEBUG - 2015-03-30 09:27:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:27:03 --> Output Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Security Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Input Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:27:03 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Loader Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:27:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:27:03 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Session Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:27:03 --> Session routines successfully run
DEBUG - 2015-03-30 09:27:03 --> Controller Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:27:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:27:03 --> Email Class Initialized
DEBUG - 2015-03-30 09:27:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:27:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:27:04 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:27:04 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:04 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:27:04 --> Final output sent to browser
DEBUG - 2015-03-30 09:27:04 --> Total execution time: 1.1131
DEBUG - 2015-03-30 09:27:08 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:08 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:27:08 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:27:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:27:08 --> URI Class Initialized
DEBUG - 2015-03-30 09:27:08 --> Router Class Initialized
DEBUG - 2015-03-30 09:27:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:27:09 --> Output Class Initialized
DEBUG - 2015-03-30 09:27:09 --> Security Class Initialized
DEBUG - 2015-03-30 09:27:09 --> Input Class Initialized
DEBUG - 2015-03-30 09:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:27:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:09 --> Language Class Initialized
DEBUG - 2015-03-30 09:27:09 --> Config Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Loader Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:27:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:27:10 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Session Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:27:10 --> Session routines successfully run
DEBUG - 2015-03-30 09:27:10 --> Controller Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:27:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:27:10 --> Email Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:27:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:27:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:27:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:10 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:27:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:27:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:27:10 --> Model Class Initialized
DEBUG - 2015-03-30 09:27:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:27:10 --> Model Class Initialized
ERROR - 2015-03-30 09:27:10 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:29:36 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:29:36 --> URI Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Router Class Initialized
DEBUG - 2015-03-30 09:29:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:29:36 --> Output Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Security Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Input Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:29:36 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Loader Class Initialized
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:29:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:29:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:29:36 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Session Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:29:37 --> Session routines successfully run
DEBUG - 2015-03-30 09:29:37 --> Controller Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:29:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:29:37 --> Email Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:29:37 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:29:37 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:29:37 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:29:37 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:29:37 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:29:37 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:37 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:29:37 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:29:37 --> Final output sent to browser
DEBUG - 2015-03-30 09:29:37 --> Total execution time: 0.7380
DEBUG - 2015-03-30 09:29:38 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:38 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:29:38 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:29:38 --> URI Class Initialized
DEBUG - 2015-03-30 09:29:38 --> Router Class Initialized
DEBUG - 2015-03-30 09:29:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:29:38 --> Output Class Initialized
DEBUG - 2015-03-30 09:29:38 --> Security Class Initialized
DEBUG - 2015-03-30 09:29:38 --> Input Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:29:39 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Loader Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:29:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:29:39 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Session Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:29:39 --> Session routines successfully run
DEBUG - 2015-03-30 09:29:39 --> Controller Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:29:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:29:39 --> Email Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:29:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:29:39 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:29:39 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:29:39 --> Final output sent to browser
DEBUG - 2015-03-30 09:29:39 --> Total execution time: 1.0661
DEBUG - 2015-03-30 09:29:43 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:29:43 --> URI Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Router Class Initialized
DEBUG - 2015-03-30 09:29:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:29:43 --> Output Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Security Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Input Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:29:43 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Language Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Config Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Loader Class Initialized
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:29:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:29:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:29:44 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:29:44 --> Session Class Initialized
DEBUG - 2015-03-30 09:29:44 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:29:44 --> Session routines successfully run
DEBUG - 2015-03-30 09:29:44 --> Controller Class Initialized
DEBUG - 2015-03-30 09:29:44 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:29:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:29:45 --> Email Class Initialized
DEBUG - 2015-03-30 09:29:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:29:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:29:45 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:29:45 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:45 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:29:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:29:45 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:29:45 --> Model Class Initialized
DEBUG - 2015-03-30 09:29:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:29:45 --> Model Class Initialized
ERROR - 2015-03-30 09:29:45 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 09:31:47 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:31:47 --> URI Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Router Class Initialized
DEBUG - 2015-03-30 09:31:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:31:47 --> Output Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Security Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Input Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:31:47 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Loader Class Initialized
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:31:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:31:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:31:48 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Session Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:31:48 --> Session routines successfully run
DEBUG - 2015-03-30 09:31:48 --> Controller Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:31:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:31:48 --> Email Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:31:48 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:31:48 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:31:48 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:31:48 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:31:48 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:31:48 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:48 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 09:31:48 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 09:31:48 --> Final output sent to browser
DEBUG - 2015-03-30 09:31:48 --> Total execution time: 0.8010
DEBUG - 2015-03-30 09:31:49 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:31:49 --> URI Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Router Class Initialized
DEBUG - 2015-03-30 09:31:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:31:49 --> Output Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Security Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Input Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:31:49 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Loader Class Initialized
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:31:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:31:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:31:50 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Session Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:31:50 --> Session routines successfully run
DEBUG - 2015-03-30 09:31:50 --> Controller Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 09:31:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:31:50 --> Email Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:31:50 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:31:50 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:31:50 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:31:50 --> Final output sent to browser
DEBUG - 2015-03-30 09:31:50 --> Total execution time: 1.1571
DEBUG - 2015-03-30 09:31:53 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 09:31:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 09:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 09:31:53 --> URI Class Initialized
DEBUG - 2015-03-30 09:31:53 --> Router Class Initialized
DEBUG - 2015-03-30 09:31:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 09:31:53 --> Output Class Initialized
DEBUG - 2015-03-30 09:31:53 --> Security Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Input Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 09:31:54 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Language Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Config Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Loader Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 09:31:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 09:31:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Session Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 09:31:54 --> Session routines successfully run
DEBUG - 2015-03-30 09:31:54 --> Controller Class Initialized
DEBUG - 2015-03-30 09:31:54 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 09:31:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 09:31:55 --> Email Class Initialized
DEBUG - 2015-03-30 09:31:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 09:31:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 09:31:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 09:31:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 09:31:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 09:31:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 09:31:55 --> Model Class Initialized
DEBUG - 2015-03-30 09:31:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 09:31:55 --> Model Class Initialized
ERROR - 2015-03-30 09:31:55 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:18:40 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:18:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:18:40 --> URI Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Router Class Initialized
DEBUG - 2015-03-30 11:18:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:18:40 --> Output Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Security Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Input Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:18:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Loader Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:18:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:18:40 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Session Class Initialized
DEBUG - 2015-03-30 11:18:40 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:18:41 --> Session routines successfully run
DEBUG - 2015-03-30 11:18:41 --> Controller Class Initialized
DEBUG - 2015-03-30 11:18:41 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:18:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:18:41 --> Email Class Initialized
DEBUG - 2015-03-30 11:18:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:18:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:18:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:18:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:41 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:18:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:18:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:18:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:41 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:18:41 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:18:41 --> Final output sent to browser
DEBUG - 2015-03-30 11:18:41 --> Total execution time: 1.1680
DEBUG - 2015-03-30 11:18:42 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:42 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:18:42 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:18:42 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:18:42 --> URI Class Initialized
DEBUG - 2015-03-30 11:18:42 --> Router Class Initialized
DEBUG - 2015-03-30 11:18:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:18:43 --> Output Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Security Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Input Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:18:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Loader Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:18:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:18:43 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Session Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:18:43 --> Session routines successfully run
DEBUG - 2015-03-30 11:18:43 --> Controller Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:18:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:18:43 --> Email Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:18:43 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:18:43 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:18:43 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:18:43 --> Final output sent to browser
DEBUG - 2015-03-30 11:18:43 --> Total execution time: 1.5781
DEBUG - 2015-03-30 11:18:58 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:18:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:18:58 --> URI Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Router Class Initialized
DEBUG - 2015-03-30 11:18:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:18:58 --> Output Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Security Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Input Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:18:58 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Language Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Config Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Loader Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:18:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:18:58 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Session Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:18:58 --> Session routines successfully run
DEBUG - 2015-03-30 11:18:58 --> Controller Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:18:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:18:58 --> Email Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:18:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:18:58 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:18:58 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:58 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:18:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:18:58 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:18:58 --> Model Class Initialized
DEBUG - 2015-03-30 11:18:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:18:58 --> Model Class Initialized
ERROR - 2015-03-30 11:18:58 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:19:13 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:19:13 --> URI Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Router Class Initialized
DEBUG - 2015-03-30 11:19:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:19:13 --> Output Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Security Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Input Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:19:13 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:13 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Loader Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:19:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:19:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Session Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:19:14 --> Session routines successfully run
DEBUG - 2015-03-30 11:19:14 --> Controller Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:19:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:19:14 --> Email Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:19:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:19:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:19:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:19:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:19:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:19:14 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:19:14 --> Final output sent to browser
DEBUG - 2015-03-30 11:19:14 --> Total execution time: 0.7620
DEBUG - 2015-03-30 11:19:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:19:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:19:15 --> URI Class Initialized
DEBUG - 2015-03-30 11:19:15 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:15 --> Router Class Initialized
DEBUG - 2015-03-30 11:19:15 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:19:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:19:15 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:19:15 --> URI Class Initialized
DEBUG - 2015-03-30 11:19:15 --> Router Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Output Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Security Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Input Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:19:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:19:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Output Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Security Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Input Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:19:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Loader Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:19:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Loader Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:19:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:19:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:19:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Session Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:19:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Session Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:19:16 --> Session routines successfully run
DEBUG - 2015-03-30 11:19:16 --> Controller Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:19:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:19:16 --> Session routines successfully run
DEBUG - 2015-03-30 11:19:16 --> Controller Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:19:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:19:16 --> Email Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:19:16 --> Email Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:19:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:19:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:19:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:19:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:19:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:19:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:19:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:19:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:19:17 --> Final output sent to browser
DEBUG - 2015-03-30 11:19:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:17 --> Total execution time: 2.1051
DEBUG - 2015-03-30 11:19:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:19:17 --> Model Class Initialized
ERROR - 2015-03-30 11:19:17 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:19:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:19:56 --> URI Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Router Class Initialized
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:19:56 --> Output Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Security Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Input Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:19:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Loader Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:19:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:19:56 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Session Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:19:56 --> Session routines successfully run
DEBUG - 2015-03-30 11:19:56 --> Controller Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:19:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:19:56 --> Email Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:19:56 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:19:56 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:19:56 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:19:56 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:19:56 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:56 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:19:56 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:19:57 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:19:57 --> Final output sent to browser
DEBUG - 2015-03-30 11:19:57 --> Total execution time: 0.7600
DEBUG - 2015-03-30 11:19:58 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:19:58 --> URI Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Router Class Initialized
DEBUG - 2015-03-30 11:19:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:19:58 --> Output Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Security Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Input Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:19:58 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Language Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Config Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Loader Class Initialized
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:19:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:19:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:19:59 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Session Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:19:59 --> Session routines successfully run
DEBUG - 2015-03-30 11:19:59 --> Controller Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:19:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:19:59 --> Email Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:19:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:19:59 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:19:59 --> Model Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:19:59 --> Final output sent to browser
DEBUG - 2015-03-30 11:19:59 --> Total execution time: 0.6800
DEBUG - 2015-03-30 11:20:01 --> Config Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:20:01 --> URI Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Router Class Initialized
DEBUG - 2015-03-30 11:20:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:20:01 --> Output Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Security Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Input Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:20:01 --> Language Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Language Class Initialized
DEBUG - 2015-03-30 11:20:01 --> Config Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Loader Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:20:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:20:02 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Session Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:20:02 --> Session routines successfully run
DEBUG - 2015-03-30 11:20:02 --> Controller Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:20:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:20:02 --> Email Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:20:02 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:20:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:20:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:20:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:20:02 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:20:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:20:03 --> Model Class Initialized
DEBUG - 2015-03-30 11:20:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:20:03 --> Model Class Initialized
DEBUG - 2015-03-30 11:20:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:20:03 --> Model Class Initialized
ERROR - 2015-03-30 11:20:03 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:21:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:21:35 --> URI Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Router Class Initialized
DEBUG - 2015-03-30 11:21:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:21:35 --> Output Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Security Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Input Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:21:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Loader Class Initialized
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:21:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:21:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:21:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Session Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:21:36 --> Session routines successfully run
DEBUG - 2015-03-30 11:21:36 --> Controller Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:21:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:21:36 --> Email Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:21:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:21:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:21:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:21:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:21:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:21:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:36 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:21:36 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:21:36 --> Final output sent to browser
DEBUG - 2015-03-30 11:21:36 --> Total execution time: 0.7740
DEBUG - 2015-03-30 11:21:38 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:21:38 --> URI Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Router Class Initialized
DEBUG - 2015-03-30 11:21:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:21:38 --> Output Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Security Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Input Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:21:38 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Loader Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:21:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:21:38 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Session Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:21:38 --> Session routines successfully run
DEBUG - 2015-03-30 11:21:38 --> Controller Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:21:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:21:38 --> Email Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:21:38 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:21:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:21:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:21:38 --> Final output sent to browser
DEBUG - 2015-03-30 11:21:38 --> Total execution time: 0.7850
DEBUG - 2015-03-30 11:21:43 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:21:43 --> URI Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Router Class Initialized
DEBUG - 2015-03-30 11:21:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:21:43 --> Output Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Security Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Input Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:21:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Config Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Loader Class Initialized
DEBUG - 2015-03-30 11:21:43 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:21:43 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:21:43 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:21:43 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:21:43 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:21:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:21:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:21:44 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:21:44 --> Session Class Initialized
DEBUG - 2015-03-30 11:21:44 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:21:44 --> Session routines successfully run
DEBUG - 2015-03-30 11:21:44 --> Controller Class Initialized
DEBUG - 2015-03-30 11:21:44 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:21:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:21:44 --> Email Class Initialized
DEBUG - 2015-03-30 11:21:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:21:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:21:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:21:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:44 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:21:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:21:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:21:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:21:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:21:44 --> Model Class Initialized
ERROR - 2015-03-30 11:21:44 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:26:43 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:26:43 --> URI Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Router Class Initialized
DEBUG - 2015-03-30 11:26:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:26:43 --> Output Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Security Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Input Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:26:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Loader Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:26:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:26:43 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Session Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:26:43 --> Session routines successfully run
DEBUG - 2015-03-30 11:26:43 --> Controller Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:26:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:26:43 --> Email Class Initialized
DEBUG - 2015-03-30 11:26:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:26:44 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:26:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:26:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:44 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:26:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:26:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:26:44 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:44 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:26:44 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:26:44 --> Final output sent to browser
DEBUG - 2015-03-30 11:26:44 --> Total execution time: 0.8010
DEBUG - 2015-03-30 11:26:45 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:26:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:26:45 --> URI Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Router Class Initialized
DEBUG - 2015-03-30 11:26:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:26:45 --> Output Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Security Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Input Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:26:45 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Loader Class Initialized
DEBUG - 2015-03-30 11:26:45 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:26:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:26:46 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Session Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:26:46 --> Session routines successfully run
DEBUG - 2015-03-30 11:26:46 --> Controller Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:26:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:26:46 --> Email Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:26:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:26:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:26:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:26:46 --> Final output sent to browser
DEBUG - 2015-03-30 11:26:46 --> Total execution time: 0.5970
DEBUG - 2015-03-30 11:26:47 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:47 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:26:47 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:26:47 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:26:47 --> URI Class Initialized
DEBUG - 2015-03-30 11:26:48 --> Router Class Initialized
DEBUG - 2015-03-30 11:26:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:26:48 --> Output Class Initialized
DEBUG - 2015-03-30 11:26:48 --> Security Class Initialized
DEBUG - 2015-03-30 11:26:48 --> Input Class Initialized
DEBUG - 2015-03-30 11:26:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:26:48 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:48 --> Language Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Config Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Loader Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:26:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:26:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Session Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:26:49 --> Session routines successfully run
DEBUG - 2015-03-30 11:26:49 --> Controller Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:26:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:26:49 --> Email Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:26:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:26:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:26:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:26:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:26:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:26:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:26:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:26:49 --> Model Class Initialized
ERROR - 2015-03-30 11:26:49 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:37:51 --> Config Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:37:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:37:51 --> URI Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Router Class Initialized
DEBUG - 2015-03-30 11:37:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:37:51 --> Output Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Security Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Input Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:37:51 --> Language Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Language Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Config Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Loader Class Initialized
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:37:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:37:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:37:51 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Session Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: string_helper
ERROR - 2015-03-30 11:37:53 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-03-30 11:37:53 --> Session routines successfully run
DEBUG - 2015-03-30 11:37:53 --> Controller Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:37:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:37:53 --> Email Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:37:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:37:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:37:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Config Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:37:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:37:53 --> URI Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Router Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Output Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Security Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Input Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:37:53 --> Language Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Language Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Config Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Loader Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:37:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:37:53 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Session Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:37:53 --> Session routines successfully run
DEBUG - 2015-03-30 11:37:53 --> Controller Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:37:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:37:53 --> Email Class Initialized
DEBUG - 2015-03-30 11:37:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:37:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:37:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:37:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:37:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:37:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:37:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:37:54 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:37:54 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:37:54 --> Final output sent to browser
DEBUG - 2015-03-30 11:37:54 --> Total execution time: 0.5000
DEBUG - 2015-03-30 11:38:15 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:15 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:15 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:15 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:15 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:15 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:15 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:38:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:16 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:38:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-30 11:38:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:16 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:16 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-30 11:38:16 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:16 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:16 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Customer MX_Controller Initialized
DEBUG - 2015-03-30 11:38:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:16 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:16 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:16 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:17 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-30 11:38:17 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-30 11:38:17 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:17 --> Total execution time: 0.5310
DEBUG - 2015-03-30 11:38:17 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:17 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:17 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:17 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:17 --> Router Class Initialized
ERROR - 2015-03-30 11:38:17 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 11:38:19 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:19 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:19 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:19 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:19 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:38:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:19 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:19 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:19 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:38:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:38:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:38:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-30 11:38:19 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:38:19 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:19 --> Total execution time: 0.7080
DEBUG - 2015-03-30 11:38:20 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:20 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:20 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:20 --> Router Class Initialized
ERROR - 2015-03-30 11:38:20 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 11:38:20 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:20 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:20 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:20 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:20 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:21 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:21 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:21 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:21 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:21 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:38:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:21 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:21 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:21 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:21 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:21 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:21 --> Total execution time: 1.0131
DEBUG - 2015-03-30 11:38:53 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:53 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:53 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:53 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:53 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:53 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:53 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:38:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:53 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:38:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:38:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:38:53 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:53 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:38:54 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:54 --> Total execution time: 0.7980
DEBUG - 2015-03-30 11:38:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:54 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:54 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:55 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:55 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:55 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:55 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:55 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:55 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:55 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:55 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:55 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:38:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:38:55 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
ERROR - 2015-03-30 11:38:55 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:38:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:55 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:55 --> Total execution time: 0.9031
DEBUG - 2015-03-30 11:38:59 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:38:59 --> URI Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Router Class Initialized
DEBUG - 2015-03-30 11:38:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:38:59 --> Output Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Security Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Input Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:38:59 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Language Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Config Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Loader Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:38:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:38:59 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Session Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:38:59 --> Session routines successfully run
DEBUG - 2015-03-30 11:38:59 --> Controller Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:38:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:38:59 --> Email Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:38:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:38:59 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:38:59 --> Model Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:38:59 --> Final output sent to browser
DEBUG - 2015-03-30 11:38:59 --> Total execution time: 0.4610
DEBUG - 2015-03-30 11:41:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:41:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:41:14 --> URI Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Router Class Initialized
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:41:14 --> Output Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Security Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Input Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:41:14 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Loader Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:41:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:41:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Session Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:41:14 --> Session routines successfully run
DEBUG - 2015-03-30 11:41:14 --> Controller Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:41:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:41:14 --> Email Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:41:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:41:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:41:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:41:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:41:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:14 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:41:14 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:41:15 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:41:15 --> Final output sent to browser
DEBUG - 2015-03-30 11:41:15 --> Total execution time: 0.7640
DEBUG - 2015-03-30 11:41:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:41:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:41:17 --> URI Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Router Class Initialized
DEBUG - 2015-03-30 11:41:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:41:17 --> Output Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Security Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Input Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:41:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Loader Class Initialized
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:41:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:41:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:41:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:41:18 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:18 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:41:18 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:41:18 --> URI Class Initialized
DEBUG - 2015-03-30 11:41:18 --> Router Class Initialized
DEBUG - 2015-03-30 11:41:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:41:19 --> Output Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Security Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Input Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Session Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:41:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Session routines successfully run
DEBUG - 2015-03-30 11:41:19 --> Controller Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:41:19 --> Loader Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:41:19 --> Email Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:41:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:41:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Session Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:41:19 --> Session routines successfully run
DEBUG - 2015-03-30 11:41:19 --> Final output sent to browser
DEBUG - 2015-03-30 11:41:19 --> Total execution time: 2.9361
DEBUG - 2015-03-30 11:41:19 --> Controller Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:41:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:41:19 --> Email Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:41:19 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:41:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:41:19 --> Model Class Initialized
ERROR - 2015-03-30 11:41:19 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:41:24 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:41:24 --> URI Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Router Class Initialized
DEBUG - 2015-03-30 11:41:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:41:24 --> Output Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Security Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Input Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:41:24 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Language Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Config Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Loader Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:41:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:41:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Session Class Initialized
DEBUG - 2015-03-30 11:41:24 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:41:24 --> Session routines successfully run
DEBUG - 2015-03-30 11:41:25 --> Controller Class Initialized
DEBUG - 2015-03-30 11:41:25 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:41:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:41:25 --> Email Class Initialized
DEBUG - 2015-03-30 11:41:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:41:25 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:41:25 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:41:25 --> Model Class Initialized
DEBUG - 2015-03-30 11:41:25 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:41:25 --> Final output sent to browser
DEBUG - 2015-03-30 11:41:25 --> Total execution time: 0.3970
DEBUG - 2015-03-30 11:45:06 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:06 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:06 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:06 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:06 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:06 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:06 --> A session cookie was not found.
DEBUG - 2015-03-30 11:45:06 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:06 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:06 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:06 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:06 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:06 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:06 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:06 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:06 --> Total execution time: 0.3620
DEBUG - 2015-03-30 11:45:31 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:31 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:31 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:31 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:31 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:31 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:31 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:31 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:31 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:31 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:31 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:31 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:31 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:31 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:31 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:31 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:31 --> Total execution time: 0.3930
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:35 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:35 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:35 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:35 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:35 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:35 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:35 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:35 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:35 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:35 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:35 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:35 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:35 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:35 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:35 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:35 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:35 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:35 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:35 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Total execution time: 0.5030
DEBUG - 2015-03-30 11:45:35 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:35 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:35 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:35 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:35 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:35 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:35 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:35 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:35 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:35 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:36 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:36 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:36 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:36 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:36 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:36 --> Total execution time: 0.5940
DEBUG - 2015-03-30 11:45:36 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:36 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:36 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:36 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:36 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:36 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:36 --> Total execution time: 0.6010
DEBUG - 2015-03-30 11:45:36 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:36 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:36 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:36 --> Total execution time: 0.5270
DEBUG - 2015-03-30 11:45:44 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:45:44 --> URI Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Router Class Initialized
DEBUG - 2015-03-30 11:45:44 --> No URI present. Default controller set.
DEBUG - 2015-03-30 11:45:44 --> Output Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Security Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Input Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:45:44 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Language Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Config Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Loader Class Initialized
DEBUG - 2015-03-30 11:45:44 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:45:44 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:45:44 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:45:44 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:45:44 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:45:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:45:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:45:45 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Session Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:45:45 --> Session routines successfully run
DEBUG - 2015-03-30 11:45:45 --> Controller Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:45:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:45:45 --> Email Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:45:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:45:45 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:45:45 --> Model Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:45:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:45:45 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:45:45 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:45:45 --> Final output sent to browser
DEBUG - 2015-03-30 11:45:45 --> Total execution time: 0.3600
DEBUG - 2015-03-30 11:46:55 --> Config Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:46:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:46:55 --> URI Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Router Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Output Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Security Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Input Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:46:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Language Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Config Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Loader Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:46:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:46:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Session Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:46:55 --> Session routines successfully run
DEBUG - 2015-03-30 11:46:55 --> Controller Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 11:46:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:46:55 --> Email Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:46:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:46:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:46:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:46:55 --> Model Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:46:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 11:46:55 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 11:46:55 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 11:46:55 --> Final output sent to browser
DEBUG - 2015-03-30 11:46:55 --> Total execution time: 0.4720
DEBUG - 2015-03-30 11:52:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:52:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:52:15 --> URI Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Router Class Initialized
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:52:15 --> Output Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Security Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Input Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:52:15 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Loader Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:52:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:52:15 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Session Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:52:15 --> Session routines successfully run
DEBUG - 2015-03-30 11:52:15 --> Controller Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:52:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:52:15 --> Email Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:52:15 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:52:15 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:52:15 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:52:15 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:52:15 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:15 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:52:15 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:52:15 --> Final output sent to browser
DEBUG - 2015-03-30 11:52:15 --> Total execution time: 0.8020
DEBUG - 2015-03-30 11:52:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:52:16 --> URI Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Router Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:52:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:52:16 --> Output Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Security Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Input Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:52:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:17 --> URI Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Router Class Initialized
DEBUG - 2015-03-30 11:52:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:52:17 --> Loader Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Output Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:52:17 --> Security Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:52:17 --> Input Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:52:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:52:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:52:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:52:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Session Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Loader Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:52:17 --> Session routines successfully run
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:52:17 --> Controller Class Initialized
DEBUG - 2015-03-30 11:52:17 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:52:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:52:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:52:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:52:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:52:18 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Email Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:52:18 --> Session Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:52:18 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:52:18 --> Session routines successfully run
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Controller Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:52:18 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:52:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Email Class Initialized
DEBUG - 2015-03-30 11:52:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:52:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Helper loaded: cookie_helper
ERROR - 2015-03-30 11:52:18 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:52:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:52:18 --> Final output sent to browser
DEBUG - 2015-03-30 11:52:18 --> Total execution time: 1.7721
DEBUG - 2015-03-30 11:52:19 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:52:19 --> URI Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Router Class Initialized
DEBUG - 2015-03-30 11:52:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:52:19 --> Output Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Security Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Input Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:52:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Loader Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:52:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:52:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Session Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:52:19 --> Session routines successfully run
DEBUG - 2015-03-30 11:52:19 --> Controller Class Initialized
DEBUG - 2015-03-30 11:52:19 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:52:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:52:20 --> Email Class Initialized
DEBUG - 2015-03-30 11:52:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:52:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:52:20 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:52:20 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:20 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:52:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:52:20 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:52:20 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:52:20 --> Model Class Initialized
ERROR - 2015-03-30 11:52:20 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:52:24 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:52:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:52:24 --> URI Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Router Class Initialized
DEBUG - 2015-03-30 11:52:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:52:24 --> Output Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Security Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Input Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:52:24 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Language Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Config Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Loader Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:52:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:52:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Session Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:52:24 --> Session routines successfully run
DEBUG - 2015-03-30 11:52:24 --> Controller Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:52:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:52:24 --> Email Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:52:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:52:24 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:52:24 --> Model Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:52:24 --> Final output sent to browser
DEBUG - 2015-03-30 11:52:24 --> Total execution time: 0.3920
DEBUG - 2015-03-30 11:54:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:54:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:54:14 --> URI Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Router Class Initialized
DEBUG - 2015-03-30 11:54:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:54:14 --> Output Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Security Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Input Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:54:14 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Loader Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:54:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:54:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Session Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:54:14 --> Session routines successfully run
DEBUG - 2015-03-30 11:54:14 --> Controller Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:54:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:54:14 --> Email Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:54:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:54:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:54:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:54:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:54:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:54:14 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:14 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:54:15 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:54:15 --> Final output sent to browser
DEBUG - 2015-03-30 11:54:15 --> Total execution time: 1.2790
DEBUG - 2015-03-30 11:54:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:54:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:54:16 --> URI Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Router Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:54:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:54:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:54:16 --> Output Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Security Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Input Class Initialized
DEBUG - 2015-03-30 11:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:54:16 --> URI Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Router Class Initialized
DEBUG - 2015-03-30 11:54:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:54:17 --> Output Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Loader Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:54:17 --> Security Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:54:17 --> Input Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:54:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:54:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:54:17 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:54:17 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:54:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Session Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Loader Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:54:17 --> Session routines successfully run
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:54:17 --> Controller Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:54:17 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:54:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:54:17 --> Email Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:54:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:54:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:54:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:54:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Session Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:54:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Session routines successfully run
DEBUG - 2015-03-30 11:54:17 --> Controller Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:54:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:54:17 --> Email Class Initialized
DEBUG - 2015-03-30 11:54:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:54:17 --> Final output sent to browser
DEBUG - 2015-03-30 11:54:17 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:54:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:54:17 --> Total execution time: 1.7491
DEBUG - 2015-03-30 11:54:17 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:18 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:54:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:54:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:54:18 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:54:18 --> Model Class Initialized
ERROR - 2015-03-30 11:54:18 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:54:22 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:54:22 --> URI Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Router Class Initialized
DEBUG - 2015-03-30 11:54:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:54:22 --> Output Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Security Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Input Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:54:22 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Language Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Config Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Loader Class Initialized
DEBUG - 2015-03-30 11:54:22 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:54:22 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:54:22 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:54:22 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:54:23 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:54:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:54:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:54:23 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Session Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:54:23 --> Session routines successfully run
DEBUG - 2015-03-30 11:54:23 --> Controller Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:54:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:54:23 --> Email Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:54:23 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:54:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:54:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:54:23 --> Final output sent to browser
DEBUG - 2015-03-30 11:54:23 --> Total execution time: 0.3540
DEBUG - 2015-03-30 11:55:23 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:55:23 --> URI Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Router Class Initialized
DEBUG - 2015-03-30 11:55:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:55:23 --> Output Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Security Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Input Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:55:23 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Loader Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:55:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:55:23 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Session Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:55:23 --> Session routines successfully run
DEBUG - 2015-03-30 11:55:23 --> Controller Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:55:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:55:23 --> Email Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:55:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:55:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:55:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:55:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:55:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:55:23 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:23 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:55:24 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:55:24 --> Final output sent to browser
DEBUG - 2015-03-30 11:55:24 --> Total execution time: 0.7600
DEBUG - 2015-03-30 11:55:25 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:55:25 --> URI Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Router Class Initialized
DEBUG - 2015-03-30 11:55:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:55:25 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:55:25 --> URI Class Initialized
DEBUG - 2015-03-30 11:55:25 --> Router Class Initialized
DEBUG - 2015-03-30 11:55:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:55:26 --> Output Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Security Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Input Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:55:26 --> Output Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Security Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Input Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:55:26 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Loader Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:55:26 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:55:26 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:55:26 --> Loader Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:55:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:55:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:55:26 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Session Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:55:26 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Session routines successfully run
DEBUG - 2015-03-30 11:55:26 --> Controller Class Initialized
DEBUG - 2015-03-30 11:55:26 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:55:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:55:27 --> Email Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:55:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:55:27 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:55:27 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Final output sent to browser
DEBUG - 2015-03-30 11:55:27 --> Total execution time: 2.0141
DEBUG - 2015-03-30 11:55:27 --> Session Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:55:27 --> Session routines successfully run
DEBUG - 2015-03-30 11:55:27 --> Controller Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:55:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:55:27 --> Email Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:55:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:55:27 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:55:27 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:27 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:55:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:55:27 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:55:28 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:55:28 --> Model Class Initialized
ERROR - 2015-03-30 11:55:28 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:55:33 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:55:33 --> URI Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Router Class Initialized
DEBUG - 2015-03-30 11:55:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:55:33 --> Output Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Security Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Input Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:55:33 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Language Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Config Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Loader Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:55:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:55:33 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Session Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:55:33 --> Session routines successfully run
DEBUG - 2015-03-30 11:55:33 --> Controller Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:55:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:55:33 --> Email Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:55:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:55:33 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:55:33 --> Model Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:55:33 --> Final output sent to browser
DEBUG - 2015-03-30 11:55:33 --> Total execution time: 0.4050
DEBUG - 2015-03-30 11:57:02 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:02 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:02 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:02 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:02 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:02 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:02 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:57:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:02 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:57:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:57:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:57:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:02 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:57:03 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:57:03 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:03 --> Total execution time: 0.7720
DEBUG - 2015-03-30 11:57:04 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:04 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:04 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:04 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:04 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:04 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:04 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:04 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:04 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:05 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:05 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:05 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:05 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:05 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:05 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:57:05 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:05 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Model Class Initialized
ERROR - 2015-03-30 11:57:05 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:57:05 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:05 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:05 --> Total execution time: 1.7461
DEBUG - 2015-03-30 11:57:10 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:10 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:10 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:10 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:11 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:11 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:11 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:11 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:57:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:11 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:11 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:11 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:11 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:11 --> Total execution time: 0.3660
DEBUG - 2015-03-30 11:57:46 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:46 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:46 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:46 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:46 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:46 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:46 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:57:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:46 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:57:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:57:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:57:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:46 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:57:47 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:57:47 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:47 --> Total execution time: 0.8360
DEBUG - 2015-03-30 11:57:48 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:49 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:49 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:49 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:49 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:49 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:49 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:49 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:49 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:49 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:49 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:57:49 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:57:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:49 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:49 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:57:49 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:57:50 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:50 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:50 --> Total execution time: 1.5731
DEBUG - 2015-03-30 11:57:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:57:50 --> Model Class Initialized
ERROR - 2015-03-30 11:57:50 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:57:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:57:54 --> URI Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Router Class Initialized
DEBUG - 2015-03-30 11:57:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:57:54 --> Output Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Security Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Input Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:57:54 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Language Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Loader Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:57:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:57:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Session Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:57:54 --> Session routines successfully run
DEBUG - 2015-03-30 11:57:54 --> Controller Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:57:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:57:54 --> Email Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:57:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:57:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:57:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:57:54 --> Final output sent to browser
DEBUG - 2015-03-30 11:57:54 --> Total execution time: 0.3670
DEBUG - 2015-03-30 11:58:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:58:54 --> URI Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Router Class Initialized
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:58:54 --> Output Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Security Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Input Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:58:54 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Loader Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:58:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:58:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Session Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:58:54 --> Session routines successfully run
DEBUG - 2015-03-30 11:58:54 --> Controller Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:58:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:58:54 --> Email Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:58:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:58:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:58:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:58:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:58:54 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:54 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:58:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:58:54 --> Final output sent to browser
DEBUG - 2015-03-30 11:58:54 --> Total execution time: 0.8440
DEBUG - 2015-03-30 11:58:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:58:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:56 --> URI Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Router Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:58:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:58:56 --> URI Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Output Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Security Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Router Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Input Class Initialized
DEBUG - 2015-03-30 11:58:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:58:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Output Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Security Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Input Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:58:56 --> Loader Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:58:56 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:58:56 --> Language Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:58:56 --> Config Class Initialized
DEBUG - 2015-03-30 11:58:56 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:58:57 --> Loader Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:58:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:58:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:58:57 --> Session Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:58:57 --> Session routines successfully run
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:58:57 --> Controller Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:58:57 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:58:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Session Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:58:57 --> Email Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:58:57 --> Session routines successfully run
DEBUG - 2015-03-30 11:58:57 --> Controller Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:58:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:58:57 --> Email Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:58:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:58:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:58:57 --> Final output sent to browser
DEBUG - 2015-03-30 11:58:57 --> Total execution time: 1.3991
DEBUG - 2015-03-30 11:58:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
DEBUG - 2015-03-30 11:58:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:58:57 --> Model Class Initialized
ERROR - 2015-03-30 11:58:57 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:59:02 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:59:02 --> URI Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Router Class Initialized
DEBUG - 2015-03-30 11:59:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:59:02 --> Output Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Security Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Input Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:59:02 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Loader Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:59:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:59:02 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Session Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:59:02 --> Session routines successfully run
DEBUG - 2015-03-30 11:59:02 --> Controller Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:59:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:59:02 --> Email Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:59:02 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:59:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:59:02 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:59:02 --> Final output sent to browser
DEBUG - 2015-03-30 11:59:02 --> Total execution time: 0.3800
DEBUG - 2015-03-30 11:59:38 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:59:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:59:38 --> URI Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Router Class Initialized
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:59:38 --> Output Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Security Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Input Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:59:38 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Loader Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:59:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:59:38 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Session Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:59:38 --> Session routines successfully run
DEBUG - 2015-03-30 11:59:38 --> Controller Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:59:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:59:38 --> Email Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:59:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:59:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:59:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:59:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:59:38 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:38 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 11:59:38 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 11:59:39 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 11:59:39 --> Final output sent to browser
DEBUG - 2015-03-30 11:59:39 --> Total execution time: 0.8040
DEBUG - 2015-03-30 11:59:40 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:59:40 --> URI Class Initialized
DEBUG - 2015-03-30 11:59:40 --> URI Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Router Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Router Class Initialized
DEBUG - 2015-03-30 11:59:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:59:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:59:40 --> Output Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Output Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Security Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Security Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Input Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Input Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:59:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:40 --> Loader Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:59:41 --> Loader Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:59:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:59:41 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Session Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:59:41 --> Session routines successfully run
DEBUG - 2015-03-30 11:59:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:59:41 --> Controller Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:59:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:59:41 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Session Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:59:41 --> Email Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Session routines successfully run
DEBUG - 2015-03-30 11:59:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:59:41 --> Controller Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:59:41 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:59:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Email Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:59:41 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:59:41 --> Final output sent to browser
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Total execution time: 0.9881
DEBUG - 2015-03-30 11:59:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:59:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 11:59:41 --> Model Class Initialized
ERROR - 2015-03-30 11:59:41 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 11:59:46 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Hooks Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Utf8 Class Initialized
DEBUG - 2015-03-30 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 11:59:46 --> URI Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Router Class Initialized
DEBUG - 2015-03-30 11:59:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 11:59:46 --> Output Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Security Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Input Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 11:59:46 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Language Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Config Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Loader Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: url_helper
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: form_helper
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: language_helper
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: user_helper
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: date_helper
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 11:59:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 11:59:46 --> Database Driver Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Session Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: string_helper
DEBUG - 2015-03-30 11:59:46 --> Session routines successfully run
DEBUG - 2015-03-30 11:59:46 --> Controller Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 11:59:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 11:59:46 --> Email Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 11:59:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 11:59:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 11:59:46 --> Model Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Form Validation Class Initialized
DEBUG - 2015-03-30 11:59:46 --> Final output sent to browser
DEBUG - 2015-03-30 11:59:46 --> Total execution time: 0.4220
DEBUG - 2015-03-30 12:00:30 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:30 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:30 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:30 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:30 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:30 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:30 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:00:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:30 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:00:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:00:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:00:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:30 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:00:30 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:00:30 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:30 --> Total execution time: 0.8360
DEBUG - 2015-03-30 12:00:32 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:32 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:32 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:32 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:32 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:33 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:33 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:33 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:33 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:33 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:33 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:33 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:33 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:33 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:33 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:00:33 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:33 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:33 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:33 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Total execution time: 1.6131
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:33 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:33 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:00:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:33 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:33 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:00:33 --> Model Class Initialized
ERROR - 2015-03-30 12:00:33 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:00:39 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:39 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:39 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:39 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:39 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:39 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:39 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:00:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:39 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:39 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:39 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:39 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:39 --> Total execution time: 0.4620
DEBUG - 2015-03-30 12:00:51 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:51 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:51 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:51 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:51 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:51 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:51 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:00:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:51 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:51 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:51 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:00:51 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:00:51 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:00:51 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:51 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:00:52 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:00:52 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:52 --> Total execution time: 0.8400
DEBUG - 2015-03-30 12:00:53 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:53 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:53 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:53 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:53 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:53 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:53 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:54 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:54 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:54 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:54 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:54 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:54 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:00:54 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:54 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:54 --> Total execution time: 1.3521
DEBUG - 2015-03-30 12:00:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:54 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:54 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:00:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:54 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:00:54 --> Model Class Initialized
ERROR - 2015-03-30 12:00:54 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:00:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:00:59 --> URI Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Router Class Initialized
DEBUG - 2015-03-30 12:00:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:00:59 --> Output Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Security Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Input Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:00:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Loader Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:00:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:00:59 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Session Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:00:59 --> Session routines successfully run
DEBUG - 2015-03-30 12:00:59 --> Controller Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:00:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:00:59 --> Email Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:00:59 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:00:59 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:00:59 --> Model Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:00:59 --> Final output sent to browser
DEBUG - 2015-03-30 12:00:59 --> Total execution time: 0.3710
DEBUG - 2015-03-30 12:01:11 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:01:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:01:11 --> URI Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Router Class Initialized
DEBUG - 2015-03-30 12:01:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:01:11 --> Output Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Security Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Input Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:01:11 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Loader Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:01:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:01:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Session Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:01:11 --> Session routines successfully run
DEBUG - 2015-03-30 12:01:11 --> Controller Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:01:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:01:11 --> Email Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:01:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:01:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:01:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:11 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:01:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:01:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:01:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:01:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:12 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:01:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:01:12 --> Final output sent to browser
DEBUG - 2015-03-30 12:01:12 --> Total execution time: 0.8180
DEBUG - 2015-03-30 12:01:13 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:13 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:01:13 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:01:13 --> URI Class Initialized
DEBUG - 2015-03-30 12:01:13 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:13 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:01:13 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:01:13 --> URI Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Router Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Router Class Initialized
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:01:14 --> Output Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Output Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Security Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Security Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Input Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Input Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:01:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:01:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Loader Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Loader Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:01:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:01:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:01:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:01:14 --> Session Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:01:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Session routines successfully run
DEBUG - 2015-03-30 12:01:14 --> Session Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Controller Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:01:14 --> Session routines successfully run
DEBUG - 2015-03-30 12:01:14 --> Controller Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:01:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:01:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:01:14 --> Email Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:01:14 --> Email Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:01:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:01:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:01:14 --> Final output sent to browser
DEBUG - 2015-03-30 12:01:14 --> Total execution time: 0.9361
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:01:14 --> Model Class Initialized
ERROR - 2015-03-30 12:01:14 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:01:19 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:01:19 --> URI Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Router Class Initialized
DEBUG - 2015-03-30 12:01:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:01:19 --> Output Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Security Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Input Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:01:19 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Language Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Config Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Loader Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:01:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:01:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Session Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:01:19 --> Session routines successfully run
DEBUG - 2015-03-30 12:01:19 --> Controller Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:01:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:01:19 --> Email Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:01:19 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:01:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:01:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:01:19 --> Final output sent to browser
DEBUG - 2015-03-30 12:01:19 --> Total execution time: 0.3820
DEBUG - 2015-03-30 12:08:00 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:08:00 --> URI Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Router Class Initialized
DEBUG - 2015-03-30 12:08:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:08:00 --> Output Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Security Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Input Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:08:00 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Loader Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:08:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:08:00 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Session Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:08:00 --> Session routines successfully run
DEBUG - 2015-03-30 12:08:00 --> Controller Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:08:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:08:00 --> Email Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:08:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:08:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:08:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:08:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:08:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:08:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:00 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:08:01 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:08:01 --> Final output sent to browser
DEBUG - 2015-03-30 12:08:01 --> Total execution time: 0.8410
DEBUG - 2015-03-30 12:08:02 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:08:02 --> URI Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Router Class Initialized
DEBUG - 2015-03-30 12:08:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:08:02 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:08:02 --> URI Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Router Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Output Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Security Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Input Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:08:02 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:08:02 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Output Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Security Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Loader Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Input Class Initialized
DEBUG - 2015-03-30 12:08:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:08:02 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:08:02 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:08:03 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:08:03 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:08:03 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:08:03 --> Loader Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:08:03 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:08:03 --> Session Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:08:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:08:03 --> Session routines successfully run
DEBUG - 2015-03-30 12:08:03 --> Controller Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:08:03 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:08:03 --> Session Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:08:03 --> Session routines successfully run
DEBUG - 2015-03-30 12:08:03 --> Email Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Controller Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:08:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:08:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Email Class Initialized
DEBUG - 2015-03-30 12:08:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:08:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:08:03 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:08:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:08:03 --> Model Class Initialized
ERROR - 2015-03-30 12:08:03 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:08:03 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:08:04 --> Final output sent to browser
DEBUG - 2015-03-30 12:08:04 --> Total execution time: 1.5321
DEBUG - 2015-03-30 12:08:10 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:08:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:08:10 --> URI Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Router Class Initialized
DEBUG - 2015-03-30 12:08:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:08:10 --> Output Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Security Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Input Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:08:10 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Language Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Config Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Loader Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:08:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:08:10 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Session Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:08:10 --> Session routines successfully run
DEBUG - 2015-03-30 12:08:10 --> Controller Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:08:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:08:10 --> Email Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:08:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:08:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:08:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:08:10 --> Final output sent to browser
DEBUG - 2015-03-30 12:08:10 --> Total execution time: 0.4150
DEBUG - 2015-03-30 12:10:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:10:09 --> URI Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Router Class Initialized
DEBUG - 2015-03-30 12:10:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:10:09 --> Output Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Security Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Input Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:10:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Loader Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:10:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:10:09 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Session Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:10:09 --> Session routines successfully run
DEBUG - 2015-03-30 12:10:09 --> Controller Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:10:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:10:09 --> Email Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:10:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:10:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:10:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:10:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:10:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:10:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:09 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:10:10 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:10:10 --> Final output sent to browser
DEBUG - 2015-03-30 12:10:10 --> Total execution time: 1.0361
DEBUG - 2015-03-30 12:10:11 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:11 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:10:11 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:10:11 --> URI Class Initialized
DEBUG - 2015-03-30 12:10:11 --> Router Class Initialized
DEBUG - 2015-03-30 12:10:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:10:12 --> Output Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:10:12 --> Security Class Initialized
DEBUG - 2015-03-30 12:10:12 --> URI Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Input Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:10:12 --> Router Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:10:12 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Output Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Security Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Input Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:10:12 --> Loader Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:10:12 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:10:12 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Loader Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:10:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:10:12 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:10:12 --> Session Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:10:12 --> Session routines successfully run
DEBUG - 2015-03-30 12:10:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:10:12 --> Controller Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:10:12 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:10:12 --> Session Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:10:12 --> Email Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:10:12 --> Session routines successfully run
DEBUG - 2015-03-30 12:10:12 --> Controller Class Initialized
DEBUG - 2015-03-30 12:10:12 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:10:12 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:10:13 --> Email Class Initialized
DEBUG - 2015-03-30 12:10:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:10:13 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:10:13 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> Final output sent to browser
DEBUG - 2015-03-30 12:10:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:10:13 --> Total execution time: 1.4701
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:10:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:10:13 --> Model Class Initialized
ERROR - 2015-03-30 12:10:13 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:10:16 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:10:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:10:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:10:16 --> URI Class Initialized
DEBUG - 2015-03-30 12:10:16 --> Router Class Initialized
DEBUG - 2015-03-30 12:10:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:10:17 --> Output Class Initialized
DEBUG - 2015-03-30 12:10:17 --> Security Class Initialized
DEBUG - 2015-03-30 12:10:17 --> Input Class Initialized
DEBUG - 2015-03-30 12:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:10:18 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:18 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:18 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:18 --> Loader Class Initialized
DEBUG - 2015-03-30 12:10:18 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:10:18 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:10:18 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:10:18 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:10:19 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:10:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:10:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:10:19 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:10:19 --> Session Class Initialized
DEBUG - 2015-03-30 12:10:19 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:10:19 --> Session routines successfully run
DEBUG - 2015-03-30 12:10:19 --> Controller Class Initialized
DEBUG - 2015-03-30 12:10:19 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:10:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:10:19 --> Email Class Initialized
DEBUG - 2015-03-30 12:10:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:10:19 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:10:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:10:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:19 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:10:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:10:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:10:19 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:10:19 --> Model Class Initialized
ERROR - 2015-03-30 12:10:19 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:10:20 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:10:20 --> URI Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Router Class Initialized
DEBUG - 2015-03-30 12:10:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:10:20 --> Output Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Security Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Input Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:10:20 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Language Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Config Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Loader Class Initialized
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:10:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:10:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:10:20 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Session Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:10:21 --> Session routines successfully run
DEBUG - 2015-03-30 12:10:21 --> Controller Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:10:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:10:21 --> Email Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:10:21 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:10:21 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:10:21 --> Model Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:10:21 --> Final output sent to browser
DEBUG - 2015-03-30 12:10:21 --> Total execution time: 0.3940
DEBUG - 2015-03-30 12:14:24 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:24 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:14:24 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: string_helper
ERROR - 2015-03-30 12:14:24 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-03-30 12:14:24 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:24 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:14:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:24 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:24 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:25 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:25 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:25 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:14:25 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:25 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 12:14:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:25 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:25 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:25 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:25 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 12:14:25 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 12:14:25 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 12:14:25 --> Final output sent to browser
DEBUG - 2015-03-30 12:14:25 --> Total execution time: 0.4360
DEBUG - 2015-03-30 12:14:44 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:44 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:44 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:44 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:44 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:14:44 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:44 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:44 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 12:14:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:44 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:45 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:45 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 12:14:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-30 12:14:45 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:45 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:45 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-03-30 12:14:45 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:45 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:45 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:14:45 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:45 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:45 --> Customer MX_Controller Initialized
DEBUG - 2015-03-30 12:14:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:45 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:46 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:46 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:46 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:46 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-03-30 12:14:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-03-30 12:14:46 --> Final output sent to browser
DEBUG - 2015-03-30 12:14:46 --> Total execution time: 0.5170
DEBUG - 2015-03-30 12:14:46 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:46 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:46 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:46 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:46 --> Router Class Initialized
ERROR - 2015-03-30 12:14:46 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 12:14:55 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:55 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:14:55 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:55 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:55 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:14:55 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:55 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:14:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:55 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:55 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:55 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:55 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:55 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:14:55 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:14:56 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:14:56 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:14:56 --> Final output sent to browser
DEBUG - 2015-03-30 12:14:56 --> Total execution time: 0.6750
DEBUG - 2015-03-30 12:14:56 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:56 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Config Class Initialized
ERROR - 2015-03-30 12:14:56 --> 404 Page Not Found --> 
DEBUG - 2015-03-30 12:14:56 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:14:56 --> URI Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Router Class Initialized
DEBUG - 2015-03-30 12:14:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:14:56 --> Output Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Security Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Input Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:14:56 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Language Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Config Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Loader Class Initialized
DEBUG - 2015-03-30 12:14:56 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:14:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:14:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Session Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:14:57 --> Session routines successfully run
DEBUG - 2015-03-30 12:14:57 --> Controller Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:14:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:14:57 --> Email Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:14:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:14:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:14:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:14:57 --> Final output sent to browser
DEBUG - 2015-03-30 12:14:57 --> Total execution time: 0.8150
DEBUG - 2015-03-30 12:15:07 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:15:07 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:15:07 --> URI Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Router Class Initialized
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:15:07 --> Output Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Security Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Input Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:15:07 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Loader Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:15:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:15:07 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Session Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:15:07 --> Session routines successfully run
DEBUG - 2015-03-30 12:15:07 --> Controller Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:15:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:15:07 --> Email Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:15:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:15:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:15:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:15:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:15:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:07 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:15:07 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:15:07 --> Final output sent to browser
DEBUG - 2015-03-30 12:15:07 --> Total execution time: 0.8340
DEBUG - 2015-03-30 12:15:08 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:15:08 --> URI Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Router Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:15:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:15:08 --> Output Class Initialized
DEBUG - 2015-03-30 12:15:08 --> URI Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Security Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Router Class Initialized
DEBUG - 2015-03-30 12:15:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:15:08 --> Input Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:15:08 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Output Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Security Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Input Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:15:08 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Loader Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:15:08 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:15:08 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:15:08 --> Loader Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:15:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:15:08 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:15:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:15:08 --> Session Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:15:08 --> Session routines successfully run
DEBUG - 2015-03-30 12:15:08 --> Controller Class Initialized
DEBUG - 2015-03-30 12:15:08 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:15:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:15:08 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Session Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Email Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:15:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:15:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:15:09 --> Session routines successfully run
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Controller Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:15:09 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:15:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:15:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:15:09 --> Email Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:15:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:15:09 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:15:09 --> Model Class Initialized
ERROR - 2015-03-30 12:15:09 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:15:09 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:15:09 --> Final output sent to browser
DEBUG - 2015-03-30 12:15:09 --> Total execution time: 1.0631
DEBUG - 2015-03-30 12:15:13 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:15:13 --> URI Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Router Class Initialized
DEBUG - 2015-03-30 12:15:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:15:13 --> Output Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Security Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Input Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:15:13 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Language Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Config Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Loader Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:15:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:15:13 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Session Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:15:13 --> Session routines successfully run
DEBUG - 2015-03-30 12:15:13 --> Controller Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:15:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:15:13 --> Email Class Initialized
DEBUG - 2015-03-30 12:15:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:15:13 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:15:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:15:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:15:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:15:14 --> Final output sent to browser
DEBUG - 2015-03-30 12:15:14 --> Total execution time: 0.6250
DEBUG - 2015-03-30 12:17:45 --> Config Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:17:45 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:17:45 --> URI Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Router Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Output Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Security Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Input Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:17:45 --> Language Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Language Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Config Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Loader Class Initialized
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:17:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:17:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:17:46 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Session Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:17:46 --> Session routines successfully run
DEBUG - 2015-03-30 12:17:46 --> Controller Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 12:17:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:17:46 --> Email Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:17:46 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:17:46 --> Model Class Initialized
DEBUG - 2015-03-30 12:17:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:17:46 --> Model Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:17:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 12:17:46 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 12:17:46 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 12:17:46 --> Final output sent to browser
DEBUG - 2015-03-30 12:17:46 --> Total execution time: 0.4740
DEBUG - 2015-03-30 12:19:25 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:19:25 --> URI Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Router Class Initialized
DEBUG - 2015-03-30 12:19:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:19:25 --> Output Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Security Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Input Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:19:25 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Loader Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:19:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:19:25 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Session Class Initialized
DEBUG - 2015-03-30 12:19:25 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:19:25 --> Session routines successfully run
DEBUG - 2015-03-30 12:19:25 --> Controller Class Initialized
DEBUG - 2015-03-30 12:19:26 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:19:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:19:26 --> Email Class Initialized
DEBUG - 2015-03-30 12:19:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:19:26 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:19:26 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:19:26 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:26 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:19:26 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:19:26 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:19:26 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:26 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:19:26 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:19:26 --> Final output sent to browser
DEBUG - 2015-03-30 12:19:26 --> Total execution time: 0.8740
DEBUG - 2015-03-30 12:19:27 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:19:27 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:19:27 --> URI Class Initialized
DEBUG - 2015-03-30 12:19:27 --> URI Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Router Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Router Class Initialized
DEBUG - 2015-03-30 12:19:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:19:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:19:27 --> Output Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Security Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Input Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:19:27 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Output Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Security Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Input Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:19:27 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:27 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Loader Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:19:28 --> Loader Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:19:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:19:28 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:19:28 --> Session Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:19:28 --> Session routines successfully run
DEBUG - 2015-03-30 12:19:28 --> Controller Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:19:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:19:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:19:28 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Email Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:19:28 --> Session Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:19:28 --> Session routines successfully run
DEBUG - 2015-03-30 12:19:28 --> Controller Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:19:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:19:28 --> Email Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:19:28 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:19:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:19:28 --> Final output sent to browser
DEBUG - 2015-03-30 12:19:28 --> Total execution time: 1.1311
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:19:28 --> Model Class Initialized
ERROR - 2015-03-30 12:19:28 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:19:32 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:19:32 --> URI Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Router Class Initialized
DEBUG - 2015-03-30 12:19:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:19:32 --> Output Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Security Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Input Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:19:32 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Loader Class Initialized
DEBUG - 2015-03-30 12:19:32 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:19:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:19:33 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:19:33 --> Session Class Initialized
DEBUG - 2015-03-30 12:19:33 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:19:33 --> Session routines successfully run
DEBUG - 2015-03-30 12:19:33 --> Controller Class Initialized
DEBUG - 2015-03-30 12:19:33 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:19:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:19:34 --> Email Class Initialized
DEBUG - 2015-03-30 12:19:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:19:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:19:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:19:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:19:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:19:35 --> URI Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Router Class Initialized
DEBUG - 2015-03-30 12:19:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:19:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:19:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:19:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Output Class Initialized
DEBUG - 2015-03-30 12:19:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:19:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Security Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Input Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Global POST and COOKIE data sanitized
ERROR - 2015-03-30 12:19:35 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:19:35 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Language Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Config Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Loader Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:19:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:19:35 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Session Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:19:35 --> Session routines successfully run
DEBUG - 2015-03-30 12:19:35 --> Controller Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:19:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:19:35 --> Email Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:19:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:19:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:19:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:19:35 --> Final output sent to browser
DEBUG - 2015-03-30 12:19:35 --> Total execution time: 0.7400
DEBUG - 2015-03-30 12:27:28 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:27:28 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:27:28 --> URI Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Router Class Initialized
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:27:28 --> Output Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Security Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Input Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:27:28 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Loader Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:27:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:27:28 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Session Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:27:28 --> Session routines successfully run
DEBUG - 2015-03-30 12:27:28 --> Controller Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:27:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:27:28 --> Email Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:27:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:27:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:27:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:27:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:27:28 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:28 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:27:28 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:27:28 --> Final output sent to browser
DEBUG - 2015-03-30 12:27:28 --> Total execution time: 0.8000
DEBUG - 2015-03-30 12:27:29 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:29 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:27:29 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:27:29 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:27:29 --> URI Class Initialized
DEBUG - 2015-03-30 12:27:29 --> Router Class Initialized
DEBUG - 2015-03-30 12:27:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:27:30 --> Output Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Security Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Input Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:27:30 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Loader Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:27:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:27:30 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Session Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:27:30 --> Session routines successfully run
DEBUG - 2015-03-30 12:27:30 --> Controller Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:27:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:27:30 --> Email Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:27:30 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:27:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:27:30 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:30 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:27:31 --> Final output sent to browser
DEBUG - 2015-03-30 12:27:31 --> Total execution time: 1.2541
DEBUG - 2015-03-30 12:27:31 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:31 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:27:31 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:27:31 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:27:31 --> URI Class Initialized
DEBUG - 2015-03-30 12:27:31 --> Router Class Initialized
DEBUG - 2015-03-30 12:27:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:27:32 --> Output Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Security Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Input Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:27:32 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Loader Class Initialized
DEBUG - 2015-03-30 12:27:32 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:27:32 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:27:32 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:27:32 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:27:32 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:27:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:27:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:27:33 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:27:33 --> Session Class Initialized
DEBUG - 2015-03-30 12:27:33 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:27:33 --> Session routines successfully run
DEBUG - 2015-03-30 12:27:33 --> Controller Class Initialized
DEBUG - 2015-03-30 12:27:33 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:27:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:27:33 --> Email Class Initialized
DEBUG - 2015-03-30 12:27:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:27:33 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:27:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:27:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:33 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:27:33 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:27:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:27:33 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:33 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:27:34 --> Model Class Initialized
ERROR - 2015-03-30 12:27:34 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:27:34 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:27:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:27:34 --> URI Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Router Class Initialized
DEBUG - 2015-03-30 12:27:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:27:34 --> Output Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Security Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Input Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:27:34 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Language Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Config Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Loader Class Initialized
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:27:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:27:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:27:34 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Session Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:27:35 --> Session routines successfully run
DEBUG - 2015-03-30 12:27:35 --> Controller Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:27:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:27:35 --> Email Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:27:35 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:27:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:27:35 --> Model Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:27:35 --> Final output sent to browser
DEBUG - 2015-03-30 12:27:35 --> Total execution time: 0.6430
DEBUG - 2015-03-30 12:28:57 --> Config Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:28:57 --> URI Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Router Class Initialized
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:28:57 --> Output Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Security Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Input Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:28:57 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Config Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Loader Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:28:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:28:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Session Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:28:57 --> Session routines successfully run
DEBUG - 2015-03-30 12:28:57 --> Controller Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:28:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:28:57 --> Email Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:28:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:28:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:28:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:28:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:28:57 --> Model Class Initialized
DEBUG - 2015-03-30 12:28:57 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:28:57 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:28:57 --> Final output sent to browser
DEBUG - 2015-03-30 12:28:57 --> Total execution time: 0.8440
DEBUG - 2015-03-30 12:28:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:28:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:28:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:28:59 --> URI Class Initialized
DEBUG - 2015-03-30 12:28:59 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:28:59 --> URI Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Router Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Router Class Initialized
DEBUG - 2015-03-30 12:28:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:28:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:28:59 --> Output Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Security Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Input Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Output Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:28:59 --> Security Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Input Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:28:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Language Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Loader Class Initialized
DEBUG - 2015-03-30 12:28:59 --> Config Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:29:00 --> Loader Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:29:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:29:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:29:00 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Session Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:29:00 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Session Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Session routines successfully run
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:29:00 --> Session routines successfully run
DEBUG - 2015-03-30 12:29:00 --> Controller Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Controller Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:29:00 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:29:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:29:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:29:00 --> Email Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Email Class Initialized
DEBUG - 2015-03-30 12:29:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:29:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:29:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:29:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:29:00 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:00 --> Form Validation Class Initialized
ERROR - 2015-03-30 12:29:00 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:29:00 --> Final output sent to browser
DEBUG - 2015-03-30 12:29:00 --> Total execution time: 1.1781
DEBUG - 2015-03-30 12:29:04 --> Config Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:29:04 --> URI Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Router Class Initialized
DEBUG - 2015-03-30 12:29:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:29:04 --> Output Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Security Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Input Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:29:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Config Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Loader Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:29:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:29:04 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Session Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:29:04 --> Session routines successfully run
DEBUG - 2015-03-30 12:29:04 --> Controller Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:29:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:29:04 --> Email Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:29:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:29:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:29:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:29:04 --> Final output sent to browser
DEBUG - 2015-03-30 12:29:04 --> Total execution time: 0.3810
DEBUG - 2015-03-30 12:33:01 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:33:01 --> URI Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Router Class Initialized
DEBUG - 2015-03-30 12:33:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:33:01 --> Output Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Security Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Input Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:33:01 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Loader Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:33:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:33:01 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Session Class Initialized
DEBUG - 2015-03-30 12:33:01 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:33:01 --> Session routines successfully run
DEBUG - 2015-03-30 12:33:01 --> Controller Class Initialized
DEBUG - 2015-03-30 12:33:02 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:33:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:33:02 --> Email Class Initialized
DEBUG - 2015-03-30 12:33:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:33:02 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:33:02 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:33:02 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:02 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:33:02 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:33:02 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:33:02 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:02 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:33:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:33:02 --> Final output sent to browser
DEBUG - 2015-03-30 12:33:02 --> Total execution time: 0.9120
DEBUG - 2015-03-30 12:33:03 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:33:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:33:03 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:33:03 --> URI Class Initialized
DEBUG - 2015-03-30 12:33:03 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:33:03 --> URI Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Router Class Initialized
DEBUG - 2015-03-30 12:33:03 --> Router Class Initialized
DEBUG - 2015-03-30 12:33:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:33:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:33:04 --> Output Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Output Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Security Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Security Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Input Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:33:04 --> Input Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:33:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Loader Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:33:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:33:04 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Loader Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:33:04 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:33:04 --> Session Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:33:04 --> Session routines successfully run
DEBUG - 2015-03-30 12:33:04 --> Controller Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:33:04 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:33:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:33:04 --> Email Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:33:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:33:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:33:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Session Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:33:04 --> Session routines successfully run
DEBUG - 2015-03-30 12:33:04 --> Controller Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:33:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:33:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:33:04 --> Email Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:33:04 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:33:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:33:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:33:04 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:33:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:33:05 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:05 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:05 --> Form Validation Class Initialized
ERROR - 2015-03-30 12:33:05 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:33:05 --> Final output sent to browser
DEBUG - 2015-03-30 12:33:05 --> Total execution time: 1.2801
DEBUG - 2015-03-30 12:33:06 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:33:06 --> URI Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Router Class Initialized
DEBUG - 2015-03-30 12:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:33:06 --> Output Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Security Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Input Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:33:06 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Loader Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:33:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:33:06 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Session Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:33:06 --> Session routines successfully run
DEBUG - 2015-03-30 12:33:06 --> Controller Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:33:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:33:06 --> Email Class Initialized
DEBUG - 2015-03-30 12:33:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:33:06 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:33:06 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:33:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:07 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:33:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:33:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:33:07 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:33:07 --> Model Class Initialized
ERROR - 2015-03-30 12:33:07 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:33:11 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:33:11 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:33:11 --> URI Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Router Class Initialized
DEBUG - 2015-03-30 12:33:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:33:11 --> Output Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Security Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Input Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:33:11 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Language Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Config Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Loader Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:33:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:33:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Session Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:33:11 --> Session routines successfully run
DEBUG - 2015-03-30 12:33:11 --> Controller Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:33:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:33:11 --> Email Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:33:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:33:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:33:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:33:11 --> Final output sent to browser
DEBUG - 2015-03-30 12:33:11 --> Total execution time: 0.4440
DEBUG - 2015-03-30 12:37:37 --> Config Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:37:37 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:37:37 --> URI Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Router Class Initialized
DEBUG - 2015-03-30 12:37:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:37:37 --> Output Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Security Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Input Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:37:37 --> Language Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Language Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Config Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Loader Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:37:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:37:37 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Session Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:37:37 --> Session routines successfully run
DEBUG - 2015-03-30 12:37:37 --> Controller Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Session Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Session routines successfully run
DEBUG - 2015-03-30 12:37:37 --> Controller Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:37:37 --> Model Class Initialized
DEBUG - 2015-03-30 12:37:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:37:37 --> Model Class Initialized
DEBUG - 2015-03-30 12:37:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:37:37 --> Email Class Initialized
ERROR - 2015-03-30 12:37:37 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-03-30 12:37:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:37:37 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:37:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:37:37 --> Model Class Initialized
ERROR - 2015-03-30 12:37:37 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-03-30 12:37:37 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-03-30 12:37:37 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-03-30 12:37:37 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-03-30 12:39:52 --> Config Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Config Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:39:52 --> URI Class Initialized
DEBUG - 2015-03-30 12:39:52 --> URI Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Router Class Initialized
DEBUG - 2015-03-30 12:39:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:39:52 --> Router Class Initialized
DEBUG - 2015-03-30 12:39:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:39:52 --> Output Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Security Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Output Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Input Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Security Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Input Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:39:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Config Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Config Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Loader Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:39:52 --> Loader Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:39:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:39:52 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:39:52 --> Session Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:39:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:39:52 --> Session routines successfully run
DEBUG - 2015-03-30 12:39:52 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Controller Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Session Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:39:52 --> Session routines successfully run
DEBUG - 2015-03-30 12:39:52 --> Controller Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:39:52 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:39:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:39:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:39:52 --> Email Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Email Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:39:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:39:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:39:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:39:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:39:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:39:53 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:39:53 --> Model Class Initialized
DEBUG - 2015-03-30 12:39:53 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:40:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:40:09 --> URI Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Router Class Initialized
DEBUG - 2015-03-30 12:40:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:40:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Output Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Security Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Input Class Initialized
DEBUG - 2015-03-30 12:40:09 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:40:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:40:09 --> URI Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Router Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:40:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:40:09 --> Loader Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:40:09 --> Output Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Security Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:40:09 --> Input Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:40:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:40:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:40:09 --> Language Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Config Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Loader Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Session Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:40:09 --> Session routines successfully run
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:40:09 --> Controller Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:40:09 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:40:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:40:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:40:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:40:09 --> Email Class Initialized
DEBUG - 2015-03-30 12:40:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:40:10 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Session Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:40:10 --> Session routines successfully run
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Controller Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:40:10 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:40:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Email Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:40:10 --> Model Class Initialized
DEBUG - 2015-03-30 12:40:10 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:41:10 --> Config Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:41:10 --> URI Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Router Class Initialized
DEBUG - 2015-03-30 12:41:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:41:10 --> Output Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Security Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Input Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:41:10 --> Language Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Language Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Config Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Loader Class Initialized
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:41:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:41:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:41:11 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Session Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:41:11 --> Session routines successfully run
DEBUG - 2015-03-30 12:41:11 --> Controller Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:41:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:41:11 --> Email Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:41:11 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:41:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:41:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:41:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:41:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:41:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:41:11 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:11 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:41:11 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-03-30 12:41:11 --> Final output sent to browser
DEBUG - 2015-03-30 12:41:11 --> Total execution time: 0.8330
DEBUG - 2015-03-30 12:41:22 --> Config Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:41:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:41:22 --> URI Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Router Class Initialized
DEBUG - 2015-03-30 12:41:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:41:22 --> Output Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Security Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Input Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:41:22 --> Language Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Language Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Config Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Loader Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:41:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:41:22 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Session Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:41:22 --> Session routines successfully run
DEBUG - 2015-03-30 12:41:22 --> Controller Class Initialized
DEBUG - 2015-03-30 12:41:22 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:41:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:41:23 --> Email Class Initialized
DEBUG - 2015-03-30 12:41:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:41:23 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:41:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-30 12:41:23 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-03-30 12:41:23 --> Model Class Initialized
DEBUG - 2015-03-30 12:41:23 --> FTP Class Initialized
ERROR - 2015-03-30 12:41:23 --> Severity: Notice  --> Undefined property: CI::$ftp C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-03-30 12:41:27 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-03-30 12:41:27 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:41:27 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-03-30 12:41:27 --> Final output sent to browser
DEBUG - 2015-03-30 12:41:27 --> Total execution time: 4.8320
DEBUG - 2015-03-30 12:42:23 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:23 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:24 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:24 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:24 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:24 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:24 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:24 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:24 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:24 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:24 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:24 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:24 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:42:24 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:42:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:24 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:24 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:42:24 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:42:34 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:34 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:34 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:34 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:34 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:34 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:34 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:34 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:42:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:34 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:42:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:42:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:42:34 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:34 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 12:42:34 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 12:42:34 --> Final output sent to browser
DEBUG - 2015-03-30 12:42:34 --> Total execution time: 0.7880
DEBUG - 2015-03-30 12:42:35 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:35 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:35 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:35 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:35 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:35 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:35 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:35 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:35 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:36 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:36 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:36 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:36 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:36 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:36 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:36 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:36 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:36 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:36 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:36 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:42:36 --> Final output sent to browser
DEBUG - 2015-03-30 12:42:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:36 --> Total execution time: 1.1511
DEBUG - 2015-03-30 12:42:36 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:42:36 --> Model Class Initialized
ERROR - 2015-03-30 12:42:36 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 12:42:36 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:42:36 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:42:36 --> URI Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Router Class Initialized
DEBUG - 2015-03-30 12:42:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:42:36 --> Output Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Security Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Input Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:42:36 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Language Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Config Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Loader Class Initialized
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:42:36 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:42:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:42:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:42:37 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Session Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:42:37 --> Session routines successfully run
DEBUG - 2015-03-30 12:42:37 --> Controller Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 12:42:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:42:37 --> Email Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:42:37 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:42:37 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:42:37 --> Model Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:42:37 --> Final output sent to browser
DEBUG - 2015-03-30 12:42:37 --> Total execution time: 0.4210
DEBUG - 2015-03-30 12:43:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:43:14 --> URI Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Router Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:43:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Output Class Initialized
DEBUG - 2015-03-30 12:43:14 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:43:14 --> Security Class Initialized
DEBUG - 2015-03-30 12:43:14 --> URI Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Input Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:43:14 --> Router Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:43:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Output Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Loader Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Security Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:43:14 --> Input Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:43:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:43:14 --> Language Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:43:14 --> Config Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:43:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:43:14 --> Loader Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:43:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:43:14 --> Session Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:43:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:43:14 --> Session routines successfully run
DEBUG - 2015-03-30 12:43:14 --> Controller Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:43:14 --> Session Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:43:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:43:14 --> Session routines successfully run
DEBUG - 2015-03-30 12:43:14 --> Controller Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Email Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:43:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:43:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:43:14 --> Email Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:43:14 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:43:14 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:43:14 --> Model Class Initialized
DEBUG - 2015-03-30 12:43:14 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 12:53:51 --> Config Class Initialized
DEBUG - 2015-03-30 12:53:51 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:53:51 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:53:51 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:53:51 --> URI Class Initialized
DEBUG - 2015-03-30 12:53:51 --> Router Class Initialized
DEBUG - 2015-03-30 12:53:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:53:52 --> Output Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Security Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Input Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:53:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Language Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Config Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Loader Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:53:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:53:52 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Session Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:53:52 --> Session routines successfully run
DEBUG - 2015-03-30 12:53:52 --> Controller Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:53:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:53:52 --> Email Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:53:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:53:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:53:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:53:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:53:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:53:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:53:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:53:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:53:52 --> Model Class Initialized
DEBUG - 2015-03-30 12:53:52 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:53:52 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-03-30 12:53:52 --> Final output sent to browser
DEBUG - 2015-03-30 12:53:52 --> Total execution time: 0.8630
DEBUG - 2015-03-30 12:54:57 --> Config Class Initialized
DEBUG - 2015-03-30 12:54:57 --> Hooks Class Initialized
DEBUG - 2015-03-30 12:54:57 --> Utf8 Class Initialized
DEBUG - 2015-03-30 12:54:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 12:54:57 --> URI Class Initialized
DEBUG - 2015-03-30 12:54:57 --> Router Class Initialized
DEBUG - 2015-03-30 12:54:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 12:54:57 --> Output Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Security Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Input Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 12:54:58 --> Language Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Language Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Config Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Loader Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: url_helper
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: form_helper
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: language_helper
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: user_helper
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: date_helper
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 12:54:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 12:54:58 --> Database Driver Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Session Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: string_helper
DEBUG - 2015-03-30 12:54:58 --> Session routines successfully run
DEBUG - 2015-03-30 12:54:58 --> Controller Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 12:54:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 12:54:58 --> Email Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 12:54:58 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Form Validation Class Initialized
DEBUG - 2015-03-30 12:54:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-03-30 12:54:58 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-03-30 12:54:58 --> Model Class Initialized
DEBUG - 2015-03-30 12:54:58 --> FTP Class Initialized
ERROR - 2015-03-30 12:54:58 --> Severity: Notice  --> Undefined property: CI::$ftp C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-03-30 12:55:01 --> Severity: Warning  --> ftp_connect(): php_network_getaddresses: getaddrinfo failed: This is usually a temporary error during hostname resolution and means that the local server did not receive a response from an authoritative server.  C:\xampp\htdocs\ecampaign247\system\libraries\Ftp.php 93
DEBUG - 2015-03-30 12:55:01 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-03-30 12:55:01 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 12:55:01 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-03-30 12:55:01 --> Final output sent to browser
DEBUG - 2015-03-30 12:55:01 --> Total execution time: 3.7440
DEBUG - 2015-03-30 13:40:20 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:20 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:20 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:20 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:20 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:20 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:20 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:20 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:40:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:20 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:20 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:20 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:40:20 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:40:20 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:40:20 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:20 --> Helper loaded: directory_helper
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-03-30 13:40:21 --> Final output sent to browser
DEBUG - 2015-03-30 13:40:21 --> Total execution time: 0.7470
DEBUG - 2015-03-30 13:40:21 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:21 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:21 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:21 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:21 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:22 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:22 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:22 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:22 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:22 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:22 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:22 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:22 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:22 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:22 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:22 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:22 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:22 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:22 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:22 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:22 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:22 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:22 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:22 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:40:22 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:22 --> Final output sent to browser
ERROR - 2015-03-30 13:40:22 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-03-30 13:40:23 --> Total execution time: 0.8981
DEBUG - 2015-03-30 13:40:26 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:26 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:26 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:26 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:26 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:26 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:27 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:27 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Getelements MX_Controller Initialized
DEBUG - 2015-03-30 13:40:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:27 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:27 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:27 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:27 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:27 --> Final output sent to browser
DEBUG - 2015-03-30 13:40:27 --> Total execution time: 0.5440
DEBUG - 2015-03-30 13:40:48 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:48 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:48 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:48 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:48 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:48 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:49 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:40:49 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:40:49 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:49 --> URI Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Router Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:40:49 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:49 --> Output Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Security Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Input Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:40:49 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:49 --> Language Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Config Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:49 --> Loader Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:40:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:40:49 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:40:49 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:40:49 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:40:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:40:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:40:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:49 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Session Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:40:49 --> Session routines successfully run
DEBUG - 2015-03-30 13:40:49 --> Controller Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Email Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 13:40:49 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:40:49 --> Model Class Initialized
DEBUG - 2015-03-30 13:40:49 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 13:41:16 --> Config Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:41:16 --> URI Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Router Class Initialized
DEBUG - 2015-03-30 13:41:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:41:16 --> Output Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Security Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Input Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:41:16 --> Language Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Language Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Config Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Loader Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:41:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:41:16 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Session Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:41:16 --> Session routines successfully run
DEBUG - 2015-03-30 13:41:16 --> Controller Class Initialized
DEBUG - 2015-03-30 13:41:16 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:41:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:41:17 --> Email Class Initialized
DEBUG - 2015-03-30 13:41:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:41:17 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:41:17 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:41:17 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:17 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:41:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:41:17 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:41:17 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:41:17 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:17 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 13:41:54 --> Config Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:41:54 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:41:54 --> URI Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Router Class Initialized
DEBUG - 2015-03-30 13:41:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:41:54 --> Output Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Security Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Input Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:41:54 --> Language Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Language Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Config Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Loader Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:41:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:41:54 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Session Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:41:54 --> Session routines successfully run
DEBUG - 2015-03-30 13:41:54 --> Controller Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:41:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:41:54 --> Email Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:41:54 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:41:54 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:41:54 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:54 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:41:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:41:54 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:41:54 --> Model Class Initialized
DEBUG - 2015-03-30 13:41:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:41:54 --> Model Class Initialized
ERROR - 2015-03-30 13:41:54 --> 404 Page Not Found --> sites/sitessave
DEBUG - 2015-03-30 13:42:00 --> Config Class Initialized
DEBUG - 2015-03-30 13:42:00 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:42:00 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:42:00 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:42:00 --> URI Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Router Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:42:01 --> Output Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Security Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Input Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:42:01 --> Language Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Language Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Config Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Loader Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:42:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:42:01 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Session Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:42:01 --> Session routines successfully run
DEBUG - 2015-03-30 13:42:01 --> Controller Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:42:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:42:01 --> Email Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:42:01 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:42:01 --> Model Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:42:01 --> Model Class Initialized
DEBUG - 2015-03-30 13:42:01 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:42:01 --> Model Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:42:01 --> Model Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:42:01 --> Model Class Initialized
DEBUG - 2015-03-30 13:42:01 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 13:44:50 --> Config Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:44:50 --> URI Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Router Class Initialized
DEBUG - 2015-03-30 13:44:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:44:50 --> Output Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Security Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Input Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:44:50 --> Language Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Language Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Config Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Loader Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:44:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:44:50 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Session Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:44:50 --> Session routines successfully run
DEBUG - 2015-03-30 13:44:50 --> Controller Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:44:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:44:50 --> Email Class Initialized
DEBUG - 2015-03-30 13:44:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:44:50 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:44:51 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:44:51 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:51 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:44:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:44:51 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:44:51 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:44:51 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:51 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 13:44:57 --> Config Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Hooks Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Utf8 Class Initialized
DEBUG - 2015-03-30 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 13:44:57 --> URI Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Router Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-03-30 13:44:57 --> Output Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Security Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Input Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 13:44:57 --> Language Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Language Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Config Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Loader Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: url_helper
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: form_helper
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: language_helper
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: user_helper
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: date_helper
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 13:44:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 13:44:57 --> Database Driver Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Session Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: string_helper
DEBUG - 2015-03-30 13:44:57 --> Session routines successfully run
DEBUG - 2015-03-30 13:44:57 --> Controller Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Sites MX_Controller Initialized
DEBUG - 2015-03-30 13:44:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 13:44:57 --> Email Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 13:44:57 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 13:44:57 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 13:44:57 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:57 --> Form Validation Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-03-30 13:44:57 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-03-30 13:44:57 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-03-30 13:44:57 --> Model Class Initialized
DEBUG - 2015-03-30 13:44:57 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-03-30 14:08:38 --> Config Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Hooks Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Utf8 Class Initialized
DEBUG - 2015-03-30 14:08:38 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 14:08:38 --> URI Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Router Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Output Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Security Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Input Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 14:08:38 --> Language Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Language Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Config Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Loader Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: url_helper
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: form_helper
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: language_helper
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: user_helper
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: date_helper
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 14:08:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 14:08:38 --> Database Driver Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Session Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: string_helper
DEBUG - 2015-03-30 14:08:38 --> Session routines successfully run
DEBUG - 2015-03-30 14:08:38 --> Controller Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 14:08:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 14:08:38 --> Email Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 14:08:38 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 14:08:38 --> Model Class Initialized
DEBUG - 2015-03-30 14:08:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 14:08:38 --> Model Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Form Validation Class Initialized
DEBUG - 2015-03-30 14:08:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 14:08:39 --> Config Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Hooks Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Utf8 Class Initialized
DEBUG - 2015-03-30 14:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-03-30 14:08:39 --> URI Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Router Class Initialized
DEBUG - 2015-03-30 14:08:39 --> No URI present. Default controller set.
DEBUG - 2015-03-30 14:08:39 --> Output Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Security Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Input Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-03-30 14:08:39 --> Language Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Language Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Config Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Loader Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: url_helper
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: form_helper
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: language_helper
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: user_helper
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: date_helper
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-03-30 14:08:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-03-30 14:08:39 --> Database Driver Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Session Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: string_helper
DEBUG - 2015-03-30 14:08:39 --> Session routines successfully run
DEBUG - 2015-03-30 14:08:39 --> Controller Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Login MX_Controller Initialized
DEBUG - 2015-03-30 14:08:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-03-30 14:08:39 --> Email Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-03-30 14:08:39 --> Helper loaded: cookie_helper
DEBUG - 2015-03-30 14:08:39 --> Model Class Initialized
DEBUG - 2015-03-30 14:08:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-03-30 14:08:39 --> Model Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Form Validation Class Initialized
DEBUG - 2015-03-30 14:08:39 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-03-30 14:08:39 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-03-30 14:08:39 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-03-30 14:08:39 --> Final output sent to browser
DEBUG - 2015-03-30 14:08:39 --> Total execution time: 0.4360
