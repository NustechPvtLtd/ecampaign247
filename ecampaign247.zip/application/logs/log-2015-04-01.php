<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-01 06:08:46 --> Config Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Hooks Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Utf8 Class Initialized
DEBUG - 2015-04-01 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 06:08:46 --> URI Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Router Class Initialized
DEBUG - 2015-04-01 06:08:46 --> No URI present. Default controller set.
DEBUG - 2015-04-01 06:08:46 --> Output Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Security Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Input Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 06:08:46 --> Language Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Language Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Config Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Loader Class Initialized
DEBUG - 2015-04-01 06:08:46 --> Helper loaded: url_helper
DEBUG - 2015-04-01 06:08:46 --> Helper loaded: form_helper
DEBUG - 2015-04-01 06:08:47 --> Helper loaded: language_helper
DEBUG - 2015-04-01 06:08:47 --> Helper loaded: user_helper
DEBUG - 2015-04-01 06:08:47 --> Helper loaded: date_helper
DEBUG - 2015-04-01 06:08:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 06:08:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 06:08:47 --> Database Driver Class Initialized
DEBUG - 2015-04-01 06:08:48 --> Session Class Initialized
DEBUG - 2015-04-01 06:08:48 --> Helper loaded: string_helper
DEBUG - 2015-04-01 06:08:48 --> A session cookie was not found.
DEBUG - 2015-04-01 06:08:48 --> Session routines successfully run
DEBUG - 2015-04-01 06:08:48 --> Controller Class Initialized
DEBUG - 2015-04-01 06:08:48 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 06:08:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 06:08:49 --> Email Class Initialized
DEBUG - 2015-04-01 06:08:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 06:08:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 06:08:49 --> Model Class Initialized
DEBUG - 2015-04-01 06:08:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 06:08:49 --> Model Class Initialized
DEBUG - 2015-04-01 06:08:49 --> Form Validation Class Initialized
DEBUG - 2015-04-01 06:08:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 06:08:49 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-01 06:08:49 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-01 06:08:49 --> Final output sent to browser
DEBUG - 2015-04-01 06:08:49 --> Total execution time: 3.5220
DEBUG - 2015-04-01 06:09:55 --> Config Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 06:09:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 06:09:55 --> URI Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Router Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Output Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Security Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Input Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 06:09:55 --> Language Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Language Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Config Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Loader Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: url_helper
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: form_helper
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: language_helper
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: user_helper
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: date_helper
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 06:09:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 06:09:55 --> Database Driver Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Session Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: string_helper
DEBUG - 2015-04-01 06:09:55 --> Session routines successfully run
DEBUG - 2015-04-01 06:09:55 --> Controller Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 06:09:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 06:09:55 --> Email Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 06:09:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 06:09:55 --> Model Class Initialized
DEBUG - 2015-04-01 06:09:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 06:09:55 --> Model Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 06:09:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 06:09:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 06:09:56 --> Config Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Hooks Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Utf8 Class Initialized
DEBUG - 2015-04-01 06:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 06:09:56 --> URI Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Router Class Initialized
DEBUG - 2015-04-01 06:09:56 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-01 06:09:56 --> Output Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Security Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Input Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 06:09:56 --> Language Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Language Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Config Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Loader Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: url_helper
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: form_helper
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: language_helper
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: user_helper
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: date_helper
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 06:09:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 06:09:56 --> Database Driver Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Session Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: string_helper
DEBUG - 2015-04-01 06:09:56 --> Session routines successfully run
DEBUG - 2015-04-01 06:09:56 --> Controller Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Customer MX_Controller Initialized
DEBUG - 2015-04-01 06:09:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 06:09:56 --> Email Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 06:09:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 06:09:56 --> Model Class Initialized
DEBUG - 2015-04-01 06:09:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 06:09:56 --> Model Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Form Validation Class Initialized
DEBUG - 2015-04-01 06:09:56 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-01 06:09:56 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-01 06:09:56 --> Final output sent to browser
DEBUG - 2015-04-01 06:09:56 --> Total execution time: 0.7440
DEBUG - 2015-04-01 06:09:56 --> Config Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Hooks Class Initialized
DEBUG - 2015-04-01 06:09:56 --> Utf8 Class Initialized
DEBUG - 2015-04-01 06:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 06:09:57 --> URI Class Initialized
DEBUG - 2015-04-01 06:09:57 --> Router Class Initialized
ERROR - 2015-04-01 06:09:57 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 07:48:05 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:48:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:48:05 --> URI Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Router Class Initialized
DEBUG - 2015-04-01 07:48:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:48:05 --> Output Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Security Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Input Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:48:05 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Loader Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:48:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:48:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Session Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:48:05 --> Session routines successfully run
DEBUG - 2015-04-01 07:48:05 --> Controller Class Initialized
DEBUG - 2015-04-01 07:48:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:48:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:48:06 --> Email Class Initialized
DEBUG - 2015-04-01 07:48:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:48:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:48:06 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:48:06 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:48:06 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:48:06 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:48:06 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 07:48:06 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 07:48:06 --> Final output sent to browser
DEBUG - 2015-04-01 07:48:06 --> Total execution time: 1.4481
DEBUG - 2015-04-01 07:48:07 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:48:07 --> URI Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Router Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:48:07 --> URI Class Initialized
ERROR - 2015-04-01 07:48:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 07:48:07 --> Router Class Initialized
DEBUG - 2015-04-01 07:48:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:48:07 --> Output Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Security Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Input Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:48:07 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Loader Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:48:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:48:07 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:48:07 --> Session Class Initialized
DEBUG - 2015-04-01 07:48:07 --> URI Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:48:07 --> Router Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Session routines successfully run
DEBUG - 2015-04-01 07:48:07 --> Controller Class Initialized
DEBUG - 2015-04-01 07:48:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:48:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:48:07 --> Output Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Security Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Input Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:48:07 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Email Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Language Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:48:07 --> Config Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:48:07 --> Loader Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:48:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:48:07 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:48:07 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:48:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:48:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:48:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:48:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:48:08 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:48:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:48:08 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:48:08 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:08 --> Final output sent to browser
DEBUG - 2015-04-01 07:48:08 --> Total execution time: 0.6600
DEBUG - 2015-04-01 07:48:09 --> Session Class Initialized
DEBUG - 2015-04-01 07:48:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:48:09 --> Session routines successfully run
DEBUG - 2015-04-01 07:48:09 --> Controller Class Initialized
DEBUG - 2015-04-01 07:48:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:48:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:48:09 --> Email Class Initialized
DEBUG - 2015-04-01 07:48:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:48:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:48:09 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:48:09 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:48:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:48:09 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:48:09 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:48:09 --> Model Class Initialized
DEBUG - 2015-04-01 07:48:09 --> Final output sent to browser
DEBUG - 2015-04-01 07:48:09 --> Total execution time: 1.4781
DEBUG - 2015-04-01 07:49:47 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:49:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:49:47 --> URI Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Router Class Initialized
DEBUG - 2015-04-01 07:49:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:49:47 --> Output Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Security Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Input Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:49:47 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Loader Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:49:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:49:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:49:47 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:49:47 --> Session Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:49:48 --> Session routines successfully run
DEBUG - 2015-04-01 07:49:48 --> Controller Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:49:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:49:48 --> Email Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:49:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:49:48 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:49:48 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:49:48 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:49:48 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:49:48 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 07:49:48 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 07:49:48 --> Final output sent to browser
DEBUG - 2015-04-01 07:49:48 --> Total execution time: 0.7590
DEBUG - 2015-04-01 07:49:48 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:49:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:49:48 --> URI Class Initialized
DEBUG - 2015-04-01 07:49:48 --> Router Class Initialized
ERROR - 2015-04-01 07:49:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 07:49:49 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:49:49 --> URI Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Router Class Initialized
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:49:49 --> Output Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Security Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Input Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:49:49 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Loader Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:49:49 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:49:49 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:49:49 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:49:49 --> URI Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Router Class Initialized
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:49:49 --> Session Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:49:49 --> Output Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Security Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Session routines successfully run
DEBUG - 2015-04-01 07:49:49 --> Input Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Controller Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:49:49 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:49:49 --> Language Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Config Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:49:49 --> Loader Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Email Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:49:49 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:49:49 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:49:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:49:49 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:49:49 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:49:49 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:49:49 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:49 --> Final output sent to browser
DEBUG - 2015-04-01 07:49:49 --> Total execution time: 0.6140
DEBUG - 2015-04-01 07:49:50 --> Session Class Initialized
DEBUG - 2015-04-01 07:49:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:49:50 --> Session routines successfully run
DEBUG - 2015-04-01 07:49:50 --> Controller Class Initialized
DEBUG - 2015-04-01 07:49:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:49:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:49:50 --> Email Class Initialized
DEBUG - 2015-04-01 07:49:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:49:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:49:50 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:49:50 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:49:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:49:50 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:49:50 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:49:50 --> Model Class Initialized
DEBUG - 2015-04-01 07:49:50 --> Final output sent to browser
DEBUG - 2015-04-01 07:49:50 --> Total execution time: 1.5210
DEBUG - 2015-04-01 07:57:18 --> Config Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 07:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 07:57:18 --> URI Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Router Class Initialized
DEBUG - 2015-04-01 07:57:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 07:57:18 --> Output Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Security Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Input Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 07:57:18 --> Language Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Language Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Config Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Loader Class Initialized
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 07:57:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 07:57:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 07:57:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Session Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 07:57:19 --> Session routines successfully run
DEBUG - 2015-04-01 07:57:19 --> Controller Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 07:57:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 07:57:19 --> Email Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 07:57:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 07:57:19 --> Model Class Initialized
DEBUG - 2015-04-01 07:57:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 07:57:19 --> Model Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 07:57:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 07:57:19 --> Model Class Initialized
DEBUG - 2015-04-01 07:57:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 07:57:19 --> Model Class Initialized
DEBUG - 2015-04-01 07:57:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 07:57:19 --> Model Class Initialized
DEBUG - 2015-04-01 07:57:19 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 07:57:19 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 07:57:19 --> Final output sent to browser
DEBUG - 2015-04-01 07:57:19 --> Total execution time: 0.9750
DEBUG - 2015-04-01 08:00:08 --> Config Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:00:08 --> URI Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Router Class Initialized
DEBUG - 2015-04-01 08:00:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:00:08 --> Output Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Security Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Input Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:00:08 --> Language Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Language Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Config Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Loader Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:00:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:00:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Session Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:00:08 --> Session routines successfully run
DEBUG - 2015-04-01 08:00:08 --> Controller Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:00:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:00:08 --> Email Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:00:08 --> Model Class Initialized
DEBUG - 2015-04-01 08:00:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:00:08 --> Model Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:00:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:00:08 --> Model Class Initialized
DEBUG - 2015-04-01 08:00:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:00:08 --> Model Class Initialized
DEBUG - 2015-04-01 08:00:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:00:08 --> Model Class Initialized
DEBUG - 2015-04-01 08:00:08 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 08:00:09 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 08:00:09 --> Final output sent to browser
DEBUG - 2015-04-01 08:00:09 --> Total execution time: 0.8550
DEBUG - 2015-04-01 08:00:55 --> Config Class Initialized
DEBUG - 2015-04-01 08:00:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:00:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:00:55 --> URI Class Initialized
DEBUG - 2015-04-01 08:00:55 --> Router Class Initialized
ERROR - 2015-04-01 08:00:55 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 08:01:12 --> Config Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:01:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:01:12 --> URI Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Router Class Initialized
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:01:12 --> Output Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Security Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Input Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:01:12 --> Language Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Language Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Config Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Loader Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:01:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:01:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Session Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:01:12 --> Session routines successfully run
DEBUG - 2015-04-01 08:01:12 --> Controller Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:01:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:01:12 --> Email Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:01:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 08:01:12 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-04-01 08:01:12 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:12 --> FTP Class Initialized
DEBUG - 2015-04-01 08:01:14 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-01 08:01:14 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 08:01:14 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 08:01:14 --> Final output sent to browser
DEBUG - 2015-04-01 08:01:14 --> Total execution time: 2.6781
DEBUG - 2015-04-01 08:01:31 --> Config Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:01:31 --> URI Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Router Class Initialized
DEBUG - 2015-04-01 08:01:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:01:31 --> Output Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Security Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Input Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:01:31 --> Language Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Language Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Config Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Loader Class Initialized
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:01:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:01:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:01:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Session Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:01:32 --> Session routines successfully run
DEBUG - 2015-04-01 08:01:32 --> Controller Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:01:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:01:32 --> Email Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:01:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:01:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:01:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:01:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:01:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:01:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:01:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:01:32 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 08:01:32 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 08:01:32 --> Final output sent to browser
DEBUG - 2015-04-01 08:01:32 --> Total execution time: 0.6840
DEBUG - 2015-04-01 08:01:37 --> Config Class Initialized
DEBUG - 2015-04-01 08:01:37 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:01:37 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:01:37 --> URI Class Initialized
DEBUG - 2015-04-01 08:01:37 --> Router Class Initialized
ERROR - 2015-04-01 08:01:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 08:07:14 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:07:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:07:14 --> URI Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Router Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:07:14 --> Output Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Security Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Input Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:07:14 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Loader Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:07:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:07:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Session Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:07:14 --> Session routines successfully run
DEBUG - 2015-04-01 08:07:14 --> Controller Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:07:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:07:14 --> Email Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:07:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:07:14 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:07:14 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:07:14 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:07:14 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:07:14 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 08:07:14 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 08:07:15 --> Final output sent to browser
DEBUG - 2015-04-01 08:07:15 --> Total execution time: 0.6310
DEBUG - 2015-04-01 08:07:15 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:07:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:07:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:07:16 --> URI Class Initialized
DEBUG - 2015-04-01 08:07:16 --> Router Class Initialized
ERROR - 2015-04-01 08:07:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 08:07:30 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:07:30 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:07:30 --> URI Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:07:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:07:30 --> Router Class Initialized
DEBUG - 2015-04-01 08:07:30 --> URI Class Initialized
DEBUG - 2015-04-01 08:07:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:07:30 --> Router Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Output Class Initialized
ERROR - 2015-04-01 08:07:30 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 08:07:30 --> Security Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Input Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:07:30 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Loader Class Initialized
DEBUG - 2015-04-01 08:07:30 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:07:30 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:07:31 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:07:31 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:07:31 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:07:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:07:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:07:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Session Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:07:32 --> Session routines successfully run
DEBUG - 2015-04-01 08:07:32 --> Controller Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:07:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:07:32 --> Email Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:07:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:07:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:07:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:07:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:07:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:07:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:07:32 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:32 --> Final output sent to browser
DEBUG - 2015-04-01 08:07:32 --> Total execution time: 1.6860
DEBUG - 2015-04-01 08:07:35 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:07:35 --> URI Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Router Class Initialized
DEBUG - 2015-04-01 08:07:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:07:35 --> Output Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Security Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Input Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:07:35 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Language Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Config Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Loader Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:07:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:07:35 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Session Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:07:35 --> Session routines successfully run
DEBUG - 2015-04-01 08:07:35 --> Controller Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:07:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:07:35 --> Email Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:07:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:07:35 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:07:35 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:07:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:07:35 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:07:35 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:07:35 --> Model Class Initialized
DEBUG - 2015-04-01 08:07:35 --> Final output sent to browser
DEBUG - 2015-04-01 08:07:35 --> Total execution time: 0.5650
DEBUG - 2015-04-01 08:24:19 --> Config Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:24:19 --> URI Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Router Class Initialized
DEBUG - 2015-04-01 08:24:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:24:19 --> Output Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Security Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Input Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:24:19 --> Language Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Language Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Config Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Loader Class Initialized
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:24:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:24:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:24:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Session Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:24:20 --> Session routines successfully run
DEBUG - 2015-04-01 08:24:20 --> Controller Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:24:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:24:20 --> Email Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:24:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:24:20 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:24:20 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:24:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:24:20 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:24:20 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:24:20 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:20 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 08:24:20 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 08:24:20 --> Final output sent to browser
DEBUG - 2015-04-01 08:24:20 --> Total execution time: 0.8120
DEBUG - 2015-04-01 08:24:40 --> Config Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:24:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:24:40 --> URI Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Router Class Initialized
DEBUG - 2015-04-01 08:24:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:24:40 --> Output Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Security Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Input Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:24:40 --> Language Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Language Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Config Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Loader Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:24:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:24:40 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Session Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:24:40 --> Session routines successfully run
DEBUG - 2015-04-01 08:24:40 --> Controller Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Session Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Session routines successfully run
DEBUG - 2015-04-01 08:24:40 --> Controller Class Initialized
DEBUG - 2015-04-01 08:24:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:24:40 --> Email Class Initialized
ERROR - 2015-04-01 08:24:40 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-01 08:24:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:24:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:24:40 --> Model Class Initialized
DEBUG - 2015-04-01 08:24:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:24:40 --> Model Class Initialized
ERROR - 2015-04-01 08:24:40 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-01 08:24:40 --> Severity: Notice  --> Undefined property: Ftpconnection::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-01 08:24:40 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-01 08:24:40 --> Severity: Notice  --> Undefined property: Ftpconnection::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-01 08:26:39 --> Config Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:26:39 --> URI Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Router Class Initialized
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:26:39 --> Output Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Security Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Input Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:26:39 --> Language Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Language Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Config Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Loader Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:26:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:26:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Session Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:26:39 --> Session routines successfully run
DEBUG - 2015-04-01 08:26:39 --> Controller Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 08:26:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:26:39 --> Email Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:39 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 08:26:39 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-01 08:26:39 --> Final output sent to browser
DEBUG - 2015-04-01 08:26:39 --> Total execution time: 0.7580
DEBUG - 2015-04-01 08:26:43 --> Config Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:26:43 --> URI Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Router Class Initialized
DEBUG - 2015-04-01 08:26:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:26:43 --> Output Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Security Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Input Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:26:43 --> Language Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Language Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Config Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Loader Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:26:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:26:43 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Session Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:26:43 --> Session routines successfully run
DEBUG - 2015-04-01 08:26:43 --> Controller Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Ftpconnection MX_Controller Initialized
DEBUG - 2015-04-01 08:26:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:26:43 --> Email Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:26:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:26:43 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:26:43 --> Model Class Initialized
DEBUG - 2015-04-01 08:26:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:26:43 --> FTP Class Initialized
DEBUG - 2015-04-01 08:26:43 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-04-01 08:26:43 --> Model Class Initialized
ERROR - 2015-04-01 08:26:44 --> Severity: Warning  --> ftp_login(): Login or password incorrect! C:\xampp\htdocs\ecampaign247\system\libraries\Ftp.php 130
DEBUG - 2015-04-01 08:26:44 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-01 08:30:15 --> Config Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:30:15 --> URI Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Router Class Initialized
DEBUG - 2015-04-01 08:30:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:30:15 --> Output Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Security Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Input Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:30:15 --> Language Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Language Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Config Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Loader Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:30:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:30:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Session Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:30:15 --> Session routines successfully run
DEBUG - 2015-04-01 08:30:15 --> Controller Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Ftpconnection MX_Controller Initialized
DEBUG - 2015-04-01 08:30:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:30:15 --> Email Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:30:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:30:15 --> Model Class Initialized
DEBUG - 2015-04-01 08:30:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:30:15 --> Model Class Initialized
DEBUG - 2015-04-01 08:30:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:30:15 --> FTP Class Initialized
DEBUG - 2015-04-01 08:30:15 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-04-01 08:30:15 --> Model Class Initialized
ERROR - 2015-04-01 08:30:15 --> Severity: Warning  --> ftp_login(): Login or password incorrect! C:\xampp\htdocs\ecampaign247\system\libraries\Ftp.php 130
DEBUG - 2015-04-01 08:30:15 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-01 08:30:41 --> Config Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 08:30:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 08:30:41 --> URI Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Router Class Initialized
DEBUG - 2015-04-01 08:30:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 08:30:41 --> Output Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Security Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Input Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 08:30:41 --> Language Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Language Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Config Class Initialized
DEBUG - 2015-04-01 08:30:41 --> Loader Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 08:30:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 08:30:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Session Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 08:30:42 --> Session routines successfully run
DEBUG - 2015-04-01 08:30:42 --> Controller Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Ftpconnection MX_Controller Initialized
DEBUG - 2015-04-01 08:30:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 08:30:42 --> Email Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 08:30:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 08:30:42 --> Model Class Initialized
DEBUG - 2015-04-01 08:30:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 08:30:42 --> Model Class Initialized
DEBUG - 2015-04-01 08:30:42 --> Form Validation Class Initialized
DEBUG - 2015-04-01 08:30:42 --> FTP Class Initialized
DEBUG - 2015-04-01 08:30:42 --> File loaded: application/modules_core/sites/models/ftpmodel.php
DEBUG - 2015-04-01 08:30:42 --> Model Class Initialized
ERROR - 2015-04-01 08:30:42 --> Severity: Warning  --> ftp_login(): Login or password incorrect! C:\xampp\htdocs\ecampaign247\system\libraries\Ftp.php 130
DEBUG - 2015-04-01 08:30:42 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-01 11:20:08 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:08 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:20:08 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:08 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:08 --> A session cookie was not found.
DEBUG - 2015-04-01 11:20:08 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:08 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:20:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:08 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:09 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:09 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:09 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:09 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 11:20:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:09 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:09 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 11:20:09 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-01 11:20:09 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-01 11:20:09 --> Final output sent to browser
DEBUG - 2015-04-01 11:20:09 --> Total execution time: 0.5070
DEBUG - 2015-04-01 11:20:38 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:38 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:38 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:38 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:38 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:38 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 11:20:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:38 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:38 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:38 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 11:20:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:20:39 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:39 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:39 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-01 11:20:39 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:39 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:39 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:39 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Customer MX_Controller Initialized
DEBUG - 2015-04-01 11:20:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:39 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:39 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-01 11:20:39 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-01 11:20:39 --> Final output sent to browser
DEBUG - 2015-04-01 11:20:39 --> Total execution time: 0.5460
DEBUG - 2015-04-01 11:20:40 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:40 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:40 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:40 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:40 --> Router Class Initialized
ERROR - 2015-04-01 11:20:40 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 11:20:57 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:57 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:57 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:57 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:20:58 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:58 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:58 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:58 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:20:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:58 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:20:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:20:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:20:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 11:20:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 11:20:58 --> Final output sent to browser
DEBUG - 2015-04-01 11:20:58 --> Total execution time: 0.6650
DEBUG - 2015-04-01 11:20:58 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:58 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Router Class Initialized
ERROR - 2015-04-01 11:20:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 11:20:58 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:58 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:58 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:20:59 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:59 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:59 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:59 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:59 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:20:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:59 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Final output sent to browser
DEBUG - 2015-04-01 11:20:59 --> Total execution time: 0.6100
DEBUG - 2015-04-01 11:20:59 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:20:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:20:59 --> URI Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Router Class Initialized
DEBUG - 2015-04-01 11:20:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:20:59 --> Output Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Security Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Input Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:20:59 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Language Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Config Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Loader Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:20:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:20:59 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Session Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:20:59 --> Session routines successfully run
DEBUG - 2015-04-01 11:20:59 --> Controller Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:20:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:20:59 --> Email Class Initialized
DEBUG - 2015-04-01 11:20:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:20:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:20:59 --> Model Class Initialized
DEBUG - 2015-04-01 11:21:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:21:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:21:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:21:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:21:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:21:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:21:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:21:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:21:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:21:00 --> Final output sent to browser
DEBUG - 2015-04-01 11:21:00 --> Total execution time: 0.4770
DEBUG - 2015-04-01 11:35:46 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:46 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:46 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:46 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:46 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:46 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:46 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:46 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:46 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 11:35:47 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:47 --> Total execution time: 1.0440
DEBUG - 2015-04-01 11:35:47 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:47 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:47 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:47 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:47 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:47 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:48 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:48 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:48 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:48 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:48 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:49 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:49 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:49 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:49 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:49 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:49 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:49 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:49 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:49 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:49 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:49 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:49 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:49 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:49 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:49 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:49 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:49 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:49 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:49 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:49 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:49 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:49 --> Total execution time: 0.9160
DEBUG - 2015-04-01 11:35:49 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:49 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:49 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:49 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:49 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:49 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:50 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:50 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:50 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:50 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:50 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:50 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:50 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:50 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:50 --> Total execution time: 0.9921
DEBUG - 2015-04-01 11:35:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:50 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:50 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:50 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:50 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:50 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:51 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
ERROR - 2015-04-01 11:35:51 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:51 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:51 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:51 --> Total execution time: 3.2492
DEBUG - 2015-04-01 11:35:51 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:51 --> Total execution time: 2.7712
DEBUG - 2015-04-01 11:35:51 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:51 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:51 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:51 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:51 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:51 --> Total execution time: 4.2192
DEBUG - 2015-04-01 11:35:51 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:52 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:52 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:52 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:52 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:52 --> Total execution time: 3.5452
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:53 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:53 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:53 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:53 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:53 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:54 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:54 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:54 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:54 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:54 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:54 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:54 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:54 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:54 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:35:54 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:54 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:54 --> Total execution time: 1.1261
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:54 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:54 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:54 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:54 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:54 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:54 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:35:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:35:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:54 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:54 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:55 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:55 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:35:55 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:55 --> Total execution time: 2.0121
DEBUG - 2015-04-01 11:35:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:55 --> Email Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:35:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:55 --> Total execution time: 1.6091
DEBUG - 2015-04-01 11:35:55 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:55 --> Total execution time: 1.5381
DEBUG - 2015-04-01 11:35:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:35:55 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:55 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:55 --> Total execution time: 2.1961
DEBUG - 2015-04-01 11:37:45 --> Config Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:37:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:37:45 --> URI Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Router Class Initialized
DEBUG - 2015-04-01 11:37:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 11:37:45 --> Output Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Security Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Input Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:37:45 --> Language Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Language Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Config Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Loader Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: language_helper
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: user_helper
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: date_helper
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 11:37:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 11:37:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Session Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:37:45 --> Session routines successfully run
DEBUG - 2015-04-01 11:37:45 --> Controller Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 11:37:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 11:37:45 --> Email Class Initialized
DEBUG - 2015-04-01 11:37:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 11:37:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 11:37:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 11:37:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:46 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:37:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 11:37:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 11:37:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 11:37:46 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:01 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:01 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:01 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:02 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:02 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:02 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:02 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:02 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:02 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:02 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:02 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:02 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:02 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:02 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:02 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:02 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 12:39:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 12:39:02 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:02 --> Total execution time: 0.9980
DEBUG - 2015-04-01 12:39:04 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:04 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:04 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:04 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:04 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:04 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:04 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:04 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:04 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:04 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:04 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:04 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:04 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:04 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:04 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:04 --> Model Class Initialized
ERROR - 2015-04-01 12:39:05 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:39:05 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:05 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:05 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 12:39:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:05 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:05 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:05 --> Total execution time: 1.3541
DEBUG - 2015-04-01 12:39:13 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:13 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:13 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:13 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:14 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:14 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:14 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:14 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:14 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:14 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:14 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:14 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:14 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:14 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:14 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:14 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:14 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:14 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:14 --> Loader Class Initialized
ERROR - 2015-04-01 12:39:14 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:14 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:15 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:15 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:15 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:15 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:15 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:15 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:15 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:15 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:15 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:15 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:15 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:15 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:15 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:15 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:15 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:15 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:15 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:15 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:15 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:15 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:16 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:16 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:16 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:16 --> Total execution time: 1.9241
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:16 --> Total execution time: 2.0311
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Total execution time: 1.8871
DEBUG - 2015-04-01 12:39:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Total execution time: 2.1581
DEBUG - 2015-04-01 12:39:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:16 --> Total execution time: 2.1691
DEBUG - 2015-04-01 12:39:17 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:17 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:39:19 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:39:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:20 --> URI Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:20 --> Router Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:39:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:20 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:20 --> Total execution time: 3.4372
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:39:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:39:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:21 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:21 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:21 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:39:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:39:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:39:21 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:21 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:21 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:39:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:21 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:21 --> Total execution time: 2.0791
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:21 --> Total execution time: 3.0832
DEBUG - 2015-04-01 12:39:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:39:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:39:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:39:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:39:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:39:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:39:23 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:23 --> Total execution time: 5.8783
DEBUG - 2015-04-01 12:39:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:39:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:39:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:39:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:39:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:39:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:39:23 --> Final output sent to browser
DEBUG - 2015-04-01 12:39:23 --> Total execution time: 6.0453
DEBUG - 2015-04-01 12:46:13 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:13 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:13 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:13 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:14 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:14 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:14 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:14 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:14 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 12:46:14 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 12:46:14 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:14 --> Total execution time: 0.7750
DEBUG - 2015-04-01 12:46:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:16 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:16 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:16 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:16 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:16 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:16 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:16 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:16 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:16 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:16 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:16 --> Total execution time: 0.6760
DEBUG - 2015-04-01 12:46:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:16 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:16 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:16 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:16 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:17 --> Model Class Initialized
ERROR - 2015-04-01 12:46:17 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:46:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:20 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:21 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:21 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:21 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:21 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:21 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:21 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:21 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:21 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:21 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:21 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:21 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:21 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:22 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:22 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:22 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:22 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:22 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:22 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:22 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Session Class Initialized
ERROR - 2015-04-01 12:46:22 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:23 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:23 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:23 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:23 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:23 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:23 --> Total execution time: 2.0751
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:23 --> Total execution time: 2.1741
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:23 --> Total execution time: 2.1971
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:23 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:24 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:46:24 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:24 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:24 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:24 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:24 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:24 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:24 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:25 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:25 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:25 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:25 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:25 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:25 --> URI Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:25 --> Router Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:46:25 --> Output Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:25 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:25 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:25 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:25 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:25 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:25 --> Security Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:25 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:25 --> Input Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Config Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:25 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:25 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:25 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:25 --> Loader Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:46:25 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:46:26 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:26 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:46:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:26 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Session Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:46:26 --> Session routines successfully run
DEBUG - 2015-04-01 12:46:26 --> Controller Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:46:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:26 --> Email Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:26 --> Total execution time: 2.5251
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:26 --> Total execution time: 4.8813
DEBUG - 2015-04-01 12:46:26 --> Total execution time: 2.8552
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Total execution time: 4.9363
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:26 --> Total execution time: 2.7882
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:26 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:26 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:27 --> Total execution time: 2.5831
DEBUG - 2015-04-01 12:46:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:46:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:46:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:46:27 --> Final output sent to browser
DEBUG - 2015-04-01 12:46:27 --> Total execution time: 2.8262
DEBUG - 2015-04-01 12:47:22 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:22 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:22 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:22 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:22 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:22 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:22 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:22 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 12:47:22 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 12:47:22 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:22 --> Total execution time: 0.7430
DEBUG - 2015-04-01 12:47:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:24 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:24 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:24 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:24 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:24 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:25 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:25 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:25 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:25 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:25 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:25 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:25 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:25 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:25 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:25 --> Form Validation Class Initialized
ERROR - 2015-04-01 12:47:25 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:47:25 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:25 --> Total execution time: 1.7151
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:26 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:26 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:26 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:26 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:27 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:27 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:27 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:27 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:27 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:27 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:27 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:27 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:27 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:27 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:27 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:27 --> Total execution time: 1.8461
DEBUG - 2015-04-01 12:47:27 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:27 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:28 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:28 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:28 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:28 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:28 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:28 --> Total execution time: 2.4591
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:29 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:29 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Total execution time: 2.9502
DEBUG - 2015-04-01 12:47:29 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:29 --> Total execution time: 2.8772
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:29 --> Model Class Initialized
ERROR - 2015-04-01 12:47:29 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:47:29 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:29 --> Total execution time: 3.1682
DEBUG - 2015-04-01 12:47:32 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:32 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:32 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:33 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:33 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:33 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:33 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:33 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:33 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:33 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:33 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:33 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:34 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:34 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:34 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:35 --> URI Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:35 --> Router Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:35 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:35 --> Output Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:35 --> Security Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:35 --> Input Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:47:33 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:34 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:35 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:35 --> Language Class Initialized
DEBUG - 2015-04-01 12:47:35 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:36 --> Config Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:36 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:36 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:36 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Loader Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:47:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:36 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:36 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:47:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:47:36 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:36 --> Total execution time: 3.7402
DEBUG - 2015-04-01 12:47:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:36 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:47:36 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:36 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:36 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:47:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:37 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Session Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Session routines successfully run
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:37 --> Controller Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:47:37 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:47:37 --> Email Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:47:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Total execution time: 4.4983
DEBUG - 2015-04-01 12:47:37 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:37 --> Total execution time: 4.0202
DEBUG - 2015-04-01 12:47:37 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:37 --> Total execution time: 4.1892
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:47:37 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:47:38 --> Model Class Initialized
DEBUG - 2015-04-01 12:47:38 --> Final output sent to browser
DEBUG - 2015-04-01 12:47:38 --> Total execution time: 4.8793
DEBUG - 2015-04-01 12:59:05 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:05 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:05 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:05 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:05 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:05 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:05 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:05 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:05 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 12:59:06 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 12:59:06 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:06 --> Total execution time: 0.8570
DEBUG - 2015-04-01 12:59:06 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:07 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:07 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:07 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:08 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:08 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:08 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:08 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:08 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:08 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:08 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 12:59:08 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:08 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:08 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:08 --> Total execution time: 1.6701
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:08 --> Model Class Initialized
ERROR - 2015-04-01 12:59:08 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:09 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:09 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:09 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:09 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:09 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:09 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:09 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:10 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:10 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:10 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:10 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:10 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:10 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:10 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:10 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:10 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:10 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:10 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:10 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:10 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:10 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:10 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:10 --> Total execution time: 0.6600
DEBUG - 2015-04-01 12:59:10 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:10 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:10 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:10 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:11 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:11 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:11 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:11 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:11 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:11 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:11 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:11 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:11 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:11 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:11 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:11 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:11 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:12 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:12 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:12 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:12 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:12 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:12 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:12 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:12 --> Total execution time: 2.5461
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:12 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Total execution time: 2.9212
DEBUG - 2015-04-01 12:59:12 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:12 --> Total execution time: 2.9162
DEBUG - 2015-04-01 12:59:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
ERROR - 2015-04-01 12:59:12 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:12 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:12 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:12 --> Total execution time: 2.9672
DEBUG - 2015-04-01 12:59:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:16 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:16 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:16 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:16 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:17 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:17 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:17 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:17 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:18 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:18 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:18 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:18 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:19 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:19 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:19 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:19 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 12:59:19 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:19 --> URI Class Initialized
DEBUG - 2015-04-01 12:59:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:19 --> Router Class Initialized
DEBUG - 2015-04-01 12:59:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 12:59:20 --> Output Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Security Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Input Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 12:59:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Language Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Config Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Loader Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 12:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:20 --> Session Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:20 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:20 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 12:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:20 --> Session routines successfully run
DEBUG - 2015-04-01 12:59:20 --> Controller Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 12:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:20 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 12:59:21 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:21 --> Email Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:21 --> Total execution time: 4.6143
DEBUG - 2015-04-01 12:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:21 --> Total execution time: 2.8702
DEBUG - 2015-04-01 12:59:21 --> Total execution time: 4.6243
DEBUG - 2015-04-01 12:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 12:59:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:21 --> Total execution time: 1.9941
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 12:59:21 --> Model Class Initialized
DEBUG - 2015-04-01 12:59:21 --> Final output sent to browser
DEBUG - 2015-04-01 12:59:21 --> Total execution time: 2.7452
DEBUG - 2015-04-01 13:01:37 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:37 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:37 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:37 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:37 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:37 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:37 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:37 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:37 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:37 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:37 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:37 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:37 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:37 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:01:38 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:01:38 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:38 --> Total execution time: 1.3721
DEBUG - 2015-04-01 13:01:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:39 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:39 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:39 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:39 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:39 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:39 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:01:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:39 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:40 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:40 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:40 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Total execution time: 0.8330
DEBUG - 2015-04-01 13:01:40 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:40 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:40 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:40 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:40 --> Model Class Initialized
ERROR - 2015-04-01 13:01:40 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:01:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:42 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:42 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:42 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:42 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:42 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:42 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:43 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:43 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:43 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:43 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:43 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:43 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:43 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:43 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:44 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: form_helper
ERROR - 2015-04-01 13:01:44 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:44 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:44 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:44 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:44 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:44 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:44 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:45 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:45 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:45 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:45 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:45 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:45 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:45 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:45 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:45 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:45 --> Total execution time: 2.9412
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:45 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:45 --> Total execution time: 2.4761
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:45 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:46 --> Total execution time: 3.3422
DEBUG - 2015-04-01 13:01:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:46 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:46 --> Total execution time: 3.3072
DEBUG - 2015-04-01 13:01:46 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:46 --> Total execution time: 3.2122
DEBUG - 2015-04-01 13:01:51 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:51 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:51 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:51 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:51 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:52 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:52 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:52 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:52 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:52 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:52 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:52 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:52 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:52 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:52 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:01:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:01:53 --> URI Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:53 --> Router Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:01:53 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Output Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Security Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Input Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Config Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:53 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Loader Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:53 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:53 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:01:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:53 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:01:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:53 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:53 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:01:53 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:53 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:53 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:01:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Session Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:54 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:54 --> Total execution time: 2.2071
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:01:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:54 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:54 --> Session routines successfully run
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:54 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Controller Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:54 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:54 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:54 --> Email Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:54 --> Total execution time: 2.2921
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:54 --> Total execution time: 2.4641
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:01:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:54 --> Total execution time: 2.2021
DEBUG - 2015-04-01 13:01:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:01:55 --> Total execution time: 2.6792
DEBUG - 2015-04-01 13:02:21 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:21 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:21 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:21 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:21 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:21 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:21 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:22 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:02:22 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:02:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:22 --> Total execution time: 0.8520
DEBUG - 2015-04-01 13:02:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:23 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:23 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:23 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:24 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:02:24 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:24 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:24 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:24 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:24 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Total execution time: 1.1941
DEBUG - 2015-04-01 13:02:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:24 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:24 --> Model Class Initialized
ERROR - 2015-04-01 13:02:24 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:26 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:26 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:27 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:27 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:27 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:27 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:27 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:27 --> Total execution time: 1.6241
DEBUG - 2015-04-01 13:02:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:28 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:28 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:28 --> Total execution time: 2.6272
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:28 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:28 --> Total execution time: 2.8932
DEBUG - 2015-04-01 13:02:28 --> Total execution time: 2.6822
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:28 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:29 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:29 --> Total execution time: 2.8532
DEBUG - 2015-04-01 13:02:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:29 --> Model Class Initialized
ERROR - 2015-04-01 13:02:29 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:02:40 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:40 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:40 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:40 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:40 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:41 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:41 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:41 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:41 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Total execution time: 1.4351
DEBUG - 2015-04-01 13:02:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:42 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:42 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:42 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:42 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:42 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:43 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:43 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:43 --> Total execution time: 3.2662
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:44 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:44 --> Total execution time: 3.4392
DEBUG - 2015-04-01 13:02:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:44 --> Total execution time: 3.3722
DEBUG - 2015-04-01 13:02:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:02:44 --> URI Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Router Class Initialized
DEBUG - 2015-04-01 13:02:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:02:44 --> Output Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Security Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Input Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:02:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Language Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Loader Class Initialized
DEBUG - 2015-04-01 13:02:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:02:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:02:45 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:02:45 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:02:45 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:02:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:02:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:02:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:02:45 --> Session Class Initialized
DEBUG - 2015-04-01 13:02:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:02:45 --> Session routines successfully run
DEBUG - 2015-04-01 13:02:45 --> Controller Class Initialized
DEBUG - 2015-04-01 13:02:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:02:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:02:46 --> Email Class Initialized
DEBUG - 2015-04-01 13:02:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:02:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:02:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:02:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:46 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:02:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:02:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:02:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:02:46 --> Model Class Initialized
DEBUG - 2015-04-01 13:02:47 --> Final output sent to browser
DEBUG - 2015-04-01 13:02:47 --> Total execution time: 6.2704
DEBUG - 2015-04-01 13:07:24 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:24 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:07:24 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Helper loaded: string_helper
ERROR - 2015-04-01 13:07:25 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-04-01 13:07:25 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:25 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:07:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:25 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:25 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:25 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:26 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:26 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:26 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 13:07:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:26 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:26 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:26 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 13:07:26 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-01 13:07:26 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-01 13:07:26 --> Final output sent to browser
DEBUG - 2015-04-01 13:07:26 --> Total execution time: 0.4680
DEBUG - 2015-04-01 13:07:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:42 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:42 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:42 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:43 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:43 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:43 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Login MX_Controller Initialized
DEBUG - 2015-04-01 13:07:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-01 13:07:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 13:07:43 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:43 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:43 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-01 13:07:43 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:44 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:44 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Customer MX_Controller Initialized
DEBUG - 2015-04-01 13:07:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:44 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:44 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-01 13:07:44 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-01 13:07:44 --> Final output sent to browser
DEBUG - 2015-04-01 13:07:44 --> Total execution time: 0.5150
DEBUG - 2015-04-01 13:07:44 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:44 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:44 --> Router Class Initialized
ERROR - 2015-04-01 13:07:44 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 13:07:50 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:50 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:07:50 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:50 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:50 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:50 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:07:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:50 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:50 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:50 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:07:50 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:07:50 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:07:50 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 13:07:50 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:07:50 --> Final output sent to browser
DEBUG - 2015-04-01 13:07:50 --> Total execution time: 0.7260
DEBUG - 2015-04-01 13:07:51 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:51 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:51 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:51 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:51 --> Router Class Initialized
ERROR - 2015-04-01 13:07:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 13:07:54 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:54 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:07:54 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:54 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:54 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:54 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:54 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:07:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:54 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:07:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:54 --> URI Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:07:54 --> Router Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:07:54 --> Output Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:07:54 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Security Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Input Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:07:54 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Final output sent to browser
DEBUG - 2015-04-01 13:07:54 --> Total execution time: 0.8030
DEBUG - 2015-04-01 13:07:54 --> Language Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Config Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Loader Class Initialized
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:07:54 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:07:55 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:07:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:07:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:07:55 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Session Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:07:56 --> Session routines successfully run
DEBUG - 2015-04-01 13:07:56 --> Controller Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:07:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:07:56 --> Email Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:07:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:07:56 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:07:56 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:07:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:07:56 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:07:56 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:07:56 --> Model Class Initialized
DEBUG - 2015-04-01 13:07:56 --> Final output sent to browser
DEBUG - 2015-04-01 13:07:56 --> Total execution time: 1.6571
DEBUG - 2015-04-01 13:08:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:08:16 --> URI Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Router Class Initialized
DEBUG - 2015-04-01 13:08:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:08:16 --> Output Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Security Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Input Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:08:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Loader Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:08:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:08:17 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Session Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:08:17 --> Session routines successfully run
DEBUG - 2015-04-01 13:08:17 --> Controller Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:08:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:08:17 --> Email Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:08:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:08:17 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:08:17 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:17 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:08:17 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:08:17 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:08:17 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-01 13:08:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:08:17 --> Final output sent to browser
DEBUG - 2015-04-01 13:08:17 --> Total execution time: 0.6080
DEBUG - 2015-04-01 13:08:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:08:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:08:18 --> URI Class Initialized
DEBUG - 2015-04-01 13:08:18 --> Router Class Initialized
ERROR - 2015-04-01 13:08:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 13:08:21 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:21 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:08:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:08:22 --> URI Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Router Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:08:22 --> UTF-8 Support Enabled
ERROR - 2015-04-01 13:08:22 --> 404 Page Not Found --> 
DEBUG - 2015-04-01 13:08:22 --> URI Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Router Class Initialized
DEBUG - 2015-04-01 13:08:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:08:22 --> Output Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Security Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Input Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:08:22 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Loader Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:08:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:08:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:08:22 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:08:23 --> Session Class Initialized
DEBUG - 2015-04-01 13:08:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:08:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Session routines successfully run
DEBUG - 2015-04-01 13:08:23 --> Controller Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:08:23 --> Output Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:08:23 --> Security Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Input Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Email Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:08:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:08:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:08:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Loader Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:08:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:08:23 --> Session Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:08:23 --> Session routines successfully run
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:08:23 --> Controller Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:08:23 --> Final output sent to browser
DEBUG - 2015-04-01 13:08:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:08:23 --> Total execution time: 1.4531
DEBUG - 2015-04-01 13:08:23 --> Email Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:08:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:08:23 --> Model Class Initialized
DEBUG - 2015-04-01 13:08:23 --> Final output sent to browser
DEBUG - 2015-04-01 13:08:23 --> Total execution time: 0.8791
DEBUG - 2015-04-01 13:09:02 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:02 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:02 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:02 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:02 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:03 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:03 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:04 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:04 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:04 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:04 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:09:04 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:09:04 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:04 --> Total execution time: 1.8521
DEBUG - 2015-04-01 13:09:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:05 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:05 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:05 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:05 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:05 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:05 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:09:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:06 --> Total execution time: 0.9801
DEBUG - 2015-04-01 13:09:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:06 --> Model Class Initialized
ERROR - 2015-04-01 13:09:06 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:09 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:09 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:09 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:09 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:09 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:09 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:09 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:09 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:09 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:10 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:10 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:10 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:10 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:10 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:10 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:10 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:10 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:10 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:10 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:10 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:10 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:10 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:10 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:10 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:10 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:11 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:11 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:12 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:12 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:12 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:12 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:12 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:12 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:09:12 --> URI Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:12 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:12 --> Router Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:12 --> Total execution time: 3.0912
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:12 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:12 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:12 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Total execution time: 2.9732
DEBUG - 2015-04-01 13:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:12 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:12 --> Total execution time: 3.4012
DEBUG - 2015-04-01 13:09:12 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Total execution time: 3.4162
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:12 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:12 --> Total execution time: 3.2242
DEBUG - 2015-04-01 13:09:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:09:12 --> Output Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Security Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:12 --> Input Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:12 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:12 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:13 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:13 --> Config Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:13 --> Loader Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:13 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:13 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:13 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:13 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:13 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:13 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:09:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:13 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:13 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:13 --> Total execution time: 1.3691
DEBUG - 2015-04-01 13:09:13 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:13 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:13 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:13 --> Total execution time: 2.5951
DEBUG - 2015-04-01 13:09:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:13 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:13 --> Total execution time: 2.1861
DEBUG - 2015-04-01 13:09:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:14 --> Total execution time: 2.2951
DEBUG - 2015-04-01 13:09:14 --> Session Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:09:14 --> Session routines successfully run
DEBUG - 2015-04-01 13:09:14 --> Controller Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:09:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:09:14 --> Email Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:09:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:09:14 --> Model Class Initialized
DEBUG - 2015-04-01 13:09:14 --> Final output sent to browser
DEBUG - 2015-04-01 13:09:14 --> Total execution time: 2.8452
DEBUG - 2015-04-01 13:44:08 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:08 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:09 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:09 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:09 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:09 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:09 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:44:09 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:44:10 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:44:10 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:10 --> Total execution time: 1.0781
DEBUG - 2015-04-01 13:44:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:10 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:11 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:11 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:11 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:11 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:12 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:12 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:44:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:12 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:12 --> Total execution time: 1.6631
DEBUG - 2015-04-01 13:44:14 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:14 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:14 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:14 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:14 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:14 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:15 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:15 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:16 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:16 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:15 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:16 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:16 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:16 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:16 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:16 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:17 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:17 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:17 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:17 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:17 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:17 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:44:17 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:17 --> URI Class Initialized
DEBUG - 2015-04-01 13:44:17 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:18 --> Router Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:44:18 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:18 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Output Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Security Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Input Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:44:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Loader Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:44:18 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:44:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:20 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Session Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:44:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:20 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Session routines successfully run
DEBUG - 2015-04-01 13:44:20 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Controller Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:20 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:44:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Email Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:20 --> Total execution time: 3.6602
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:20 --> Total execution time: 3.9772
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:20 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
ERROR - 2015-04-01 13:44:21 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:21 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:21 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:21 --> Total execution time: 4.9353
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:44:22 --> Total execution time: 6.5054
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:22 --> Total execution time: 5.5903
DEBUG - 2015-04-01 13:44:22 --> Total execution time: 6.4734
DEBUG - 2015-04-01 13:44:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:22 --> Total execution time: 5.4463
DEBUG - 2015-04-01 13:44:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:44:22 --> Model Class Initialized
DEBUG - 2015-04-01 13:44:22 --> Final output sent to browser
DEBUG - 2015-04-01 13:44:22 --> Total execution time: 8.0395
DEBUG - 2015-04-01 13:46:37 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:37 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:37 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:37 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:37 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:37 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:37 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:37 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:38 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:38 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:38 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:38 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:38 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:38 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:38 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:38 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:38 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:46:38 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:46:38 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:38 --> Total execution time: 0.7680
DEBUG - 2015-04-01 13:46:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:39 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:39 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:39 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:39 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:39 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:39 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:39 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:46:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:39 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:39 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:39 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:39 --> Total execution time: 0.8931
DEBUG - 2015-04-01 13:46:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:39 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:40 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:40 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:40 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:40 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:40 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:40 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:41 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:41 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:41 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:41 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:41 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:41 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:41 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:41 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:42 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:42 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:42 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:42 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:42 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: user_helper
ERROR - 2015-04-01 13:46:42 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:42 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Total execution time: 0.8981
DEBUG - 2015-04-01 13:46:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:42 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:42 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:42 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:42 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:42 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:42 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:43 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:43 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:43 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:43 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:43 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:43 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:43 --> Total execution time: 2.6662
DEBUG - 2015-04-01 13:46:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:43 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:43 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:44 --> Total execution time: 2.7022
DEBUG - 2015-04-01 13:46:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:44 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:44 --> Total execution time: 3.1652
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:44 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:44 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:44 --> Total execution time: 3.3072
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:55 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:55 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:55 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:55 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:55 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:55 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:55 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:55 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:55 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:55 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:55 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:55 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:56 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:56 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:46:56 --> URI Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Router Class Initialized
DEBUG - 2015-04-01 13:46:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:46:56 --> Output Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Security Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Input Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:46:56 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Language Class Initialized
DEBUG - 2015-04-01 13:46:56 --> Config Class Initialized
DEBUG - 2015-04-01 13:46:57 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:57 --> Loader Class Initialized
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:46:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:58 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:58 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:58 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:58 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:58 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:46:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:58 --> Session routines successfully run
DEBUG - 2015-04-01 13:46:58 --> Controller Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:58 --> Total execution time: 3.3952
DEBUG - 2015-04-01 13:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:58 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:46:58 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:58 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Email Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:46:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Final output sent to browser
DEBUG - 2015-04-01 13:46:59 --> Total execution time: 4.6123
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:46:59 --> Model Class Initialized
DEBUG - 2015-04-01 13:46:59 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:47:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> Final output sent to browser
DEBUG - 2015-04-01 13:47:00 --> Total execution time: 4.9563
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:47:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:47:00 --> Final output sent to browser
DEBUG - 2015-04-01 13:47:00 --> Final output sent to browser
DEBUG - 2015-04-01 13:47:00 --> Total execution time: 4.2222
DEBUG - 2015-04-01 13:47:00 --> Total execution time: 5.4723
DEBUG - 2015-04-01 13:51:57 --> Config Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:51:57 --> URI Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Router Class Initialized
DEBUG - 2015-04-01 13:51:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:51:57 --> Output Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Security Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Input Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:51:57 --> Language Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Language Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Config Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Loader Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:51:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:51:57 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Session Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:51:57 --> Session routines successfully run
DEBUG - 2015-04-01 13:51:57 --> Controller Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:51:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:51:57 --> Email Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:51:57 --> Model Class Initialized
DEBUG - 2015-04-01 13:51:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:51:57 --> Model Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:51:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:51:57 --> Model Class Initialized
DEBUG - 2015-04-01 13:51:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:51:57 --> Model Class Initialized
DEBUG - 2015-04-01 13:51:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:51:57 --> Model Class Initialized
DEBUG - 2015-04-01 13:51:57 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:51:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:51:58 --> Final output sent to browser
DEBUG - 2015-04-01 13:51:58 --> Total execution time: 1.1121
DEBUG - 2015-04-01 13:51:59 --> Config Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:51:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:51:59 --> URI Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Router Class Initialized
DEBUG - 2015-04-01 13:51:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:51:59 --> Output Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Security Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Input Class Initialized
DEBUG - 2015-04-01 13:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:51:59 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:00 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:00 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:52:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:00 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:00 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:00 --> Total execution time: 1.3341
DEBUG - 2015-04-01 13:52:02 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:02 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:02 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:03 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:03 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:03 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:03 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:03 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:03 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:04 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:04 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:04 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Total execution time: 1.6481
DEBUG - 2015-04-01 13:52:04 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:04 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:04 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:05 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:05 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:05 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:05 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:05 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:05 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:06 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:06 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:06 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:06 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:06 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:06 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:06 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:06 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:06 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:06 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:06 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:06 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:06 --> Total execution time: 4.1862
DEBUG - 2015-04-01 13:52:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:07 --> Total execution time: 1.0631
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:07 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:07 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:07 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:07 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Total execution time: 5.0133
DEBUG - 2015-04-01 13:52:07 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:07 --> Total execution time: 5.1553
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:07 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:52:08 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:08 --> Output Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:08 --> URI Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:08 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Router Class Initialized
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:52:08 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Output Class Initialized
ERROR - 2015-04-01 13:52:08 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:08 --> Security Class Initialized
DEBUG - 2015-04-01 13:52:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:08 --> Input Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:09 --> Total execution time: 6.2824
DEBUG - 2015-04-01 13:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:52:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:09 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:09 --> Language Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:09 --> Config Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:09 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:09 --> Total execution time: 3.5122
DEBUG - 2015-04-01 13:52:09 --> Loader Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:52:09 --> Total execution time: 3.4512
DEBUG - 2015-04-01 13:52:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:52:09 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:52:09 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:09 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:52:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:52:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:52:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Session Class Initialized
DEBUG - 2015-04-01 13:52:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:52:10 --> Session routines successfully run
DEBUG - 2015-04-01 13:52:10 --> Controller Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:52:10 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:52:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:10 --> Email Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:52:10 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:10 --> Total execution time: 2.8062
DEBUG - 2015-04-01 13:52:10 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:52:10 --> Model Class Initialized
DEBUG - 2015-04-01 13:52:11 --> Final output sent to browser
DEBUG - 2015-04-01 13:52:11 --> Total execution time: 3.1652
DEBUG - 2015-04-01 13:54:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:16 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:16 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:16 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:16 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:16 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:16 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:17 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:54:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:54:17 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:17 --> Total execution time: 1.1301
DEBUG - 2015-04-01 13:54:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:18 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:18 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:19 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:19 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:54:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:19 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:19 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:19 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:19 --> Total execution time: 1.3421
DEBUG - 2015-04-01 13:54:22 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:22 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:22 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:22 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:22 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:22 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:22 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:22 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:23 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:23 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:23 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:23 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:23 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:23 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:23 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:24 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:24 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:24 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:24 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:24 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Total execution time: 1.6991
DEBUG - 2015-04-01 13:54:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:24 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:24 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:24 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:24 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:24 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:24 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:24 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:24 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:24 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:24 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:24 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:24 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:25 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:25 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:25 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:25 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:25 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:25 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Form Validation Class Initialized
ERROR - 2015-04-01 13:54:25 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:54:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:25 --> Total execution time: 2.6482
DEBUG - 2015-04-01 13:54:25 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:25 --> Total execution time: 2.7542
DEBUG - 2015-04-01 13:54:25 --> Total execution time: 2.6652
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:25 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:25 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:25 --> Total execution time: 2.5501
DEBUG - 2015-04-01 13:54:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:26 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:26 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:26 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:27 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:27 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:27 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:27 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:27 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:27 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:27 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:27 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:27 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:28 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:28 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:28 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:28 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:29 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:29 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:29 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:29 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:29 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:29 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:29 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:29 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Total execution time: 2.6562
DEBUG - 2015-04-01 13:54:29 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:54:29 --> URI Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Router Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:29 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:29 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:30 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Output Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Security Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:30 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:30 --> Total execution time: 3.7422
DEBUG - 2015-04-01 13:54:30 --> Input Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:54:30 --> Total execution time: 3.0362
DEBUG - 2015-04-01 13:54:30 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:30 --> Language Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:30 --> Config Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:30 --> Loader Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:54:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:54:30 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:54:30 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:54:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:54:31 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:31 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:31 --> Session Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:54:31 --> Session routines successfully run
DEBUG - 2015-04-01 13:54:31 --> Controller Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:54:31 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:54:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Email Class Initialized
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:54:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:31 --> Total execution time: 3.6592
DEBUG - 2015-04-01 13:54:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:54:31 --> Model Class Initialized
DEBUG - 2015-04-01 13:54:31 --> Final output sent to browser
DEBUG - 2015-04-01 13:54:31 --> Total execution time: 2.3881
DEBUG - 2015-04-01 13:57:00 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:00 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:00 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:00 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:00 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:00 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:00 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:00 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:00 --> Helper loaded: directory_helper
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-01 13:57:00 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-01 13:57:00 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:00 --> Total execution time: 0.7990
DEBUG - 2015-04-01 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:01 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:01 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:01 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:01 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:01 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:01 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:02 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:02 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:02 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:02 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:02 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:02 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:02 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:02 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:02 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> Total execution time: 1.3441
DEBUG - 2015-04-01 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:02 --> Model Class Initialized
ERROR - 2015-04-01 13:57:02 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:03 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:03 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:03 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:03 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:04 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:04 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:04 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:04 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:04 --> Total execution time: 0.7450
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:04 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:04 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:04 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:05 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:05 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:05 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:05 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:06 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:06 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:06 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Total execution time: 3.1042
DEBUG - 2015-04-01 13:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:06 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:06 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:07 --> Total execution time: 3.2352
DEBUG - 2015-04-01 13:57:07 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:07 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:07 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:07 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:07 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:07 --> Total execution time: 3.5072
DEBUG - 2015-04-01 13:57:07 --> Total execution time: 3.4602
DEBUG - 2015-04-01 13:57:07 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:07 --> URI Class Initialized
ERROR - 2015-04-01 13:57:07 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-01 13:57:07 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:07 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:07 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:07 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:07 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:07 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:07 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:07 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:07 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:07 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:07 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:07 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:08 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:08 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:08 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:10 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:10 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:10 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:10 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:11 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:11 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:11 --> Total execution time: 3.9492
DEBUG - 2015-04-01 13:57:11 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:11 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:11 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:11 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:11 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:11 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:11 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:11 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:11 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:11 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:12 --> Total execution time: 4.9233
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:12 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:12 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:12 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:12 --> Total execution time: 4.3903
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:12 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:12 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:12 --> Total execution time: 5.2993
DEBUG - 2015-04-01 13:57:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:13 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:13 --> Final output sent to browser
DEBUG - 2015-04-01 13:57:13 --> Total execution time: 5.0823
DEBUG - 2015-04-01 13:57:48 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 13:57:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 13:57:48 --> URI Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Router Class Initialized
DEBUG - 2015-04-01 13:57:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-01 13:57:48 --> Output Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Security Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Input Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 13:57:48 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Language Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Config Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Loader Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: url_helper
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: form_helper
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: language_helper
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: user_helper
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: date_helper
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-01 13:57:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-01 13:57:48 --> Database Driver Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Session Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: string_helper
DEBUG - 2015-04-01 13:57:48 --> Session routines successfully run
DEBUG - 2015-04-01 13:57:48 --> Controller Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-01 13:57:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-01 13:57:48 --> Email Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-01 13:57:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-01 13:57:48 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-01 13:57:48 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:48 --> Form Validation Class Initialized
DEBUG - 2015-04-01 13:57:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-01 13:57:48 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-01 13:57:48 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-01 13:57:48 --> Model Class Initialized
DEBUG - 2015-04-01 13:57:49 --> File loaded: application/modules_core/sites/views/partials/success.php
