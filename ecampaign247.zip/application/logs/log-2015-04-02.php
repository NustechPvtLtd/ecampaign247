<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-02 05:49:25 --> Config Class Initialized
DEBUG - 2015-04-02 05:49:25 --> Hooks Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Utf8 Class Initialized
DEBUG - 2015-04-02 05:49:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 05:49:26 --> URI Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Router Class Initialized
DEBUG - 2015-04-02 05:49:26 --> No URI present. Default controller set.
DEBUG - 2015-04-02 05:49:26 --> Output Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Security Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Input Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 05:49:26 --> Language Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Language Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Config Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Loader Class Initialized
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: url_helper
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: form_helper
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 05:49:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 05:49:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 05:49:27 --> Database Driver Class Initialized
DEBUG - 2015-04-02 05:49:28 --> Session Class Initialized
DEBUG - 2015-04-02 05:49:28 --> Helper loaded: string_helper
DEBUG - 2015-04-02 05:49:28 --> A session cookie was not found.
DEBUG - 2015-04-02 05:49:28 --> Session routines successfully run
DEBUG - 2015-04-02 05:49:28 --> Controller Class Initialized
DEBUG - 2015-04-02 05:49:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-02 05:49:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 05:49:28 --> Email Class Initialized
DEBUG - 2015-04-02 05:49:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 05:49:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 05:49:28 --> Model Class Initialized
DEBUG - 2015-04-02 05:49:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 05:49:28 --> Model Class Initialized
DEBUG - 2015-04-02 05:49:28 --> Form Validation Class Initialized
DEBUG - 2015-04-02 05:49:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-02 05:49:29 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-02 05:49:29 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-02 05:49:29 --> Final output sent to browser
DEBUG - 2015-04-02 05:49:29 --> Total execution time: 3.3650
DEBUG - 2015-04-02 06:04:33 --> Config Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Hooks Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Utf8 Class Initialized
DEBUG - 2015-04-02 06:04:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 06:04:33 --> URI Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Router Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Output Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Security Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Input Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 06:04:33 --> Language Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Language Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Config Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Loader Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: url_helper
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: form_helper
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: language_helper
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: user_helper
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: date_helper
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 06:04:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 06:04:33 --> Database Driver Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Session Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 06:04:33 --> Session routines successfully run
DEBUG - 2015-04-02 06:04:33 --> Controller Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Login MX_Controller Initialized
DEBUG - 2015-04-02 06:04:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 06:04:33 --> Email Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 06:04:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 06:04:33 --> Model Class Initialized
DEBUG - 2015-04-02 06:04:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 06:04:33 --> Model Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Form Validation Class Initialized
DEBUG - 2015-04-02 06:04:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-02 06:04:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-02 06:04:34 --> Config Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Hooks Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Utf8 Class Initialized
DEBUG - 2015-04-02 06:04:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 06:04:34 --> URI Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Router Class Initialized
DEBUG - 2015-04-02 06:04:34 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-02 06:04:34 --> Output Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Security Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Input Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 06:04:34 --> Language Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Language Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Config Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Loader Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: url_helper
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: form_helper
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: language_helper
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: user_helper
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: date_helper
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 06:04:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 06:04:34 --> Database Driver Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Session Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: string_helper
DEBUG - 2015-04-02 06:04:34 --> Session routines successfully run
DEBUG - 2015-04-02 06:04:34 --> Controller Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Customer MX_Controller Initialized
DEBUG - 2015-04-02 06:04:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 06:04:34 --> Email Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 06:04:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 06:04:34 --> Model Class Initialized
DEBUG - 2015-04-02 06:04:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 06:04:34 --> Model Class Initialized
DEBUG - 2015-04-02 06:04:34 --> Form Validation Class Initialized
DEBUG - 2015-04-02 06:04:34 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-02 06:04:34 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-02 06:04:34 --> Final output sent to browser
DEBUG - 2015-04-02 06:04:34 --> Total execution time: 0.6850
DEBUG - 2015-04-02 06:04:35 --> Config Class Initialized
DEBUG - 2015-04-02 06:04:35 --> Hooks Class Initialized
DEBUG - 2015-04-02 06:04:35 --> Utf8 Class Initialized
DEBUG - 2015-04-02 06:04:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 06:04:35 --> URI Class Initialized
DEBUG - 2015-04-02 06:04:35 --> Router Class Initialized
ERROR - 2015-04-02 06:04:35 --> 404 Page Not Found --> 
DEBUG - 2015-04-02 08:29:31 --> Config Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:29:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:29:31 --> URI Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Router Class Initialized
DEBUG - 2015-04-02 08:29:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:29:31 --> Output Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Security Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Input Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:29:31 --> Language Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Language Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Config Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Loader Class Initialized
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:29:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:29:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:29:32 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:29:33 --> Session Class Initialized
DEBUG - 2015-04-02 08:29:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:29:33 --> A session cookie was not found.
DEBUG - 2015-04-02 08:29:33 --> Session routines successfully run
DEBUG - 2015-04-02 08:29:33 --> Controller Class Initialized
DEBUG - 2015-04-02 08:29:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:29:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:29:33 --> Email Class Initialized
DEBUG - 2015-04-02 08:29:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:29:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:29:33 --> Model Class Initialized
DEBUG - 2015-04-02 08:29:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:29:33 --> Model Class Initialized
DEBUG - 2015-04-02 08:29:33 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Config Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:29:34 --> URI Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Router Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Output Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Security Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Input Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:29:34 --> Language Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Language Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Config Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Loader Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:29:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:29:34 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Session Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:29:34 --> Session routines successfully run
DEBUG - 2015-04-02 08:29:34 --> Controller Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Login MX_Controller Initialized
DEBUG - 2015-04-02 08:29:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:29:34 --> Email Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:29:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:29:34 --> Model Class Initialized
DEBUG - 2015-04-02 08:29:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:29:34 --> Model Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:29:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-02 08:29:34 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-02 08:29:34 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-02 08:29:34 --> Final output sent to browser
DEBUG - 2015-04-02 08:29:34 --> Total execution time: 0.8420
DEBUG - 2015-04-02 08:30:28 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:28 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:28 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:28 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:29 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:29 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Login MX_Controller Initialized
DEBUG - 2015-04-02 08:30:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:29 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:29 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:29 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-02 08:30:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-02 08:30:30 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:30 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:30 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-02 08:30:30 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:30 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:30 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:30 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:30 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Customer MX_Controller Initialized
DEBUG - 2015-04-02 08:30:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:30 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:30 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:30 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:30 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:30 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-02 08:30:30 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-02 08:30:30 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:30 --> Total execution time: 0.6450
DEBUG - 2015-04-02 08:30:31 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:31 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:31 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:31 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:31 --> Router Class Initialized
ERROR - 2015-04-02 08:30:31 --> 404 Page Not Found --> 
DEBUG - 2015-04-02 08:30:36 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:36 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:36 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:36 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:36 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:36 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:36 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:36 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:37 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:37 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:37 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:37 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:37 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:37 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-02 08:30:37 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 08:30:37 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:37 --> Total execution time: 0.9541
DEBUG - 2015-04-02 08:30:37 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:37 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:37 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:37 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:37 --> Router Class Initialized
ERROR - 2015-04-02 08:30:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-02 08:30:38 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:38 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:38 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:38 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:38 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:38 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:38 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:38 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:38 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:38 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:38 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:38 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:38 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:38 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:38 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:38 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:38 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:38 --> Total execution time: 0.9061
DEBUG - 2015-04-02 08:30:39 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:39 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:39 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:39 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:39 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:39 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:39 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:39 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:39 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:39 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:39 --> Total execution time: 0.7160
DEBUG - 2015-04-02 08:30:47 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:47 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:47 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:47 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:47 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:47 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:47 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:48 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:48 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:48 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:48 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:48 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:48 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:48 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:48 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:48 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:48 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-02 08:30:48 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 08:30:48 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:48 --> Total execution time: 0.7770
DEBUG - 2015-04-02 08:30:48 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:48 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:48 --> Router Class Initialized
ERROR - 2015-04-02 08:30:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-02 08:30:50 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:50 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:50 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:50 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:50 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:50 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: date_helper
ERROR - 2015-04-02 08:30:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:50 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:50 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:50 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:50 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:51 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:51 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:51 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:51 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:51 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:51 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:51 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:51 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:51 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:51 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:51 --> Total execution time: 0.9381
DEBUG - 2015-04-02 08:30:52 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:52 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:52 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:52 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:52 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:52 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:52 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:52 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:52 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:53 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:53 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:53 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:53 --> Total execution time: 2.9822
DEBUG - 2015-04-02 08:30:55 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:55 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:55 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:55 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:55 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:55 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:55 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:55 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:55 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:55 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:55 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:55 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:55 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:55 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 08:30:56 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:56 --> Total execution time: 0.9651
DEBUG - 2015-04-02 08:30:56 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:56 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:56 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:56 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:56 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:56 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:56 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:56 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:56 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:56 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:56 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:56 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:57 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 08:30:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:57 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:57 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:57 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:57 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:57 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:57 --> Total execution time: 0.7700
DEBUG - 2015-04-02 08:30:57 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:57 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:57 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:58 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:58 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:58 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:30:58 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:58 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:58 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:58 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:58 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:58 --> URI Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:58 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:58 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:58 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:58 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:58 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:58 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:58 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:58 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:58 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:58 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:58 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:59 --> Router Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:59 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:30:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Output Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Security Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:59 --> Total execution time: 1.7761
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:59 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:59 --> Input Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:59 --> Language Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:59 --> Config Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:59 --> Loader Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Session Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:30:59 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:59 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:30:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:30:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:30:59 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:59 --> Session routines successfully run
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:59 --> Controller Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:30:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Email Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:30:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:30:59 --> Final output sent to browser
DEBUG - 2015-04-02 08:30:59 --> Total execution time: 1.6221
DEBUG - 2015-04-02 08:30:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:30:59 --> Model Class Initialized
DEBUG - 2015-04-02 08:30:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:00 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:00 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:00 --> Total execution time: 2.7372
DEBUG - 2015-04-02 08:31:00 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:31:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:31:00 --> URI Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Router Class Initialized
DEBUG - 2015-04-02 08:31:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:31:00 --> Output Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Security Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Input Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:31:00 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Loader Class Initialized
DEBUG - 2015-04-02 08:31:00 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:31:01 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:31:01 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> URI Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Router Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:31:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:31:01 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:01 --> Output Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:31:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:31:01 --> URI Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:31:01 --> URI Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:01 --> Security Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:01 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:01 --> Input Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Router Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:31:01 --> Router Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:01 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:01 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:31:01 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Output Class Initialized
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Security Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Input Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Output Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:01 --> Security Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:31:01 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Input Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Loader Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:01 --> URI Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Router Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:01 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:31:01 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Loader Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:31:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:31:01 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:01 --> Total execution time: 1.2311
DEBUG - 2015-04-02 08:31:01 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:01 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:02 --> Total execution time: 3.8252
DEBUG - 2015-04-02 08:31:02 --> Loader Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:31:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:31:02 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 08:31:02 --> Output Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Security Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:31:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:31:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:02 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:02 --> Input Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:03 --> Controller Class Initialized
ERROR - 2015-04-02 08:31:03 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:31:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 08:31:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:31:03 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Language Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Config Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:03 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:31:03 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:03 --> Loader Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:31:03 --> Total execution time: 5.5763
DEBUG - 2015-04-02 08:31:03 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: url_helper
DEBUG - 2015-04-02 08:31:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:03 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:03 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:03 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: form_helper
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: language_helper
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: user_helper
DEBUG - 2015-04-02 08:31:03 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:03 --> Helper loaded: date_helper
DEBUG - 2015-04-02 08:31:03 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:03 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:04 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 08:31:04 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 08:31:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:04 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Total execution time: 3.1762
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:04 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:04 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:04 --> Total execution time: 4.0002
DEBUG - 2015-04-02 08:31:05 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:06 --> Session Class Initialized
DEBUG - 2015-04-02 08:31:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:06 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:06 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:06 --> Total execution time: 5.6493
DEBUG - 2015-04-02 08:31:06 --> Helper loaded: string_helper
DEBUG - 2015-04-02 08:31:06 --> Session routines successfully run
DEBUG - 2015-04-02 08:31:06 --> Controller Class Initialized
DEBUG - 2015-04-02 08:31:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 08:31:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 08:31:06 --> Email Class Initialized
DEBUG - 2015-04-02 08:31:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 08:31:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 08:31:07 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 08:31:07 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:07 --> Form Validation Class Initialized
DEBUG - 2015-04-02 08:31:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 08:31:07 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 08:31:07 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 08:31:07 --> Model Class Initialized
DEBUG - 2015-04-02 08:31:07 --> Final output sent to browser
DEBUG - 2015-04-02 08:31:07 --> Total execution time: 6.3724
DEBUG - 2015-04-02 09:04:56 --> Config Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:04:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:04:56 --> URI Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Router Class Initialized
DEBUG - 2015-04-02 09:04:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:04:56 --> Output Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Security Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Input Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:04:56 --> Language Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Language Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Config Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Loader Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:04:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:04:56 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Session Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:04:56 --> Session routines successfully run
DEBUG - 2015-04-02 09:04:56 --> Controller Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:04:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:04:56 --> Email Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:04:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:04:56 --> Model Class Initialized
DEBUG - 2015-04-02 09:04:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:04:56 --> Model Class Initialized
DEBUG - 2015-04-02 09:04:56 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:04:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:04:56 --> Model Class Initialized
DEBUG - 2015-04-02 09:04:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:04:56 --> Model Class Initialized
DEBUG - 2015-04-02 09:04:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:04:56 --> Model Class Initialized
DEBUG - 2015-04-02 09:04:57 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-02 09:05:02 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:02 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:02 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:02 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:02 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:02 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:02 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:03 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:03 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:03 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:03 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:03 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:03 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:03 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 09:05:03 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 09:05:03 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:03 --> Total execution time: 1.1651
DEBUG - 2015-04-02 09:05:04 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:04 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:04 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:04 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:04 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:04 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:04 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:04 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:04 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:04 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 09:05:04 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:04 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:04 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:04 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:04 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:04 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:04 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:04 --> Total execution time: 0.7060
DEBUG - 2015-04-02 09:05:04 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:05 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:05 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:05 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:05 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:05 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:05 --> Model Class Initialized
ERROR - 2015-04-02 09:05:05 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 09:05:08 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:08 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:08 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:08 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:08 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:09 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:09 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:09 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:09 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:09 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:09 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:09 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:09 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:09 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:09 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:09 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:09 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:09 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:09 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:09 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:09 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:10 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:10 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:10 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:10 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:10 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:10 --> Total execution time: 1.5871
DEBUG - 2015-04-02 09:05:10 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:10 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:10 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:10 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:10 --> Total execution time: 2.1311
DEBUG - 2015-04-02 09:05:11 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:11 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:11 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:11 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:11 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:11 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:11 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:11 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:12 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:12 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:12 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:12 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:12 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:12 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:12 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:12 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:12 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:12 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:05:12 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:12 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:12 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:12 --> URI Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:12 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:12 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:12 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:12 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Router Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:12 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:12 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:05:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:12 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:12 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:13 --> Total execution time: 3.8882
DEBUG - 2015-04-02 09:05:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:13 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:13 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:13 --> Output Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:13 --> Security Class Initialized
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Input Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:05:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Language Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Config Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:13 --> Loader Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:05:13 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:05:13 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:13 --> Total execution time: 2.4651
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:13 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:13 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:05:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:14 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:14 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:14 --> Total execution time: 2.3631
DEBUG - 2015-04-02 09:05:14 --> Total execution time: 2.5581
DEBUG - 2015-04-02 09:05:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:05:14 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:14 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:14 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:14 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Session Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:14 --> Total execution time: 6.1654
DEBUG - 2015-04-02 09:05:14 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:14 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:05:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:14 --> Session routines successfully run
DEBUG - 2015-04-02 09:05:14 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Controller Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:05:14 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:14 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:05:14 --> Email Class Initialized
DEBUG - 2015-04-02 09:05:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:05:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:15 --> Total execution time: 3.1782
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:05:15 --> Model Class Initialized
DEBUG - 2015-04-02 09:05:15 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:15 --> Total execution time: 3.1982
DEBUG - 2015-04-02 09:05:15 --> Final output sent to browser
DEBUG - 2015-04-02 09:05:15 --> Total execution time: 6.3224
DEBUG - 2015-04-02 09:18:32 --> Config Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Hooks Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Utf8 Class Initialized
DEBUG - 2015-04-02 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 09:18:32 --> URI Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Router Class Initialized
DEBUG - 2015-04-02 09:18:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 09:18:32 --> Output Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Security Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Input Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 09:18:32 --> Language Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Language Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Config Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Loader Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: url_helper
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: form_helper
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: language_helper
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: user_helper
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: date_helper
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 09:18:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 09:18:32 --> Database Driver Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Session Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: string_helper
DEBUG - 2015-04-02 09:18:32 --> Session routines successfully run
DEBUG - 2015-04-02 09:18:32 --> Controller Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 09:18:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 09:18:32 --> Email Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 09:18:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 09:18:32 --> Model Class Initialized
DEBUG - 2015-04-02 09:18:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 09:18:32 --> Model Class Initialized
DEBUG - 2015-04-02 09:18:32 --> Form Validation Class Initialized
DEBUG - 2015-04-02 09:18:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 09:18:32 --> Model Class Initialized
DEBUG - 2015-04-02 09:18:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 09:18:32 --> Model Class Initialized
DEBUG - 2015-04-02 09:18:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 09:18:32 --> Model Class Initialized
ERROR - 2015-04-02 09:18:33 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 490
ERROR - 2015-04-02 09:18:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 419
DEBUG - 2015-04-02 09:18:33 --> Final output sent to browser
DEBUG - 2015-04-02 09:18:33 --> Total execution time: 0.6230
DEBUG - 2015-04-02 10:41:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:10 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:10 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:10 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:10 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:10 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:10 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:10 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 10:41:11 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 10:41:11 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:11 --> Total execution time: 1.3351
DEBUG - 2015-04-02 10:41:12 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:12 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:12 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:12 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 10:41:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:12 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:12 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:12 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:12 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:12 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:13 --> Total execution time: 1.1681
DEBUG - 2015-04-02 10:41:13 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:13 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:13 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:13 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:13 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:13 --> Model Class Initialized
ERROR - 2015-04-02 10:41:13 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:41:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:16 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:16 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:16 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:16 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:17 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:17 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:17 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:17 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:17 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:17 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:17 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Total execution time: 1.3331
DEBUG - 2015-04-02 10:41:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:17 --> Total execution time: 1.0891
DEBUG - 2015-04-02 10:41:17 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:17 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:17 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:17 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:17 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:17 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:17 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:18 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:18 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:18 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:18 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:18 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:18 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:18 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:18 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:18 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:18 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:18 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:18 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:18 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:18 --> Total execution time: 1.1581
DEBUG - 2015-04-02 10:41:18 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:18 --> Total execution time: 1.0311
DEBUG - 2015-04-02 10:41:18 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:19 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:19 --> Total execution time: 1.2721
DEBUG - 2015-04-02 10:41:20 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:20 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:20 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:20 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:20 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:20 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:21 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:21 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:21 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:21 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:21 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:21 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:21 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:22 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:22 --> Total execution time: 1.5581
DEBUG - 2015-04-02 10:41:22 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Total execution time: 1.7691
DEBUG - 2015-04-02 10:41:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:22 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Total execution time: 1.9461
DEBUG - 2015-04-02 10:41:22 --> Total execution time: 1.3021
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:41:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:41:22 --> Total execution time: 1.6671
DEBUG - 2015-04-02 10:41:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:41:59 --> URI Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Router Class Initialized
DEBUG - 2015-04-02 10:41:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:41:59 --> Output Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Security Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Input Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:41:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Loader Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:41:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:41:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Session Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:41:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:41:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:41:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:41:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:41:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:41:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:41:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:41:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:41:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:41:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:00 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:00 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:00 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-02 10:42:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:08 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:08 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:08 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:09 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 10:42:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 10:42:09 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:09 --> Total execution time: 1.0051
DEBUG - 2015-04-02 10:42:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:10 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:10 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:10 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:10 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:10 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:11 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:11 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: user_helper
ERROR - 2015-04-02 10:42:11 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:11 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:11 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:11 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 10:42:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:11 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:11 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:11 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:11 --> Total execution time: 1.2211
DEBUG - 2015-04-02 10:42:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:14 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:14 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:15 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:15 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:15 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:15 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:15 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:15 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:15 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:15 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:15 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:15 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:15 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:15 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:15 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:16 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:16 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:16 --> Total execution time: 2.0381
DEBUG - 2015-04-02 10:42:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:16 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:16 --> Total execution time: 1.6031
DEBUG - 2015-04-02 10:42:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:16 --> Total execution time: 1.8861
DEBUG - 2015-04-02 10:42:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:17 --> Total execution time: 2.1651
DEBUG - 2015-04-02 10:42:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:17 --> Total execution time: 2.2921
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:42:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:18 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:42:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:42:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:42:19 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:42:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:19 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:19 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:19 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:20 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:20 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:20 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:20 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:20 --> Total execution time: 2.2171
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:20 --> Total execution time: 2.0881
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:20 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:20 --> Total execution time: 2.9962
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:42:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:42:21 --> Total execution time: 3.1822
DEBUG - 2015-04-02 10:42:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:42:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:42:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:42:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:42:21 --> Final output sent to browser
DEBUG - 2015-04-02 10:42:21 --> Total execution time: 3.5452
DEBUG - 2015-04-02 10:49:27 --> Config Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:49:27 --> URI Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Router Class Initialized
DEBUG - 2015-04-02 10:49:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:49:27 --> Output Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Security Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Input Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:49:27 --> Language Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Language Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Config Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Loader Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:49:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:49:27 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Session Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:49:27 --> Session routines successfully run
DEBUG - 2015-04-02 10:49:27 --> Controller Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Session Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Session routines successfully run
DEBUG - 2015-04-02 10:49:27 --> Controller Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:49:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:49:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:49:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:49:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:49:27 --> Email Class Initialized
ERROR - 2015-04-02 10:49:28 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-02 10:49:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:49:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:49:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:49:28 --> Model Class Initialized
ERROR - 2015-04-02 10:49:28 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-02 10:49:28 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-02 10:49:28 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-02 10:49:28 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-02 10:49:50 --> Config Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:49:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:49:50 --> URI Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Router Class Initialized
DEBUG - 2015-04-02 10:49:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:49:50 --> Output Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Security Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Input Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:49:50 --> Language Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Language Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Config Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Loader Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:49:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:49:50 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Session Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:49:50 --> Session routines successfully run
DEBUG - 2015-04-02 10:49:50 --> Controller Class Initialized
DEBUG - 2015-04-02 10:49:50 --> Session Class Initialized
DEBUG - 2015-04-02 10:49:51 --> Session routines successfully run
DEBUG - 2015-04-02 10:49:51 --> Controller Class Initialized
DEBUG - 2015-04-02 10:49:51 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:49:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:49:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:49:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:49:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:49:51 --> Email Class Initialized
ERROR - 2015-04-02 10:49:51 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-02 10:49:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:49:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:49:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:49:51 --> Model Class Initialized
ERROR - 2015-04-02 10:49:51 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-02 10:49:51 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-02 10:49:51 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-02 10:49:51 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-02 10:55:07 --> Config Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:55:07 --> URI Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:55:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:55:07 --> Output Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Security Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Input Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:55:07 --> Language Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Language Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Config Class Initialized
DEBUG - 2015-04-02 10:55:07 --> Loader Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:55:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:55:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:55:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:55:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:55:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:55:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:55:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:55:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:55:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:55:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:55:08 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:55:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:55:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:55:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:55:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:55:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:55:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:55:08 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-02 10:56:57 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:56:57 --> URI Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Router Class Initialized
DEBUG - 2015-04-02 10:56:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:56:57 --> Output Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Security Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Input Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:56:57 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Loader Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:56:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:56:57 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Session Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:56:57 --> Session routines successfully run
DEBUG - 2015-04-02 10:56:57 --> Controller Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:56:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:56:57 --> Email Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:56:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:56:57 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:56:57 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:57 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:56:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:56:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:56:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:58 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 10:56:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 10:56:58 --> Final output sent to browser
DEBUG - 2015-04-02 10:56:58 --> Total execution time: 0.9960
DEBUG - 2015-04-02 10:56:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:56:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:56:59 --> URI Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Router Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:56:59 --> Output Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Security Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Input Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:56:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:56:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:59 --> URI Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Loader Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Router Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:56:59 --> Output Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:56:59 --> Security Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:56:59 --> Input Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:56:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:56:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:56:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Language Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Config Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Session Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Loader Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:56:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:56:59 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Session Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:56:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:56:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 10:56:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:56:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:56:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:56:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:56:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:56:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:56:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> Final output sent to browser
DEBUG - 2015-04-02 10:56:59 --> Total execution time: 0.6240
DEBUG - 2015-04-02 10:56:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:56:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:56:59 --> Model Class Initialized
ERROR - 2015-04-02 10:56:59 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:03 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:03 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:03 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:03 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:03 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:03 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:03 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:03 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:03 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:03 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:03 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:04 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:04 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:04 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:04 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:04 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:04 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:04 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:04 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:04 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:04 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:04 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:04 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:04 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:04 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:04 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:04 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:04 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:04 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:04 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:04 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:04 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:04 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:04 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:04 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:04 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:04 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: date_helper
ERROR - 2015-04-02 10:57:05 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:05 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:05 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:05 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:05 --> Total execution time: 1.6641
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:05 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:05 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:05 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:05 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:05 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:05 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:05 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:05 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:05 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:05 --> Total execution time: 1.7241
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:05 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:06 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:06 --> Total execution time: 2.1611
DEBUG - 2015-04-02 10:57:06 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:06 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:06 --> Total execution time: 2.0761
DEBUG - 2015-04-02 10:57:06 --> Total execution time: 2.2131
DEBUG - 2015-04-02 10:57:06 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:06 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:06 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:06 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:06 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:06 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:07 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:07 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:07 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:07 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:07 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:07 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:07 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:07 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:07 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:07 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:08 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:08 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:08 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:08 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:08 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:08 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:08 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:09 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:09 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:09 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Total execution time: 2.8472
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:09 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:09 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:10 --> Total execution time: 2.3991
DEBUG - 2015-04-02 10:57:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:10 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:10 --> Total execution time: 2.1821
DEBUG - 2015-04-02 10:57:10 --> Total execution time: 3.1762
DEBUG - 2015-04-02 10:57:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:10 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:10 --> Total execution time: 2.4901
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:10 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:10 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:11 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:11 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:11 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:11 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:11 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:11 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:11 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:11 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:11 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:11 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:12 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:12 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:12 --> Form Validation Class Initialized
ERROR - 2015-04-02 10:57:12 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
ERROR - 2015-04-02 10:57:12 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:12 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:12 --> Total execution time: 2.2981
DEBUG - 2015-04-02 10:57:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:13 --> Model Class Initialized
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:13 --> Model Class Initialized
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:13 --> Total execution time: 2.7652
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:13 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:13 --> Total execution time: 2.7522
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:13 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:13 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:13 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:13 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:13 --> Output Class Initialized
ERROR - 2015-04-02 10:57:13 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:13 --> Total execution time: 2.7272
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:13 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:13 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Total execution time: 3.4752
DEBUG - 2015-04-02 10:57:13 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:13 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:13 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:14 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:14 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:14 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:14 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:14 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:14 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:14 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:14 --> UTF-8 Support Enabled
ERROR - 2015-04-02 10:57:14 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:14 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:14 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:14 --> Total execution time: 3.6922
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:14 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:14 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:14 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:14 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:14 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:14 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:14 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:14 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:14 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:14 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:14 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:14 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:14 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:14 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:14 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:14 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:15 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:15 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:15 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:15 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: language_helper
ERROR - 2015-04-02 10:57:15 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:15 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: cookie_helper
ERROR - 2015-04-02 10:57:15 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:15 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Total execution time: 2.0031
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:15 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:15 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:15 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:15 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:15 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:15 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:15 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:16 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
ERROR - 2015-04-02 10:57:16 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:16 --> Session Class Initialized
ERROR - 2015-04-02 10:57:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:16 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:16 --> Config file loaded: application/config/ion_auth.php
ERROR - 2015-04-02 10:57:16 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: string_helper
ERROR - 2015-04-02 10:57:16 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:16 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:16 --> Total execution time: 2.7692
DEBUG - 2015-04-02 10:57:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Total execution time: 2.6061
DEBUG - 2015-04-02 10:57:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:16 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:16 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:16 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:16 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:16 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:16 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:16 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:16 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:16 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:16 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:16 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:17 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:17 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:17 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/usermodel.php
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: language_helper
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:17 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Total execution time: 1.7951
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:17 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:17 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:17 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:17 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:17 --> Router Class Initialized
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:17 --> Helper loaded: string_helper
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:17 --> Session routines successfully run
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:17 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:17 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:17 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-02 10:57:17 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:17 --> Total execution time: 2.7562
DEBUG - 2015-04-02 10:57:17 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:17 --> Total execution time: 3.6572
DEBUG - 2015-04-02 10:57:17 --> Total execution time: 3.6732
DEBUG - 2015-04-02 10:57:17 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:18 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:18 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:18 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:18 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:18 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:18 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:18 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:18 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:18 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:18 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:18 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:18 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:18 --> Controller Class Initialized
ERROR - 2015-04-02 10:57:18 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
ERROR - 2015-04-02 10:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:19 --> Total execution time: 2.3921
DEBUG - 2015-04-02 10:57:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config Class Initialized
ERROR - 2015-04-02 10:57:19 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:19 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:19 --> Total execution time: 2.8012
DEBUG - 2015-04-02 10:57:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:19 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:19 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:19 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:19 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:19 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:19 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:19 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:19 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:19 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:19 --> Config Class Initialized
ERROR - 2015-04-02 10:57:19 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:19 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:19 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:19 --> Total execution time: 2.4391
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:20 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:20 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:20 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:20 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:20 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:20 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:20 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:20 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:20 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:20 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:20 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:20 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:20 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:20 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:21 --> Controller Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:21 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:21 --> Total execution time: 2.8902
DEBUG - 2015-04-02 10:57:21 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:21 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:21 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:21 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:21 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:21 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:21 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Output Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:21 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:21 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:21 --> Total execution time: 3.6062
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:21 --> Model Class Initialized
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:21 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:21 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:21 --> Total execution time: 3.7092
DEBUG - 2015-04-02 10:57:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
ERROR - 2015-04-02 10:57:21 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Total execution time: 1.9811
DEBUG - 2015-04-02 10:57:22 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Loader Class Initialized
ERROR - 2015-04-02 10:57:22 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:22 --> Total execution time: 2.9772
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:22 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:22 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:22 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:22 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:22 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
ERROR - 2015-04-02 10:57:22 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:22 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Session Class Initialized
ERROR - 2015-04-02 10:57:22 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:22 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:22 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:22 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:22 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:22 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:22 --> Total execution time: 3.5772
DEBUG - 2015-04-02 10:57:22 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:22 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:22 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:22 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:23 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:23 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:23 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:23 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:23 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:23 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:23 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:23 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:23 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:23 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:23 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:23 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:23 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:23 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:23 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:23 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:23 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:23 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:23 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:23 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Session Class Initialized
ERROR - 2015-04-02 10:57:23 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:23 --> Output Class Initialized
ERROR - 2015-04-02 10:57:23 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:23 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:23 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:23 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:23 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:23 --> Total execution time: 2.5351
DEBUG - 2015-04-02 10:57:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:23 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:23 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:24 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:24 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:24 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:24 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
ERROR - 2015-04-02 10:57:24 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/usermodel.php
ERROR - 2015-04-02 10:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:24 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Total execution time: 2.2271
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:24 --> Model Class Initialized
ERROR - 2015-04-02 10:57:24 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:24 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:24 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:24 --> Total execution time: 1.9461
DEBUG - 2015-04-02 10:57:24 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:24 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:24 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:24 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:24 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:25 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:25 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:25 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:25 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:25 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Global POST and COOKIE data sanitized
ERROR - 2015-04-02 10:57:25 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:25 --> Language Class Initialized
ERROR - 2015-04-02 10:57:25 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:25 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-02 10:57:25 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:25 --> Total execution time: 2.8412
DEBUG - 2015-04-02 10:57:25 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:25 --> Total execution time: 2.4161
DEBUG - 2015-04-02 10:57:25 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:25 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:25 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:25 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:25 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:25 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:26 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:26 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:26 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:26 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:26 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:26 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:26 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:26 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:26 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:26 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:26 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:26 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:26 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:26 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:26 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:26 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:26 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:27 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:27 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: string_helper
ERROR - 2015-04-02 10:57:27 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:27 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:27 --> Total execution time: 2.2611
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:27 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:27 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:27 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:27 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:27 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:27 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:27 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:27 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:27 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:27 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
ERROR - 2015-04-02 10:57:27 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:27 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:27 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:27 --> Total execution time: 5.7103
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:27 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:27 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:28 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:28 --> Model Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:28 --> Config Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:28 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:28 --> Total execution time: 3.2832
DEBUG - 2015-04-02 10:57:28 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:28 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:28 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:28 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:28 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:28 --> Router Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:28 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:28 --> URI Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:28 --> Session routines successfully run
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:28 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:28 --> Router Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:28 --> Final output sent to browser
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:28 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:28 --> Total execution time: 2.9222
DEBUG - 2015-04-02 10:57:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:28 --> Output Class Initialized
ERROR - 2015-04-02 10:57:28 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:28 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Total execution time: 2.9902
DEBUG - 2015-04-02 10:57:28 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:29 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:29 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Total execution time: 5.0113
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:29 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:29 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:29 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:29 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:29 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:29 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:29 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:29 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:29 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:29 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:29 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:29 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:29 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:29 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:29 --> Utf8 Class Initialized
ERROR - 2015-04-02 10:57:29 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:29 --> UTF-8 Support Enabled
ERROR - 2015-04-02 10:57:29 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:29 --> Total execution time: 2.4871
DEBUG - 2015-04-02 10:57:29 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:29 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:29 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:29 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:29 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:29 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:29 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:29 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:30 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:30 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:30 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:30 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:30 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:30 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:30 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:30 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:30 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:30 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:30 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:30 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:30 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:30 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
ERROR - 2015-04-02 10:57:30 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:30 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Output Class Initialized
ERROR - 2015-04-02 10:57:30 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:30 --> Total execution time: 2.2881
DEBUG - 2015-04-02 10:57:30 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:31 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:31 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:31 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:31 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:31 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:31 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
ERROR - 2015-04-02 10:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:31 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: date_helper
ERROR - 2015-04-02 10:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:31 --> Final output sent to browser
ERROR - 2015-04-02 10:57:31 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:31 --> Total execution time: 2.3571
DEBUG - 2015-04-02 10:57:31 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:31 --> Database Driver Class Initialized
ERROR - 2015-04-02 10:57:31 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:31 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:31 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:31 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:31 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:31 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:31 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:31 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:31 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Total execution time: 2.8092
DEBUG - 2015-04-02 10:57:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:31 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:31 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:32 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:32 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:32 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:32 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:32 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:32 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:32 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:32 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Output Class Initialized
ERROR - 2015-04-02 10:57:32 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: date_helper
ERROR - 2015-04-02 10:57:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:32 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:32 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:32 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: language_helper
ERROR - 2015-04-02 10:57:32 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:32 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:32 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Config Class Initialized
ERROR - 2015-04-02 10:57:32 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:32 --> Total execution time: 4.1812
DEBUG - 2015-04-02 10:57:32 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:32 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:32 --> Total execution time: 2.6541
DEBUG - 2015-04-02 10:57:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:33 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:33 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:33 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:33 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:33 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:33 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:33 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:33 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:33 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:33 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:33 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:33 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:33 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Language Class Initialized
ERROR - 2015-04-02 10:57:33 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:33 --> Config file loaded: application/config/ion_auth.php
ERROR - 2015-04-02 10:57:33 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:33 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:33 --> Total execution time: 4.0082
DEBUG - 2015-04-02 10:57:33 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:33 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:33 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:33 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:33 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:33 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:33 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:33 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:33 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Config file loaded: application/config/ion_auth.php
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:34 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Config Class Initialized
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:34 --> Total execution time: 2.4811
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:34 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:34 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:34 --> Config Class Initialized
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:34 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:34 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:34 --> Total execution time: 2.4481
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:34 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:34 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:34 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:34 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:34 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:34 --> Total execution time: 3.9772
DEBUG - 2015-04-02 10:57:34 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Helper loaded: date_helper
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:34 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:34 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:34 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:34 --> Total execution time: 2.1741
DEBUG - 2015-04-02 10:57:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:34 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:35 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:35 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:35 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:35 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:35 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:35 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:35 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:35 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:35 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:35 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:35 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:35 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:35 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:35 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:35 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:35 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:35 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:35 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:35 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:35 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:36 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:36 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:36 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:36 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:36 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:36 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:36 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:36 --> Form Validation Class Initialized
ERROR - 2015-04-02 10:57:36 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:36 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:36 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:36 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:36 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:36 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Total execution time: 3.3952
DEBUG - 2015-04-02 10:57:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:36 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:36 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:36 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:36 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:36 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:36 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:36 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:36 --> Router Class Initialized
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:37 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:37 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:37 --> Total execution time: 2.6922
DEBUG - 2015-04-02 10:57:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:37 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Security Class Initialized
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:37 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:37 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Loader Class Initialized
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:37 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:37 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:37 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:37 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: user_helper
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:37 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: form_helper
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:37 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:37 --> Total execution time: 3.6682
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:37 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:37 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:37 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:37 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:37 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:37 --> Total execution time: 2.2271
DEBUG - 2015-04-02 10:57:37 --> Language file loaded: language/english/ion_auth_lang.php
ERROR - 2015-04-02 10:57:37 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:37 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:38 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:38 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:38 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:38 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:38 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:38 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Total execution time: 3.4032
ERROR - 2015-04-02 10:57:38 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:38 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-02 10:57:38 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:38 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:38 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:38 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Total execution time: 3.4052
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:38 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:38 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:38 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:39 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
ERROR - 2015-04-02 10:57:39 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:39 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: form_helper
ERROR - 2015-04-02 10:57:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:39 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:39 --> Total execution time: 1.9471
DEBUG - 2015-04-02 10:57:39 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:39 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:39 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:39 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:39 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:39 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:39 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:39 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:39 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:39 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:39 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:39 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:39 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:39 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:39 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:39 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Session Class Initialized
ERROR - 2015-04-02 10:57:39 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:39 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:39 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:39 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:39 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:39 --> Sites MX_Controller Initialized
ERROR - 2015-04-02 10:57:39 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:39 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:39 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Total execution time: 3.0392
DEBUG - 2015-04-02 10:57:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:39 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:39 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:39 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:40 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:40 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:40 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:40 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:40 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:40 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:40 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:40 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:40 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:40 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:40 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: language_helper
ERROR - 2015-04-02 10:57:40 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Helper loaded: string_helper
ERROR - 2015-04-02 10:57:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:40 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:40 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:40 --> Total execution time: 2.7512
DEBUG - 2015-04-02 10:57:40 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
ERROR - 2015-04-02 10:57:40 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:40 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:40 --> Config file loaded: application/config/ion_auth.php
ERROR - 2015-04-02 10:57:40 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:41 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Total execution time: 3.0482
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
ERROR - 2015-04-02 10:57:41 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:41 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:41 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:41 --> Total execution time: 2.9252
DEBUG - 2015-04-02 10:57:41 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Form Validation Class Initialized
ERROR - 2015-04-02 10:57:41 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:41 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:41 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:41 --> Total execution time: 2.0611
DEBUG - 2015-04-02 10:57:41 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:41 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:41 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:41 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Loader Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:41 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:41 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:57:41 --> URI Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Router Class Initialized
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:41 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:41 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:41 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:57:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:41 --> Output Class Initialized
DEBUG - 2015-04-02 10:57:41 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Security Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Input Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Language Class Initialized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-02 10:57:42 --> Config Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Loader Class Initialized
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: url_helper
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:42 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:42 --> Total execution time: 1.0601
DEBUG - 2015-04-02 10:57:42 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:42 --> Total execution time: 3.1962
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:57:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:57:42 --> Model Class Initialized
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:42 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:42 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:42 --> Total execution time: 2.5771
DEBUG - 2015-04-02 10:57:42 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Session Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:57:42 --> Session routines successfully run
DEBUG - 2015-04-02 10:57:42 --> Controller Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:57:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:57:42 --> Email Class Initialized
DEBUG - 2015-04-02 10:57:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:57:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:57:43 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:57:43 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:43 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:57:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:57:43 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:57:43 --> Model Class Initialized
DEBUG - 2015-04-02 10:57:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:57:43 --> Model Class Initialized
ERROR - 2015-04-02 10:57:43 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-02 10:57:43 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-02 10:57:43 --> Final output sent to browser
DEBUG - 2015-04-02 10:57:43 --> Total execution time: 2.1901
DEBUG - 2015-04-02 10:59:50 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:50 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:50 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:51 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:51 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:51 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:51 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:51 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:51 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:51 --> Helper loaded: directory_helper
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-02 10:59:51 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-02 10:59:51 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:51 --> Total execution time: 1.1460
DEBUG - 2015-04-02 10:59:52 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:52 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:52 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:52 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:52 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:52 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:53 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:53 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:53 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:53 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:53 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:53 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:53 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:53 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:53 --> Model Class Initialized
ERROR - 2015-04-02 10:59:53 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:53 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:53 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:53 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-02 10:59:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:54 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:54 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:54 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:54 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:54 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:54 --> Total execution time: 1.0261
DEBUG - 2015-04-02 10:59:57 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:57 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:57 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:57 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-02 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> URI Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> Router Class Initialized
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Output Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Security Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Input Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Config Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Loader Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-02 10:59:58 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:58 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-02 10:59:58 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:58 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:58 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:58 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-02 10:59:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 10:59:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 10:59:58 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:58 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:58 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:59 --> Total execution time: 1.1441
DEBUG - 2015-04-02 10:59:59 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:59 --> Session Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: string_helper
DEBUG - 2015-04-02 10:59:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:59 --> Session routines successfully run
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Controller Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Email Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:59 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Total execution time: 1.5891
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:59 --> Total execution time: 1.7461
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
ERROR - 2015-04-02 10:59:59 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> Form Validation Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> Final output sent to browser
DEBUG - 2015-04-02 10:59:59 --> Total execution time: 1.9181
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 10:59:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 10:59:59 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:00 --> Total execution time: 2.0701
DEBUG - 2015-04-02 11:00:00 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Hooks Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Utf8 Class Initialized
DEBUG - 2015-04-02 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 11:00:00 --> URI Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Router Class Initialized
DEBUG - 2015-04-02 11:00:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 11:00:00 --> Output Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Security Class Initialized
DEBUG - 2015-04-02 11:00:00 --> Input Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 11:00:01 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Hooks Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 11:00:01 --> URI Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Utf8 Class Initialized
DEBUG - 2015-04-02 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 11:00:01 --> URI Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Router Class Initialized
DEBUG - 2015-04-02 11:00:01 --> Router Class Initialized
DEBUG - 2015-04-02 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-02 11:00:01 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:01 --> URI Class Initialized
DEBUG - 2015-04-02 11:00:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 11:00:01 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:01 --> URI Class Initialized
DEBUG - 2015-04-02 11:00:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 11:00:01 --> Router Class Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 11:00:02 --> Output Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Output Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Security Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Input Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 11:00:02 --> Loader Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 11:00:02 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 11:00:02 --> Loader Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 11:00:02 --> Security Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Output Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 11:00:02 --> Security Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Input Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Input Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 11:00:02 --> Session Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: string_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 11:00:02 --> Session routines successfully run
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 11:00:02 --> Controller Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 11:00:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Router Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Session Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: string_helper
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-02 11:00:02 --> Email Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Output Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Loader Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Session routines successfully run
DEBUG - 2015-04-02 11:00:02 --> Controller Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 11:00:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 11:00:02 --> Security Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 11:00:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 11:00:02 --> Input Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 11:00:02 --> Email Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 11:00:02 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 11:00:02 --> Loader Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 11:00:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Config Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Loader Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: url_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: form_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: language_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 11:00:02 --> Form Validation Class Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:02 --> Session Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Total execution time: 2.0821
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: user_helper
DEBUG - 2015-04-02 11:00:02 --> Form Validation Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: string_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: date_helper
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-02 11:00:02 --> Session routines successfully run
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Database Driver Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-02 11:00:02 --> Controller Class Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Session Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 11:00:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 11:00:02 --> Helper loaded: string_helper
DEBUG - 2015-04-02 11:00:02 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:02 --> Session routines successfully run
DEBUG - 2015-04-02 11:00:02 --> Controller Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 11:00:03 --> Database Driver Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 11:00:03 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:03 --> Total execution time: 1.6841
DEBUG - 2015-04-02 11:00:03 --> Email Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Session Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 11:00:03 --> Helper loaded: string_helper
DEBUG - 2015-04-02 11:00:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 11:00:03 --> Session routines successfully run
DEBUG - 2015-04-02 11:00:03 --> Controller Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 11:00:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-02 11:00:03 --> Email Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 11:00:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 11:00:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Email Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-02 11:00:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Form Validation Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Form Validation Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Form Validation Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:03 --> Total execution time: 1.9851
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-02 11:00:03 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Total execution time: 2.0051
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-02 11:00:03 --> Model Class Initialized
DEBUG - 2015-04-02 11:00:03 --> Final output sent to browser
DEBUG - 2015-04-02 11:00:03 --> Total execution time: 2.4821
