<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-03 05:30:32 --> Config Class Initialized
DEBUG - 2015-04-03 05:30:32 --> Hooks Class Initialized
DEBUG - 2015-04-03 05:30:32 --> Utf8 Class Initialized
DEBUG - 2015-04-03 05:30:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 05:30:33 --> URI Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Router Class Initialized
DEBUG - 2015-04-03 05:30:33 --> No URI present. Default controller set.
DEBUG - 2015-04-03 05:30:33 --> Output Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Security Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Input Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 05:30:33 --> Language Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Language Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Config Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Loader Class Initialized
DEBUG - 2015-04-03 05:30:33 --> Helper loaded: url_helper
DEBUG - 2015-04-03 05:30:33 --> Helper loaded: form_helper
DEBUG - 2015-04-03 05:30:33 --> Helper loaded: language_helper
DEBUG - 2015-04-03 05:30:33 --> Helper loaded: user_helper
DEBUG - 2015-04-03 05:30:33 --> Helper loaded: date_helper
DEBUG - 2015-04-03 05:30:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 05:30:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 05:30:34 --> Database Driver Class Initialized
DEBUG - 2015-04-03 05:30:35 --> Session Class Initialized
DEBUG - 2015-04-03 05:30:35 --> Helper loaded: string_helper
DEBUG - 2015-04-03 05:30:35 --> A session cookie was not found.
DEBUG - 2015-04-03 05:30:35 --> Session routines successfully run
DEBUG - 2015-04-03 05:30:35 --> Controller Class Initialized
DEBUG - 2015-04-03 05:30:35 --> Login MX_Controller Initialized
DEBUG - 2015-04-03 05:30:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 05:30:35 --> Email Class Initialized
DEBUG - 2015-04-03 05:30:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 05:30:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 05:30:35 --> Model Class Initialized
DEBUG - 2015-04-03 05:30:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 05:30:35 --> Model Class Initialized
DEBUG - 2015-04-03 05:30:35 --> Form Validation Class Initialized
DEBUG - 2015-04-03 05:30:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-03 05:30:36 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-03 05:30:36 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-03 05:30:36 --> Final output sent to browser
DEBUG - 2015-04-03 05:30:36 --> Total execution time: 3.3610
DEBUG - 2015-04-03 07:09:53 --> Config Class Initialized
DEBUG - 2015-04-03 07:09:53 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:09:53 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:09:54 --> URI Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Router Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Output Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Security Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Input Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:09:54 --> Language Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Language Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Config Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Loader Class Initialized
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:09:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:09:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:09:54 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:09:55 --> Session Class Initialized
DEBUG - 2015-04-03 07:09:55 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:09:56 --> Session routines successfully run
DEBUG - 2015-04-03 07:09:56 --> Controller Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Login MX_Controller Initialized
DEBUG - 2015-04-03 07:09:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:09:56 --> Email Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:09:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:09:56 --> Model Class Initialized
DEBUG - 2015-04-03 07:09:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:09:56 --> Model Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-03 07:09:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-03 07:09:56 --> Config Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:09:56 --> URI Class Initialized
DEBUG - 2015-04-03 07:09:56 --> Router Class Initialized
DEBUG - 2015-04-03 07:09:56 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-03 07:09:56 --> Output Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:09:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:09:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:09:57 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Session Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:09:57 --> Session routines successfully run
DEBUG - 2015-04-03 07:09:57 --> Controller Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Customer MX_Controller Initialized
DEBUG - 2015-04-03 07:09:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:09:57 --> Email Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:09:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:09:57 --> Model Class Initialized
DEBUG - 2015-04-03 07:09:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:09:57 --> Model Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:09:57 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-03 07:09:57 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-03 07:09:57 --> Final output sent to browser
DEBUG - 2015-04-03 07:09:57 --> Total execution time: 0.9330
DEBUG - 2015-04-03 07:09:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:09:57 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:09:58 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:09:58 --> URI Class Initialized
DEBUG - 2015-04-03 07:09:58 --> Router Class Initialized
ERROR - 2015-04-03 07:09:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-03 07:22:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:15 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:15 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:16 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:16 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:17 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:17 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:17 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-03 07:22:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:22:17 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:17 --> Total execution time: 2.5961
DEBUG - 2015-04-03 07:22:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:18 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:18 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:18 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:18 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Input Class Initialized
ERROR - 2015-04-03 07:22:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-03 07:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:18 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:19 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:19 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:19 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:19 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:19 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:19 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:19 --> Total execution time: 0.7220
DEBUG - 2015-04-03 07:22:19 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:19 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:19 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:19 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:20 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:20 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:20 --> Total execution time: 2.1731
DEBUG - 2015-04-03 07:22:31 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:31 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:31 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:31 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:31 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:32 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:32 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:32 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:32 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:32 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:32 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:32 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:32 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:32 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:32 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:22:32 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:22:32 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:22:32 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:32 --> Total execution time: 1.1011
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:33 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:33 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:33 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:34 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:34 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:34 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:34 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:34 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:34 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:34 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:34 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:34 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:34 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:35 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:35 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:35 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:35 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:35 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:35 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:35 --> Total execution time: 2.0701
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:35 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:35 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:35 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:35 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:35 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:35 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:35 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:35 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:35 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Email Class Initialized
ERROR - 2015-04-03 07:22:35 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:22:35 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:35 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:35 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:35 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:36 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:36 --> Total execution time: 2.4731
DEBUG - 2015-04-03 07:22:36 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:36 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:36 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:36 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:36 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:36 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:36 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:36 --> Total execution time: 1.1681
DEBUG - 2015-04-03 07:22:36 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:36 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:36 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:36 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:36 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:36 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:36 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:37 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:37 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:37 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:37 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:37 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:37 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:37 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:37 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:37 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:22:37 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:37 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:37 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:38 --> URI Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:38 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:38 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:38 --> Router Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:38 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:38 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:38 --> Total execution time: 4.8443
DEBUG - 2015-04-03 07:22:38 --> Output Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:38 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:38 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:38 --> Total execution time: 4.9623
DEBUG - 2015-04-03 07:22:38 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:38 --> Security Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Input Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:38 --> Total execution time: 5.1283
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:22:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:38 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:38 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Language Class Initialized
DEBUG - 2015-04-03 07:22:38 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:39 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:39 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Config Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:39 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:39 --> Loader Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:39 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:39 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:22:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:22:39 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:22:39 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:22:39 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:39 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:39 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:39 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:39 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Total execution time: 2.1741
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:39 --> Total execution time: 2.2351
DEBUG - 2015-04-03 07:22:39 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:40 --> Total execution time: 2.4641
DEBUG - 2015-04-03 07:22:40 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:40 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:40 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:40 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Session Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:22:40 --> Session routines successfully run
DEBUG - 2015-04-03 07:22:40 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:40 --> Controller Class Initialized
DEBUG - 2015-04-03 07:22:40 --> Total execution time: 3.2572
DEBUG - 2015-04-03 07:22:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:22:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:22:40 --> Email Class Initialized
DEBUG - 2015-04-03 07:22:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:22:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:22:41 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:22:41 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:41 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:22:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:22:41 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:22:41 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:22:41 --> Model Class Initialized
DEBUG - 2015-04-03 07:22:41 --> Final output sent to browser
DEBUG - 2015-04-03 07:22:41 --> Total execution time: 3.4972
DEBUG - 2015-04-03 07:23:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:23:38 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:23:38 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:23:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:23:39 --> URI Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Router Class Initialized
DEBUG - 2015-04-03 07:23:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:23:39 --> Output Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Security Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Input Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:23:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Config Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Loader Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:23:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:23:39 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Session Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:23:39 --> Session routines successfully run
DEBUG - 2015-04-03 07:23:39 --> Controller Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:23:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:23:39 --> Email Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:23:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:23:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:23:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:23:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:23:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:23:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:23:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:23:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:23:39 --> Model Class Initialized
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: file_helper
DEBUG - 2015-04-03 07:23:39 --> Helper loaded: directory_helper
DEBUG - 2015-04-03 07:23:39 --> FTP Class Initialized
DEBUG - 2015-04-03 07:23:41 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-03 07:42:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:42:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:42:57 --> URI Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Router Class Initialized
DEBUG - 2015-04-03 07:42:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:42:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:42:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:42:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:42:57 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Session Class Initialized
DEBUG - 2015-04-03 07:42:57 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:42:58 --> Session routines successfully run
DEBUG - 2015-04-03 07:42:58 --> Controller Class Initialized
DEBUG - 2015-04-03 07:42:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:42:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:42:58 --> Email Class Initialized
DEBUG - 2015-04-03 07:42:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:42:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:42:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:42:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:42:58 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:42:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:42:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:42:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:42:58 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:42:58 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:42:58 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:42:59 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:42:59 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:42:59 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:42:59 --> Final output sent to browser
DEBUG - 2015-04-03 07:42:59 --> Total execution time: 1.9040
DEBUG - 2015-04-03 07:42:59 --> Config Class Initialized
DEBUG - 2015-04-03 07:42:59 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:42:59 --> Config Class Initialized
DEBUG - 2015-04-03 07:42:59 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:42:59 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:00 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:00 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:00 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:00 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:00 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:00 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:00 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:00 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:00 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:00 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:00 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:00 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:00 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:00 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:00 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:00 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:00 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:00 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:43:00 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:01 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:01 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:01 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
ERROR - 2015-04-03 07:43:01 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:43:01 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:01 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:01 --> Total execution time: 1.7051
DEBUG - 2015-04-03 07:43:03 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:03 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:03 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:03 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:03 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:03 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:03 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:03 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:03 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:03 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:03 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:04 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:04 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:04 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:04 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:04 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:04 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:04 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:04 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:05 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:05 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:05 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:05 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:06 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:06 --> Total execution time: 2.7192
DEBUG - 2015-04-03 07:43:06 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:06 --> Total execution time: 3.1682
DEBUG - 2015-04-03 07:43:06 --> Total execution time: 3.1212
DEBUG - 2015-04-03 07:43:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:06 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:06 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:06 --> Total execution time: 2.8272
DEBUG - 2015-04-03 07:43:06 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:06 --> Total execution time: 3.2672
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:12 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:43:12 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:43:12 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:12 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:12 --> URI Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Router Class Initialized
DEBUG - 2015-04-03 07:43:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:43:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:12 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:12 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:43:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:43:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:43:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:43:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:13 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:43:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Total execution time: 2.1501
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Total execution time: 2.2151
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:14 --> Total execution time: 2.1551
DEBUG - 2015-04-03 07:43:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:43:14 --> Total execution time: 2.2501
DEBUG - 2015-04-03 07:43:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:43:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:43:14 --> Total execution time: 2.5451
DEBUG - 2015-04-03 07:44:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:11 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:11 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:11 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:11 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:11 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:11 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:11 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:11 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:11 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:11 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:11 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:11 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:44:11 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:44:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:44:12 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:12 --> Total execution time: 1.0630
DEBUG - 2015-04-03 07:44:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:14 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:14 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:14 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:14 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:15 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:44:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:15 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:15 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:15 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:15 --> Total execution time: 1.4881
ERROR - 2015-04-03 07:44:15 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:44:20 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:20 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:20 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:20 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:20 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:21 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:21 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:21 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:21 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:21 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:21 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:21 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:22 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:22 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:22 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:22 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:22 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:22 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:22 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:22 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:22 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:22 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:22 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:22 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:22 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:22 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:22 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:22 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:23 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:23 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:23 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:23 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:23 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:23 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:24 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:24 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:24 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:24 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:24 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:24 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:24 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Total execution time: 3.5492
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:44:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:44:24 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:24 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:25 --> URI Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/usermodel.php
ERROR - 2015-04-03 07:44:25 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:44:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:25 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:25 --> Router Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:25 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:25 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:25 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:25 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Total execution time: 3.8672
DEBUG - 2015-04-03 07:44:25 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:25 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:44:25 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:25 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Total execution time: 4.6023
DEBUG - 2015-04-03 07:44:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:25 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Output Class Initialized
DEBUG - 2015-04-03 07:44:25 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:26 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:26 --> Total execution time: 4.7193
DEBUG - 2015-04-03 07:44:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:26 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Security Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Input Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:44:26 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:26 --> Language Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Config Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:26 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:26 --> Total execution time: 5.4243
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:26 --> Loader Class Initialized
DEBUG - 2015-04-03 07:44:26 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:27 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:27 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:27 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:44:27 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:27 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:27 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:27 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:44:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:27 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:27 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:44:27 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:27 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:27 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:44:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:27 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:27 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:44:28 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:28 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:44:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:44:28 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:28 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:28 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:28 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:28 --> Total execution time: 4.7353
DEBUG - 2015-04-03 07:44:28 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:28 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:28 --> Total execution time: 5.3673
DEBUG - 2015-04-03 07:44:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:28 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:29 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:29 --> Total execution time: 5.5003
DEBUG - 2015-04-03 07:44:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:29 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:29 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:29 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:29 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:29 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:29 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:29 --> Session Class Initialized
DEBUG - 2015-04-03 07:44:29 --> Total execution time: 5.7453
DEBUG - 2015-04-03 07:44:29 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:44:29 --> Session routines successfully run
DEBUG - 2015-04-03 07:44:29 --> Controller Class Initialized
DEBUG - 2015-04-03 07:44:29 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:44:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:44:29 --> Email Class Initialized
DEBUG - 2015-04-03 07:44:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:44:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:44:30 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:44:30 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:30 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:44:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:44:30 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:44:30 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:44:30 --> Model Class Initialized
DEBUG - 2015-04-03 07:44:30 --> Final output sent to browser
DEBUG - 2015-04-03 07:44:30 --> Total execution time: 7.1384
DEBUG - 2015-04-03 07:46:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:46:19 --> URI Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Router Class Initialized
DEBUG - 2015-04-03 07:46:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:46:19 --> Output Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Security Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Input Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:46:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Loader Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:46:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:46:19 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Session Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:46:19 --> Session routines successfully run
DEBUG - 2015-04-03 07:46:19 --> Controller Class Initialized
DEBUG - 2015-04-03 07:46:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:46:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:46:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:46:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:46:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:46:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:46:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:46:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:46:20 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:46:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:46:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:46:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:46:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:46:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:46:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:46:20 --> Helper loaded: file_helper
DEBUG - 2015-04-03 07:46:20 --> Helper loaded: directory_helper
DEBUG - 2015-04-03 07:46:20 --> FTP Class Initialized
DEBUG - 2015-04-03 07:46:22 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-03 07:53:36 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:36 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:36 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:36 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:36 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:36 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:36 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:36 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:36 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:36 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:53:37 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:53:37 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:53:37 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:37 --> Total execution time: 1.1830
DEBUG - 2015-04-03 07:53:38 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:38 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:39 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:39 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:39 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:39 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:39 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:39 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:39 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:39 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:39 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:40 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:40 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:40 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:40 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:40 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:40 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:53:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Model Class Initialized
ERROR - 2015-04-03 07:53:40 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:53:40 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:40 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:40 --> Total execution time: 1.7681
DEBUG - 2015-04-03 07:53:44 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:44 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:44 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:44 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:44 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:44 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:44 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:44 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:44 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:44 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:45 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:45 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:45 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:45 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:45 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:45 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:45 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:45 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:45 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:45 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:45 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:45 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:45 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:45 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:45 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:45 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:45 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:45 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:45 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:45 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:45 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:45 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:45 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:45 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:46 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:46 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:46 --> Total execution time: 2.0291
DEBUG - 2015-04-03 07:53:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:46 --> Total execution time: 2.7782
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:46 --> Total execution time: 2.1171
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:46 --> Total execution time: 2.3371
DEBUG - 2015-04-03 07:53:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:46 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:46 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:46 --> Total execution time: 2.4231
DEBUG - 2015-04-03 07:53:47 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:47 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:47 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:47 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:47 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:48 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:48 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:48 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:48 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:48 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:49 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:49 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:49 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:49 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:50 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:50 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:50 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:50 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:50 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:50 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:50 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:50 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:50 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:50 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:50 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:50 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:51 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:51 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:51 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:51 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:51 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:51 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:51 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:51 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:51 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:51 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:51 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:51 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:52 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:52 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:52 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Total execution time: 4.2662
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:53 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:53 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:53 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:53 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:53 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:53 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:53 --> Total execution time: 2.6161
DEBUG - 2015-04-03 07:53:53 --> Total execution time: 3.4092
DEBUG - 2015-04-03 07:53:53 --> Total execution time: 5.7943
DEBUG - 2015-04-03 07:53:53 --> Total execution time: 5.8463
DEBUG - 2015-04-03 07:53:53 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:53 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:53 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:53 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:53 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:54 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:54 --> Model Class Initialized
ERROR - 2015-04-03 07:53:54 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-03 07:53:54 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:53:54 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:54 --> Total execution time: 1.4321
DEBUG - 2015-04-03 07:53:56 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:56 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:56 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:56 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:57 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:53:57 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> URI Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Router Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:57 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:57 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:57 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:57 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:58 --> Language Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:58 --> Config Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:58 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Loader Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:58 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:53:58 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:58 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:53:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:58 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:53:58 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Session Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:58 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:58 --> Session routines successfully run
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:58 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Email Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Controller Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:58 --> Email Class Initialized
ERROR - 2015-04-03 07:53:58 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
ERROR - 2015-04-03 07:53:58 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:53:58 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:53:58 --> Total execution time: 2.6262
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:58 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/usermodel.php
ERROR - 2015-04-03 07:53:58 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:59 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:53:59 --> Model Class Initialized
ERROR - 2015-04-03 07:53:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:53:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:53:59 --> Final output sent to browser
ERROR - 2015-04-03 07:53:59 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
DEBUG - 2015-04-03 07:53:59 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:59 --> Total execution time: 2.8332
ERROR - 2015-04-03 07:53:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:53:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:53:59 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:59 --> Total execution time: 2.9082
DEBUG - 2015-04-03 07:53:59 --> Model Class Initialized
DEBUG - 2015-04-03 07:53:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:53:59 --> Model Class Initialized
ERROR - 2015-04-03 07:53:59 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-03 07:53:59 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:53:59 --> Final output sent to browser
DEBUG - 2015-04-03 07:53:59 --> Total execution time: 2.9412
DEBUG - 2015-04-03 07:56:04 --> Config Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:56:05 --> URI Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Router Class Initialized
DEBUG - 2015-04-03 07:56:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:56:05 --> Output Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Security Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Input Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:56:05 --> Language Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Language Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Config Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Loader Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:56:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:56:05 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Session Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:56:05 --> Session routines successfully run
DEBUG - 2015-04-03 07:56:05 --> Controller Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:56:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:56:05 --> Email Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:56:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:56:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:56:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:56:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:56:05 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:56:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:56:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:56:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:56:05 --> Model Class Initialized
DEBUG - 2015-04-03 07:56:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:56:05 --> Model Class Initialized
ERROR - 2015-04-03 07:56:05 --> Severity: Notice  --> Undefined offset: 0 C:\xampp\htdocs\ecampaign247\application\modules_core\sites\models\sitemodel.php 498
ERROR - 2015-04-03 07:56:05 --> Severity: Notice  --> Trying to get property of non-object C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 418
DEBUG - 2015-04-03 07:56:05 --> Final output sent to browser
DEBUG - 2015-04-03 07:56:05 --> Total execution time: 0.8790
DEBUG - 2015-04-03 07:58:02 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:02 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:02 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:02 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:02 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:03 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:03 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:03 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:03 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:03 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:03 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:04 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:04 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:04 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:04 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:04 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:04 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:04 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:04 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:58:05 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:58:05 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:58:05 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:05 --> Total execution time: 3.1590
DEBUG - 2015-04-03 07:58:06 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:06 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:06 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:06 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:06 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:06 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:07 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:07 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:07 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:07 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:07 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:07 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:58:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:07 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:07 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:07 --> Total execution time: 1.1591
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:07 --> Model Class Initialized
ERROR - 2015-04-03 07:58:08 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:11 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:11 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:12 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:14 --> Total execution time: 2.5921
DEBUG - 2015-04-03 07:58:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:14 --> Total execution time: 2.7382
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:14 --> Total execution time: 2.6832
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
ERROR - 2015-04-03 07:58:14 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:14 --> Total execution time: 2.7972
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:14 --> Total execution time: 2.9802
DEBUG - 2015-04-03 07:58:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:15 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:15 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:15 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:15 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:15 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:15 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:16 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:16 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:16 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:16 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:17 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:17 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:17 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:17 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:17 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:17 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:17 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:17 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:17 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:18 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:18 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:18 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:18 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:18 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:18 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:18 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:18 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:18 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:18 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:18 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Total execution time: 3.1872
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:19 --> Total execution time: 4.4052
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:19 --> Total execution time: 3.7612
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:19 --> Total execution time: 5.0353
DEBUG - 2015-04-03 07:58:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:58:19 --> Total execution time: 4.0062
DEBUG - 2015-04-03 07:58:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:58:57 --> URI Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Router Class Initialized
DEBUG - 2015-04-03 07:58:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:58:57 --> Output Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Security Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Input Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:58:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Language Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Config Class Initialized
DEBUG - 2015-04-03 07:58:57 --> Loader Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:58:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:58:58 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Session Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:58:58 --> Session routines successfully run
DEBUG - 2015-04-03 07:58:58 --> Controller Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:58:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:58:58 --> Email Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:58:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:58:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:58:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:58 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:58:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:58:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:58:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:58:58 --> Model Class Initialized
DEBUG - 2015-04-03 07:58:58 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-03 07:59:07 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:07 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:07 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:07 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:07 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:07 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:07 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:07 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:07 --> Helper loaded: directory_helper
ERROR - 2015-04-03 07:59:07 --> Could not find the language line "actionbuttons_preview"
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 07:59:07 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 07:59:07 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:07 --> Total execution time: 0.7290
DEBUG - 2015-04-03 07:59:09 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:09 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:09 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:09 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:09 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:09 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:09 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:09 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:10 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:10 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:10 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 07:59:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:10 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:10 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:10 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:10 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:10 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:10 --> Total execution time: 1.0651
DEBUG - 2015-04-03 07:59:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:10 --> Model Class Initialized
ERROR - 2015-04-03 07:59:10 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:59:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:13 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:13 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:13 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:13 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:13 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:13 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:14 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:14 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:14 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:14 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:14 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:14 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:14 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:14 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:14 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:15 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:15 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
ERROR - 2015-04-03 07:59:15 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:15 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:15 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:15 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:15 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:15 --> Total execution time: 1.2681
DEBUG - 2015-04-03 07:59:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:15 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:15 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:15 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:15 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:15 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:15 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:15 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:16 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:16 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Total execution time: 1.9131
DEBUG - 2015-04-03 07:59:16 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:16 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:16 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:16 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:16 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:16 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:16 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:16 --> Total execution time: 2.3761
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:16 --> Total execution time: 2.4281
DEBUG - 2015-04-03 07:59:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:16 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:16 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:16 --> Total execution time: 2.4751
DEBUG - 2015-04-03 07:59:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:17 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:17 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:17 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:17 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:17 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:17 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:18 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:18 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:18 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:18 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:18 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:18 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:18 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Hooks Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Utf8 Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 07:59:18 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:18 --> URI Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:18 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Router Class Initialized
DEBUG - 2015-04-03 07:59:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:19 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:19 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:19 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:19 --> Total execution time: 2.1551
DEBUG - 2015-04-03 07:59:19 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:19 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:19 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 07:59:19 --> Output Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Security Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Input Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:19 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 07:59:19 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:19 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:19 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Language Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Config Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Loader Class Initialized
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: url_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:19 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: form_helper
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: language_helper
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: user_helper
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: date_helper
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:20 --> Database Driver Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:20 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:20 --> Total execution time: 3.0842
DEBUG - 2015-04-03 07:59:20 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:20 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:20 --> Session Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: string_helper
DEBUG - 2015-04-03 07:59:20 --> Session routines successfully run
DEBUG - 2015-04-03 07:59:20 --> Controller Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:20 --> Email Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 07:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 07:59:20 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> Total execution time: 2.9292
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:20 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:21 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:21 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> Form Validation Class Initialized
DEBUG - 2015-04-03 07:59:21 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:21 --> Total execution time: 2.2301
DEBUG - 2015-04-03 07:59:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 07:59:21 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 07:59:21 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 07:59:21 --> Model Class Initialized
DEBUG - 2015-04-03 07:59:21 --> Final output sent to browser
DEBUG - 2015-04-03 07:59:21 --> Total execution time: 2.2971
DEBUG - 2015-04-03 08:00:39 --> Config Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Hooks Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Utf8 Class Initialized
DEBUG - 2015-04-03 08:00:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 08:00:39 --> URI Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Router Class Initialized
DEBUG - 2015-04-03 08:00:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 08:00:39 --> Output Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Security Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Input Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 08:00:39 --> Language Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Language Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Config Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Loader Class Initialized
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: url_helper
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: form_helper
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: language_helper
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: user_helper
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: date_helper
DEBUG - 2015-04-03 08:00:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 08:00:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 08:00:40 --> Database Driver Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Session Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Helper loaded: string_helper
DEBUG - 2015-04-03 08:00:40 --> Session routines successfully run
DEBUG - 2015-04-03 08:00:40 --> Controller Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 08:00:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 08:00:40 --> Email Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 08:00:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 08:00:40 --> Model Class Initialized
DEBUG - 2015-04-03 08:00:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 08:00:40 --> Model Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Form Validation Class Initialized
DEBUG - 2015-04-03 08:00:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 08:00:40 --> Model Class Initialized
DEBUG - 2015-04-03 08:00:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 08:00:40 --> Model Class Initialized
DEBUG - 2015-04-03 08:00:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 08:00:40 --> Model Class Initialized
DEBUG - 2015-04-03 08:00:40 --> Helper loaded: file_helper
DEBUG - 2015-04-03 08:00:40 --> Helper loaded: directory_helper
DEBUG - 2015-04-03 08:00:40 --> FTP Class Initialized
DEBUG - 2015-04-03 08:00:42 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-03 10:47:24 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:24 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:24 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:24 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:24 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:25 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:25 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:25 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:25 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:25 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:25 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:25 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:25 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:25 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:25 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:25 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:26 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:26 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:26 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:26 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:26 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:26 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:26 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:26 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:26 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:26 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:26 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:26 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:26 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:26 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:26 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:26 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:26 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:26 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:26 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:26 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:26 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:26 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:26 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:26 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:26 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:26 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:26 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:26 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:27 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:27 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:27 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:27 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:27 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:27 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:27 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:27 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:27 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:27 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:27 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:27 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:27 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:47:27 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:27 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:27 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:27 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:27 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:27 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:28 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:28 --> A session cookie was not found.
DEBUG - 2015-04-03 10:47:28 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:28 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:47:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:28 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:28 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:28 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:47:28 --> URI Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Router Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Output Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Security Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Input Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:47:28 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Language Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Config Class Initialized
DEBUG - 2015-04-03 10:47:28 --> Loader Class Initialized
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:47:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:47:31 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:47:31 --> Session Class Initialized
DEBUG - 2015-04-03 10:47:31 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:47:31 --> Session routines successfully run
DEBUG - 2015-04-03 10:47:32 --> Controller Class Initialized
DEBUG - 2015-04-03 10:47:32 --> Login MX_Controller Initialized
DEBUG - 2015-04-03 10:47:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:47:32 --> Email Class Initialized
DEBUG - 2015-04-03 10:47:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:47:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:47:32 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:47:32 --> Model Class Initialized
DEBUG - 2015-04-03 10:47:32 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:47:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-03 10:47:32 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-03 10:47:32 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-03 10:47:32 --> Final output sent to browser
DEBUG - 2015-04-03 10:47:32 --> Total execution time: 3.5922
DEBUG - 2015-04-03 10:51:40 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:40 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:40 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:40 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:41 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:41 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:41 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Login MX_Controller Initialized
DEBUG - 2015-04-03 10:51:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:41 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:41 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:41 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-03 10:51:41 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:41 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:41 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-03 10:51:41 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:41 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:41 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:41 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:41 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Customer MX_Controller Initialized
DEBUG - 2015-04-03 10:51:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:41 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:41 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:42 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:42 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-03 10:51:42 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-03 10:51:42 --> Final output sent to browser
DEBUG - 2015-04-03 10:51:42 --> Total execution time: 0.5660
DEBUG - 2015-04-03 10:51:42 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:42 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:42 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:42 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:42 --> Router Class Initialized
ERROR - 2015-04-03 10:51:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-03 10:51:44 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:44 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:51:44 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:44 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:44 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:44 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:44 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:51:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:44 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:44 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:51:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:51:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:51:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 10:51:44 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 10:51:45 --> Final output sent to browser
DEBUG - 2015-04-03 10:51:45 --> Total execution time: 1.0311
DEBUG - 2015-04-03 10:51:45 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:45 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Router Class Initialized
ERROR - 2015-04-03 10:51:45 --> 404 Page Not Found --> 
DEBUG - 2015-04-03 10:51:45 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:45 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:51:45 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:45 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:46 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:46 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:46 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:51:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:46 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:46 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:46 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:51:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:46 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:51:46 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:46 --> Final output sent to browser
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:46 --> Total execution time: 1.0241
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:46 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:46 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:46 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:51:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:46 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:51:46 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:51:47 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:51:47 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:47 --> Final output sent to browser
DEBUG - 2015-04-03 10:51:47 --> Total execution time: 0.8040
DEBUG - 2015-04-03 10:51:54 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:54 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:54 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:54 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:54 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:51:54 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:55 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:55 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Session Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:51:55 --> Session routines successfully run
DEBUG - 2015-04-03 10:51:55 --> Controller Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:51:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:51:55 --> Email Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:51:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:51:55 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:51:55 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:55 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:51:55 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:51:55 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:51:55 --> Model Class Initialized
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-03 10:51:55 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 10:51:55 --> Final output sent to browser
DEBUG - 2015-04-03 10:51:55 --> Total execution time: 0.6340
DEBUG - 2015-04-03 10:51:57 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:57 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:57 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:57 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:57 --> Router Class Initialized
ERROR - 2015-04-03 10:51:57 --> 404 Page Not Found --> 
DEBUG - 2015-04-03 10:51:59 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:51:59 --> URI Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Router Class Initialized
DEBUG - 2015-04-03 10:51:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:51:59 --> Output Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Security Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Input Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:51:59 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Language Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Config Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Loader Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:51:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:51:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:51:59 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:51:59 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:00 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:00 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:00 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:00 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:00 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:00 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:00 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:00 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:00 --> Total execution time: 0.9321
DEBUG - 2015-04-03 10:52:00 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:00 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:00 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:00 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:00 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:00 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:01 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:01 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:01 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:01 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:01 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:01 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:01 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:01 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:01 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:01 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:01 --> Total execution time: 0.5610
DEBUG - 2015-04-03 10:52:42 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:42 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:42 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:42 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:42 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:42 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:42 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:42 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:42 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:42 --> Helper loaded: directory_helper
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-03 10:52:42 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-03 10:52:43 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-03 10:52:43 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:43 --> Total execution time: 0.9261
DEBUG - 2015-04-03 10:52:43 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:43 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:43 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:43 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:43 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:43 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:43 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:43 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:43 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:43 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:43 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:44 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:44 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:44 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:44 --> Total execution time: 0.7700
DEBUG - 2015-04-03 10:52:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:44 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:44 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:44 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:44 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:44 --> Model Class Initialized
ERROR - 2015-04-03 10:52:44 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-03 10:52:46 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:46 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:47 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:47 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:47 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:47 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:47 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:47 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:47 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:47 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:47 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:47 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:47 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:47 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:47 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:47 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:47 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:47 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:47 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:47 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:47 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:48 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:48 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:48 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:48 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:48 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:48 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:48 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:48 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:48 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:48 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:48 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:48 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:48 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:48 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:48 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:48 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:48 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:48 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:48 --> Total execution time: 1.9651
DEBUG - 2015-04-03 10:52:48 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:48 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:48 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:48 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:48 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:48 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:49 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Total execution time: 2.1891
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:49 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Total execution time: 2.3001
DEBUG - 2015-04-03 10:52:49 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:49 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Total execution time: 2.0701
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:49 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:49 --> Total execution time: 2.2781
DEBUG - 2015-04-03 10:52:49 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:49 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:49 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:50 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-03 10:52:50 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:50 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-03 10:52:50 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:50 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:50 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:50 --> URI Class Initialized
DEBUG - 2015-04-03 10:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:50 --> Router Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-03 10:52:50 --> Output Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:50 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:50 --> Security Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Input Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:50 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:51 --> Language Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:51 --> Config Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:51 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:51 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:51 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:51 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:51 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:51 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:51 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:51 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Loader Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-03 10:52:51 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-03 10:52:51 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:51 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Total execution time: 1.2021
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:51 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:51 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:51 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Session Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:51 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:51 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:51 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:52 --> Helper loaded: string_helper
DEBUG - 2015-04-03 10:52:52 --> Session routines successfully run
DEBUG - 2015-04-03 10:52:52 --> Controller Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:52 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-03 10:52:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Email Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Total execution time: 2.1541
DEBUG - 2015-04-03 10:52:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-03 10:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:52 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:52 --> Total execution time: 2.3421
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:52 --> Total execution time: 2.0791
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-03 10:52:52 --> Model Class Initialized
DEBUG - 2015-04-03 10:52:52 --> Final output sent to browser
DEBUG - 2015-04-03 10:52:52 --> Total execution time: 2.2771
