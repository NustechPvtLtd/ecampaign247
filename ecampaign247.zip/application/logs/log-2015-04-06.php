<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-06 05:43:18 --> Config Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Hooks Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Utf8 Class Initialized
DEBUG - 2015-04-06 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 05:43:18 --> URI Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Router Class Initialized
DEBUG - 2015-04-06 05:43:18 --> No URI present. Default controller set.
DEBUG - 2015-04-06 05:43:18 --> Output Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Security Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Input Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 05:43:18 --> Language Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Language Class Initialized
DEBUG - 2015-04-06 05:43:18 --> Config Class Initialized
DEBUG - 2015-04-06 05:43:19 --> Loader Class Initialized
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: url_helper
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: form_helper
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: language_helper
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: user_helper
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: date_helper
DEBUG - 2015-04-06 05:43:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 05:43:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 05:43:19 --> Database Driver Class Initialized
DEBUG - 2015-04-06 05:43:20 --> Session Class Initialized
DEBUG - 2015-04-06 05:43:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 05:43:20 --> A session cookie was not found.
DEBUG - 2015-04-06 05:43:20 --> Session routines successfully run
DEBUG - 2015-04-06 05:43:20 --> Controller Class Initialized
DEBUG - 2015-04-06 05:43:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 05:43:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 05:43:21 --> Email Class Initialized
DEBUG - 2015-04-06 05:43:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 05:43:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 05:43:21 --> Model Class Initialized
DEBUG - 2015-04-06 05:43:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 05:43:21 --> Model Class Initialized
DEBUG - 2015-04-06 05:43:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 05:43:21 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 05:43:21 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-06 05:43:21 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-06 05:43:21 --> Final output sent to browser
DEBUG - 2015-04-06 05:43:21 --> Total execution time: 3.5310
DEBUG - 2015-04-06 06:06:23 --> Config Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:06:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:06:23 --> URI Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Router Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Output Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Security Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Input Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 06:06:23 --> Language Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Language Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Config Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Loader Class Initialized
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: url_helper
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: form_helper
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: language_helper
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: user_helper
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: date_helper
DEBUG - 2015-04-06 06:06:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 06:06:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 06:06:23 --> Database Driver Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Session Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Helper loaded: string_helper
DEBUG - 2015-04-06 06:06:24 --> Session routines successfully run
DEBUG - 2015-04-06 06:06:24 --> Controller Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 06:06:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 06:06:24 --> Email Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 06:06:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 06:06:24 --> Model Class Initialized
DEBUG - 2015-04-06 06:06:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 06:06:24 --> Model Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Form Validation Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 06:06:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 06:06:24 --> Config Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:06:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:06:24 --> URI Class Initialized
DEBUG - 2015-04-06 06:06:24 --> Router Class Initialized
DEBUG - 2015-04-06 06:06:24 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-06 06:06:24 --> Output Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Security Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Input Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 06:06:25 --> Language Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Language Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Config Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Loader Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: url_helper
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: form_helper
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: language_helper
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: user_helper
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: date_helper
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 06:06:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 06:06:25 --> Database Driver Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Session Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: string_helper
DEBUG - 2015-04-06 06:06:25 --> Session routines successfully run
DEBUG - 2015-04-06 06:06:25 --> Controller Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Customer MX_Controller Initialized
DEBUG - 2015-04-06 06:06:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 06:06:25 --> Email Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 06:06:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 06:06:25 --> Model Class Initialized
DEBUG - 2015-04-06 06:06:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 06:06:25 --> Model Class Initialized
DEBUG - 2015-04-06 06:06:25 --> Form Validation Class Initialized
DEBUG - 2015-04-06 06:06:25 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-06 06:06:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-06 06:06:25 --> Final output sent to browser
DEBUG - 2015-04-06 06:06:25 --> Total execution time: 0.8791
DEBUG - 2015-04-06 06:06:26 --> Config Class Initialized
DEBUG - 2015-04-06 06:06:26 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:06:26 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:06:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:06:26 --> URI Class Initialized
DEBUG - 2015-04-06 06:06:26 --> Router Class Initialized
ERROR - 2015-04-06 06:06:26 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 06:38:45 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:38:45 --> URI Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Router Class Initialized
DEBUG - 2015-04-06 06:38:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 06:38:45 --> Output Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Security Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Input Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 06:38:45 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Loader Class Initialized
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: url_helper
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: form_helper
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: language_helper
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: user_helper
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: date_helper
DEBUG - 2015-04-06 06:38:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 06:38:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 06:38:46 --> Database Driver Class Initialized
DEBUG - 2015-04-06 06:38:47 --> Session Class Initialized
DEBUG - 2015-04-06 06:38:47 --> Helper loaded: string_helper
DEBUG - 2015-04-06 06:38:47 --> Session routines successfully run
DEBUG - 2015-04-06 06:38:47 --> Controller Class Initialized
DEBUG - 2015-04-06 06:38:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 06:38:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 06:38:47 --> Email Class Initialized
DEBUG - 2015-04-06 06:38:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 06:38:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 06:38:47 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 06:38:47 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:47 --> Form Validation Class Initialized
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 06:38:47 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 06:38:47 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 06:38:47 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 06:38:47 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 06:38:48 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-06 06:38:48 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 06:38:48 --> Final output sent to browser
DEBUG - 2015-04-06 06:38:48 --> Total execution time: 2.6522
DEBUG - 2015-04-06 06:38:48 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:38:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:38:48 --> URI Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Router Class Initialized
ERROR - 2015-04-06 06:38:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 06:38:48 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:38:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:38:48 --> URI Class Initialized
DEBUG - 2015-04-06 06:38:48 --> Router Class Initialized
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 06:38:49 --> Output Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Security Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Input Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 06:38:49 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Loader Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: url_helper
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: form_helper
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: language_helper
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: user_helper
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: date_helper
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 06:38:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 06:38:49 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Hooks Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Database Driver Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Utf8 Class Initialized
DEBUG - 2015-04-06 06:38:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 06:38:49 --> Session Class Initialized
DEBUG - 2015-04-06 06:38:49 --> URI Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: string_helper
DEBUG - 2015-04-06 06:38:49 --> Router Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Session routines successfully run
DEBUG - 2015-04-06 06:38:49 --> Controller Class Initialized
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 06:38:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 06:38:49 --> Output Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Security Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 06:38:49 --> Input Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Email Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 06:38:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 06:38:49 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 06:38:49 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Language Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Config Class Initialized
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 06:38:49 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Loader Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: url_helper
DEBUG - 2015-04-06 06:38:49 --> Form Validation Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: form_helper
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: language_helper
DEBUG - 2015-04-06 06:38:49 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: user_helper
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: date_helper
DEBUG - 2015-04-06 06:38:49 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 06:38:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 06:38:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 06:38:49 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Database Driver Class Initialized
DEBUG - 2015-04-06 06:38:49 --> Final output sent to browser
DEBUG - 2015-04-06 06:38:49 --> Total execution time: 1.0311
DEBUG - 2015-04-06 06:38:50 --> Session Class Initialized
DEBUG - 2015-04-06 06:38:50 --> Helper loaded: string_helper
DEBUG - 2015-04-06 06:38:50 --> Session routines successfully run
DEBUG - 2015-04-06 06:38:50 --> Controller Class Initialized
DEBUG - 2015-04-06 06:38:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 06:38:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 06:38:51 --> Email Class Initialized
DEBUG - 2015-04-06 06:38:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 06:38:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 06:38:51 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 06:38:51 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:51 --> Form Validation Class Initialized
DEBUG - 2015-04-06 06:38:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 06:38:51 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 06:38:51 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 06:38:51 --> Model Class Initialized
DEBUG - 2015-04-06 06:38:51 --> Final output sent to browser
DEBUG - 2015-04-06 06:38:51 --> Total execution time: 1.8231
DEBUG - 2015-04-06 07:01:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:01:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:01:58 --> URI Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Router Class Initialized
DEBUG - 2015-04-06 07:01:58 --> No URI present. Default controller set.
DEBUG - 2015-04-06 07:01:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:01:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:01:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:01:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:01:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Session Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:01:59 --> Session routines successfully run
DEBUG - 2015-04-06 07:01:59 --> Controller Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 07:01:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:01:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:01:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:01:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:01:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:01:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:01:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 07:02:11 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:02:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:02:11 --> URI Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Router Class Initialized
DEBUG - 2015-04-06 07:02:11 --> No URI present. Default controller set.
DEBUG - 2015-04-06 07:02:11 --> Output Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Security Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Input Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:02:11 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Loader Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:02:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:02:11 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Session Class Initialized
DEBUG - 2015-04-06 07:02:11 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:02:11 --> Session routines successfully run
DEBUG - 2015-04-06 07:02:11 --> Controller Class Initialized
DEBUG - 2015-04-06 07:02:12 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 07:02:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:02:12 --> Email Class Initialized
DEBUG - 2015-04-06 07:02:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:02:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:02:12 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:02:12 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:12 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:02:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 07:02:25 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:02:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:02:25 --> URI Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Router Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:02:25 --> Output Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Security Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Input Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:02:25 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Loader Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:02:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:02:25 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Session Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:02:25 --> Session routines successfully run
DEBUG - 2015-04-06 07:02:25 --> Controller Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:02:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:02:25 --> Email Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:02:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:02:25 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:02:25 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:25 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:02:25 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:02:25 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:02:25 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-06 07:02:25 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 07:02:25 --> Final output sent to browser
DEBUG - 2015-04-06 07:02:25 --> Total execution time: 0.7150
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:02:26 --> URI Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Router Class Initialized
DEBUG - 2015-04-06 07:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:02:26 --> Output Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Security Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Input Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:02:26 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:02:26 --> URI Class Initialized
DEBUG - 2015-04-06 07:02:26 --> URI Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Router Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Router Class Initialized
DEBUG - 2015-04-06 07:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:02:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:02:26 --> Output Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Security Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Loader Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:02:26 --> Output Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Security Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Input Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:02:26 --> Input Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:02:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:02:26 --> Language Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Loader Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Config Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:02:26 --> Loader Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:02:26 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:02:26 --> Session Class Initialized
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:02:26 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:02:27 --> Session routines successfully run
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:02:27 --> Controller Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:02:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Session Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:02:27 --> Email Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:02:27 --> Session routines successfully run
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Controller Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:02:27 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Email Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
ERROR - 2015-04-06 07:02:27 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:02:27 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:27 --> Final output sent to browser
DEBUG - 2015-04-06 07:02:27 --> Total execution time: 0.9800
DEBUG - 2015-04-06 07:02:28 --> Session Class Initialized
DEBUG - 2015-04-06 07:02:28 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:02:28 --> Session routines successfully run
DEBUG - 2015-04-06 07:02:28 --> Controller Class Initialized
DEBUG - 2015-04-06 07:02:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:02:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:02:28 --> Email Class Initialized
DEBUG - 2015-04-06 07:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:02:28 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:02:28 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:28 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:02:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:02:28 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:02:28 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:02:28 --> Model Class Initialized
DEBUG - 2015-04-06 07:02:28 --> Final output sent to browser
DEBUG - 2015-04-06 07:02:28 --> Total execution time: 1.7910
DEBUG - 2015-04-06 07:52:48 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:48 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:48 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:48 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:48 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:48 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:48 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:48 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:48 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:48 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:48 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:48 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:48 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-06 07:52:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 07:52:49 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:49 --> Total execution time: 0.9380
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:50 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:50 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:50 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:51 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:51 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:51 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:51 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:51 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:51 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:51 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:51 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:51 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:51 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:51 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:51 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:51 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:51 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:51 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:51 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:51 --> Total execution time: 1.7571
DEBUG - 2015-04-06 07:52:51 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:52 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:52 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:52 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:52 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:52 --> Total execution time: 2.1861
DEBUG - 2015-04-06 07:52:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:52 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:52 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:52 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:52 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:52 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:52 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:52 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:52 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:52 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:52 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:52 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:52 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:52 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:52 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:53 --> Total execution time: 2.9592
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:53 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:53 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:53 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:53 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:53 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:53 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:53 --> Total execution time: 3.5382
DEBUG - 2015-04-06 07:52:53 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:53 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:53 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:54 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:54 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:54 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:54 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:54 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-06 07:52:54 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:54 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:54 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:54 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:54 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:54 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:54 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:54 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:54 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:54 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:54 --> Total execution time: 4.8423
DEBUG - 2015-04-06 07:52:54 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:54 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:54 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:54 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:54 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:55 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:55 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:55 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:55 --> Total execution time: 2.3771
DEBUG - 2015-04-06 07:52:55 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: cookie_helper
ERROR - 2015-04-06 07:52:55 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-06 07:52:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:55 --> Total execution time: 3.2302
DEBUG - 2015-04-06 07:52:55 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:55 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:55 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:55 --> Total execution time: 1.2031
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:55 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:55 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:55 --> Total execution time: 2.5971
DEBUG - 2015-04-06 07:52:55 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:55 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:55 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:55 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:56 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:56 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:56 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:56 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:56 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:56 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:56 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:56 --> Total execution time: 1.3551
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:57 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:57 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:57 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Loader Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:52:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:58 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:58 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:58 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:52:58 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:58 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:58 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:52:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:58 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:58 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:59 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:59 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:59 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:59 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Session Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:52:59 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:59 --> Session routines successfully run
DEBUG - 2015-04-06 07:52:59 --> Controller Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Total execution time: 1.5481
DEBUG - 2015-04-06 07:52:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:52:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:59 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:52:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:59 --> URI Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Router Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:59 --> Email Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:52:59 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:59 --> Output Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Total execution time: 2.1481
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Security Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Final output sent to browser
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:52:59 --> Input Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:52:59 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Language Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Total execution time: 2.2131
DEBUG - 2015-04-06 07:52:59 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:52:59 --> Config Class Initialized
DEBUG - 2015-04-06 07:52:59 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:53:00 --> URI Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Router Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Config Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Hooks Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:53:00 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:00 --> Utf8 Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Total execution time: 2.4581
DEBUG - 2015-04-06 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 07:53:00 --> URI Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Output Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Security Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Loader Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Input Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Router Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:53:00 --> Language Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:53:00 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:53:00 --> Language Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Config Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:53:00 --> Output Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Loader Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:53:00 --> Security Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Input Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:53:00 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Session Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Session routines successfully run
DEBUG - 2015-04-06 07:53:00 --> Controller Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:53:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:53:00 --> Language Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:53:00 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:00 --> Total execution time: 2.9002
DEBUG - 2015-04-06 07:53:00 --> Email Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:53:00 --> Language Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:00 --> Config Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:53:00 --> Loader Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: url_helper
DEBUG - 2015-04-06 07:53:00 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Total execution time: 3.3342
DEBUG - 2015-04-06 07:53:00 --> Session Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: form_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: language_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: user_helper
DEBUG - 2015-04-06 07:53:00 --> Session routines successfully run
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: date_helper
DEBUG - 2015-04-06 07:53:00 --> Controller Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:53:00 --> Database Driver Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Session Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: string_helper
DEBUG - 2015-04-06 07:53:00 --> Session routines successfully run
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:53:00 --> Controller Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:53:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:53:00 --> Email Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:53:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:00 --> Email Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 07:53:00 --> Total execution time: 1.4181
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:53:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 07:53:00 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:00 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:53:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> Form Validation Class Initialized
DEBUG - 2015-04-06 07:53:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:01 --> Total execution time: 1.1161
DEBUG - 2015-04-06 07:53:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 07:53:01 --> Model Class Initialized
DEBUG - 2015-04-06 07:53:01 --> Final output sent to browser
DEBUG - 2015-04-06 07:53:01 --> Total execution time: 1.0881
DEBUG - 2015-04-06 12:27:23 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:23 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:27:23 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:23 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:23 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:23 --> A session cookie was not found.
DEBUG - 2015-04-06 12:27:23 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:23 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:27:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:23 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:23 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:23 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:23 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:24 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:24 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:24 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:24 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:24 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 12:27:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:24 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:24 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:24 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:25 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 12:27:25 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-06 12:27:25 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-06 12:27:25 --> Final output sent to browser
DEBUG - 2015-04-06 12:27:25 --> Total execution time: 0.7290
DEBUG - 2015-04-06 12:27:45 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:45 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:45 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:45 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:45 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:45 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Login MX_Controller Initialized
DEBUG - 2015-04-06 12:27:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:45 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-06 12:27:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 12:27:46 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:46 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:46 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-06 12:27:46 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:46 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:46 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:46 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:46 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Customer MX_Controller Initialized
DEBUG - 2015-04-06 12:27:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:46 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:46 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:46 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:46 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:46 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-06 12:27:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-06 12:27:46 --> Final output sent to browser
DEBUG - 2015-04-06 12:27:46 --> Total execution time: 0.6550
DEBUG - 2015-04-06 12:27:47 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:47 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:47 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:47 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:47 --> Router Class Initialized
ERROR - 2015-04-06 12:27:47 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 12:27:49 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:49 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:27:49 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:49 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:49 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:49 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:49 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:27:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:49 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:49 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:49 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:50 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:27:50 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:27:50 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:27:50 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-06 12:27:50 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 12:27:50 --> Final output sent to browser
DEBUG - 2015-04-06 12:27:50 --> Total execution time: 1.4021
DEBUG - 2015-04-06 12:27:51 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:51 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Router Class Initialized
ERROR - 2015-04-06 12:27:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 12:27:51 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:51 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:51 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Router Class Initialized
ERROR - 2015-04-06 12:27:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 12:27:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:27:51 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:51 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:51 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:52 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:52 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:52 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:27:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:52 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:52 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:52 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:27:52 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:27:52 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:27:52 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:52 --> Final output sent to browser
DEBUG - 2015-04-06 12:27:52 --> Total execution time: 0.6800
DEBUG - 2015-04-06 12:27:55 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:27:55 --> URI Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Router Class Initialized
DEBUG - 2015-04-06 12:27:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:27:55 --> Output Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Security Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Input Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:27:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Config Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Loader Class Initialized
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:27:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:27:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:27:56 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Session Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:27:56 --> Session routines successfully run
DEBUG - 2015-04-06 12:27:56 --> Controller Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:27:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:27:56 --> Email Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:27:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:27:56 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:27:56 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:27:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:27:56 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:27:56 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:27:56 --> Model Class Initialized
DEBUG - 2015-04-06 12:27:56 --> Final output sent to browser
DEBUG - 2015-04-06 12:27:56 --> Total execution time: 1.1151
DEBUG - 2015-04-06 12:28:00 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:00 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:00 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:00 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:00 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:00 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:00 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:00 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:00 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:00 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:00 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:01 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:01 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:01 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:01 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-06 12:28:01 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 12:28:01 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:01 --> Total execution time: 1.2521
DEBUG - 2015-04-06 12:28:02 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:02 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:02 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:02 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:02 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:02 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:02 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:02 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:02 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:02 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:02 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:02 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:02 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:02 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:02 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-06 12:28:02 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:03 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:03 --> Total execution time: 1.0921
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:03 --> Model Class Initialized
ERROR - 2015-04-06 12:28:03 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:05 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:05 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:07 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:07 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:07 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:07 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:07 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:07 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:07 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:08 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:08 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:08 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:08 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:08 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:08 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:08 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Total execution time: 3.4102
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:08 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:08 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:08 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:09 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:09 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:09 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:09 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:09 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:09 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:09 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:09 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:10 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:10 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:10 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 5.0523
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 1.9631
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 5.1903
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 5.0143
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 5.6923
DEBUG - 2015-04-06 12:28:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:10 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:10 --> Total execution time: 5.3483
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:11 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:11 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:11 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:11 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:11 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:11 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:11 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:11 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:11 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:11 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:11 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:11 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:12 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:12 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:12 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:12 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:12 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:12 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:12 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:12 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:12 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:12 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:12 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:12 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:12 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:12 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:12 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:12 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:12 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:12 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:12 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:12 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:13 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:13 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:13 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:13 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:13 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:13 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:13 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:13 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:13 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:13 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:13 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:13 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:14 --> Total execution time: 3.3212
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:14 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:14 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:14 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:14 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:15 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:15 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:15 --> Total execution time: 4.7853
DEBUG - 2015-04-06 12:28:15 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:15 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:15 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:15 --> Total execution time: 5.8453
DEBUG - 2015-04-06 12:28:15 --> Total execution time: 4.2542
DEBUG - 2015-04-06 12:28:15 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:16 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:16 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:16 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 3.7092
DEBUG - 2015-04-06 12:28:16 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 6.2074
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 4.7793
DEBUG - 2015-04-06 12:28:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 5.2413
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 1.6261
DEBUG - 2015-04-06 12:28:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:16 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:16 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:16 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:16 --> Total execution time: 0.7940
DEBUG - 2015-04-06 12:28:17 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:17 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:17 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:17 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:17 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:17 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:18 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:18 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:18 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:18 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:18 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:18 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:18 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:18 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:18 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:18 --> Final output sent to browser
DEBUG - 2015-04-06 12:28:18 --> Total execution time: 1.2251
DEBUG - 2015-04-06 12:28:41 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:41 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Router Class Initialized
DEBUG - 2015-04-06 12:28:41 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:28:41 --> Output Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Security Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Input Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:28:41 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Language Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Loader Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:28:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:28:41 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Session Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:28:41 --> Session routines successfully run
DEBUG - 2015-04-06 12:28:41 --> Controller Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:28:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:28:41 --> Email Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:28:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:28:41 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:28:41 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:41 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:28:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:28:42 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:28:42 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:28:42 --> Model Class Initialized
DEBUG - 2015-04-06 12:28:42 --> Helper loaded: file_helper
DEBUG - 2015-04-06 12:28:42 --> Helper loaded: directory_helper
ERROR - 2015-04-06 12:28:46 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 897
ERROR - 2015-04-06 12:28:46 --> Severity: Notice  --> Array to string conversion C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 897
DEBUG - 2015-04-06 12:28:46 --> Config Class Initialized
DEBUG - 2015-04-06 12:28:46 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:28:46 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:28:46 --> URI Class Initialized
DEBUG - 2015-04-06 12:28:46 --> Router Class Initialized
ERROR - 2015-04-06 12:28:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 12:31:08 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:08 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:08 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:08 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:08 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:08 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:08 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:08 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:08 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:09 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-06 12:31:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 12:31:09 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:09 --> Total execution time: 1.3591
DEBUG - 2015-04-06 12:31:09 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:09 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:09 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:10 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:10 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:10 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:10 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:10 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:10 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:10 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-06 12:31:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:10 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:10 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:11 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:11 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Total execution time: 1.1771
DEBUG - 2015-04-06 12:31:11 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:11 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:11 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:11 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:11 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:11 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:11 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:11 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:11 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:11 --> Model Class Initialized
ERROR - 2015-04-06 12:31:11 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:14 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:14 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:14 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:14 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:14 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:14 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:14 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:14 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:15 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:15 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:15 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:15 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:15 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:15 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:15 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:15 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:15 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:15 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:15 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:15 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:15 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:15 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:15 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:15 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:15 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:15 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:15 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:15 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:15 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:15 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:15 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:15 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:15 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:15 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:15 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:15 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:15 --> Total execution time: 1.6231
DEBUG - 2015-04-06 12:31:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:15 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:16 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:16 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:16 --> Total execution time: 1.4691
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:16 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:16 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:16 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:16 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:16 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:16 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:16 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:16 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:16 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:16 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:16 --> Total execution time: 2.0531
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:16 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:16 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:16 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:16 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:17 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:17 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:17 --> Total execution time: 2.9102
DEBUG - 2015-04-06 12:31:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:17 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:17 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:17 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:17 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:17 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:17 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:17 --> Total execution time: 2.5851
DEBUG - 2015-04-06 12:31:17 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:17 --> Total execution time: 3.1242
DEBUG - 2015-04-06 12:31:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:17 --> Total execution time: 1.6251
DEBUG - 2015-04-06 12:31:17 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:17 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:17 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:17 --> Total execution time: 1.5621
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:19 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:19 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:19 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:19 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:19 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:19 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:19 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:19 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:19 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:19 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:20 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:20 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:20 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:20 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:20 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:20 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:20 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:20 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:20 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:20 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:20 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:20 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:20 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:20 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:20 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:20 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:20 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:20 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:20 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:20 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:20 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:20 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:20 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:21 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:21 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Total execution time: 1.5191
DEBUG - 2015-04-06 12:31:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:21 --> Total execution time: 2.0271
DEBUG - 2015-04-06 12:31:21 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:21 --> Total execution time: 2.1561
DEBUG - 2015-04-06 12:31:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:21 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:21 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:21 --> Total execution time: 2.2451
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:21 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:21 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:21 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:21 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:21 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:21 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:21 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:21 --> Total execution time: 0.4590
DEBUG - 2015-04-06 12:31:21 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:22 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:22 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:22 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:22 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:22 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:22 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:22 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Total execution time: 3.4642
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:22 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:22 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:22 --> Total execution time: 2.8292
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:22 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:22 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:22 --> Total execution time: 1.7171
DEBUG - 2015-04-06 12:31:22 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:22 --> Final output sent to browser
DEBUG - 2015-04-06 12:31:23 --> Total execution time: 1.0311
DEBUG - 2015-04-06 12:31:55 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:31:55 --> URI Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Router Class Initialized
DEBUG - 2015-04-06 12:31:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:31:55 --> Output Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Security Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Input Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:31:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Config Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Loader Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:31:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:31:55 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Session Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:31:55 --> Session routines successfully run
DEBUG - 2015-04-06 12:31:55 --> Controller Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:31:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:31:55 --> Email Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:31:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:31:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:31:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:31:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:31:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:31:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:31:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:31:56 --> Helper loaded: file_helper
DEBUG - 2015-04-06 12:31:56 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:35:46 --> Config Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:35:46 --> URI Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Router Class Initialized
DEBUG - 2015-04-06 12:35:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:35:46 --> Output Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Security Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Input Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:35:46 --> Language Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Language Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Config Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Loader Class Initialized
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:35:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:35:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:35:47 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:35:47 --> Session Class Initialized
DEBUG - 2015-04-06 12:35:47 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:35:47 --> Session routines successfully run
DEBUG - 2015-04-06 12:35:47 --> Controller Class Initialized
DEBUG - 2015-04-06 12:35:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:35:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:35:47 --> Email Class Initialized
DEBUG - 2015-04-06 12:35:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:35:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:35:47 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:35:47 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:47 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:35:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:35:47 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:35:47 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:35:47 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:48 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-06 12:35:54 --> Config Class Initialized
DEBUG - 2015-04-06 12:35:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:35:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:35:54 --> URI Class Initialized
DEBUG - 2015-04-06 12:35:54 --> Router Class Initialized
DEBUG - 2015-04-06 12:35:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:35:55 --> Output Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Security Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Input Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:35:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Language Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Config Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Loader Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:35:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:35:55 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Session Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:35:55 --> Session routines successfully run
DEBUG - 2015-04-06 12:35:55 --> Controller Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:35:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:35:55 --> Email Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: file_helper
DEBUG - 2015-04-06 12:35:55 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:40:03 --> Config Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:40:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:40:03 --> URI Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Router Class Initialized
DEBUG - 2015-04-06 12:40:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:40:03 --> Output Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Security Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Input Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:40:03 --> Language Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Language Class Initialized
DEBUG - 2015-04-06 12:40:03 --> Config Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Loader Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:40:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:40:04 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Session Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:40:04 --> Session routines successfully run
DEBUG - 2015-04-06 12:40:04 --> Controller Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Session Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Session routines successfully run
DEBUG - 2015-04-06 12:40:04 --> Controller Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:40:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:40:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:40:04 --> Email Class Initialized
ERROR - 2015-04-06 12:40:04 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-06 12:40:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:40:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:40:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:40:04 --> Model Class Initialized
ERROR - 2015-04-06 12:40:04 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-06 12:40:04 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-06 12:40:04 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-06 12:40:04 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-06 12:40:33 --> Config Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:40:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:40:33 --> URI Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Router Class Initialized
DEBUG - 2015-04-06 12:40:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:40:33 --> Output Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Security Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Input Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:40:33 --> Language Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Language Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Config Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Loader Class Initialized
DEBUG - 2015-04-06 12:40:33 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:40:33 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:40:33 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:40:33 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:40:33 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:40:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:40:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:40:34 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:40:34 --> Session Class Initialized
DEBUG - 2015-04-06 12:40:34 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:40:34 --> Session routines successfully run
DEBUG - 2015-04-06 12:40:34 --> Controller Class Initialized
DEBUG - 2015-04-06 12:40:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:40:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:40:34 --> Email Class Initialized
DEBUG - 2015-04-06 12:40:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:40:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:40:34 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:40:34 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:34 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:40:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:40:34 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:40:34 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:40:34 --> Model Class Initialized
DEBUG - 2015-04-06 12:40:35 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-06 12:41:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:41:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:41:07 --> URI Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Router Class Initialized
DEBUG - 2015-04-06 12:41:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:41:07 --> Output Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Security Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Input Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:41:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Loader Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:41:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:41:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Session Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:41:07 --> Session routines successfully run
DEBUG - 2015-04-06 12:41:07 --> Controller Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Session Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Session routines successfully run
DEBUG - 2015-04-06 12:41:07 --> Controller Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:41:07 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:41:07 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:41:07 --> Email Class Initialized
ERROR - 2015-04-06 12:41:07 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-06 12:41:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:41:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:41:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:41:07 --> Model Class Initialized
ERROR - 2015-04-06 12:41:07 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-06 12:41:07 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-06 12:41:07 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-06 12:41:07 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-06 12:41:22 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:41:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:41:22 --> URI Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Router Class Initialized
DEBUG - 2015-04-06 12:41:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:41:22 --> Output Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Security Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Input Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:41:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Loader Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:41:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:41:22 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Session Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:41:22 --> Session routines successfully run
DEBUG - 2015-04-06 12:41:22 --> Controller Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Session Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Session routines successfully run
DEBUG - 2015-04-06 12:41:22 --> Controller Class Initialized
DEBUG - 2015-04-06 12:41:22 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:41:23 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:41:23 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:41:23 --> Email Class Initialized
ERROR - 2015-04-06 12:41:23 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-06 12:41:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:41:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:41:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:41:23 --> Model Class Initialized
ERROR - 2015-04-06 12:41:23 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-06 12:41:23 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-06 12:41:23 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-06 12:41:23 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-06 12:41:58 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:58 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:41:58 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:41:58 --> URI Class Initialized
DEBUG - 2015-04-06 12:41:58 --> Router Class Initialized
DEBUG - 2015-04-06 12:41:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:41:59 --> Output Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Security Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Input Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:41:59 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Language Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Config Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Loader Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:41:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:41:59 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Session Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:41:59 --> Session routines successfully run
DEBUG - 2015-04-06 12:41:59 --> Controller Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:41:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:41:59 --> Email Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:41:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:41:59 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:41:59 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:41:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:41:59 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:41:59 --> Model Class Initialized
DEBUG - 2015-04-06 12:41:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:41:59 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:00 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-06 12:42:04 --> Config Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:42:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:42:04 --> URI Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Router Class Initialized
DEBUG - 2015-04-06 12:42:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:42:04 --> Output Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Security Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Input Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:42:04 --> Language Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Language Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Config Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Loader Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:42:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:42:04 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Session Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:42:04 --> Session routines successfully run
DEBUG - 2015-04-06 12:42:04 --> Controller Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:42:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:42:04 --> Email Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:42:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:42:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:42:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:42:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:42:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:42:04 --> Model Class Initialized
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: file_helper
DEBUG - 2015-04-06 12:42:04 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 12:51:44 --> Config Class Initialized
DEBUG - 2015-04-06 12:51:44 --> Hooks Class Initialized
DEBUG - 2015-04-06 12:51:44 --> Utf8 Class Initialized
DEBUG - 2015-04-06 12:51:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 12:51:44 --> URI Class Initialized
DEBUG - 2015-04-06 12:51:44 --> Router Class Initialized
DEBUG - 2015-04-06 12:51:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 12:51:44 --> Output Class Initialized
DEBUG - 2015-04-06 12:51:44 --> Security Class Initialized
DEBUG - 2015-04-06 12:51:44 --> Input Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 12:51:45 --> Language Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Language Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Config Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Loader Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: url_helper
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: form_helper
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: language_helper
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: user_helper
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: date_helper
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 12:51:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 12:51:45 --> Database Driver Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Session Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: string_helper
DEBUG - 2015-04-06 12:51:45 --> Session routines successfully run
DEBUG - 2015-04-06 12:51:45 --> Controller Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 12:51:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 12:51:45 --> Email Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 12:51:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 12:51:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:51:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 12:51:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:51:45 --> Form Validation Class Initialized
DEBUG - 2015-04-06 12:51:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 12:51:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:51:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 12:51:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:51:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 12:51:45 --> Model Class Initialized
DEBUG - 2015-04-06 12:51:46 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-06 13:15:01 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:01 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:15:01 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:15:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:15:01 --> URI Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Router Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:15:02 --> Output Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Security Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Input Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:15:02 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Loader Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:15:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:15:02 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Session Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:15:02 --> Session routines successfully run
DEBUG - 2015-04-06 13:15:02 --> Controller Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 13:15:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:15:02 --> Email Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:15:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:15:02 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:15:02 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:02 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:15:02 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:15:02 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 13:15:02 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-06 13:15:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 13:15:02 --> Final output sent to browser
DEBUG - 2015-04-06 13:15:02 --> Total execution time: 1.0460
DEBUG - 2015-04-06 13:15:04 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:04 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:15:04 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:15:04 --> URI Class Initialized
DEBUG - 2015-04-06 13:15:04 --> Router Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:15:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:15:05 --> URI Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Router Class Initialized
DEBUG - 2015-04-06 13:15:05 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-06 13:15:05 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:15:05 --> Output Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Security Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Input Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:15:05 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Loader Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:15:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:15:05 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Session Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:15:05 --> Session routines successfully run
DEBUG - 2015-04-06 13:15:05 --> Controller Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 13:15:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:15:05 --> Email Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:15:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:15:05 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:15:05 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:15:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:15:05 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:15:05 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 13:15:05 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:05 --> Final output sent to browser
DEBUG - 2015-04-06 13:15:05 --> Total execution time: 0.8800
DEBUG - 2015-04-06 13:15:10 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:15:10 --> URI Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Router Class Initialized
DEBUG - 2015-04-06 13:15:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:15:10 --> Output Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Security Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Input Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:15:10 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Language Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Config Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Loader Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:15:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:15:10 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Session Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:15:10 --> Session routines successfully run
DEBUG - 2015-04-06 13:15:10 --> Controller Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-06 13:15:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:15:10 --> Email Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:15:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:15:10 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:15:10 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:15:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:15:10 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:15:10 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-06 13:15:10 --> Model Class Initialized
DEBUG - 2015-04-06 13:15:10 --> Final output sent to browser
DEBUG - 2015-04-06 13:15:10 --> Total execution time: 0.7110
DEBUG - 2015-04-06 13:18:19 --> Config Class Initialized
DEBUG - 2015-04-06 13:18:19 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:18:19 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:18:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:18:19 --> URI Class Initialized
DEBUG - 2015-04-06 13:18:19 --> Router Class Initialized
ERROR - 2015-04-06 13:18:19 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:18:42 --> Config Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:18:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:18:42 --> URI Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Router Class Initialized
DEBUG - 2015-04-06 13:18:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:18:42 --> Output Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Security Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Input Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:18:42 --> Language Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Language Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Config Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Loader Class Initialized
DEBUG - 2015-04-06 13:18:42 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:18:42 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:18:42 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:18:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:18:43 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Session Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:18:43 --> Session routines successfully run
DEBUG - 2015-04-06 13:18:43 --> Controller Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Session Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Session routines successfully run
DEBUG - 2015-04-06 13:18:43 --> Controller Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:18:43 --> Model Class Initialized
DEBUG - 2015-04-06 13:18:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:18:43 --> Model Class Initialized
DEBUG - 2015-04-06 13:18:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:18:43 --> Email Class Initialized
ERROR - 2015-04-06 13:18:43 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-06 13:18:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:18:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:18:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:18:43 --> Model Class Initialized
ERROR - 2015-04-06 13:18:43 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-06 13:18:43 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-06 13:18:43 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-06 13:18:43 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-06 13:20:25 --> Config Class Initialized
DEBUG - 2015-04-06 13:20:25 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:20:25 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:20:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:20:25 --> URI Class Initialized
DEBUG - 2015-04-06 13:20:25 --> Router Class Initialized
ERROR - 2015-04-06 13:20:25 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:20:29 --> Config Class Initialized
DEBUG - 2015-04-06 13:20:29 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:20:29 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:20:29 --> URI Class Initialized
DEBUG - 2015-04-06 13:20:29 --> Router Class Initialized
ERROR - 2015-04-06 13:20:29 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:21:55 --> Config Class Initialized
DEBUG - 2015-04-06 13:21:55 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:21:55 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:21:55 --> URI Class Initialized
DEBUG - 2015-04-06 13:21:55 --> Router Class Initialized
DEBUG - 2015-04-06 13:21:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:21:56 --> Output Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Security Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Input Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:21:56 --> Language Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Language Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Config Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Loader Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:21:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:21:56 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Session Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:21:56 --> Session routines successfully run
DEBUG - 2015-04-06 13:21:56 --> Controller Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Session Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Session routines successfully run
DEBUG - 2015-04-06 13:21:56 --> Controller Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:21:56 --> Model Class Initialized
DEBUG - 2015-04-06 13:21:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:21:56 --> Model Class Initialized
DEBUG - 2015-04-06 13:21:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:21:56 --> Email Class Initialized
ERROR - 2015-04-06 13:21:56 --> Severity: Notice  --> Undefined property: CI::$email C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
DEBUG - 2015-04-06 13:21:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:21:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:21:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:21:56 --> Model Class Initialized
ERROR - 2015-04-06 13:21:56 --> Severity: Notice  --> Undefined property: CI::$bcrypt C:\xampp\htdocs\ecampaign247\application\third_party\MX\Loader.php 168
ERROR - 2015-04-06 13:21:56 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
ERROR - 2015-04-06 13:21:56 --> Severity: Notice  --> Indirect modification of overloaded property Ion_auth::$ion_auth_model has no effect C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 71
ERROR - 2015-04-06 13:21:56 --> Severity: Notice  --> Undefined property: Assets::$ion_auth_model C:\xampp\htdocs\ecampaign247\application\libraries\Ion_auth.php 125
DEBUG - 2015-04-06 13:23:06 --> Config Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:23:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:23:06 --> URI Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Router Class Initialized
DEBUG - 2015-04-06 13:23:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:23:06 --> Output Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Security Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Input Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:23:06 --> Language Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Language Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Config Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Loader Class Initialized
DEBUG - 2015-04-06 13:23:06 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:23:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:23:07 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Session Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:23:07 --> Session routines successfully run
DEBUG - 2015-04-06 13:23:07 --> Controller Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Assets MX_Controller Initialized
DEBUG - 2015-04-06 13:23:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:23:07 --> Email Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:23:07 --> Model Class Initialized
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:23:07 --> Model Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:23:07 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:23:07 --> Model Class Initialized
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:23:07 --> Model Class Initialized
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/views/shared/header.php
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/views/shared/nav.php
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:23:07 --> File loaded: application/modules_core/sites/views/assets/images.php
DEBUG - 2015-04-06 13:23:07 --> Final output sent to browser
DEBUG - 2015-04-06 13:23:07 --> Total execution time: 0.8790
DEBUG - 2015-04-06 13:25:57 --> Config Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:25:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:25:57 --> URI Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Router Class Initialized
DEBUG - 2015-04-06 13:25:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:25:57 --> Output Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Security Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Input Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:25:57 --> Language Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Language Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Config Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Loader Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:25:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:25:57 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Session Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:25:57 --> Session routines successfully run
DEBUG - 2015-04-06 13:25:57 --> Controller Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Assets MX_Controller Initialized
DEBUG - 2015-04-06 13:25:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:25:57 --> Email Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:25:57 --> Model Class Initialized
DEBUG - 2015-04-06 13:25:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:25:57 --> Model Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:25:57 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:25:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:25:57 --> Model Class Initialized
DEBUG - 2015-04-06 13:25:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:25:58 --> Model Class Initialized
DEBUG - 2015-04-06 13:25:58 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:25:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:25:58 --> File loaded: application/views/../modules_core/sites/views/assets/images.php
DEBUG - 2015-04-06 13:25:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 13:25:58 --> Final output sent to browser
DEBUG - 2015-04-06 13:25:58 --> Total execution time: 0.8870
DEBUG - 2015-04-06 13:25:59 --> Config Class Initialized
DEBUG - 2015-04-06 13:25:59 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:25:59 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:25:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:25:59 --> URI Class Initialized
DEBUG - 2015-04-06 13:25:59 --> Router Class Initialized
ERROR - 2015-04-06 13:25:59 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:26:11 --> Config Class Initialized
DEBUG - 2015-04-06 13:26:11 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:26:11 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:26:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:26:11 --> URI Class Initialized
DEBUG - 2015-04-06 13:26:12 --> Router Class Initialized
ERROR - 2015-04-06 13:26:12 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:29:00 --> Config Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:29:00 --> URI Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Router Class Initialized
DEBUG - 2015-04-06 13:29:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:29:00 --> Output Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Security Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Input Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:29:00 --> Language Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Language Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Config Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Loader Class Initialized
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:29:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:29:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:29:01 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Session Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:29:01 --> Session routines successfully run
DEBUG - 2015-04-06 13:29:01 --> Controller Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Assets MX_Controller Initialized
DEBUG - 2015-04-06 13:29:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:29:01 --> Email Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:29:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:29:01 --> Model Class Initialized
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:29:01 --> Model Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:29:01 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:29:01 --> Model Class Initialized
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:29:01 --> Model Class Initialized
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/views/../modules_core/sites/views/assets/images.php
DEBUG - 2015-04-06 13:29:01 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 13:29:01 --> Final output sent to browser
DEBUG - 2015-04-06 13:29:01 --> Total execution time: 0.9010
DEBUG - 2015-04-06 13:29:03 --> Config Class Initialized
DEBUG - 2015-04-06 13:29:03 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:29:03 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:29:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:29:03 --> URI Class Initialized
DEBUG - 2015-04-06 13:29:03 --> Router Class Initialized
ERROR - 2015-04-06 13:29:03 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:36:18 --> Config Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:36:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:36:18 --> URI Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Router Class Initialized
DEBUG - 2015-04-06 13:36:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:36:18 --> Output Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Security Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Input Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:36:18 --> Language Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Language Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Config Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Loader Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:36:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:36:18 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Session Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:36:18 --> Session routines successfully run
DEBUG - 2015-04-06 13:36:18 --> Controller Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Assets MX_Controller Initialized
DEBUG - 2015-04-06 13:36:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:36:18 --> Email Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:36:18 --> Model Class Initialized
DEBUG - 2015-04-06 13:36:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:36:18 --> Model Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:36:18 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:36:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:36:18 --> Model Class Initialized
DEBUG - 2015-04-06 13:36:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:36:18 --> Model Class Initialized
DEBUG - 2015-04-06 13:36:18 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:36:19 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:36:19 --> File loaded: application/views/../modules_core/sites/views/assets/images.php
DEBUG - 2015-04-06 13:36:19 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 13:36:19 --> Final output sent to browser
DEBUG - 2015-04-06 13:36:19 --> Total execution time: 0.9061
DEBUG - 2015-04-06 13:36:20 --> Config Class Initialized
DEBUG - 2015-04-06 13:36:20 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:36:20 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:36:20 --> URI Class Initialized
DEBUG - 2015-04-06 13:36:20 --> Router Class Initialized
ERROR - 2015-04-06 13:36:20 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:40:54 --> Config Class Initialized
DEBUG - 2015-04-06 13:40:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:40:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:40:54 --> URI Class Initialized
DEBUG - 2015-04-06 13:40:54 --> Router Class Initialized
ERROR - 2015-04-06 13:40:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-06 13:43:47 --> Config Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:43:47 --> URI Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Router Class Initialized
DEBUG - 2015-04-06 13:43:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-06 13:43:47 --> Output Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Security Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Input Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 13:43:47 --> Language Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Language Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Config Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Loader Class Initialized
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: url_helper
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: form_helper
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: language_helper
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: user_helper
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: date_helper
DEBUG - 2015-04-06 13:43:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-06 13:43:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-06 13:43:48 --> Database Driver Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Session Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Helper loaded: string_helper
DEBUG - 2015-04-06 13:43:48 --> Session routines successfully run
DEBUG - 2015-04-06 13:43:48 --> Controller Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Assets MX_Controller Initialized
DEBUG - 2015-04-06 13:43:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-06 13:43:48 --> Email Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-06 13:43:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-06 13:43:48 --> Model Class Initialized
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-06 13:43:48 --> Model Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Form Validation Class Initialized
DEBUG - 2015-04-06 13:43:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-06 13:43:48 --> Model Class Initialized
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-06 13:43:48 --> Model Class Initialized
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/views/../modules_core/sites/views/assets/images.php
DEBUG - 2015-04-06 13:43:48 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-06 13:43:48 --> Final output sent to browser
DEBUG - 2015-04-06 13:43:48 --> Total execution time: 1.0121
DEBUG - 2015-04-06 13:43:51 --> Config Class Initialized
DEBUG - 2015-04-06 13:43:51 --> Hooks Class Initialized
DEBUG - 2015-04-06 13:43:51 --> Utf8 Class Initialized
DEBUG - 2015-04-06 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 13:43:51 --> URI Class Initialized
DEBUG - 2015-04-06 13:43:51 --> Router Class Initialized
ERROR - 2015-04-06 13:43:51 --> 404 Page Not Found --> 
