<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-07 05:47:28 --> Config Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Hooks Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Utf8 Class Initialized
DEBUG - 2015-04-07 05:47:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 05:47:28 --> URI Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Router Class Initialized
DEBUG - 2015-04-07 05:47:28 --> No URI present. Default controller set.
DEBUG - 2015-04-07 05:47:28 --> Output Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Security Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Input Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 05:47:28 --> Language Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Language Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Config Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Loader Class Initialized
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: url_helper
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: form_helper
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: language_helper
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: user_helper
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: date_helper
DEBUG - 2015-04-07 05:47:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 05:47:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 05:47:28 --> Database Driver Class Initialized
DEBUG - 2015-04-07 05:47:29 --> Session Class Initialized
DEBUG - 2015-04-07 05:47:29 --> Helper loaded: string_helper
DEBUG - 2015-04-07 05:47:29 --> A session cookie was not found.
DEBUG - 2015-04-07 05:47:29 --> Session routines successfully run
DEBUG - 2015-04-07 05:47:29 --> Controller Class Initialized
DEBUG - 2015-04-07 05:47:30 --> Login MX_Controller Initialized
DEBUG - 2015-04-07 05:47:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 05:47:30 --> Email Class Initialized
DEBUG - 2015-04-07 05:47:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 05:47:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 05:47:30 --> Model Class Initialized
DEBUG - 2015-04-07 05:47:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 05:47:30 --> Model Class Initialized
DEBUG - 2015-04-07 05:47:30 --> Form Validation Class Initialized
DEBUG - 2015-04-07 05:47:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-07 05:47:30 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-07 05:47:30 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-07 05:47:30 --> Final output sent to browser
DEBUG - 2015-04-07 05:47:30 --> Total execution time: 1.9680
DEBUG - 2015-04-07 07:14:47 --> Config Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:14:47 --> URI Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Router Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Output Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Security Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Input Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 07:14:47 --> Language Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Language Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Config Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Loader Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: url_helper
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 07:14:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 07:14:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Session Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: string_helper
DEBUG - 2015-04-07 07:14:47 --> Session routines successfully run
DEBUG - 2015-04-07 07:14:47 --> Controller Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Login MX_Controller Initialized
DEBUG - 2015-04-07 07:14:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 07:14:47 --> Email Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 07:14:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 07:14:47 --> Model Class Initialized
DEBUG - 2015-04-07 07:14:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 07:14:47 --> Model Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 07:14:47 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-07 07:14:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-07 07:14:48 --> Config Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:14:48 --> URI Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Router Class Initialized
DEBUG - 2015-04-07 07:14:48 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-07 07:14:48 --> Output Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Security Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Input Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 07:14:48 --> Language Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Language Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Config Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Loader Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: url_helper
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: form_helper
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: language_helper
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: user_helper
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: date_helper
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 07:14:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 07:14:48 --> Database Driver Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Session Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: string_helper
DEBUG - 2015-04-07 07:14:48 --> Session routines successfully run
DEBUG - 2015-04-07 07:14:48 --> Controller Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Customer MX_Controller Initialized
DEBUG - 2015-04-07 07:14:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 07:14:48 --> Email Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 07:14:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 07:14:48 --> Model Class Initialized
DEBUG - 2015-04-07 07:14:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 07:14:48 --> Model Class Initialized
DEBUG - 2015-04-07 07:14:48 --> Form Validation Class Initialized
DEBUG - 2015-04-07 07:14:48 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-07 07:14:48 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-07 07:14:49 --> Final output sent to browser
DEBUG - 2015-04-07 07:14:49 --> Total execution time: 0.5170
DEBUG - 2015-04-07 07:14:49 --> Config Class Initialized
DEBUG - 2015-04-07 07:14:49 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:14:49 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:14:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:14:49 --> URI Class Initialized
DEBUG - 2015-04-07 07:14:49 --> Router Class Initialized
ERROR - 2015-04-07 07:14:49 --> 404 Page Not Found --> 
DEBUG - 2015-04-07 07:53:14 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:53:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:53:14 --> URI Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Router Class Initialized
DEBUG - 2015-04-07 07:53:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 07:53:14 --> Output Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Security Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Input Class Initialized
DEBUG - 2015-04-07 07:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 07:53:14 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:15 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:15 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:15 --> Loader Class Initialized
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: url_helper
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: form_helper
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: language_helper
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: user_helper
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: date_helper
DEBUG - 2015-04-07 07:53:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 07:53:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 07:53:15 --> Database Driver Class Initialized
DEBUG - 2015-04-07 07:53:16 --> Session Class Initialized
DEBUG - 2015-04-07 07:53:16 --> Helper loaded: string_helper
DEBUG - 2015-04-07 07:53:16 --> Session routines successfully run
DEBUG - 2015-04-07 07:53:16 --> Controller Class Initialized
DEBUG - 2015-04-07 07:53:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 07:53:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 07:53:16 --> Email Class Initialized
DEBUG - 2015-04-07 07:53:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 07:53:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 07:53:16 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 07:53:16 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:16 --> Form Validation Class Initialized
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 07:53:16 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 07:53:16 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 07:53:16 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-07 07:53:16 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-07 07:53:17 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-07 07:53:17 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-07 07:53:17 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-07 07:53:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-07 07:53:17 --> Final output sent to browser
DEBUG - 2015-04-07 07:53:17 --> Total execution time: 2.2761
DEBUG - 2015-04-07 07:53:17 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:53:17 --> URI Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Router Class Initialized
ERROR - 2015-04-07 07:53:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-07 07:53:17 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:53:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:53:17 --> URI Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Router Class Initialized
DEBUG - 2015-04-07 07:53:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 07:53:17 --> Output Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Security Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Input Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 07:53:17 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Loader Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: url_helper
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: form_helper
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: language_helper
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: user_helper
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: date_helper
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 07:53:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 07:53:17 --> Database Driver Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Session Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: string_helper
DEBUG - 2015-04-07 07:53:17 --> Session routines successfully run
DEBUG - 2015-04-07 07:53:17 --> Controller Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 07:53:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 07:53:17 --> Email Class Initialized
DEBUG - 2015-04-07 07:53:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 07:53:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 07:53:17 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Hooks Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Utf8 Class Initialized
DEBUG - 2015-04-07 07:53:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 07:53:18 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:18 --> URI Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Router Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Form Validation Class Initialized
DEBUG - 2015-04-07 07:53:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 07:53:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 07:53:18 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Output Class Initialized
DEBUG - 2015-04-07 07:53:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 07:53:18 --> Security Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Input Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 07:53:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 07:53:18 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Language Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Config Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Loader Class Initialized
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: url_helper
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: form_helper
DEBUG - 2015-04-07 07:53:18 --> Final output sent to browser
DEBUG - 2015-04-07 07:53:18 --> Total execution time: 0.8430
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: language_helper
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: user_helper
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: date_helper
DEBUG - 2015-04-07 07:53:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 07:53:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 07:53:18 --> Database Driver Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Session Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Helper loaded: string_helper
DEBUG - 2015-04-07 07:53:19 --> Session routines successfully run
DEBUG - 2015-04-07 07:53:19 --> Controller Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 07:53:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 07:53:19 --> Email Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 07:53:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 07:53:19 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 07:53:19 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Form Validation Class Initialized
DEBUG - 2015-04-07 07:53:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 07:53:19 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 07:53:19 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 07:53:19 --> Model Class Initialized
DEBUG - 2015-04-07 07:53:19 --> Final output sent to browser
DEBUG - 2015-04-07 07:53:19 --> Total execution time: 1.5731
DEBUG - 2015-04-07 08:13:37 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:37 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:37 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:37 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:37 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:37 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:37 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:37 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:37 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:37 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:37 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:37 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:37 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:37 --> Helper loaded: directory_helper
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-07 08:13:38 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:38 --> Total execution time: 1.2340
DEBUG - 2015-04-07 08:13:38 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:38 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:38 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:38 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:39 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:39 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:39 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:39 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:39 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:39 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:40 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:40 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:40 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:40 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:40 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:40 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:40 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:41 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:41 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:41 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:41 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:41 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:41 --> Total execution time: 2.2981
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:41 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
ERROR - 2015-04-07 08:13:41 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-07 08:13:41 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:41 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:41 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:41 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:42 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:42 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:42 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:42 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:42 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:42 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:42 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:42 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:42 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:42 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:42 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:42 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:42 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:42 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:42 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:42 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:43 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:43 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:43 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Total execution time: 4.3722
DEBUG - 2015-04-07 08:13:43 --> Total execution time: 3.8722
DEBUG - 2015-04-07 08:13:43 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:43 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:43 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:43 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:43 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:43 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:43 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:43 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:43 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:43 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:43 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:43 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:43 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:43 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:43 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:43 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:44 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:44 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:44 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:44 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:44 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:44 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:44 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:44 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:44 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:44 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:44 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Total execution time: 5.3763
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:44 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:44 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:44 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:45 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:45 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:45 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:45 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:45 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:45 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:45 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:45 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:45 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:45 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:45 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:45 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:46 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:46 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:46 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:46 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:46 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:46 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:46 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:46 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:46 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:46 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:47 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:47 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:47 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:47 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:47 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:47 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:47 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:47 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:47 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:47 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:47 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:47 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:47 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 3.3782
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 4.9232
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 9.1574
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 2.4321
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 5.6473
DEBUG - 2015-04-07 08:13:48 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:48 --> Total execution time: 6.4083
DEBUG - 2015-04-07 08:13:48 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:48 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:48 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:48 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:48 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:48 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:48 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:48 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:48 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:48 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:48 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:48 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:48 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:48 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:48 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:49 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:49 --> Total execution time: 4.8012
DEBUG - 2015-04-07 08:13:49 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:49 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:49 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:49 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:49 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Total execution time: 3.5091
DEBUG - 2015-04-07 08:13:49 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:49 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:49 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:49 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:49 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:49 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:49 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:49 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:50 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:50 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:50 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:50 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:50 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:50 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:50 --> Total execution time: 2.4391
DEBUG - 2015-04-07 08:13:50 --> Total execution time: 4.9872
DEBUG - 2015-04-07 08:13:51 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:51 --> Total execution time: 4.9742
DEBUG - 2015-04-07 08:13:51 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:51 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Total execution time: 5.0242
DEBUG - 2015-04-07 08:13:51 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:13:51 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:51 --> Total execution time: 1.5521
DEBUG - 2015-04-07 08:13:51 --> URI Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Router Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:51 --> Total execution time: 5.3632
DEBUG - 2015-04-07 08:13:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:13:51 --> Output Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Security Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Input Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:13:51 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Language Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Config Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Loader Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:13:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:13:51 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Session Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:13:51 --> Session routines successfully run
DEBUG - 2015-04-07 08:13:51 --> Controller Class Initialized
DEBUG - 2015-04-07 08:13:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:13:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:13:52 --> Email Class Initialized
DEBUG - 2015-04-07 08:13:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:13:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:13:52 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:13:52 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:52 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:13:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:13:52 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:13:52 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:13:52 --> Model Class Initialized
DEBUG - 2015-04-07 08:13:52 --> Final output sent to browser
DEBUG - 2015-04-07 08:13:52 --> Total execution time: 1.0841
DEBUG - 2015-04-07 08:14:59 --> Config Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Hooks Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Utf8 Class Initialized
DEBUG - 2015-04-07 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-07 08:14:59 --> URI Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Router Class Initialized
DEBUG - 2015-04-07 08:14:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-07 08:14:59 --> Output Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Security Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Input Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-07 08:14:59 --> Language Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Language Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Config Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Loader Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: url_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: form_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: language_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: user_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: date_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-07 08:14:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-07 08:14:59 --> Database Driver Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Session Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: string_helper
DEBUG - 2015-04-07 08:14:59 --> Session routines successfully run
DEBUG - 2015-04-07 08:14:59 --> Controller Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-07 08:14:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-07 08:14:59 --> Email Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-07 08:14:59 --> Model Class Initialized
DEBUG - 2015-04-07 08:14:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-07 08:14:59 --> Model Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Form Validation Class Initialized
DEBUG - 2015-04-07 08:14:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-07 08:14:59 --> Model Class Initialized
DEBUG - 2015-04-07 08:14:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-07 08:14:59 --> Model Class Initialized
DEBUG - 2015-04-07 08:14:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-07 08:14:59 --> Model Class Initialized
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: file_helper
DEBUG - 2015-04-07 08:14:59 --> Helper loaded: directory_helper
