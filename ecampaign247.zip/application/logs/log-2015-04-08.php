<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-08 05:46:56 --> Config Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Hooks Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Utf8 Class Initialized
DEBUG - 2015-04-08 05:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 05:46:56 --> URI Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Router Class Initialized
DEBUG - 2015-04-08 05:46:56 --> No URI present. Default controller set.
DEBUG - 2015-04-08 05:46:56 --> Output Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Security Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Input Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 05:46:56 --> Language Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Language Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Config Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Loader Class Initialized
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: url_helper
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: form_helper
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: language_helper
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: user_helper
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: date_helper
DEBUG - 2015-04-08 05:46:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 05:46:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 05:46:56 --> Database Driver Class Initialized
DEBUG - 2015-04-08 05:46:57 --> Session Class Initialized
DEBUG - 2015-04-08 05:46:57 --> Helper loaded: string_helper
DEBUG - 2015-04-08 05:46:57 --> A session cookie was not found.
DEBUG - 2015-04-08 05:46:57 --> Session routines successfully run
DEBUG - 2015-04-08 05:46:57 --> Controller Class Initialized
DEBUG - 2015-04-08 05:46:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 05:46:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 05:46:58 --> Email Class Initialized
DEBUG - 2015-04-08 05:46:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 05:46:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 05:46:58 --> Model Class Initialized
DEBUG - 2015-04-08 05:46:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 05:46:58 --> Model Class Initialized
DEBUG - 2015-04-08 05:46:58 --> Form Validation Class Initialized
DEBUG - 2015-04-08 05:46:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 05:46:58 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-08 05:46:58 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-08 05:46:58 --> Final output sent to browser
DEBUG - 2015-04-08 05:46:58 --> Total execution time: 1.8361
DEBUG - 2015-04-08 07:29:10 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:10 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Router Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Output Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Security Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Input Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:29:10 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Loader Class Initialized
DEBUG - 2015-04-08 07:29:10 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:29:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:29:11 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Session Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:29:11 --> Session routines successfully run
DEBUG - 2015-04-08 07:29:11 --> Controller Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 07:29:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:29:11 --> Email Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:29:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:29:11 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:29:11 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 07:29:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-08 07:29:11 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:11 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:11 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Router Class Initialized
DEBUG - 2015-04-08 07:29:12 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-08 07:29:12 --> Output Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Security Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Input Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:29:12 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Loader Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:29:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:29:12 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Session Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:29:12 --> Session routines successfully run
DEBUG - 2015-04-08 07:29:12 --> Controller Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Customer MX_Controller Initialized
DEBUG - 2015-04-08 07:29:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:29:12 --> Email Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:29:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:29:12 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:29:12 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:12 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:29:12 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-08 07:29:12 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-08 07:29:12 --> Final output sent to browser
DEBUG - 2015-04-08 07:29:12 --> Total execution time: 0.6540
DEBUG - 2015-04-08 07:29:13 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:13 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:13 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:13 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:13 --> Router Class Initialized
ERROR - 2015-04-08 07:29:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-08 07:29:16 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:16 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Router Class Initialized
DEBUG - 2015-04-08 07:29:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:29:16 --> Output Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Security Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Input Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:29:16 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Loader Class Initialized
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:29:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:29:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:29:16 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:29:17 --> Session Class Initialized
DEBUG - 2015-04-08 07:29:17 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:29:17 --> Session routines successfully run
DEBUG - 2015-04-08 07:29:17 --> Controller Class Initialized
DEBUG - 2015-04-08 07:29:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:29:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:29:17 --> Email Class Initialized
DEBUG - 2015-04-08 07:29:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:29:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:29:17 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:29:17 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:17 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:29:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:29:17 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:29:17 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:29:17 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-08 07:29:18 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-08 07:29:18 --> Final output sent to browser
DEBUG - 2015-04-08 07:29:18 --> Total execution time: 2.2411
DEBUG - 2015-04-08 07:29:18 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:18 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:18 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:18 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:18 --> Router Class Initialized
ERROR - 2015-04-08 07:29:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-08 07:29:19 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:19 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Router Class Initialized
DEBUG - 2015-04-08 07:29:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:29:19 --> Output Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Security Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Input Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:29:19 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Loader Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:29:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:29:19 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Session Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:29:19 --> Session routines successfully run
DEBUG - 2015-04-08 07:29:19 --> Controller Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:29:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:29:19 --> Email Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:29:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:29:19 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:29:19 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:29:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:29:19 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:29:19 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:29:19 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:19 --> Final output sent to browser
DEBUG - 2015-04-08 07:29:19 --> Total execution time: 0.6140
DEBUG - 2015-04-08 07:29:20 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:29:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:29:20 --> URI Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Router Class Initialized
DEBUG - 2015-04-08 07:29:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:29:20 --> Output Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Security Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Input Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:29:20 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Language Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Config Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Loader Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:29:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:29:20 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Session Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:29:20 --> Session routines successfully run
DEBUG - 2015-04-08 07:29:20 --> Controller Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:29:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:29:20 --> Email Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:29:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:29:20 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:29:20 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:29:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:29:20 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:29:20 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:29:20 --> Model Class Initialized
DEBUG - 2015-04-08 07:29:20 --> Final output sent to browser
DEBUG - 2015-04-08 07:29:20 --> Total execution time: 0.8020
DEBUG - 2015-04-08 07:35:30 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:30 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:30 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:30 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:30 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:30 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:30 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:31 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:31 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:31 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:31 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:31 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:31 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:31 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:31 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:31 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:31 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-08 07:35:31 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-08 07:35:31 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:31 --> Total execution time: 1.3010
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:32 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:32 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:32 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:32 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:32 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:32 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:32 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:32 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:32 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:32 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:33 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:33 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:33 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:33 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:33 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:33 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:33 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:33 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:33 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:33 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:33 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:33 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:33 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:33 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:34 --> Total execution time: 1.2291
DEBUG - 2015-04-08 07:35:34 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:34 --> Total execution time: 1.2351
DEBUG - 2015-04-08 07:35:34 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:34 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:34 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:34 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:34 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:34 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:34 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:34 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:34 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:34 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:34 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:34 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:34 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:34 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:34 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:34 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:34 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:34 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:34 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:34 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:34 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:34 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:35 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:35 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:35 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:35 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:35 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:35 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:35 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Total execution time: 2.5301
DEBUG - 2015-04-08 07:35:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:35 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:35 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
ERROR - 2015-04-08 07:35:35 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-08 07:35:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:35 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:35 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:35 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:35 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:35 --> Total execution time: 3.8222
DEBUG - 2015-04-08 07:35:35 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Total execution time: 1.4151
DEBUG - 2015-04-08 07:35:36 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:36 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:36 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:36 --> Total execution time: 3.7132
DEBUG - 2015-04-08 07:35:36 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:36 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:36 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:36 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:36 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:36 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:36 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:36 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:36 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:36 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:36 --> Total execution time: 2.4581
DEBUG - 2015-04-08 07:35:36 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:36 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:36 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:36 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:36 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:36 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:36 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:36 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:36 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:37 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:37 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:37 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:37 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:37 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:37 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:37 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:37 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:37 --> Total execution time: 1.6001
DEBUG - 2015-04-08 07:35:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:37 --> Total execution time: 1.3381
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:37 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:37 --> Total execution time: 1.4171
DEBUG - 2015-04-08 07:35:37 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:37 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:37 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:38 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:38 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:38 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:38 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:38 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:38 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:38 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:38 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:38 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:38 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:38 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:39 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:39 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:39 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:39 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:39 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:39 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:39 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:39 --> Total execution time: 1.7451
DEBUG - 2015-04-08 07:35:39 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:39 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:39 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:39 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:39 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:40 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Total execution time: 1.9601
DEBUG - 2015-04-08 07:35:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:40 --> Total execution time: 1.8501
DEBUG - 2015-04-08 07:35:40 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:40 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:40 --> Total execution time: 2.3811
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:40 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:40 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:40 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:40 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:40 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:40 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:40 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:40 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:40 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:40 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:40 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:40 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:40 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:41 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:41 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:41 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:41 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:41 --> Total execution time: 3.3012
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:41 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:41 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:41 --> Total execution time: 1.9891
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:41 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:41 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:41 --> Total execution time: 3.5552
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:41 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:41 --> Total execution time: 1.2821
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:41 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:42 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:35:42 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:35:42 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:35:42 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:42 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:42 --> Total execution time: 2.1561
DEBUG - 2015-04-08 07:35:44 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:44 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:35:44 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:44 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:44 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:45 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:45 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:45 --> A session cookie was not found.
DEBUG - 2015-04-08 07:35:45 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:45 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:35:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:46 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:46 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:46 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:35:46 --> URI Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Router Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Output Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Security Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Input Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:35:46 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Language Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Config Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Loader Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:35:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:35:46 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Session Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:35:46 --> A session cookie was not found.
DEBUG - 2015-04-08 07:35:46 --> Session routines successfully run
DEBUG - 2015-04-08 07:35:46 --> Controller Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 07:35:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:35:46 --> Email Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:35:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:35:46 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:35:46 --> Model Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:35:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 07:35:46 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-08 07:35:46 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-08 07:35:46 --> Final output sent to browser
DEBUG - 2015-04-08 07:35:46 --> Total execution time: 0.5110
DEBUG - 2015-04-08 07:37:43 --> Config Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Hooks Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Utf8 Class Initialized
DEBUG - 2015-04-08 07:37:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 07:37:43 --> URI Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Router Class Initialized
DEBUG - 2015-04-08 07:37:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 07:37:43 --> Output Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Security Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Input Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 07:37:43 --> Language Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Language Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Config Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Loader Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: url_helper
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: form_helper
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: language_helper
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: user_helper
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: date_helper
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 07:37:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 07:37:43 --> Database Driver Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Session Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: string_helper
DEBUG - 2015-04-08 07:37:43 --> Session routines successfully run
DEBUG - 2015-04-08 07:37:43 --> Controller Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 07:37:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 07:37:43 --> Email Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 07:37:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 07:37:43 --> Model Class Initialized
DEBUG - 2015-04-08 07:37:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 07:37:43 --> Model Class Initialized
DEBUG - 2015-04-08 07:37:43 --> Form Validation Class Initialized
DEBUG - 2015-04-08 07:37:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 07:37:43 --> Model Class Initialized
DEBUG - 2015-04-08 07:37:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 07:37:43 --> Model Class Initialized
DEBUG - 2015-04-08 07:37:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 07:37:43 --> Model Class Initialized
DEBUG - 2015-04-08 07:37:44 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 07:37:44 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-08 07:37:44 --> Final output sent to browser
DEBUG - 2015-04-08 07:37:44 --> Total execution time: 0.7670
DEBUG - 2015-04-08 08:39:03 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Hooks Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Utf8 Class Initialized
DEBUG - 2015-04-08 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 08:39:03 --> URI Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Router Class Initialized
DEBUG - 2015-04-08 08:39:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 08:39:03 --> Output Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Security Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Input Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 08:39:03 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Loader Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: url_helper
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: form_helper
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: language_helper
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: user_helper
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: date_helper
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 08:39:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 08:39:03 --> Database Driver Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Session Class Initialized
DEBUG - 2015-04-08 08:39:03 --> Helper loaded: string_helper
DEBUG - 2015-04-08 08:39:04 --> Session routines successfully run
DEBUG - 2015-04-08 08:39:04 --> Controller Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Hooks Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Utf8 Class Initialized
DEBUG - 2015-04-08 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 08:39:04 --> URI Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 08:39:04 --> Router Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 08:39:04 --> Email Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Output Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Security Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 08:39:04 --> Input Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 08:39:04 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Form Validation Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Loader Class Initialized
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: url_helper
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: form_helper
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: language_helper
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: user_helper
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: date_helper
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 08:39:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 08:39:04 --> Database Driver Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Session Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: string_helper
DEBUG - 2015-04-08 08:39:04 --> Session routines successfully run
DEBUG - 2015-04-08 08:39:04 --> Controller Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 08:39:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 08:39:04 --> Email Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 08:39:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> Final output sent to browser
DEBUG - 2015-04-08 08:39:04 --> Total execution time: 1.6701
DEBUG - 2015-04-08 08:39:04 --> Form Validation Class Initialized
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 08:39:04 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 08:39:05 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:05 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 08:39:05 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-08 08:39:05 --> Final output sent to browser
DEBUG - 2015-04-08 08:39:05 --> Total execution time: 1.1631
DEBUG - 2015-04-08 08:39:52 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Hooks Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Utf8 Class Initialized
DEBUG - 2015-04-08 08:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 08:39:52 --> URI Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Router Class Initialized
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 08:39:52 --> Output Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Security Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Input Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 08:39:52 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Language Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Config Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Loader Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: url_helper
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: form_helper
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: language_helper
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: user_helper
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: date_helper
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 08:39:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 08:39:52 --> Database Driver Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Session Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: string_helper
DEBUG - 2015-04-08 08:39:52 --> Session routines successfully run
DEBUG - 2015-04-08 08:39:52 --> Controller Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 08:39:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 08:39:52 --> Email Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 08:39:52 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 08:39:52 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Form Validation Class Initialized
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 08:39:52 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 08:39:52 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 08:39:52 --> Model Class Initialized
DEBUG - 2015-04-08 08:39:52 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 08:39:52 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-08 08:39:52 --> Final output sent to browser
DEBUG - 2015-04-08 08:39:52 --> Total execution time: 0.8270
DEBUG - 2015-04-08 11:32:04 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:04 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:04 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:04 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:04 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:32:05 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:05 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:05 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:05 --> A session cookie was not found.
DEBUG - 2015-04-08 11:32:05 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:05 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:32:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:05 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:05 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:05 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:07 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 11:32:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:07 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:07 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 11:32:07 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-08 11:32:07 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-08 11:32:07 --> Final output sent to browser
DEBUG - 2015-04-08 11:32:07 --> Total execution time: 0.6060
DEBUG - 2015-04-08 11:32:28 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:28 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:28 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:28 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:28 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:28 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 11:32:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:28 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 11:32:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-08 11:32:28 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:28 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:29 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:29 --> File loaded: application/modules_core/customer/config/routes.php
DEBUG - 2015-04-08 11:32:29 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:29 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:29 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:29 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:29 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Customer MX_Controller Initialized
DEBUG - 2015-04-08 11:32:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:29 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:29 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:29 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:29 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:29 --> File loaded: application/views/../modules_core/customer/views/customer/index.php
DEBUG - 2015-04-08 11:32:29 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-08 11:32:29 --> Final output sent to browser
DEBUG - 2015-04-08 11:32:29 --> Total execution time: 0.6220
DEBUG - 2015-04-08 11:32:30 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:30 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:30 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:30 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:30 --> Router Class Initialized
ERROR - 2015-04-08 11:32:30 --> 404 Page Not Found --> 
DEBUG - 2015-04-08 11:32:48 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:48 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:32:48 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:48 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:49 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:49 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:49 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:32:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:49 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:49 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:49 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:32:49 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:32:49 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:32:49 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-08 11:32:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-08 11:32:49 --> Final output sent to browser
DEBUG - 2015-04-08 11:32:49 --> Total execution time: 0.8670
DEBUG - 2015-04-08 11:32:49 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:49 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:50 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Router Class Initialized
ERROR - 2015-04-08 11:32:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-08 11:32:50 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:50 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:32:50 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:50 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:50 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:50 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:50 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:32:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:50 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:50 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:50 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:32:50 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:32:50 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:32:50 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:50 --> Final output sent to browser
DEBUG - 2015-04-08 11:32:50 --> Total execution time: 0.6470
DEBUG - 2015-04-08 11:32:53 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:32:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:32:53 --> URI Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Router Class Initialized
DEBUG - 2015-04-08 11:32:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:32:53 --> Output Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Security Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Input Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:32:53 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Language Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Config Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Loader Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:32:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:32:53 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Session Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:32:53 --> Session routines successfully run
DEBUG - 2015-04-08 11:32:53 --> Controller Class Initialized
DEBUG - 2015-04-08 11:32:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:32:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:32:54 --> Email Class Initialized
DEBUG - 2015-04-08 11:32:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:32:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:32:54 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:32:54 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:54 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:32:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:32:54 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:32:54 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:32:54 --> Model Class Initialized
DEBUG - 2015-04-08 11:32:54 --> Final output sent to browser
DEBUG - 2015-04-08 11:32:54 --> Total execution time: 0.6570
DEBUG - 2015-04-08 11:33:00 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:00 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:00 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:00 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:00 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:00 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:00 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:01 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:01 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:01 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:01 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:01 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:01 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:01 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:01 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:01 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:01 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:01 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-08 11:33:01 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-08 11:33:01 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:01 --> Total execution time: 0.9441
DEBUG - 2015-04-08 11:33:02 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:02 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:02 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:02 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:02 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:02 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:02 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:02 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:02 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:02 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:02 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:02 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:02 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:02 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:02 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:02 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-08 11:33:02 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:02 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:02 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:02 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:02 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:02 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:03 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:03 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:03 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:03 --> Total execution time: 0.8861
DEBUG - 2015-04-08 11:33:03 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:03 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:03 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:03 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:03 --> Model Class Initialized
ERROR - 2015-04-08 11:33:03 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:06 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:06 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:06 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:06 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:06 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:06 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:06 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:06 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:06 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:06 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:07 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:07 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:07 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:07 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:07 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:07 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:07 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:07 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:07 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:07 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:07 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:07 --> Total execution time: 1.6391
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:07 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:07 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:07 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:07 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:07 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:07 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:07 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:07 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:07 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:07 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:08 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:08 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:08 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 1.9081
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:08 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:08 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:08 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:08 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:08 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 1.9261
DEBUG - 2015-04-08 11:33:08 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:08 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:08 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 2.4361
DEBUG - 2015-04-08 11:33:08 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 2.1371
DEBUG - 2015-04-08 11:33:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:08 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:08 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 2.0941
DEBUG - 2015-04-08 11:33:08 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:08 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:08 --> Total execution time: 1.1621
DEBUG - 2015-04-08 11:33:08 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:08 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:09 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:09 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:09 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:09 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:09 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:09 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:09 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:09 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:09 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:09 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:09 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:09 --> Total execution time: 1.0081
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:10 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:10 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:10 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:10 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:10 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:10 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:10 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:10 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:10 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:10 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:10 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:10 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:10 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:10 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:10 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:10 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:10 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:10 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:11 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:11 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:11 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:11 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:11 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:11 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:11 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:11 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:11 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:11 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:11 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:11 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:11 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:11 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:11 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:11 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:11 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:11 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:11 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:11 --> Total execution time: 1.2581
DEBUG - 2015-04-08 11:33:11 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:11 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:11 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:11 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:11 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:11 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:11 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:11 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:11 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:12 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:12 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:12 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:12 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:12 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:12 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:12 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:12 --> Total execution time: 2.0301
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:12 --> Total execution time: 1.9481
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:12 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:12 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:12 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:12 --> Total execution time: 2.2481
DEBUG - 2015-04-08 11:33:12 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:12 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:33:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:12 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:13 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:13 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:13 --> URI Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:13 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:13 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Total execution time: 2.4631
DEBUG - 2015-04-08 11:33:13 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:13 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:13 --> Router Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:13 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:13 --> Output Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Security Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:13 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:13 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:13 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:13 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:13 --> Input Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:33:13 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:13 --> Language Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Config Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:13 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:13 --> Total execution time: 1.6011
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Loader Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:33:13 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:33:13 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:13 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:33:13 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Session Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:33:13 --> Session routines successfully run
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:13 --> Controller Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:33:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:13 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:33:13 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Email Class Initialized
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:14 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Total execution time: 1.2271
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Model Class Initialized
DEBUG - 2015-04-08 11:33:14 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:14 --> Total execution time: 1.6441
DEBUG - 2015-04-08 11:33:14 --> Final output sent to browser
DEBUG - 2015-04-08 11:33:14 --> Total execution time: 4.0522
DEBUG - 2015-04-08 11:34:28 --> Config Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Hooks Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Utf8 Class Initialized
DEBUG - 2015-04-08 11:34:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 11:34:28 --> URI Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Router Class Initialized
DEBUG - 2015-04-08 11:34:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-08 11:34:28 --> Output Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Security Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Input Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 11:34:28 --> Language Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Language Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Config Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Loader Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: url_helper
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: form_helper
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: language_helper
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: user_helper
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: date_helper
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 11:34:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 11:34:28 --> Database Driver Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Session Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: string_helper
DEBUG - 2015-04-08 11:34:28 --> Session routines successfully run
DEBUG - 2015-04-08 11:34:28 --> Controller Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-08 11:34:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 11:34:28 --> Email Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 11:34:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 11:34:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:34:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 11:34:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:34:28 --> Form Validation Class Initialized
DEBUG - 2015-04-08 11:34:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-08 11:34:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:34:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-08 11:34:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:34:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-08 11:34:28 --> Model Class Initialized
DEBUG - 2015-04-08 11:34:29 --> Helper loaded: directory_helper
DEBUG - 2015-04-08 11:34:29 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-08 11:34:29 --> Final output sent to browser
DEBUG - 2015-04-08 11:34:29 --> Total execution time: 0.9760
DEBUG - 2015-04-08 13:26:01 --> Config Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Hooks Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Utf8 Class Initialized
DEBUG - 2015-04-08 13:26:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-08 13:26:01 --> URI Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Router Class Initialized
DEBUG - 2015-04-08 13:26:01 --> No URI present. Default controller set.
DEBUG - 2015-04-08 13:26:01 --> Output Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Security Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Input Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-08 13:26:01 --> Language Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Language Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Config Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Loader Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: url_helper
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: form_helper
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: language_helper
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: user_helper
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: date_helper
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-08 13:26:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-08 13:26:01 --> Database Driver Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Session Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: string_helper
ERROR - 2015-04-08 13:26:01 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-04-08 13:26:01 --> Session routines successfully run
DEBUG - 2015-04-08 13:26:01 --> Controller Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-08 13:26:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-08 13:26:01 --> Email Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-08 13:26:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-08 13:26:01 --> Model Class Initialized
DEBUG - 2015-04-08 13:26:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-08 13:26:01 --> Model Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Form Validation Class Initialized
DEBUG - 2015-04-08 13:26:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-08 13:26:01 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-08 13:26:01 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-08 13:26:01 --> Final output sent to browser
DEBUG - 2015-04-08 13:26:01 --> Total execution time: 0.9931
