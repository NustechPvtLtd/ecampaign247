<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-13 05:31:51 --> Config Class Initialized
DEBUG - 2015-04-13 05:31:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 05:31:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 05:31:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 05:31:51 --> URI Class Initialized
DEBUG - 2015-04-13 05:31:51 --> Router Class Initialized
DEBUG - 2015-04-13 05:31:51 --> No URI present. Default controller set.
DEBUG - 2015-04-13 05:31:52 --> Output Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Security Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Input Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 05:31:52 --> Language Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Language Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Config Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Loader Class Initialized
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 05:31:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 05:31:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 05:31:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Session Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Helper loaded: string_helper
DEBUG - 2015-04-13 05:31:54 --> A session cookie was not found.
DEBUG - 2015-04-13 05:31:54 --> Session routines successfully run
DEBUG - 2015-04-13 05:31:54 --> Controller Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 05:31:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 05:31:54 --> Email Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 05:31:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 05:31:54 --> Model Class Initialized
DEBUG - 2015-04-13 05:31:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 05:31:54 --> Model Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Form Validation Class Initialized
DEBUG - 2015-04-13 05:31:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 05:31:54 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 05:31:54 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 05:31:54 --> Final output sent to browser
DEBUG - 2015-04-13 05:31:54 --> Total execution time: 3.4352
DEBUG - 2015-04-13 08:22:23 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:22:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:22:23 --> URI Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Router Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Output Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Security Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Input Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:22:23 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Loader Class Initialized
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:22:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:22:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:22:23 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:22:24 --> Session Class Initialized
DEBUG - 2015-04-13 08:22:24 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:22:24 --> A session cookie was not found.
DEBUG - 2015-04-13 08:22:24 --> Session routines successfully run
DEBUG - 2015-04-13 08:22:24 --> Controller Class Initialized
DEBUG - 2015-04-13 08:22:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:22:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:22:24 --> Email Class Initialized
DEBUG - 2015-04-13 08:22:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:22:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:22:25 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:22:25 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:22:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 08:22:25 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:22:25 --> URI Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Router Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Output Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Security Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Input Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:22:25 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Loader Class Initialized
DEBUG - 2015-04-13 08:22:25 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:22:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:22:26 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Session Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:22:26 --> Session routines successfully run
DEBUG - 2015-04-13 08:22:26 --> Controller Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:22:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:22:26 --> Email Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:22:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:22:26 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:22:26 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:22:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:22:26 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 08:22:26 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:22:26 --> Final output sent to browser
DEBUG - 2015-04-13 08:22:26 --> Total execution time: 0.9251
DEBUG - 2015-04-13 08:22:39 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:40 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:22:40 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:22:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:22:41 --> URI Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Router Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Output Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Security Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Input Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:22:41 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Loader Class Initialized
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:22:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:22:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:22:42 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Session Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:22:42 --> Session routines successfully run
DEBUG - 2015-04-13 08:22:42 --> Controller Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:22:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:22:42 --> Email Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:22:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:22:42 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:22:42 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:22:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:22:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 08:22:43 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:22:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:22:43 --> URI Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Router Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Output Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Security Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Input Class Initialized
DEBUG - 2015-04-13 08:22:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:22:43 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Language Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Config Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Loader Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:22:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:22:44 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Session Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:22:44 --> Session routines successfully run
DEBUG - 2015-04-13 08:22:44 --> Controller Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:22:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:22:44 --> Email Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:22:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:22:44 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:22:44 --> Model Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:22:44 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:22:44 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 08:22:44 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:22:44 --> Final output sent to browser
DEBUG - 2015-04-13 08:22:44 --> Total execution time: 0.8390
DEBUG - 2015-04-13 08:23:10 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:23:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:23:10 --> URI Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Router Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Output Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Security Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Input Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:23:10 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Loader Class Initialized
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:23:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:23:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:23:10 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:23:11 --> Session Class Initialized
DEBUG - 2015-04-13 08:23:11 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:23:11 --> Session routines successfully run
DEBUG - 2015-04-13 08:23:11 --> Controller Class Initialized
DEBUG - 2015-04-13 08:23:11 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:23:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:23:11 --> Email Class Initialized
DEBUG - 2015-04-13 08:23:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:23:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:23:12 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:23:12 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:12 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:23:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:23:12 --> File loaded: application/views/../modules_core/login/views/forgot_password.php
DEBUG - 2015-04-13 08:23:13 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:23:13 --> Final output sent to browser
DEBUG - 2015-04-13 08:23:13 --> Total execution time: 3.0722
DEBUG - 2015-04-13 08:23:29 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:29 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:23:29 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:23:29 --> URI Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Router Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Output Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Security Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Input Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:23:30 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Loader Class Initialized
DEBUG - 2015-04-13 08:23:30 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:23:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:23:31 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:23:31 --> Session Class Initialized
DEBUG - 2015-04-13 08:23:31 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:23:32 --> Session routines successfully run
DEBUG - 2015-04-13 08:23:32 --> Controller Class Initialized
DEBUG - 2015-04-13 08:23:32 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:23:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:23:32 --> Email Class Initialized
DEBUG - 2015-04-13 08:23:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:23:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:23:32 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:23:32 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:32 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:23:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:23:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 08:23:34 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:23:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:23:34 --> URI Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Router Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Output Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Security Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Input Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:23:34 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Language Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Config Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Loader Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:23:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:23:34 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Session Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:23:34 --> Session routines successfully run
DEBUG - 2015-04-13 08:23:34 --> Controller Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:23:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:23:34 --> Email Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:23:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:23:34 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:23:34 --> Model Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:23:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:23:34 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 08:23:34 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:23:35 --> Final output sent to browser
DEBUG - 2015-04-13 08:23:35 --> Total execution time: 0.8350
DEBUG - 2015-04-13 08:27:13 --> Config Class Initialized
DEBUG - 2015-04-13 08:27:13 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:27:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:27:14 --> URI Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Router Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Output Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Security Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Input Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:27:14 --> Language Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Language Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Config Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Loader Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:27:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:27:14 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Session Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:27:14 --> Session routines successfully run
DEBUG - 2015-04-13 08:27:14 --> Controller Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:27:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:27:14 --> Email Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:27:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:27:14 --> Model Class Initialized
DEBUG - 2015-04-13 08:27:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:27:14 --> Model Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:27:14 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:27:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:27:51 --> Config Class Initialized
DEBUG - 2015-04-13 08:27:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:27:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:27:51 --> URI Class Initialized
DEBUG - 2015-04-13 08:27:51 --> Router Class Initialized
ERROR - 2015-04-13 08:27:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:28:01 --> Config Class Initialized
DEBUG - 2015-04-13 08:28:01 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:28:01 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:28:01 --> URI Class Initialized
DEBUG - 2015-04-13 08:28:01 --> Router Class Initialized
ERROR - 2015-04-13 08:28:01 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:28:20 --> Config Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:28:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:28:20 --> URI Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Router Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Output Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Security Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Input Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:28:20 --> Language Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Language Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Config Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Loader Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:28:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:28:20 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Session Class Initialized
DEBUG - 2015-04-13 08:28:20 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:28:20 --> Session routines successfully run
DEBUG - 2015-04-13 08:28:21 --> Controller Class Initialized
DEBUG - 2015-04-13 08:28:21 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:28:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:28:21 --> Email Class Initialized
DEBUG - 2015-04-13 08:28:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:28:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:28:21 --> Model Class Initialized
DEBUG - 2015-04-13 08:28:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:28:21 --> Model Class Initialized
DEBUG - 2015-04-13 08:28:21 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:28:21 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:28:21 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:29:12 --> Config Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:29:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:29:12 --> URI Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Router Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Output Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Security Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Input Class Initialized
DEBUG - 2015-04-13 08:29:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:29:13 --> Language Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Language Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Config Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Loader Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:29:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:29:13 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Session Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:29:13 --> Session routines successfully run
DEBUG - 2015-04-13 08:29:13 --> Controller Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:29:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:29:13 --> Email Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:29:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:29:13 --> Model Class Initialized
DEBUG - 2015-04-13 08:29:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:29:13 --> Model Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:29:13 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:29:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:29:38 --> Config Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:29:38 --> URI Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Router Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Output Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Security Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Input Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:29:38 --> Language Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Language Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Config Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Loader Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:29:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:29:38 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Session Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:29:38 --> Session routines successfully run
DEBUG - 2015-04-13 08:29:38 --> Controller Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:29:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:29:38 --> Email Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:29:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:29:38 --> Model Class Initialized
DEBUG - 2015-04-13 08:29:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:29:38 --> Model Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:29:38 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:29:38 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:37:45 --> Config Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:37:45 --> URI Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Router Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Output Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Security Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Input Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:37:45 --> Language Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Language Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Config Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Loader Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:37:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:37:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:37:45 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:37:45 --> Session Class Initialized
DEBUG - 2015-04-13 08:37:46 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:37:46 --> Session routines successfully run
DEBUG - 2015-04-13 08:37:46 --> Controller Class Initialized
DEBUG - 2015-04-13 08:37:46 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:37:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:37:46 --> Email Class Initialized
DEBUG - 2015-04-13 08:37:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:37:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:37:46 --> Model Class Initialized
DEBUG - 2015-04-13 08:37:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:37:46 --> Model Class Initialized
DEBUG - 2015-04-13 08:37:46 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:37:46 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:37:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:38:22 --> Config Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:38:22 --> URI Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Router Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Output Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Security Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Input Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:38:22 --> Language Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Language Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Config Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Loader Class Initialized
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:38:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:38:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:38:22 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Session Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:38:23 --> Session routines successfully run
DEBUG - 2015-04-13 08:38:23 --> Controller Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:38:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:38:23 --> Email Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:38:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:38:23 --> Model Class Initialized
DEBUG - 2015-04-13 08:38:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:38:23 --> Model Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:38:23 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:38:23 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:38:37 --> Config Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:38:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:38:37 --> URI Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Router Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Output Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Security Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Input Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:38:37 --> Language Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Language Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Config Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Loader Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:38:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:38:37 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Session Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:38:37 --> Session routines successfully run
DEBUG - 2015-04-13 08:38:37 --> Controller Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:38:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:38:37 --> Email Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:38:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:38:37 --> Model Class Initialized
DEBUG - 2015-04-13 08:38:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:38:37 --> Model Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:38:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:38:38 --> Config Class Initialized
DEBUG - 2015-04-13 08:38:38 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:38:38 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:38:38 --> URI Class Initialized
DEBUG - 2015-04-13 08:38:38 --> Router Class Initialized
ERROR - 2015-04-13 08:38:38 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:40:47 --> Config Class Initialized
DEBUG - 2015-04-13 08:40:47 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:40:47 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:40:47 --> URI Class Initialized
DEBUG - 2015-04-13 08:40:47 --> Router Class Initialized
ERROR - 2015-04-13 08:40:47 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:40:58 --> Config Class Initialized
DEBUG - 2015-04-13 08:40:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:40:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:40:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:40:58 --> URI Class Initialized
DEBUG - 2015-04-13 08:40:58 --> Router Class Initialized
ERROR - 2015-04-13 08:40:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:41:37 --> Config Class Initialized
DEBUG - 2015-04-13 08:41:37 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:41:37 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:41:37 --> URI Class Initialized
DEBUG - 2015-04-13 08:41:37 --> Router Class Initialized
ERROR - 2015-04-13 08:41:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:42:00 --> Config Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:42:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:42:00 --> URI Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Router Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Output Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Security Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Input Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:42:00 --> Language Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Language Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Config Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Loader Class Initialized
DEBUG - 2015-04-13 08:42:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:42:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:42:01 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Session Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:42:01 --> Session routines successfully run
DEBUG - 2015-04-13 08:42:01 --> Controller Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:42:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:42:01 --> Email Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:42:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:42:01 --> Model Class Initialized
DEBUG - 2015-04-13 08:42:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:42:01 --> Model Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:42:01 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 293
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 296
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 302
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 308
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 315
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:42:01 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:42:02 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:42:02 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:42:02 --> Final output sent to browser
DEBUG - 2015-04-13 08:42:02 --> Total execution time: 1.3781
DEBUG - 2015-04-13 08:42:43 --> Config Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:42:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:42:43 --> URI Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Router Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Output Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Security Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Input Class Initialized
DEBUG - 2015-04-13 08:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:42:44 --> Language Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Language Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Config Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Loader Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:42:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:42:44 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Session Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:42:44 --> Session routines successfully run
DEBUG - 2015-04-13 08:42:44 --> Controller Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:42:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:42:44 --> Email Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:42:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:42:44 --> Model Class Initialized
DEBUG - 2015-04-13 08:42:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:42:44 --> Model Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:42:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 293
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 296
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 302
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 308
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 315
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:42:44 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:42:45 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:42:45 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:42:45 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:42:45 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:42:45 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:42:45 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:42:45 --> Final output sent to browser
DEBUG - 2015-04-13 08:42:45 --> Total execution time: 1.3351
DEBUG - 2015-04-13 08:42:57 --> Config Class Initialized
DEBUG - 2015-04-13 08:42:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:42:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:42:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:42:57 --> URI Class Initialized
DEBUG - 2015-04-13 08:42:57 --> Router Class Initialized
ERROR - 2015-04-13 08:42:57 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:45:10 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:45:10 --> URI Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Router Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Output Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Security Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Input Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:45:10 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Loader Class Initialized
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:45:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:45:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:45:10 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:45:11 --> Session Class Initialized
DEBUG - 2015-04-13 08:45:11 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:45:11 --> Session routines successfully run
DEBUG - 2015-04-13 08:45:11 --> Controller Class Initialized
DEBUG - 2015-04-13 08:45:11 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:45:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:45:11 --> Email Class Initialized
DEBUG - 2015-04-13 08:45:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:45:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:45:11 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:45:11 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:11 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:45:12 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 293
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 296
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 302
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 308
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 315
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:45:12 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:45:12 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:45:12 --> Final output sent to browser
DEBUG - 2015-04-13 08:45:12 --> Total execution time: 2.5591
DEBUG - 2015-04-13 08:45:42 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:42 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:45:42 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:45:43 --> URI Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Router Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Output Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Security Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Input Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:45:43 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Loader Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:45:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:45:43 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Session Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:45:43 --> Session routines successfully run
DEBUG - 2015-04-13 08:45:43 --> Controller Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:45:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:45:43 --> Email Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:45:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:45:43 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:45:43 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:45:43 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 293
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 296
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 302
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 308
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 315
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:43 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:45:44 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:45:44 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:45:44 --> Final output sent to browser
DEBUG - 2015-04-13 08:45:44 --> Total execution time: 1.2241
DEBUG - 2015-04-13 08:45:51 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:45:51 --> URI Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Router Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Output Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Security Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Input Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:45:51 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Language Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Config Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Loader Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:45:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:45:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Session Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:45:51 --> Session routines successfully run
DEBUG - 2015-04-13 08:45:51 --> Controller Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:45:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:45:51 --> Email Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:45:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:45:51 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:45:51 --> Model Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:45:51 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 293
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 296
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 302
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 308
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 315
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:45:52 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:45:52 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:45:52 --> Final output sent to browser
DEBUG - 2015-04-13 08:45:52 --> Total execution time: 1.1181
DEBUG - 2015-04-13 08:46:10 --> Config Class Initialized
DEBUG - 2015-04-13 08:46:10 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:46:10 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:46:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:46:10 --> URI Class Initialized
DEBUG - 2015-04-13 08:46:10 --> Router Class Initialized
ERROR - 2015-04-13 08:46:10 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:49:06 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:06 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:49:06 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:49:06 --> URI Class Initialized
DEBUG - 2015-04-13 08:49:06 --> Router Class Initialized
ERROR - 2015-04-13 08:49:06 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:49:14 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:14 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:49:14 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:49:14 --> URI Class Initialized
DEBUG - 2015-04-13 08:49:14 --> Router Class Initialized
DEBUG - 2015-04-13 08:49:14 --> Output Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Security Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Input Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:49:15 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Loader Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:49:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:49:15 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Session Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:49:15 --> Session routines successfully run
DEBUG - 2015-04-13 08:49:15 --> Controller Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:49:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:49:15 --> Email Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:49:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:49:15 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:49:15 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:49:15 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:49:15 --> URI Class Initialized
DEBUG - 2015-04-13 08:49:15 --> Router Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Output Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Security Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Input Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:49:16 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Loader Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:49:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:49:16 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Session Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:49:16 --> Session routines successfully run
DEBUG - 2015-04-13 08:49:16 --> Controller Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:49:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:49:16 --> Email Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:49:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:49:16 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:49:16 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:49:16 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:49:16 --> File loaded: application/views/../modules_core/login/views/forgot_password.php
DEBUG - 2015-04-13 08:49:16 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:49:16 --> Final output sent to browser
DEBUG - 2015-04-13 08:49:16 --> Total execution time: 1.0201
DEBUG - 2015-04-13 08:49:58 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:49:58 --> URI Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Router Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Output Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Security Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Input Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:49:58 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Loader Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:49:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:49:58 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Session Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:49:58 --> Session routines successfully run
DEBUG - 2015-04-13 08:49:58 --> Controller Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:49:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:49:58 --> Email Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:49:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:49:58 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:49:58 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:49:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:49:58 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:49:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:49:59 --> URI Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Router Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Output Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Security Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Input Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:49:59 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Language Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Config Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Loader Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:49:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:49:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Session Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:49:59 --> Session routines successfully run
DEBUG - 2015-04-13 08:49:59 --> Controller Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:49:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:49:59 --> Email Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:49:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:49:59 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:49:59 --> Model Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:49:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:49:59 --> File loaded: application/views/../modules_core/login/views/forgot_password.php
DEBUG - 2015-04-13 08:49:59 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:49:59 --> Final output sent to browser
DEBUG - 2015-04-13 08:50:00 --> Total execution time: 0.9981
DEBUG - 2015-04-13 08:50:23 --> Config Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:50:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:50:23 --> URI Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Router Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Output Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Security Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Input Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:50:23 --> Language Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Language Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Config Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Loader Class Initialized
DEBUG - 2015-04-13 08:50:23 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:50:23 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:50:23 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:50:23 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:50:24 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:50:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:50:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:50:24 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Session Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:50:24 --> Session routines successfully run
DEBUG - 2015-04-13 08:50:24 --> Controller Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:50:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:50:24 --> Email Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:50:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:50:24 --> Model Class Initialized
DEBUG - 2015-04-13 08:50:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:50:24 --> Model Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:50:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:50:53 --> Config Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:50:53 --> URI Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Router Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Output Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Security Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Input Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:50:53 --> Language Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Language Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Config Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Loader Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:50:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:50:53 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Session Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:50:53 --> Session routines successfully run
DEBUG - 2015-04-13 08:50:53 --> Controller Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:50:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:50:53 --> Email Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:50:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:50:53 --> Model Class Initialized
DEBUG - 2015-04-13 08:50:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:50:53 --> Model Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:50:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:51:07 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:07 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:51:07 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:51:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:51:07 --> URI Class Initialized
DEBUG - 2015-04-13 08:51:07 --> Router Class Initialized
DEBUG - 2015-04-13 08:51:07 --> Output Class Initialized
DEBUG - 2015-04-13 08:51:07 --> Security Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Input Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:51:08 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Loader Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:51:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:51:08 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Session Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:51:08 --> Session routines successfully run
DEBUG - 2015-04-13 08:51:08 --> Controller Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:51:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:51:08 --> Email Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:51:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:51:08 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:51:08 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:51:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:51:16 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:16 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:51:16 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:51:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:51:17 --> URI Class Initialized
DEBUG - 2015-04-13 08:51:17 --> Router Class Initialized
ERROR - 2015-04-13 08:51:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 08:51:22 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:51:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:51:22 --> URI Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Router Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Output Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Security Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Input Class Initialized
DEBUG - 2015-04-13 08:51:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:51:22 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Loader Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:51:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:51:23 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Session Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:51:23 --> Session routines successfully run
DEBUG - 2015-04-13 08:51:23 --> Controller Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:51:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:51:23 --> Email Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:51:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:51:23 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:51:23 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:51:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:51:38 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:38 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:51:38 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:51:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:51:38 --> URI Class Initialized
DEBUG - 2015-04-13 08:51:38 --> Router Class Initialized
DEBUG - 2015-04-13 08:51:38 --> Output Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Security Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Input Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:51:39 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Language Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Config Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Loader Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:51:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:51:39 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Session Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:51:39 --> Session routines successfully run
DEBUG - 2015-04-13 08:51:39 --> Controller Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:51:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:51:39 --> Email Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:51:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:51:39 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:51:39 --> Model Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:51:39 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-13 08:51:39 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:39 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 292
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 294
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 295
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 301
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 307
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 313
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 314
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: message C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 3
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: code C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 5
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: min_password_length C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 8
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: new_password C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 9
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: new_password_confirm C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 14
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: user_id C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 17
ERROR - 2015-04-13 08:51:40 --> Severity: Notice  --> Undefined variable: csrf C:\xampp\htdocs\ecampaign247\application\modules_core\login\views\reset_password.php 18
DEBUG - 2015-04-13 08:51:40 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:51:40 --> Final output sent to browser
DEBUG - 2015-04-13 08:51:40 --> Total execution time: 1.6891
DEBUG - 2015-04-13 08:54:51 --> Config Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:54:51 --> URI Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Router Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Output Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Security Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Input Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:54:51 --> Language Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Language Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Config Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Loader Class Initialized
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:54:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:54:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:54:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Session Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:54:52 --> Session routines successfully run
DEBUG - 2015-04-13 08:54:52 --> Controller Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:54:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:54:52 --> Email Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:54:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:54:52 --> Model Class Initialized
DEBUG - 2015-04-13 08:54:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:54:52 --> Model Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:54:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:54:52 --> File loaded: application/modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:54:52 --> Final output sent to browser
DEBUG - 2015-04-13 08:54:52 --> Total execution time: 0.8030
DEBUG - 2015-04-13 08:55:52 --> Config Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:55:52 --> URI Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Router Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Output Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Security Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Input Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:55:52 --> Language Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Language Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Config Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Loader Class Initialized
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:55:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:55:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:55:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Session Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:55:53 --> Session routines successfully run
DEBUG - 2015-04-13 08:55:53 --> Controller Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:55:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:55:53 --> Email Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:55:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:55:53 --> Model Class Initialized
DEBUG - 2015-04-13 08:55:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:55:53 --> Model Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:55:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:55:53 --> File loaded: application/views/../modules_core/login/views/reset_password.php
ERROR - 2015-04-13 08:55:53 --> Severity: Notice  --> Undefined variable: title C:\xampp\htdocs\ecampaign247\application\views\templates\guest.php 5
ERROR - 2015-04-13 08:55:53 --> Severity: Notice  --> Undefined variable: pageMetaDescription C:\xampp\htdocs\ecampaign247\application\views\templates\guest.php 7
DEBUG - 2015-04-13 08:55:53 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:55:53 --> Final output sent to browser
DEBUG - 2015-04-13 08:55:53 --> Total execution time: 0.9040
DEBUG - 2015-04-13 08:57:01 --> Config Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Hooks Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Utf8 Class Initialized
DEBUG - 2015-04-13 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 08:57:01 --> URI Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Router Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Output Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Security Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Input Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 08:57:01 --> Language Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Language Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Config Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Loader Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: url_helper
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: language_helper
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: user_helper
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: date_helper
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 08:57:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 08:57:01 --> Database Driver Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Session Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: string_helper
DEBUG - 2015-04-13 08:57:01 --> Session routines successfully run
DEBUG - 2015-04-13 08:57:01 --> Controller Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 08:57:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 08:57:01 --> Email Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 08:57:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 08:57:01 --> Model Class Initialized
DEBUG - 2015-04-13 08:57:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 08:57:01 --> Model Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 08:57:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 08:57:02 --> File loaded: application/views/../modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 08:57:02 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 08:57:02 --> Final output sent to browser
DEBUG - 2015-04-13 08:57:02 --> Total execution time: 0.9061
DEBUG - 2015-04-13 09:01:56 --> Config Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:01:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:01:56 --> URI Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Router Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Output Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Security Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Input Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:01:56 --> Language Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Language Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Config Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Loader Class Initialized
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:01:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:01:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:01:57 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Session Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:01:57 --> Session routines successfully run
DEBUG - 2015-04-13 09:01:57 --> Controller Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:01:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:01:57 --> Email Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:01:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:01:57 --> Model Class Initialized
DEBUG - 2015-04-13 09:01:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:01:57 --> Model Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:01:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:01:57 --> File loaded: application/views/../modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 09:01:57 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 09:01:57 --> Final output sent to browser
DEBUG - 2015-04-13 09:01:57 --> Total execution time: 0.9000
DEBUG - 2015-04-13 09:02:57 --> Config Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:02:57 --> URI Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Router Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Output Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Security Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Input Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:02:57 --> Language Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Language Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Config Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Loader Class Initialized
DEBUG - 2015-04-13 09:02:57 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:02:57 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:02:57 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:02:57 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:02:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:02:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:02:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:02:58 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Session Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:02:58 --> Session routines successfully run
DEBUG - 2015-04-13 09:02:58 --> Controller Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:02:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:02:58 --> Email Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:02:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:02:58 --> Model Class Initialized
DEBUG - 2015-04-13 09:02:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:02:58 --> Model Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:02:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:02:58 --> File loaded: application/views/../modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 09:02:58 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 09:02:58 --> Final output sent to browser
DEBUG - 2015-04-13 09:02:58 --> Total execution time: 0.8730
DEBUG - 2015-04-13 09:05:21 --> Config Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:05:21 --> URI Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Router Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Output Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Security Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Input Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:05:21 --> Language Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Language Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Config Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Loader Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:05:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:05:21 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Session Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:05:21 --> Session routines successfully run
DEBUG - 2015-04-13 09:05:21 --> Controller Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:05:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:05:21 --> Email Class Initialized
DEBUG - 2015-04-13 09:05:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:05:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:05:21 --> Model Class Initialized
DEBUG - 2015-04-13 09:05:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:05:21 --> Model Class Initialized
DEBUG - 2015-04-13 09:05:22 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:05:22 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:05:22 --> File loaded: application/views/../modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 09:05:22 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 09:05:22 --> Final output sent to browser
DEBUG - 2015-04-13 09:05:22 --> Total execution time: 0.8260
DEBUG - 2015-04-13 09:06:24 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:06:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:06:24 --> URI Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Router Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Output Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Security Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Input Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:06:24 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Loader Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:06:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:06:24 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Session Class Initialized
DEBUG - 2015-04-13 09:06:24 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:06:25 --> Session routines successfully run
DEBUG - 2015-04-13 09:06:25 --> Controller Class Initialized
DEBUG - 2015-04-13 09:06:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:06:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:06:25 --> Email Class Initialized
DEBUG - 2015-04-13 09:06:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:06:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:06:25 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:06:25 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:25 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:06:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:06:25 --> File loaded: application/views/../modules_core/login/views/reset_password.php
DEBUG - 2015-04-13 09:06:25 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 09:06:25 --> Final output sent to browser
DEBUG - 2015-04-13 09:06:25 --> Total execution time: 1.0911
DEBUG - 2015-04-13 09:06:51 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:06:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:06:51 --> URI Class Initialized
DEBUG - 2015-04-13 09:06:51 --> Router Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Output Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Security Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Input Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:06:52 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Loader Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:06:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:06:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Session Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:06:52 --> Session routines successfully run
DEBUG - 2015-04-13 09:06:52 --> Controller Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:06:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:06:52 --> Email Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:06:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:06:52 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:06:52 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:06:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:06:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 09:06:53 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:06:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:06:53 --> URI Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Router Class Initialized
DEBUG - 2015-04-13 09:06:53 --> No URI present. Default controller set.
DEBUG - 2015-04-13 09:06:53 --> Output Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Security Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Input Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:06:53 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Language Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Config Class Initialized
DEBUG - 2015-04-13 09:06:53 --> Loader Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:06:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:06:54 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Session Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:06:54 --> Session routines successfully run
DEBUG - 2015-04-13 09:06:54 --> Controller Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:06:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:06:54 --> Email Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:06:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:06:54 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:06:54 --> Model Class Initialized
DEBUG - 2015-04-13 09:06:54 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:06:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:06:55 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 09:06:55 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 09:06:55 --> Final output sent to browser
DEBUG - 2015-04-13 09:06:55 --> Total execution time: 1.5851
DEBUG - 2015-04-13 09:07:59 --> Config Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:07:59 --> URI Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Router Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Output Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Security Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Input Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:07:59 --> Language Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Language Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Config Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Loader Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:07:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:07:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Session Class Initialized
DEBUG - 2015-04-13 09:07:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:07:59 --> Session routines successfully run
DEBUG - 2015-04-13 09:08:00 --> Controller Class Initialized
DEBUG - 2015-04-13 09:08:00 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:08:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:08:00 --> Email Class Initialized
DEBUG - 2015-04-13 09:08:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:08:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:08:00 --> Model Class Initialized
DEBUG - 2015-04-13 09:08:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:08:00 --> Model Class Initialized
DEBUG - 2015-04-13 09:08:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:08:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:08:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 09:08:01 --> Config Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:08:01 --> URI Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Router Class Initialized
DEBUG - 2015-04-13 09:08:01 --> No URI present. Default controller set.
DEBUG - 2015-04-13 09:08:01 --> Output Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Security Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Input Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:08:01 --> Language Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Language Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Config Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Loader Class Initialized
DEBUG - 2015-04-13 09:08:01 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:08:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:08:01 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:08:01 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:08:02 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:08:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:08:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:08:02 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Session Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:08:02 --> Session routines successfully run
DEBUG - 2015-04-13 09:08:02 --> Controller Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:08:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:08:02 --> Email Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:08:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:08:02 --> Model Class Initialized
DEBUG - 2015-04-13 09:08:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:08:02 --> Model Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:08:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:08:03 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 09:08:03 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 09:08:03 --> Final output sent to browser
DEBUG - 2015-04-13 09:08:03 --> Total execution time: 2.1561
DEBUG - 2015-04-13 09:08:04 --> Config Class Initialized
DEBUG - 2015-04-13 09:08:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:08:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:08:04 --> URI Class Initialized
DEBUG - 2015-04-13 09:08:04 --> Router Class Initialized
ERROR - 2015-04-13 09:08:04 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 09:13:27 --> Config Class Initialized
DEBUG - 2015-04-13 09:13:27 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:13:27 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:13:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:13:27 --> URI Class Initialized
DEBUG - 2015-04-13 09:13:27 --> Router Class Initialized
ERROR - 2015-04-13 09:13:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 09:13:42 --> Config Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:13:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:13:42 --> URI Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Router Class Initialized
DEBUG - 2015-04-13 09:13:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-13 09:13:42 --> Output Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Security Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Input Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:13:42 --> Language Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Language Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Config Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Loader Class Initialized
DEBUG - 2015-04-13 09:13:42 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:13:42 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:13:42 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:13:43 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:13:43 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:13:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:13:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:13:43 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:13:44 --> Session Class Initialized
DEBUG - 2015-04-13 09:13:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:13:44 --> Session routines successfully run
DEBUG - 2015-04-13 09:13:44 --> Controller Class Initialized
DEBUG - 2015-04-13 09:13:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-13 09:13:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:13:44 --> Email Class Initialized
DEBUG - 2015-04-13 09:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:13:44 --> Model Class Initialized
DEBUG - 2015-04-13 09:13:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:13:44 --> Model Class Initialized
DEBUG - 2015-04-13 09:13:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:13:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-13 09:13:44 --> Model Class Initialized
DEBUG - 2015-04-13 09:13:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-13 09:13:44 --> Model Class Initialized
DEBUG - 2015-04-13 09:13:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-13 09:13:44 --> Model Class Initialized
ERROR - 2015-04-13 09:13:44 --> 404 Page Not Found --> sites/user
DEBUG - 2015-04-13 09:13:59 --> Config Class Initialized
DEBUG - 2015-04-13 09:13:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:13:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:14:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:14:00 --> URI Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Router Class Initialized
DEBUG - 2015-04-13 09:14:00 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 09:14:00 --> Output Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Security Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Input Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:14:00 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Config Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Loader Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:14:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:14:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Session Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:14:00 --> Session routines successfully run
DEBUG - 2015-04-13 09:14:00 --> Controller Class Initialized
DEBUG - 2015-04-13 09:14:00 --> User MX_Controller Initialized
DEBUG - 2015-04-13 09:14:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:14:00 --> Email Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:14:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:14:00 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 09:14:00 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 09:14:00 --> Final output sent to browser
DEBUG - 2015-04-13 09:14:00 --> Total execution time: 0.8490
DEBUG - 2015-04-13 09:14:01 --> Config Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:14:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:14:01 --> URI Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Router Class Initialized
DEBUG - 2015-04-13 09:14:01 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 09:14:01 --> Output Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Security Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Input Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:14:01 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Config Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Loader Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:14:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:14:01 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Session Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:14:01 --> Session routines successfully run
DEBUG - 2015-04-13 09:14:01 --> Controller Class Initialized
DEBUG - 2015-04-13 09:14:01 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 09:14:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:14:01 --> Email Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:14:02 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:14:02 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Config Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:14:02 --> URI Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Router Class Initialized
DEBUG - 2015-04-13 09:14:02 --> No URI present. Default controller set.
DEBUG - 2015-04-13 09:14:02 --> Output Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Security Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Input Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:14:02 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Language Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Config Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Loader Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:14:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:14:02 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Session Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:14:02 --> Session routines successfully run
DEBUG - 2015-04-13 09:14:02 --> Controller Class Initialized
DEBUG - 2015-04-13 09:14:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 09:14:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:14:03 --> Email Class Initialized
DEBUG - 2015-04-13 09:14:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:14:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:14:03 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:14:03 --> Model Class Initialized
DEBUG - 2015-04-13 09:14:03 --> Form Validation Class Initialized
DEBUG - 2015-04-13 09:14:03 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 09:14:03 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 09:14:03 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 09:14:03 --> Final output sent to browser
DEBUG - 2015-04-13 09:14:03 --> Total execution time: 1.0861
DEBUG - 2015-04-13 09:15:31 --> Config Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:15:31 --> URI Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Router Class Initialized
DEBUG - 2015-04-13 09:15:31 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 09:15:31 --> Output Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Security Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Input Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:15:31 --> Language Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Language Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Config Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Loader Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:15:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:15:31 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Session Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:15:31 --> Session routines successfully run
DEBUG - 2015-04-13 09:15:31 --> Controller Class Initialized
DEBUG - 2015-04-13 09:15:31 --> User MX_Controller Initialized
DEBUG - 2015-04-13 09:15:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:15:31 --> Email Class Initialized
DEBUG - 2015-04-13 09:15:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:15:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:15:31 --> Model Class Initialized
DEBUG - 2015-04-13 09:15:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:15:31 --> Model Class Initialized
DEBUG - 2015-04-13 09:15:32 --> Form Validation Class Initialized
ERROR - 2015-04-13 09:15:32 --> Non-existent class: Grid
ERROR - 2015-04-13 09:15:32 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php:569) C:\xampp\htdocs\ecampaign247\system\core\Common.php 441
DEBUG - 2015-04-13 09:16:40 --> Config Class Initialized
DEBUG - 2015-04-13 09:16:40 --> Hooks Class Initialized
DEBUG - 2015-04-13 09:16:40 --> Utf8 Class Initialized
DEBUG - 2015-04-13 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 09:16:41 --> URI Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Router Class Initialized
DEBUG - 2015-04-13 09:16:41 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 09:16:41 --> Output Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Security Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Input Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 09:16:41 --> Language Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Language Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Config Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Loader Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: url_helper
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: form_helper
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: language_helper
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: user_helper
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: date_helper
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 09:16:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 09:16:41 --> Database Driver Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Session Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: string_helper
DEBUG - 2015-04-13 09:16:41 --> Session routines successfully run
DEBUG - 2015-04-13 09:16:41 --> Controller Class Initialized
DEBUG - 2015-04-13 09:16:41 --> User MX_Controller Initialized
DEBUG - 2015-04-13 09:16:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 09:16:41 --> Email Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 09:16:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 09:16:41 --> Model Class Initialized
DEBUG - 2015-04-13 09:16:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 09:16:41 --> Model Class Initialized
DEBUG - 2015-04-13 09:16:41 --> Form Validation Class Initialized
ERROR - 2015-04-13 09:16:41 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 09:16:41 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:16:48 --> Config Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:16:48 --> URI Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Router Class Initialized
DEBUG - 2015-04-13 12:16:48 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:16:48 --> Output Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Security Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Input Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:16:48 --> Language Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Language Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Config Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Loader Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:16:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:16:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Session Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:16:48 --> A session cookie was not found.
DEBUG - 2015-04-13 12:16:48 --> Session routines successfully run
DEBUG - 2015-04-13 12:16:48 --> Controller Class Initialized
DEBUG - 2015-04-13 12:16:48 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:16:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:16:48 --> Email Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:16:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:16:48 --> Model Class Initialized
DEBUG - 2015-04-13 12:16:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:16:48 --> Model Class Initialized
DEBUG - 2015-04-13 12:16:48 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:16:49 --> URI Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Router Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Output Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Security Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Input Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:16:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Loader Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:16:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:16:49 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Session Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:16:49 --> Session routines successfully run
DEBUG - 2015-04-13 12:16:49 --> Controller Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:16:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:16:49 --> Email Class Initialized
DEBUG - 2015-04-13 12:16:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:16:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:16:50 --> Model Class Initialized
DEBUG - 2015-04-13 12:16:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:16:50 --> Model Class Initialized
DEBUG - 2015-04-13 12:16:50 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:16:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:16:50 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 12:16:50 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 12:16:50 --> Final output sent to browser
DEBUG - 2015-04-13 12:16:50 --> Total execution time: 0.8130
DEBUG - 2015-04-13 12:17:00 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:17:00 --> URI Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Router Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Output Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Security Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Input Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:17:00 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Loader Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:17:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:17:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Session Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:17:00 --> Session routines successfully run
DEBUG - 2015-04-13 12:17:00 --> Controller Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:17:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:17:00 --> Email Class Initialized
DEBUG - 2015-04-13 12:17:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:17:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:17:01 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:17:01 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:17:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 12:17:01 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:17:01 --> URI Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Router Class Initialized
DEBUG - 2015-04-13 12:17:01 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:17:01 --> Output Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Security Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Input Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:17:01 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Loader Class Initialized
DEBUG - 2015-04-13 12:17:01 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:17:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:17:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:17:02 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Session Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:17:02 --> Session routines successfully run
DEBUG - 2015-04-13 12:17:02 --> Controller Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:17:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:17:02 --> Email Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:17:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:17:02 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:17:02 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:17:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:17:02 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:17:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:17:02 --> Final output sent to browser
DEBUG - 2015-04-13 12:17:02 --> Total execution time: 1.0401
DEBUG - 2015-04-13 12:17:03 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:03 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:17:03 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:17:03 --> URI Class Initialized
DEBUG - 2015-04-13 12:17:03 --> Router Class Initialized
ERROR - 2015-04-13 12:17:03 --> 404 Page Not Found --> 
DEBUG - 2015-04-13 12:17:14 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:17:14 --> URI Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Router Class Initialized
DEBUG - 2015-04-13 12:17:14 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:17:14 --> Output Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Security Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Input Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:17:14 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Language Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Config Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Loader Class Initialized
DEBUG - 2015-04-13 12:17:14 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:17:14 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:17:14 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:17:14 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:17:15 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:17:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:17:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:17:15 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:17:16 --> Session Class Initialized
DEBUG - 2015-04-13 12:17:16 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:17:16 --> Session routines successfully run
DEBUG - 2015-04-13 12:17:16 --> Controller Class Initialized
DEBUG - 2015-04-13 12:17:16 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:17:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:17:16 --> Email Class Initialized
DEBUG - 2015-04-13 12:17:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:17:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:17:16 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:17:16 --> Model Class Initialized
DEBUG - 2015-04-13 12:17:16 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:17:16 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:17:16 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:22:48 --> Config Class Initialized
DEBUG - 2015-04-13 12:22:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:22:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:22:48 --> URI Class Initialized
DEBUG - 2015-04-13 12:22:48 --> Router Class Initialized
DEBUG - 2015-04-13 12:22:48 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:22:48 --> Output Class Initialized
DEBUG - 2015-04-13 12:22:48 --> Security Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Input Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:22:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Loader Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:22:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:22:49 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Session Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:22:49 --> Session routines successfully run
DEBUG - 2015-04-13 12:22:49 --> Controller Class Initialized
DEBUG - 2015-04-13 12:22:49 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:22:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:22:49 --> Email Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:22:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:22:49 --> Model Class Initialized
DEBUG - 2015-04-13 12:22:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:22:49 --> Model Class Initialized
DEBUG - 2015-04-13 12:22:49 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:22:49 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:22:49 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:22:52 --> Config Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:22:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:22:52 --> URI Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Router Class Initialized
DEBUG - 2015-04-13 12:22:52 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:22:52 --> Output Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Security Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Input Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:22:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Config Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Loader Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:22:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:22:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Session Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:22:52 --> Session routines successfully run
DEBUG - 2015-04-13 12:22:52 --> Controller Class Initialized
DEBUG - 2015-04-13 12:22:52 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:22:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:22:52 --> Email Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:22:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:22:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:22:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:22:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:22:52 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:22:52 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:22:52 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:26:36 --> Config Class Initialized
DEBUG - 2015-04-13 12:26:36 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:26:36 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:26:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:26:37 --> URI Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Router Class Initialized
DEBUG - 2015-04-13 12:26:37 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:26:37 --> Output Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Security Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Input Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:26:37 --> Language Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Language Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Config Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Loader Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:26:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:26:37 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Session Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:26:37 --> Session routines successfully run
DEBUG - 2015-04-13 12:26:37 --> Controller Class Initialized
DEBUG - 2015-04-13 12:26:37 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:26:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:26:37 --> Email Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:26:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:26:37 --> Model Class Initialized
DEBUG - 2015-04-13 12:26:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:26:37 --> Model Class Initialized
DEBUG - 2015-04-13 12:26:37 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:26:37 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:26:37 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:27:32 --> Config Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:27:32 --> URI Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Router Class Initialized
DEBUG - 2015-04-13 12:27:32 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:27:32 --> Output Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Security Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Input Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:27:32 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Config Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Loader Class Initialized
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:27:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:27:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:27:32 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:27:33 --> Session Class Initialized
DEBUG - 2015-04-13 12:27:33 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:27:33 --> Session routines successfully run
DEBUG - 2015-04-13 12:27:33 --> Controller Class Initialized
DEBUG - 2015-04-13 12:27:33 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:27:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:27:33 --> Email Class Initialized
DEBUG - 2015-04-13 12:27:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:27:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:27:33 --> Model Class Initialized
DEBUG - 2015-04-13 12:27:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:27:33 --> Model Class Initialized
DEBUG - 2015-04-13 12:27:33 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:27:33 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:27:33 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:27:52 --> Config Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:27:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:27:52 --> URI Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Router Class Initialized
DEBUG - 2015-04-13 12:27:52 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:27:52 --> Output Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Security Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Input Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:27:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Config Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Loader Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:27:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:27:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Session Class Initialized
DEBUG - 2015-04-13 12:27:52 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:27:53 --> Session routines successfully run
DEBUG - 2015-04-13 12:27:53 --> Controller Class Initialized
DEBUG - 2015-04-13 12:27:53 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:27:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:27:53 --> Email Class Initialized
DEBUG - 2015-04-13 12:27:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:27:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:27:53 --> Model Class Initialized
DEBUG - 2015-04-13 12:27:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:27:53 --> Model Class Initialized
DEBUG - 2015-04-13 12:27:53 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:27:53 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:27:53 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:27:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:27:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:27:59 --> URI Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Router Class Initialized
DEBUG - 2015-04-13 12:27:59 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:27:59 --> Output Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Security Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Input Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:27:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:27:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Loader Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:28:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:28:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Session Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:28:00 --> Session routines successfully run
DEBUG - 2015-04-13 12:28:00 --> Controller Class Initialized
DEBUG - 2015-04-13 12:28:00 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:28:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:28:00 --> Email Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:28:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:28:00 --> Model Class Initialized
DEBUG - 2015-04-13 12:28:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:28:00 --> Model Class Initialized
DEBUG - 2015-04-13 12:28:00 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:28:00 --> Severity: Notice  --> Undefined index: cols C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 242
ERROR - 2015-04-13 12:28:00 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:30:00 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:00 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:00 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:30:00 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:00 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:00 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:00 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:00 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:30:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:30:00 --> Email Class Initialized
DEBUG - 2015-04-13 12:30:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:30:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:30:01 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:30:01 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:30:01 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:30:01 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:30:01 --> Final output sent to browser
DEBUG - 2015-04-13 12:30:01 --> Total execution time: 0.7960
DEBUG - 2015-04-13 12:30:02 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:02 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:02 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:02 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:02 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:03 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:30:03 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:03 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:03 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:03 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:03 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:30:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:30:03 --> Email Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:30:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:30:03 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:30:03 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:03 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:04 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:04 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:30:04 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:04 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:04 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:05 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:05 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:30:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:30:05 --> Email Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:30:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:30:05 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:30:05 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:30:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:30:06 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:30:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:30:06 --> Final output sent to browser
DEBUG - 2015-04-13 12:30:06 --> Total execution time: 2.0721
DEBUG - 2015-04-13 12:30:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:56 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:56 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:30:56 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:56 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:56 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:56 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:56 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:30:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:30:56 --> Email Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:30:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:30:56 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:30:56 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:56 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:30:56 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:30:56 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:30:56 --> Final output sent to browser
DEBUG - 2015-04-13 12:30:57 --> Total execution time: 0.8210
DEBUG - 2015-04-13 12:30:57 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:57 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:57 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:30:57 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:57 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:57 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:58 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:58 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:58 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:30:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:30:58 --> Email Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:30:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:30:58 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:30:58 --> Model Class Initialized
DEBUG - 2015-04-13 12:30:58 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:30:59 --> URI Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Router Class Initialized
DEBUG - 2015-04-13 12:30:59 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:30:59 --> Output Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Security Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Input Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:30:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Loader Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:30:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:30:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Session Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:30:59 --> Session routines successfully run
DEBUG - 2015-04-13 12:30:59 --> Controller Class Initialized
DEBUG - 2015-04-13 12:30:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:30:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:31:00 --> Email Class Initialized
DEBUG - 2015-04-13 12:31:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:31:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:31:00 --> Model Class Initialized
DEBUG - 2015-04-13 12:31:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:31:00 --> Model Class Initialized
DEBUG - 2015-04-13 12:31:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:31:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:31:00 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:31:00 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:31:00 --> Final output sent to browser
DEBUG - 2015-04-13 12:31:00 --> Total execution time: 1.1861
DEBUG - 2015-04-13 12:32:04 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:32:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:32:04 --> URI Class Initialized
DEBUG - 2015-04-13 12:32:04 --> Router Class Initialized
DEBUG - 2015-04-13 12:32:04 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:32:04 --> Output Class Initialized
DEBUG - 2015-04-13 12:32:04 --> Security Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Input Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:32:05 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Loader Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:32:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:32:05 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Session Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:32:05 --> Session routines successfully run
DEBUG - 2015-04-13 12:32:05 --> Controller Class Initialized
DEBUG - 2015-04-13 12:32:05 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:32:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:32:05 --> Email Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:32:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:32:05 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:32:05 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:05 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:32:05 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:32:05 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:32:05 --> Final output sent to browser
DEBUG - 2015-04-13 12:32:05 --> Total execution time: 0.9061
DEBUG - 2015-04-13 12:32:06 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:32:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:32:06 --> URI Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Router Class Initialized
DEBUG - 2015-04-13 12:32:06 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:32:06 --> Output Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Security Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Input Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:32:06 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Loader Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:32:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:32:06 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Session Class Initialized
DEBUG - 2015-04-13 12:32:06 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:32:06 --> Session routines successfully run
DEBUG - 2015-04-13 12:32:07 --> Controller Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:32:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:32:07 --> Email Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:32:07 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:32:07 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:32:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:32:07 --> URI Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Router Class Initialized
DEBUG - 2015-04-13 12:32:07 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:32:07 --> Output Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Security Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Input Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:32:07 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Language Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Config Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Loader Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:32:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:32:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:32:07 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:32:07 --> Session Class Initialized
DEBUG - 2015-04-13 12:32:08 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:32:08 --> Session routines successfully run
DEBUG - 2015-04-13 12:32:08 --> Controller Class Initialized
DEBUG - 2015-04-13 12:32:08 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:32:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:32:08 --> Email Class Initialized
DEBUG - 2015-04-13 12:32:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:32:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:32:08 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:32:08 --> Model Class Initialized
DEBUG - 2015-04-13 12:32:08 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:32:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:32:08 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:32:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:32:08 --> Final output sent to browser
DEBUG - 2015-04-13 12:32:08 --> Total execution time: 1.0591
DEBUG - 2015-04-13 12:33:43 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:33:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:33:43 --> URI Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Router Class Initialized
DEBUG - 2015-04-13 12:33:43 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:33:43 --> Output Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Security Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Input Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:33:43 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Loader Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:33:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:33:43 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Session Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:33:43 --> Session routines successfully run
DEBUG - 2015-04-13 12:33:43 --> Controller Class Initialized
DEBUG - 2015-04-13 12:33:43 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:33:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:33:43 --> Email Class Initialized
DEBUG - 2015-04-13 12:33:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:33:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:33:43 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:33:43 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:33:44 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:33:44 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:33:44 --> Final output sent to browser
DEBUG - 2015-04-13 12:33:44 --> Total execution time: 0.8730
DEBUG - 2015-04-13 12:33:44 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:44 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:33:44 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:33:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:33:45 --> URI Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Router Class Initialized
DEBUG - 2015-04-13 12:33:45 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:33:45 --> Output Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Security Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Input Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:33:45 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Loader Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:33:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:33:45 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Session Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:33:45 --> Session routines successfully run
DEBUG - 2015-04-13 12:33:45 --> Controller Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:33:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:33:45 --> Email Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:33:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:33:45 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:33:45 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:45 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:33:46 --> URI Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Router Class Initialized
DEBUG - 2015-04-13 12:33:46 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:33:46 --> Output Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Security Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Input Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:33:46 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Loader Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:33:46 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:33:46 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:33:46 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:33:46 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:33:46 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:33:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:33:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:33:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:33:47 --> URI Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Router Class Initialized
DEBUG - 2015-04-13 12:33:47 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:33:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Output Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Session Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:33:47 --> Security Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Session routines successfully run
DEBUG - 2015-04-13 12:33:47 --> Input Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Controller Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:33:47 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:33:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:33:47 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Email Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Language Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:33:47 --> Config Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:33:47 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Loader Class Initialized
DEBUG - 2015-04-13 12:33:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:33:47 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:33:47 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: user_helper
ERROR - 2015-04-13 12:33:47 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 452
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:33:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:33:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:33:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Session Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:33:48 --> Session routines successfully run
DEBUG - 2015-04-13 12:33:48 --> Controller Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:33:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:33:48 --> Email Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:33:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:33:48 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:33:48 --> Model Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:33:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:33:48 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:33:48 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:33:48 --> Final output sent to browser
DEBUG - 2015-04-13 12:33:48 --> Total execution time: 1.6981
DEBUG - 2015-04-13 12:51:55 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:51:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:51:55 --> URI Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Router Class Initialized
DEBUG - 2015-04-13 12:51:55 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:51:55 --> Output Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Security Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Input Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:51:55 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Loader Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:51:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:51:55 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Session Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:51:55 --> Session routines successfully run
DEBUG - 2015-04-13 12:51:55 --> Controller Class Initialized
DEBUG - 2015-04-13 12:51:55 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:51:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:51:55 --> Email Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:51:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:51:55 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:51:55 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:55 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:51:55 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:51:55 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:51:55 --> Final output sent to browser
DEBUG - 2015-04-13 12:51:56 --> Total execution time: 0.7900
DEBUG - 2015-04-13 12:51:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:51:56 --> URI Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Router Class Initialized
DEBUG - 2015-04-13 12:51:56 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:51:56 --> Output Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Security Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Input Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:51:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Loader Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:51:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:51:56 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Session Class Initialized
DEBUG - 2015-04-13 12:51:56 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:51:57 --> Session routines successfully run
DEBUG - 2015-04-13 12:51:57 --> Controller Class Initialized
DEBUG - 2015-04-13 12:51:57 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:51:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:51:57 --> Email Class Initialized
DEBUG - 2015-04-13 12:51:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:51:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:51:57 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:51:57 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:57 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:51:58 --> URI Class Initialized
DEBUG - 2015-04-13 12:51:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:51:58 --> Router Class Initialized
DEBUG - 2015-04-13 12:51:58 --> URI Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Router Class Initialized
DEBUG - 2015-04-13 12:51:58 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:51:58 --> Output Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Security Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Input Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:51:58 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Loader Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:51:58 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:51:58 --> Output Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:51:58 --> Security Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:51:58 --> Input Class Initialized
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:51:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:51:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:51:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Language Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Loader Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Session Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:51:59 --> Session routines successfully run
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:51:59 --> Controller Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:51:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:51:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:51:59 --> Email Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:51:59 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:51:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:51:59 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:51:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:51:59 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:51:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Session Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:51:59 --> Session routines successfully run
DEBUG - 2015-04-13 12:51:59 --> Controller Class Initialized
DEBUG - 2015-04-13 12:51:59 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:51:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:51:59 --> Email Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:51:59 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:51:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:51:59 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:51:59 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:51:59 --> Model Class Initialized
DEBUG - 2015-04-13 12:51:59 --> Final output sent to browser
DEBUG - 2015-04-13 12:52:00 --> Total execution time: 1.5661
DEBUG - 2015-04-13 12:52:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Config Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:54:20 --> URI Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Router Class Initialized
DEBUG - 2015-04-13 12:54:20 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:54:20 --> Output Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Security Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Input Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:54:20 --> Language Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Language Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Config Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Loader Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:54:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:54:20 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Session Class Initialized
DEBUG - 2015-04-13 12:54:20 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:54:20 --> Session routines successfully run
DEBUG - 2015-04-13 12:54:21 --> Controller Class Initialized
DEBUG - 2015-04-13 12:54:21 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:54:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:54:21 --> Email Class Initialized
DEBUG - 2015-04-13 12:54:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:54:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:54:21 --> Model Class Initialized
DEBUG - 2015-04-13 12:54:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:54:21 --> Model Class Initialized
DEBUG - 2015-04-13 12:54:21 --> Form Validation Class Initialized
ERROR - 2015-04-13 12:54:21 --> Severity: Notice  --> Undefined property: CI::$base C:\xampp\htdocs\ecampaign247\application\libraries\Grid.php 450
DEBUG - 2015-04-13 12:55:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:55:49 --> URI Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Router Class Initialized
DEBUG - 2015-04-13 12:55:49 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:55:49 --> Output Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Security Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Input Class Initialized
DEBUG - 2015-04-13 12:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:55:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Loader Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:55:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:55:50 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Session Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:55:50 --> Session routines successfully run
DEBUG - 2015-04-13 12:55:50 --> Controller Class Initialized
DEBUG - 2015-04-13 12:55:50 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:55:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:55:50 --> Email Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:55:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:55:50 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:55:50 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:50 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:55:50 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:55:50 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:55:50 --> Final output sent to browser
DEBUG - 2015-04-13 12:55:50 --> Total execution time: 0.8260
DEBUG - 2015-04-13 12:55:51 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:55:52 --> URI Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Router Class Initialized
DEBUG - 2015-04-13 12:55:52 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:55:52 --> Output Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Security Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Input Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:55:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Loader Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:55:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:55:52 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Session Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:55:52 --> Session routines successfully run
DEBUG - 2015-04-13 12:55:52 --> Controller Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:55:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:55:52 --> Email Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:55:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:55:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:55:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:52 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:55:53 --> URI Class Initialized
DEBUG - 2015-04-13 12:55:53 --> URI Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Router Class Initialized
DEBUG - 2015-04-13 12:55:53 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:55:53 --> Output Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Router Class Initialized
DEBUG - 2015-04-13 12:55:53 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:55:53 --> Security Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Output Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Input Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Security Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:55:53 --> Input Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:55:53 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Loader Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Language Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Config Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Loader Class Initialized
DEBUG - 2015-04-13 12:55:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:55:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:55:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:55:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:55:54 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Session Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:55:54 --> Session Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:55:54 --> Session routines successfully run
DEBUG - 2015-04-13 12:55:54 --> Session routines successfully run
DEBUG - 2015-04-13 12:55:54 --> Controller Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:55:54 --> Controller Class Initialized
DEBUG - 2015-04-13 12:55:54 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:55:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:55:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:55:54 --> Email Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Email Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:55:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:55:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:55:54 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:55:54 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:54 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:55:55 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:55:55 --> Model Class Initialized
DEBUG - 2015-04-13 12:55:55 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:55:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:55:55 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:55:55 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:55:55 --> Final output sent to browser
DEBUG - 2015-04-13 12:55:55 --> Total execution time: 2.1551
DEBUG - 2015-04-13 12:56:39 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:56:39 --> URI Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Router Class Initialized
DEBUG - 2015-04-13 12:56:39 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:56:39 --> Output Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Security Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Input Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:56:39 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Loader Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:56:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:56:39 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Session Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:56:39 --> Session routines successfully run
DEBUG - 2015-04-13 12:56:39 --> Controller Class Initialized
DEBUG - 2015-04-13 12:56:39 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:56:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:56:39 --> Email Class Initialized
DEBUG - 2015-04-13 12:56:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:56:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:56:39 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:56:39 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:40 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:56:40 --> Final output sent to browser
DEBUG - 2015-04-13 12:56:40 --> Total execution time: 0.8691
DEBUG - 2015-04-13 12:56:47 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:56:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:56:47 --> URI Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Router Class Initialized
DEBUG - 2015-04-13 12:56:47 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:56:47 --> Output Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Security Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Input Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:56:47 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Loader Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:56:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:56:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Session Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:56:47 --> Session routines successfully run
DEBUG - 2015-04-13 12:56:47 --> Controller Class Initialized
DEBUG - 2015-04-13 12:56:47 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:56:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:56:47 --> Email Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:56:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:56:47 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:56:47 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:47 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:56:47 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:56:48 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:56:48 --> Final output sent to browser
DEBUG - 2015-04-13 12:56:48 --> Total execution time: 0.8290
DEBUG - 2015-04-13 12:56:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:56:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:56:49 --> URI Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Router Class Initialized
DEBUG - 2015-04-13 12:56:49 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:56:49 --> Output Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Security Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Input Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:56:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Loader Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:56:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:56:49 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Session Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:56:49 --> Session routines successfully run
DEBUG - 2015-04-13 12:56:49 --> Controller Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:56:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:56:49 --> Email Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:56:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:56:49 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:56:49 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:56:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:56:50 --> URI Class Initialized
DEBUG - 2015-04-13 12:56:50 --> URI Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Router Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Router Class Initialized
DEBUG - 2015-04-13 12:56:50 --> No URI present. Default controller set.
DEBUG - 2015-04-13 12:56:50 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:56:50 --> Output Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Security Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Output Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Input Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Security Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:56:50 --> Input Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:50 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:56:51 --> Loader Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:56:51 --> Language Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:56:51 --> Config Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Loader Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:56:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:56:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Session Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:56:51 --> Session routines successfully run
DEBUG - 2015-04-13 12:56:51 --> Controller Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:56:51 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 12:56:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:56:51 --> Session Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Email Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:56:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:56:51 --> Session routines successfully run
DEBUG - 2015-04-13 12:56:51 --> Controller Class Initialized
DEBUG - 2015-04-13 12:56:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:56:51 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:56:51 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:56:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:56:51 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:52 --> Email Class Initialized
DEBUG - 2015-04-13 12:56:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:56:52 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:56:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:56:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 12:56:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:56:52 --> Model Class Initialized
DEBUG - 2015-04-13 12:56:52 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:56:52 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 12:56:52 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:56:52 --> Final output sent to browser
DEBUG - 2015-04-13 12:56:52 --> Total execution time: 2.3311
DEBUG - 2015-04-13 12:56:52 --> Final output sent to browser
DEBUG - 2015-04-13 12:56:52 --> Total execution time: 2.1611
DEBUG - 2015-04-13 12:59:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:59:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:59:56 --> URI Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Router Class Initialized
DEBUG - 2015-04-13 12:59:56 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:59:56 --> Output Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Security Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Input Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:59:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Language Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Config Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Loader Class Initialized
DEBUG - 2015-04-13 12:59:56 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:59:56 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:59:56 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:59:56 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:59:56 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:59:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:59:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:59:57 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:59:57 --> Session Class Initialized
DEBUG - 2015-04-13 12:59:57 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:59:57 --> Session routines successfully run
DEBUG - 2015-04-13 12:59:57 --> Controller Class Initialized
DEBUG - 2015-04-13 12:59:57 --> User MX_Controller Initialized
DEBUG - 2015-04-13 12:59:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:59:57 --> Email Class Initialized
DEBUG - 2015-04-13 12:59:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:59:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:59:57 --> Model Class Initialized
DEBUG - 2015-04-13 12:59:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:59:57 --> Model Class Initialized
DEBUG - 2015-04-13 12:59:57 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:59:57 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 12:59:57 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 12:59:57 --> Final output sent to browser
DEBUG - 2015-04-13 12:59:57 --> Total execution time: 0.8250
DEBUG - 2015-04-13 12:59:58 --> Config Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 12:59:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 12:59:58 --> URI Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Router Class Initialized
DEBUG - 2015-04-13 12:59:58 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 12:59:58 --> Output Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Security Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Input Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 12:59:58 --> Language Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Language Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Config Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Loader Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: url_helper
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: form_helper
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: language_helper
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: user_helper
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 12:59:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 12:59:58 --> Database Driver Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Session Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: string_helper
DEBUG - 2015-04-13 12:59:58 --> Session routines successfully run
DEBUG - 2015-04-13 12:59:58 --> Controller Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 12:59:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 12:59:58 --> Email Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 12:59:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 12:59:58 --> Model Class Initialized
DEBUG - 2015-04-13 12:59:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 12:59:58 --> Model Class Initialized
DEBUG - 2015-04-13 12:59:58 --> Form Validation Class Initialized
DEBUG - 2015-04-13 12:59:59 --> Config Class Initialized
DEBUG - 2015-04-13 12:59:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 12:59:59 --> Config Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:00:00 --> URI Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:00:00 --> Router Class Initialized
DEBUG - 2015-04-13 13:00:00 --> URI Class Initialized
DEBUG - 2015-04-13 13:00:00 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:00:00 --> Router Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Output Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Security Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Input Class Initialized
DEBUG - 2015-04-13 13:00:00 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:00:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Output Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Security Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Input Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Config Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:00:00 --> Loader Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:00:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:00:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:00:00 --> Config Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:00:00 --> Loader Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:00:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:00:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Session Class Initialized
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:00:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:00:01 --> Session routines successfully run
DEBUG - 2015-04-13 13:00:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:00:01 --> Controller Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:00:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:00:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:00:01 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Email Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:00:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:00:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:00:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:00:01 --> Session Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:00:01 --> Session routines successfully run
DEBUG - 2015-04-13 13:00:01 --> Controller Class Initialized
DEBUG - 2015-04-13 13:00:01 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:00:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:00:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:00:01 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:00:01 --> Email Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:00:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:00:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:00:01 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:00:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:00:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:00:01 --> Final output sent to browser
DEBUG - 2015-04-13 13:00:01 --> Total execution time: 1.7791
DEBUG - 2015-04-13 13:00:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:00:02 --> Final output sent to browser
DEBUG - 2015-04-13 13:00:02 --> Total execution time: 2.0281
DEBUG - 2015-04-13 13:03:44 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:44 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:03:44 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:03:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:03:45 --> URI Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Router Class Initialized
DEBUG - 2015-04-13 13:03:45 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:03:45 --> Output Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Security Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Input Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:03:45 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Loader Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:03:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:03:45 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Session Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:03:45 --> Session routines successfully run
DEBUG - 2015-04-13 13:03:45 --> Controller Class Initialized
DEBUG - 2015-04-13 13:03:45 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:03:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:03:45 --> Email Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:03:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:03:45 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:03:45 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:45 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:03:45 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 13:03:45 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:03:45 --> Final output sent to browser
DEBUG - 2015-04-13 13:03:45 --> Total execution time: 0.7930
DEBUG - 2015-04-13 13:03:46 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:03:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:03:46 --> URI Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Router Class Initialized
DEBUG - 2015-04-13 13:03:46 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:03:46 --> Output Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Security Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Input Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:03:46 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Loader Class Initialized
DEBUG - 2015-04-13 13:03:46 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:03:46 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:03:46 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:03:46 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:03:47 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:03:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:03:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:03:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Session Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:03:47 --> Session routines successfully run
DEBUG - 2015-04-13 13:03:47 --> Controller Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 13:03:47 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:03:47 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:03:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:03:47 --> Email Class Initialized
DEBUG - 2015-04-13 13:03:47 --> URI Class Initialized
DEBUG - 2015-04-13 13:03:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:03:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:03:47 --> Router Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:48 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:03:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:03:48 --> Output Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Security Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Input Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:03:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Loader Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:03:48 --> URI Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:03:48 --> Router Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:03:48 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:03:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:03:48 --> Output Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Security Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Input Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:03:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Session Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:03:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Loader Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Session routines successfully run
DEBUG - 2015-04-13 13:03:48 --> Controller Class Initialized
DEBUG - 2015-04-13 13:03:48 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:03:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:03:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:03:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:03:48 --> Email Class Initialized
DEBUG - 2015-04-13 13:03:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:03:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Session Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:03:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:03:49 --> Session routines successfully run
DEBUG - 2015-04-13 13:03:49 --> Controller Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:03:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:03:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:03:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Email Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:03:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:03:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:03:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Final output sent to browser
DEBUG - 2015-04-13 13:03:49 --> Total execution time: 1.8391
DEBUG - 2015-04-13 13:03:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:03:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:03:49 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:03:49 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:03:49 --> Final output sent to browser
DEBUG - 2015-04-13 13:03:49 --> Total execution time: 1.6281
DEBUG - 2015-04-13 13:09:57 --> Config Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:09:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:09:57 --> URI Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Router Class Initialized
DEBUG - 2015-04-13 13:09:57 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:09:57 --> Output Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Security Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Input Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:09:57 --> Language Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Language Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Config Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Loader Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:09:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:09:57 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Session Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:09:57 --> Session routines successfully run
DEBUG - 2015-04-13 13:09:57 --> Controller Class Initialized
DEBUG - 2015-04-13 13:09:57 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:09:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:09:57 --> Email Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:09:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:09:57 --> Model Class Initialized
DEBUG - 2015-04-13 13:09:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:09:57 --> Model Class Initialized
DEBUG - 2015-04-13 13:09:57 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:09:58 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 13:09:58 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:09:58 --> Final output sent to browser
DEBUG - 2015-04-13 13:09:58 --> Total execution time: 0.8961
DEBUG - 2015-04-13 13:09:58 --> Config Class Initialized
DEBUG - 2015-04-13 13:09:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:09:58 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:09:58 --> URI Class Initialized
DEBUG - 2015-04-13 13:09:58 --> Router Class Initialized
DEBUG - 2015-04-13 13:09:59 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:09:59 --> Output Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Security Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Input Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:09:59 --> Language Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Language Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Config Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Loader Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:09:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:09:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Config Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Session Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:09:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:09:59 --> URI Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:09:59 --> Router Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Session routines successfully run
DEBUG - 2015-04-13 13:09:59 --> Controller Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 13:09:59 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:09:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:09:59 --> Output Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Email Class Initialized
DEBUG - 2015-04-13 13:09:59 --> Security Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:10:00 --> Input Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:10:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:10:00 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:10:00 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Loader Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:10:00 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:10:00 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:10:00 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:10:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:10:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:10:00 --> URI Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Session Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:10:00 --> Router Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Session routines successfully run
DEBUG - 2015-04-13 13:10:00 --> Controller Class Initialized
DEBUG - 2015-04-13 13:10:00 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:10:00 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:10:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:10:00 --> Output Class Initialized
DEBUG - 2015-04-13 13:10:00 --> Security Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Email Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Input Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:10:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:10:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Loader Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Final output sent to browser
DEBUG - 2015-04-13 13:10:01 --> Total execution time: 1.6691
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:10:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:10:01 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Session Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:10:01 --> Session routines successfully run
DEBUG - 2015-04-13 13:10:01 --> Controller Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:10:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:10:01 --> Email Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:10:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:10:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:10:01 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:10:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:10:02 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:10:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:10:02 --> Final output sent to browser
DEBUG - 2015-04-13 13:10:02 --> Total execution time: 1.5161
DEBUG - 2015-04-13 13:10:22 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:22 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:10:22 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:10:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:10:22 --> URI Class Initialized
DEBUG - 2015-04-13 13:10:22 --> Router Class Initialized
DEBUG - 2015-04-13 13:10:22 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:10:22 --> Output Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Security Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Input Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:10:23 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Loader Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:10:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:10:23 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Session Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:10:23 --> Session routines successfully run
DEBUG - 2015-04-13 13:10:23 --> Controller Class Initialized
DEBUG - 2015-04-13 13:10:23 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:10:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:10:23 --> Email Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:10:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:10:23 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:10:23 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:10:23 --> Final output sent to browser
DEBUG - 2015-04-13 13:10:23 --> Total execution time: 0.8070
DEBUG - 2015-04-13 13:10:25 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:10:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:10:25 --> URI Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Router Class Initialized
DEBUG - 2015-04-13 13:10:25 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:10:25 --> Output Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Security Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Input Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:10:25 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Language Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Config Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Loader Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:10:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:10:25 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Session Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:10:25 --> Session routines successfully run
DEBUG - 2015-04-13 13:10:25 --> Controller Class Initialized
DEBUG - 2015-04-13 13:10:25 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:10:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:10:25 --> Email Class Initialized
DEBUG - 2015-04-13 13:10:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:10:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:10:26 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:10:26 --> Model Class Initialized
DEBUG - 2015-04-13 13:10:26 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:10:26 --> Final output sent to browser
DEBUG - 2015-04-13 13:10:26 --> Total execution time: 0.8340
DEBUG - 2015-04-13 13:14:59 --> Config Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:14:59 --> URI Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Router Class Initialized
DEBUG - 2015-04-13 13:14:59 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:14:59 --> Output Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Security Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Input Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:14:59 --> Language Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Language Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Config Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Loader Class Initialized
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:14:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:14:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:14:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:15:00 --> Session Class Initialized
DEBUG - 2015-04-13 13:15:00 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:15:00 --> Session routines successfully run
DEBUG - 2015-04-13 13:15:00 --> Controller Class Initialized
DEBUG - 2015-04-13 13:15:00 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:15:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:15:00 --> Email Class Initialized
DEBUG - 2015-04-13 13:15:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:15:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:15:00 --> Model Class Initialized
DEBUG - 2015-04-13 13:15:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:15:00 --> Model Class Initialized
DEBUG - 2015-04-13 13:15:00 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:15:00 --> Final output sent to browser
DEBUG - 2015-04-13 13:15:00 --> Total execution time: 1.0291
DEBUG - 2015-04-13 13:17:46 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:17:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:17:46 --> URI Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Router Class Initialized
DEBUG - 2015-04-13 13:17:46 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:17:46 --> Output Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Security Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Input Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:17:46 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Loader Class Initialized
DEBUG - 2015-04-13 13:17:46 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:17:46 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:17:46 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:17:46 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:17:47 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:17:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:17:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:17:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:17:47 --> Session Class Initialized
DEBUG - 2015-04-13 13:17:47 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:17:47 --> Session routines successfully run
DEBUG - 2015-04-13 13:17:47 --> Controller Class Initialized
DEBUG - 2015-04-13 13:17:47 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:17:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:17:47 --> Email Class Initialized
DEBUG - 2015-04-13 13:17:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:17:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:17:47 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:17:47 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:47 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:17:47 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 13:17:47 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:17:47 --> Final output sent to browser
DEBUG - 2015-04-13 13:17:47 --> Total execution time: 0.9731
DEBUG - 2015-04-13 13:17:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:17:48 --> URI Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Router Class Initialized
DEBUG - 2015-04-13 13:17:48 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:17:48 --> Output Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Security Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Input Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:17:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Loader Class Initialized
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:17:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:17:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:17:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Session Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:17:49 --> Session routines successfully run
DEBUG - 2015-04-13 13:17:49 --> Controller Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 13:17:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:17:49 --> Email Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:17:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:17:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:17:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:17:49 --> URI Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Router Class Initialized
DEBUG - 2015-04-13 13:17:49 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:17:49 --> Output Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Security Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Input Class Initialized
DEBUG - 2015-04-13 13:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:17:49 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:17:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:17:50 --> Loader Class Initialized
DEBUG - 2015-04-13 13:17:50 --> URI Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:17:50 --> Router Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:17:50 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:17:50 --> Output Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:17:50 --> Security Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:17:50 --> Input Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:17:50 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:17:50 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Session Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:17:50 --> Session routines successfully run
DEBUG - 2015-04-13 13:17:50 --> Controller Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Language Class Initialized
DEBUG - 2015-04-13 13:17:50 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:17:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:17:50 --> Config Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Email Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:17:50 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Loader Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:17:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:17:50 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:17:50 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:17:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:17:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:17:51 --> Final output sent to browser
DEBUG - 2015-04-13 13:17:51 --> Total execution time: 1.6121
DEBUG - 2015-04-13 13:17:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Session Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:17:51 --> Session routines successfully run
DEBUG - 2015-04-13 13:17:51 --> Controller Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:17:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:17:51 --> Email Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:17:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:17:51 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:17:51 --> Model Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:17:51 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:17:51 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:17:51 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:17:51 --> Final output sent to browser
DEBUG - 2015-04-13 13:17:51 --> Total execution time: 1.8401
DEBUG - 2015-04-13 13:25:21 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:25:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:25:21 --> URI Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Router Class Initialized
DEBUG - 2015-04-13 13:25:21 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:25:21 --> Output Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Security Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Input Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:25:21 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Loader Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:25:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:25:21 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Session Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:25:21 --> Session routines successfully run
DEBUG - 2015-04-13 13:25:21 --> Controller Class Initialized
DEBUG - 2015-04-13 13:25:21 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:25:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:25:21 --> Email Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:25:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:25:21 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:25:21 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:21 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:25:21 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 13:25:21 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:25:21 --> Final output sent to browser
DEBUG - 2015-04-13 13:25:21 --> Total execution time: 0.8721
DEBUG - 2015-04-13 13:25:22 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:25:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:25:22 --> URI Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Router Class Initialized
DEBUG - 2015-04-13 13:25:22 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:25:22 --> Output Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Security Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Input Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:25:22 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Loader Class Initialized
DEBUG - 2015-04-13 13:25:22 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:25:22 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:25:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:25:23 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:25:23 --> Session Class Initialized
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:25:23 --> Session routines successfully run
DEBUG - 2015-04-13 13:25:23 --> Controller Class Initialized
DEBUG - 2015-04-13 13:25:23 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 13:25:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:25:23 --> Email Class Initialized
DEBUG - 2015-04-13 13:25:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:25:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:25:23 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:25:23 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:23 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:25:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:25:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:25:24 --> URI Class Initialized
DEBUG - 2015-04-13 13:25:24 --> URI Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Router Class Initialized
DEBUG - 2015-04-13 13:25:24 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:25:24 --> Router Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Output Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Security Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Input Class Initialized
DEBUG - 2015-04-13 13:25:24 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:25:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:25:24 --> Output Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:24 --> Security Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Input Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:25:25 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Language Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Loader Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Config Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:25:25 --> Loader Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:25:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:25:25 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:25:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:25:25 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Session Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:25:25 --> Session routines successfully run
DEBUG - 2015-04-13 13:25:25 --> Controller Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:25:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:25:25 --> Email Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:25:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:25:25 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:25:25 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:25:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:25:26 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:25:26 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:25:26 --> Final output sent to browser
DEBUG - 2015-04-13 13:25:26 --> Total execution time: 1.7261
DEBUG - 2015-04-13 13:25:26 --> Session Class Initialized
DEBUG - 2015-04-13 13:25:26 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:25:26 --> Session routines successfully run
DEBUG - 2015-04-13 13:25:26 --> Controller Class Initialized
DEBUG - 2015-04-13 13:25:26 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:25:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:25:26 --> Email Class Initialized
DEBUG - 2015-04-13 13:25:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:25:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:25:26 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:25:26 --> Model Class Initialized
DEBUG - 2015-04-13 13:25:26 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:25:26 --> Final output sent to browser
DEBUG - 2015-04-13 13:25:26 --> Total execution time: 2.5041
DEBUG - 2015-04-13 13:32:43 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:32:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:32:43 --> URI Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Router Class Initialized
DEBUG - 2015-04-13 13:32:43 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:32:43 --> Output Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Security Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Input Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:32:43 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Loader Class Initialized
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:32:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:32:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:32:43 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:32:44 --> Session Class Initialized
DEBUG - 2015-04-13 13:32:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:32:44 --> Session routines successfully run
DEBUG - 2015-04-13 13:32:44 --> Controller Class Initialized
DEBUG - 2015-04-13 13:32:44 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:32:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:32:44 --> Email Class Initialized
DEBUG - 2015-04-13 13:32:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:32:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:32:44 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:32:44 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:32:44 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-13 13:32:44 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:32:44 --> Final output sent to browser
DEBUG - 2015-04-13 13:32:44 --> Total execution time: 1.2001
DEBUG - 2015-04-13 13:32:45 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:32:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:32:45 --> URI Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Router Class Initialized
DEBUG - 2015-04-13 13:32:45 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:32:45 --> Output Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Security Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Input Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:32:45 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Loader Class Initialized
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:32:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:32:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:32:46 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:32:46 --> Session Class Initialized
DEBUG - 2015-04-13 13:32:46 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:32:46 --> Session routines successfully run
DEBUG - 2015-04-13 13:32:46 --> Controller Class Initialized
DEBUG - 2015-04-13 13:32:46 --> Services MX_Controller Initialized
DEBUG - 2015-04-13 13:32:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:32:46 --> Email Class Initialized
DEBUG - 2015-04-13 13:32:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:32:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:32:46 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:32:46 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:46 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:32:47 --> URI Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Router Class Initialized
DEBUG - 2015-04-13 13:32:47 --> No URI present. Default controller set.
DEBUG - 2015-04-13 13:32:47 --> Output Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Security Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Input Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:32:47 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:47 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Loader Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:32:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:32:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Session Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:32:48 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Session routines successfully run
DEBUG - 2015-04-13 13:32:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Controller Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 13:32:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:32:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:32:48 --> Email Class Initialized
DEBUG - 2015-04-13 13:32:48 --> URI Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Router Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:32:48 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:32:48 --> Output Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Security Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Input Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:32:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:32:48 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:32:48 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:48 --> Language Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Config Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Loader Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:32:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:32:49 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-13 13:32:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:32:49 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-13 13:32:49 --> Final output sent to browser
DEBUG - 2015-04-13 13:32:49 --> Total execution time: 1.5731
DEBUG - 2015-04-13 13:32:49 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Session Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:32:49 --> Session routines successfully run
DEBUG - 2015-04-13 13:32:49 --> Controller Class Initialized
DEBUG - 2015-04-13 13:32:49 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:32:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:32:49 --> Email Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:32:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:32:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:32:49 --> Model Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:32:49 --> Final output sent to browser
DEBUG - 2015-04-13 13:32:49 --> Total execution time: 1.5961
DEBUG - 2015-04-13 13:33:30 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:30 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:33:31 --> URI Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Router Class Initialized
DEBUG - 2015-04-13 13:33:31 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:33:31 --> Output Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Security Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Input Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:33:31 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Loader Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:33:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:33:31 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Session Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:33:31 --> Session routines successfully run
DEBUG - 2015-04-13 13:33:31 --> Controller Class Initialized
DEBUG - 2015-04-13 13:33:31 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:33:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:33:31 --> Email Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:33:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:33:31 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:33:31 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:31 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:33:32 --> Final output sent to browser
DEBUG - 2015-04-13 13:33:32 --> Total execution time: 1.1721
DEBUG - 2015-04-13 13:33:35 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:33:35 --> URI Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Router Class Initialized
DEBUG - 2015-04-13 13:33:35 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:33:35 --> Output Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Security Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Input Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:33:35 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Loader Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:33:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:33:35 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Session Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:33:35 --> Session routines successfully run
DEBUG - 2015-04-13 13:33:35 --> Controller Class Initialized
DEBUG - 2015-04-13 13:33:35 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:33:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:33:35 --> Email Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:33:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:33:35 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:33:35 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:33:35 --> Final output sent to browser
DEBUG - 2015-04-13 13:33:35 --> Total execution time: 0.9841
DEBUG - 2015-04-13 13:33:37 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:33:37 --> URI Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Router Class Initialized
DEBUG - 2015-04-13 13:33:37 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:33:37 --> Output Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Security Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Input Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:33:37 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Loader Class Initialized
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:33:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:33:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:33:37 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:33:38 --> Session Class Initialized
DEBUG - 2015-04-13 13:33:38 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:33:38 --> Session routines successfully run
DEBUG - 2015-04-13 13:33:38 --> Controller Class Initialized
DEBUG - 2015-04-13 13:33:38 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:33:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:33:38 --> Email Class Initialized
DEBUG - 2015-04-13 13:33:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:33:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:33:38 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:33:38 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:38 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:33:38 --> Final output sent to browser
DEBUG - 2015-04-13 13:33:38 --> Total execution time: 1.0881
DEBUG - 2015-04-13 13:33:39 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:39 --> Hooks Class Initialized
DEBUG - 2015-04-13 13:33:39 --> Utf8 Class Initialized
DEBUG - 2015-04-13 13:33:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 13:33:39 --> URI Class Initialized
DEBUG - 2015-04-13 13:33:39 --> Router Class Initialized
DEBUG - 2015-04-13 13:33:39 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-13 13:33:39 --> Output Class Initialized
DEBUG - 2015-04-13 13:33:39 --> Security Class Initialized
DEBUG - 2015-04-13 13:33:39 --> Input Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 13:33:40 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Language Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Config Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Loader Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: url_helper
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: form_helper
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: language_helper
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: user_helper
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: date_helper
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 13:33:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 13:33:40 --> Database Driver Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Session Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: string_helper
DEBUG - 2015-04-13 13:33:40 --> Session routines successfully run
DEBUG - 2015-04-13 13:33:40 --> Controller Class Initialized
DEBUG - 2015-04-13 13:33:40 --> User MX_Controller Initialized
DEBUG - 2015-04-13 13:33:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 13:33:40 --> Email Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 13:33:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 13:33:40 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 13:33:40 --> Model Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Form Validation Class Initialized
DEBUG - 2015-04-13 13:33:40 --> Final output sent to browser
DEBUG - 2015-04-13 13:33:40 --> Total execution time: 0.9921
DEBUG - 2015-04-13 14:11:57 --> Config Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:11:57 --> URI Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Router Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Output Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Security Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Input Class Initialized
DEBUG - 2015-04-13 14:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:11:57 --> Language Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Language Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Config Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Loader Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: language_helper
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: user_helper
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: date_helper
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 14:11:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 14:11:58 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Session Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: string_helper
ERROR - 2015-04-13 14:11:58 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-04-13 14:11:58 --> Session routines successfully run
DEBUG - 2015-04-13 14:11:58 --> Controller Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 14:11:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 14:11:58 --> Email Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 14:11:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 14:11:58 --> Model Class Initialized
DEBUG - 2015-04-13 14:11:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 14:11:58 --> Model Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 14:11:58 --> Config Class Initialized
DEBUG - 2015-04-13 14:11:58 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:11:59 --> URI Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Router Class Initialized
DEBUG - 2015-04-13 14:11:59 --> No URI present. Default controller set.
DEBUG - 2015-04-13 14:11:59 --> Output Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Security Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Input Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:11:59 --> Language Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Language Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Config Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Loader Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: language_helper
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: user_helper
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: date_helper
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-13 14:11:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-13 14:11:59 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Session Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:11:59 --> Session routines successfully run
DEBUG - 2015-04-13 14:11:59 --> Controller Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-13 14:11:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-13 14:11:59 --> Email Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-13 14:11:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-13 14:11:59 --> Model Class Initialized
DEBUG - 2015-04-13 14:11:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-13 14:11:59 --> Model Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:11:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-13 14:11:59 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-13 14:11:59 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-13 14:11:59 --> Final output sent to browser
DEBUG - 2015-04-13 14:11:59 --> Total execution time: 0.8830
