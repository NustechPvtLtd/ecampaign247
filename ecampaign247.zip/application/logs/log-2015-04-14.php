<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-14 05:48:02 --> Config Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Hooks Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Utf8 Class Initialized
DEBUG - 2015-04-14 05:48:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 05:48:02 --> URI Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Router Class Initialized
DEBUG - 2015-04-14 05:48:02 --> No URI present. Default controller set.
DEBUG - 2015-04-14 05:48:02 --> Output Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Security Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Input Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 05:48:02 --> Language Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Language Class Initialized
DEBUG - 2015-04-14 05:48:02 --> Config Class Initialized
DEBUG - 2015-04-14 05:48:03 --> Loader Class Initialized
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: url_helper
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: form_helper
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: language_helper
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: user_helper
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: date_helper
DEBUG - 2015-04-14 05:48:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 05:48:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 05:48:03 --> Database Driver Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Session Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Helper loaded: string_helper
DEBUG - 2015-04-14 05:48:04 --> A session cookie was not found.
DEBUG - 2015-04-14 05:48:04 --> Session routines successfully run
DEBUG - 2015-04-14 05:48:04 --> Controller Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 05:48:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 05:48:04 --> Email Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 05:48:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 05:48:04 --> Model Class Initialized
DEBUG - 2015-04-14 05:48:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 05:48:04 --> Model Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Form Validation Class Initialized
DEBUG - 2015-04-14 05:48:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 05:48:04 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-14 05:48:04 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-14 05:48:04 --> Final output sent to browser
DEBUG - 2015-04-14 05:48:04 --> Total execution time: 1.9481
DEBUG - 2015-04-14 07:01:04 --> Config Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Hooks Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Utf8 Class Initialized
DEBUG - 2015-04-14 07:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 07:01:04 --> URI Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Router Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Output Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Security Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Input Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 07:01:04 --> Language Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Language Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Config Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Loader Class Initialized
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: url_helper
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: form_helper
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: language_helper
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: user_helper
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: date_helper
DEBUG - 2015-04-14 07:01:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 07:01:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 07:01:05 --> Database Driver Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Session Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Helper loaded: string_helper
DEBUG - 2015-04-14 07:01:05 --> Session routines successfully run
DEBUG - 2015-04-14 07:01:05 --> Controller Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 07:01:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 07:01:05 --> Email Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 07:01:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 07:01:05 --> Model Class Initialized
DEBUG - 2015-04-14 07:01:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 07:01:05 --> Model Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Form Validation Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 07:01:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-14 07:01:05 --> Config Class Initialized
DEBUG - 2015-04-14 07:01:05 --> Hooks Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Utf8 Class Initialized
DEBUG - 2015-04-14 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 07:01:06 --> URI Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Router Class Initialized
DEBUG - 2015-04-14 07:01:06 --> No URI present. Default controller set.
DEBUG - 2015-04-14 07:01:06 --> Output Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Security Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Input Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 07:01:06 --> Language Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Language Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Config Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Loader Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: url_helper
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: form_helper
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: language_helper
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: user_helper
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: date_helper
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 07:01:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 07:01:06 --> Database Driver Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Session Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: string_helper
DEBUG - 2015-04-14 07:01:06 --> Session routines successfully run
DEBUG - 2015-04-14 07:01:06 --> Controller Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 07:01:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 07:01:06 --> Email Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 07:01:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 07:01:06 --> Model Class Initialized
DEBUG - 2015-04-14 07:01:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 07:01:06 --> Model Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Form Validation Class Initialized
DEBUG - 2015-04-14 07:01:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 07:01:06 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-14 07:01:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 07:01:06 --> Final output sent to browser
DEBUG - 2015-04-14 07:01:06 --> Total execution time: 0.7710
DEBUG - 2015-04-14 07:01:07 --> Config Class Initialized
DEBUG - 2015-04-14 07:01:07 --> Hooks Class Initialized
DEBUG - 2015-04-14 07:01:07 --> Utf8 Class Initialized
DEBUG - 2015-04-14 07:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 07:01:07 --> URI Class Initialized
DEBUG - 2015-04-14 07:01:07 --> Router Class Initialized
ERROR - 2015-04-14 07:01:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 08:46:31 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:31 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Router Class Initialized
DEBUG - 2015-04-14 08:46:31 --> No URI present. Default controller set.
DEBUG - 2015-04-14 08:46:31 --> Output Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Security Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Input Class Initialized
DEBUG - 2015-04-14 08:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 08:46:32 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:32 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:32 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:32 --> Loader Class Initialized
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: url_helper
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: form_helper
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: language_helper
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: user_helper
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: date_helper
DEBUG - 2015-04-14 08:46:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 08:46:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 08:46:32 --> Database Driver Class Initialized
DEBUG - 2015-04-14 08:46:33 --> Session Class Initialized
DEBUG - 2015-04-14 08:46:33 --> Helper loaded: string_helper
DEBUG - 2015-04-14 08:46:33 --> Session routines successfully run
DEBUG - 2015-04-14 08:46:33 --> Controller Class Initialized
DEBUG - 2015-04-14 08:46:33 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 08:46:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 08:46:33 --> Email Class Initialized
DEBUG - 2015-04-14 08:46:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 08:46:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 08:46:33 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 08:46:33 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:34 --> Form Validation Class Initialized
DEBUG - 2015-04-14 08:46:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 08:46:34 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-14 08:46:34 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 08:46:34 --> Final output sent to browser
DEBUG - 2015-04-14 08:46:34 --> Total execution time: 2.7352
DEBUG - 2015-04-14 08:46:34 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:34 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:34 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:34 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:35 --> Router Class Initialized
ERROR - 2015-04-14 08:46:35 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 08:46:35 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:35 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:35 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:35 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:35 --> Router Class Initialized
ERROR - 2015-04-14 08:46:36 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 08:46:42 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:42 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:42 --> Router Class Initialized
DEBUG - 2015-04-14 08:46:42 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 08:46:42 --> Output Class Initialized
DEBUG - 2015-04-14 08:46:42 --> Security Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Input Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 08:46:43 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Loader Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: url_helper
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: form_helper
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: language_helper
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: user_helper
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: date_helper
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 08:46:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 08:46:43 --> Database Driver Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Session Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: string_helper
DEBUG - 2015-04-14 08:46:43 --> Session routines successfully run
DEBUG - 2015-04-14 08:46:43 --> Controller Class Initialized
DEBUG - 2015-04-14 08:46:43 --> User MX_Controller Initialized
DEBUG - 2015-04-14 08:46:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 08:46:43 --> Email Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 08:46:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 08:46:43 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 08:46:43 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:43 --> Form Validation Class Initialized
DEBUG - 2015-04-14 08:46:43 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 08:46:43 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 08:46:43 --> Final output sent to browser
DEBUG - 2015-04-14 08:46:43 --> Total execution time: 1.0651
DEBUG - 2015-04-14 08:46:45 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:45 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:45 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:45 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:45 --> Router Class Initialized
ERROR - 2015-04-14 08:46:45 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 08:46:46 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:46 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Router Class Initialized
ERROR - 2015-04-14 08:46:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 08:46:46 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Hooks Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Utf8 Class Initialized
DEBUG - 2015-04-14 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 08:46:46 --> URI Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Router Class Initialized
DEBUG - 2015-04-14 08:46:46 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-14 08:46:46 --> Output Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Security Class Initialized
DEBUG - 2015-04-14 08:46:46 --> Input Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 08:46:47 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Language Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Config Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Loader Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: url_helper
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: form_helper
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: language_helper
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: user_helper
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: date_helper
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 08:46:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 08:46:47 --> Database Driver Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Session Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: string_helper
DEBUG - 2015-04-14 08:46:47 --> Session routines successfully run
DEBUG - 2015-04-14 08:46:47 --> Controller Class Initialized
DEBUG - 2015-04-14 08:46:47 --> User MX_Controller Initialized
DEBUG - 2015-04-14 08:46:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 08:46:47 --> Email Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 08:46:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 08:46:47 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 08:46:47 --> Model Class Initialized
DEBUG - 2015-04-14 08:46:47 --> Form Validation Class Initialized
DEBUG - 2015-04-14 08:46:48 --> Final output sent to browser
DEBUG - 2015-04-14 08:46:49 --> Total execution time: 1.1861
DEBUG - 2015-04-14 11:04:17 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:17 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:17 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:17 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:17 --> Router Class Initialized
DEBUG - 2015-04-14 11:04:17 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:04:17 --> Output Class Initialized
DEBUG - 2015-04-14 11:04:17 --> Security Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Input Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:04:18 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Loader Class Initialized
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:04:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:04:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:04:18 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Session Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:04:19 --> A session cookie was not found.
DEBUG - 2015-04-14 11:04:19 --> Session routines successfully run
DEBUG - 2015-04-14 11:04:19 --> Controller Class Initialized
DEBUG - 2015-04-14 11:04:19 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:04:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:04:19 --> Email Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:04:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:04:19 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:04:19 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:19 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:20 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Router Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Output Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Security Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Input Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:04:20 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Loader Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:04:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:04:20 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Session Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:04:20 --> Session routines successfully run
DEBUG - 2015-04-14 11:04:20 --> Controller Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 11:04:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:04:20 --> Email Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:04:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:04:20 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:04:20 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:04:20 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 11:04:20 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-14 11:04:20 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-14 11:04:20 --> Final output sent to browser
DEBUG - 2015-04-14 11:04:20 --> Total execution time: 0.7260
DEBUG - 2015-04-14 11:04:30 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:30 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Router Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Output Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Security Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Input Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:04:30 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Loader Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:04:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:04:30 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Session Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:04:30 --> Session routines successfully run
DEBUG - 2015-04-14 11:04:30 --> Controller Class Initialized
DEBUG - 2015-04-14 11:04:30 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 11:04:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:04:31 --> Email Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:04:31 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:04:31 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 11:04:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-14 11:04:31 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:31 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Router Class Initialized
DEBUG - 2015-04-14 11:04:31 --> No URI present. Default controller set.
DEBUG - 2015-04-14 11:04:31 --> Output Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Security Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Input Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:04:31 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Loader Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:04:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:04:31 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Session Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:04:31 --> Session routines successfully run
DEBUG - 2015-04-14 11:04:31 --> Controller Class Initialized
DEBUG - 2015-04-14 11:04:31 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 11:04:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:04:32 --> Email Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:04:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:04:32 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:04:32 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 11:04:32 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-14 11:04:32 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:04:32 --> Final output sent to browser
DEBUG - 2015-04-14 11:04:32 --> Total execution time: 0.8590
DEBUG - 2015-04-14 11:04:32 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:32 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:32 --> Router Class Initialized
ERROR - 2015-04-14 11:04:32 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:04:39 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:04:39 --> URI Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Router Class Initialized
DEBUG - 2015-04-14 11:04:39 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:04:39 --> Output Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Security Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Input Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:04:39 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Language Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Config Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Loader Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:04:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:04:39 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Session Class Initialized
DEBUG - 2015-04-14 11:04:39 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:04:39 --> Session routines successfully run
DEBUG - 2015-04-14 11:04:39 --> Controller Class Initialized
DEBUG - 2015-04-14 11:04:39 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:04:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:04:40 --> Email Class Initialized
DEBUG - 2015-04-14 11:04:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:04:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:04:40 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:04:40 --> Model Class Initialized
DEBUG - 2015-04-14 11:04:40 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:04:40 --> Final output sent to browser
DEBUG - 2015-04-14 11:04:40 --> Total execution time: 0.6490
DEBUG - 2015-04-14 11:08:36 --> Config Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:08:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:08:36 --> URI Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Router Class Initialized
DEBUG - 2015-04-14 11:08:36 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:08:36 --> Output Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Security Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Input Class Initialized
DEBUG - 2015-04-14 11:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:08:36 --> Language Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Language Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Config Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Loader Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:08:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:08:37 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Session Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:08:37 --> Session routines successfully run
DEBUG - 2015-04-14 11:08:37 --> Controller Class Initialized
DEBUG - 2015-04-14 11:08:37 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:08:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:08:37 --> Email Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:08:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:08:37 --> Model Class Initialized
DEBUG - 2015-04-14 11:08:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:08:37 --> Model Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:08:37 --> Final output sent to browser
DEBUG - 2015-04-14 11:08:37 --> Total execution time: 0.5860
DEBUG - 2015-04-14 11:14:51 --> Config Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:14:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:14:51 --> URI Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Router Class Initialized
DEBUG - 2015-04-14 11:14:51 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:14:51 --> Output Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Security Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Input Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:14:51 --> Language Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Language Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Config Class Initialized
DEBUG - 2015-04-14 11:14:51 --> Loader Class Initialized
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:14:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:14:52 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:14:52 --> Session Class Initialized
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:14:52 --> Session routines successfully run
DEBUG - 2015-04-14 11:14:52 --> Controller Class Initialized
DEBUG - 2015-04-14 11:14:52 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:14:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:14:52 --> Email Class Initialized
DEBUG - 2015-04-14 11:14:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:14:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:14:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:14:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:14:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:14:52 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Config Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:15:17 --> URI Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Router Class Initialized
DEBUG - 2015-04-14 11:15:17 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:15:17 --> Output Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Security Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Input Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:15:17 --> Language Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Language Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Config Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Loader Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:15:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:15:17 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Session Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:15:17 --> Session routines successfully run
DEBUG - 2015-04-14 11:15:17 --> Controller Class Initialized
DEBUG - 2015-04-14 11:15:17 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:15:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:15:17 --> Email Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:15:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:15:17 --> Model Class Initialized
DEBUG - 2015-04-14 11:15:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:15:17 --> Model Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:15:17 --> Final output sent to browser
DEBUG - 2015-04-14 11:15:17 --> Total execution time: 0.6030
DEBUG - 2015-04-14 11:18:51 --> Config Class Initialized
DEBUG - 2015-04-14 11:18:51 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:18:51 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:18:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:18:51 --> URI Class Initialized
DEBUG - 2015-04-14 11:18:51 --> Router Class Initialized
DEBUG - 2015-04-14 11:18:51 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:18:51 --> Output Class Initialized
DEBUG - 2015-04-14 11:18:51 --> Security Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Input Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:18:52 --> Language Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Language Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Config Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Loader Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:18:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:18:52 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Session Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:18:52 --> Session routines successfully run
DEBUG - 2015-04-14 11:18:52 --> Controller Class Initialized
DEBUG - 2015-04-14 11:18:52 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:18:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:18:52 --> Email Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:18:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:18:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:18:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:18:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:18:52 --> Final output sent to browser
DEBUG - 2015-04-14 11:18:52 --> Total execution time: 0.6010
DEBUG - 2015-04-14 11:19:08 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:19:08 --> URI Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Router Class Initialized
DEBUG - 2015-04-14 11:19:08 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:19:08 --> Output Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Security Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Input Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:19:08 --> Language Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Language Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Loader Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:19:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:19:08 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Session Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:19:08 --> Session routines successfully run
DEBUG - 2015-04-14 11:19:08 --> Controller Class Initialized
DEBUG - 2015-04-14 11:19:08 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:19:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:19:08 --> Email Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:19:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:19:08 --> Model Class Initialized
DEBUG - 2015-04-14 11:19:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:19:08 --> Model Class Initialized
DEBUG - 2015-04-14 11:19:08 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:19:08 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:19:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:19:08 --> Final output sent to browser
DEBUG - 2015-04-14 11:19:08 --> Total execution time: 0.5600
DEBUG - 2015-04-14 11:19:09 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:09 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:19:09 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:19:09 --> URI Class Initialized
DEBUG - 2015-04-14 11:19:09 --> Router Class Initialized
ERROR - 2015-04-14 11:19:09 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:19:19 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:19:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:19:19 --> URI Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Router Class Initialized
DEBUG - 2015-04-14 11:19:19 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:19:19 --> Output Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Security Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Input Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:19:19 --> Language Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Language Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Loader Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:19:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:19:19 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Session Class Initialized
DEBUG - 2015-04-14 11:19:19 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:19:19 --> Session routines successfully run
DEBUG - 2015-04-14 11:19:19 --> Controller Class Initialized
DEBUG - 2015-04-14 11:19:19 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:19:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:19:20 --> Email Class Initialized
DEBUG - 2015-04-14 11:19:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:19:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:19:20 --> Model Class Initialized
DEBUG - 2015-04-14 11:19:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:19:20 --> Model Class Initialized
DEBUG - 2015-04-14 11:19:20 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:19:20 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:19:20 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:19:20 --> Final output sent to browser
DEBUG - 2015-04-14 11:19:20 --> Total execution time: 0.9741
DEBUG - 2015-04-14 11:19:21 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:21 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:19:21 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:19:21 --> URI Class Initialized
DEBUG - 2015-04-14 11:19:21 --> Router Class Initialized
ERROR - 2015-04-14 11:19:21 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:19:23 --> Config Class Initialized
DEBUG - 2015-04-14 11:19:23 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:19:23 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:19:23 --> URI Class Initialized
DEBUG - 2015-04-14 11:19:23 --> Router Class Initialized
ERROR - 2015-04-14 11:19:23 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:21:58 --> Config Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:21:58 --> URI Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Router Class Initialized
DEBUG - 2015-04-14 11:21:58 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:21:58 --> Output Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Security Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Input Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:21:58 --> Language Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Language Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Config Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Loader Class Initialized
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:21:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:21:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:21:59 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:21:59 --> Session Class Initialized
DEBUG - 2015-04-14 11:21:59 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:21:59 --> Session routines successfully run
DEBUG - 2015-04-14 11:21:59 --> Controller Class Initialized
DEBUG - 2015-04-14 11:21:59 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:21:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:21:59 --> Email Class Initialized
DEBUG - 2015-04-14 11:21:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:21:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:21:59 --> Model Class Initialized
DEBUG - 2015-04-14 11:21:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:21:59 --> Model Class Initialized
DEBUG - 2015-04-14 11:21:59 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:21:59 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:21:59 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:21:59 --> Final output sent to browser
DEBUG - 2015-04-14 11:21:59 --> Total execution time: 0.7070
DEBUG - 2015-04-14 11:22:00 --> Config Class Initialized
DEBUG - 2015-04-14 11:22:00 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:22:00 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:22:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:22:00 --> URI Class Initialized
DEBUG - 2015-04-14 11:22:00 --> Router Class Initialized
ERROR - 2015-04-14 11:22:00 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:22:02 --> Config Class Initialized
DEBUG - 2015-04-14 11:22:02 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:22:02 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:22:02 --> URI Class Initialized
DEBUG - 2015-04-14 11:22:02 --> Router Class Initialized
ERROR - 2015-04-14 11:22:02 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:22:03 --> Config Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:22:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:22:03 --> URI Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Router Class Initialized
DEBUG - 2015-04-14 11:22:03 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:22:03 --> Output Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Security Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Input Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:22:03 --> Language Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Language Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Config Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Loader Class Initialized
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:22:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:22:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:22:03 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:22:05 --> Session Class Initialized
DEBUG - 2015-04-14 11:22:05 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:22:05 --> Session routines successfully run
DEBUG - 2015-04-14 11:22:05 --> Controller Class Initialized
DEBUG - 2015-04-14 11:22:05 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:22:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:22:05 --> Email Class Initialized
DEBUG - 2015-04-14 11:22:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:22:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:22:05 --> Model Class Initialized
DEBUG - 2015-04-14 11:22:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:22:05 --> Model Class Initialized
DEBUG - 2015-04-14 11:22:05 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:22:05 --> Final output sent to browser
DEBUG - 2015-04-14 11:22:05 --> Total execution time: 2.1121
DEBUG - 2015-04-14 11:27:23 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:27:23 --> URI Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Router Class Initialized
DEBUG - 2015-04-14 11:27:23 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:27:23 --> Output Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Security Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Input Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:27:23 --> Language Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Language Class Initialized
DEBUG - 2015-04-14 11:27:23 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Loader Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:27:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:27:24 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Session Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:27:24 --> Session routines successfully run
DEBUG - 2015-04-14 11:27:24 --> Controller Class Initialized
DEBUG - 2015-04-14 11:27:24 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:27:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:27:24 --> Email Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:27:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 11:27:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 11:27:24 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:27:24 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:27:24 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:27:24 --> Final output sent to browser
DEBUG - 2015-04-14 11:27:24 --> Total execution time: 0.7980
DEBUG - 2015-04-14 11:27:25 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:25 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:27:25 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:27:26 --> URI Class Initialized
DEBUG - 2015-04-14 11:27:26 --> Router Class Initialized
ERROR - 2015-04-14 11:27:26 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:27:27 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:27 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:27:27 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:27:28 --> URI Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Router Class Initialized
ERROR - 2015-04-14 11:27:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:27:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:27:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:27:28 --> URI Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Router Class Initialized
DEBUG - 2015-04-14 11:27:28 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:27:28 --> Output Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Security Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Input Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:27:28 --> Language Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Language Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Loader Class Initialized
DEBUG - 2015-04-14 11:27:28 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:27:28 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:27:28 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:27:29 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:27:29 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:27:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:27:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:27:29 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:27:30 --> Session Class Initialized
DEBUG - 2015-04-14 11:27:30 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:27:30 --> Session routines successfully run
DEBUG - 2015-04-14 11:27:30 --> Controller Class Initialized
DEBUG - 2015-04-14 11:27:30 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:27:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:27:30 --> Email Class Initialized
DEBUG - 2015-04-14 11:27:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:27:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:27:30 --> Model Class Initialized
DEBUG - 2015-04-14 11:27:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:27:30 --> Model Class Initialized
DEBUG - 2015-04-14 11:27:30 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:27:30 --> Final output sent to browser
DEBUG - 2015-04-14 11:27:30 --> Total execution time: 2.1091
DEBUG - 2015-04-14 11:32:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:32:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:32:07 --> URI Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Router Class Initialized
DEBUG - 2015-04-14 11:32:07 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:32:07 --> Output Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Security Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Input Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:32:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Loader Class Initialized
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:32:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:32:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:32:08 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:32:08 --> Session Class Initialized
DEBUG - 2015-04-14 11:32:08 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:32:08 --> Session routines successfully run
DEBUG - 2015-04-14 11:32:08 --> Controller Class Initialized
DEBUG - 2015-04-14 11:32:08 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:32:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:32:08 --> Email Class Initialized
DEBUG - 2015-04-14 11:32:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:32:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:32:08 --> Model Class Initialized
DEBUG - 2015-04-14 11:32:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:32:08 --> Model Class Initialized
DEBUG - 2015-04-14 11:32:08 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:32:08 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:32:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:32:08 --> Final output sent to browser
DEBUG - 2015-04-14 11:32:08 --> Total execution time: 0.6320
DEBUG - 2015-04-14 11:32:10 --> Config Class Initialized
DEBUG - 2015-04-14 11:32:10 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:32:10 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:32:10 --> URI Class Initialized
DEBUG - 2015-04-14 11:32:10 --> Router Class Initialized
ERROR - 2015-04-14 11:32:10 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:32:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:32:12 --> URI Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Router Class Initialized
DEBUG - 2015-04-14 11:32:12 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:32:12 --> Output Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Security Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Input Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:32:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Loader Class Initialized
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:32:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:32:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:32:12 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:32:14 --> Session Class Initialized
DEBUG - 2015-04-14 11:32:14 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:32:14 --> Session routines successfully run
DEBUG - 2015-04-14 11:32:14 --> Controller Class Initialized
DEBUG - 2015-04-14 11:32:14 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:32:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:32:14 --> Email Class Initialized
DEBUG - 2015-04-14 11:32:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:32:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:32:14 --> Model Class Initialized
DEBUG - 2015-04-14 11:32:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:32:14 --> Model Class Initialized
DEBUG - 2015-04-14 11:32:14 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:32:14 --> Final output sent to browser
DEBUG - 2015-04-14 11:32:14 --> Total execution time: 1.9981
DEBUG - 2015-04-14 11:36:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:36:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:36:07 --> URI Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Router Class Initialized
DEBUG - 2015-04-14 11:36:07 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:36:07 --> Output Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Security Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Input Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:36:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Loader Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:36:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:36:07 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Session Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:36:07 --> Session routines successfully run
DEBUG - 2015-04-14 11:36:07 --> Controller Class Initialized
DEBUG - 2015-04-14 11:36:07 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:36:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:36:07 --> Email Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:36:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:36:07 --> Model Class Initialized
DEBUG - 2015-04-14 11:36:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:36:07 --> Model Class Initialized
DEBUG - 2015-04-14 11:36:07 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:36:08 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:36:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:36:08 --> Final output sent to browser
DEBUG - 2015-04-14 11:36:08 --> Total execution time: 0.9101
DEBUG - 2015-04-14 11:36:09 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:09 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:36:09 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:36:09 --> URI Class Initialized
DEBUG - 2015-04-14 11:36:09 --> Router Class Initialized
ERROR - 2015-04-14 11:36:09 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:36:11 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:11 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:36:11 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:36:11 --> URI Class Initialized
DEBUG - 2015-04-14 11:36:11 --> Router Class Initialized
ERROR - 2015-04-14 11:36:11 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:36:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:36:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:36:12 --> URI Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Router Class Initialized
DEBUG - 2015-04-14 11:36:12 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:36:12 --> Output Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Security Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Input Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:36:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Loader Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:36:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:36:12 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Session Class Initialized
DEBUG - 2015-04-14 11:36:12 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:36:12 --> Session routines successfully run
DEBUG - 2015-04-14 11:36:12 --> Controller Class Initialized
DEBUG - 2015-04-14 11:36:12 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:36:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:36:13 --> Email Class Initialized
DEBUG - 2015-04-14 11:36:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:36:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:36:13 --> Model Class Initialized
DEBUG - 2015-04-14 11:36:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:36:13 --> Model Class Initialized
DEBUG - 2015-04-14 11:36:13 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:36:13 --> Final output sent to browser
DEBUG - 2015-04-14 11:36:13 --> Total execution time: 1.3751
DEBUG - 2015-04-14 11:43:25 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:43:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:43:25 --> URI Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Router Class Initialized
DEBUG - 2015-04-14 11:43:25 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:43:25 --> Output Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Security Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Input Class Initialized
DEBUG - 2015-04-14 11:43:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:43:25 --> Language Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Language Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Loader Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:43:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:43:26 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Session Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:43:26 --> Session routines successfully run
DEBUG - 2015-04-14 11:43:26 --> Controller Class Initialized
DEBUG - 2015-04-14 11:43:26 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:43:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:43:26 --> Email Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:43:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:43:26 --> Model Class Initialized
DEBUG - 2015-04-14 11:43:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:43:26 --> Model Class Initialized
DEBUG - 2015-04-14 11:43:26 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:43:26 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:43:26 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:43:26 --> Final output sent to browser
DEBUG - 2015-04-14 11:43:26 --> Total execution time: 0.9311
DEBUG - 2015-04-14 11:43:27 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:27 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:43:27 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:43:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:43:27 --> URI Class Initialized
DEBUG - 2015-04-14 11:43:27 --> Router Class Initialized
ERROR - 2015-04-14 11:43:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:43:30 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:43:30 --> URI Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Router Class Initialized
ERROR - 2015-04-14 11:43:30 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:43:30 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:43:30 --> URI Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Router Class Initialized
DEBUG - 2015-04-14 11:43:30 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:43:30 --> Output Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Security Class Initialized
DEBUG - 2015-04-14 11:43:30 --> Input Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:43:31 --> Language Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Language Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Config Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Loader Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:43:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:43:31 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Session Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:43:31 --> Session routines successfully run
DEBUG - 2015-04-14 11:43:31 --> Controller Class Initialized
DEBUG - 2015-04-14 11:43:31 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:43:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:43:31 --> Email Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:43:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:43:31 --> Model Class Initialized
DEBUG - 2015-04-14 11:43:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:43:31 --> Model Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:43:31 --> Final output sent to browser
DEBUG - 2015-04-14 11:43:31 --> Total execution time: 0.9951
DEBUG - 2015-04-14 11:44:42 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:42 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:42 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:42 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:42 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:42 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:43 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:43 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:43 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:43 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:43 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:43 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:43 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:43 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:43 --> Total execution time: 0.6840
DEBUG - 2015-04-14 11:44:47 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:47 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:47 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:47 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:47 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:47 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:47 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:47 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:47 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:47 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:47 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:48 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:48 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:48 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:48 --> Total execution time: 0.6100
DEBUG - 2015-04-14 11:44:50 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:50 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:50 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:50 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:50 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:50 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:50 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:51 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:51 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:51 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:51 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:51 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:51 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:51 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:51 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:51 --> Total execution time: 0.6450
DEBUG - 2015-04-14 11:44:52 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:52 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:52 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:52 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:52 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:52 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:52 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:52 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:52 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:52 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:52 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:52 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:52 --> Total execution time: 0.6790
DEBUG - 2015-04-14 11:44:53 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:53 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:53 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:53 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:53 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:53 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:53 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:53 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:53 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:53 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:53 --> Total execution time: 0.7030
DEBUG - 2015-04-14 11:44:54 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:54 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:54 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:54 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:54 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:54 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:54 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:54 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:54 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:54 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:54 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:54 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:54 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:55 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:55 --> Total execution time: 0.7130
DEBUG - 2015-04-14 11:44:56 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:44:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:44:56 --> URI Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Router Class Initialized
DEBUG - 2015-04-14 11:44:56 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:44:56 --> Output Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Security Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Input Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:44:56 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Language Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Config Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Loader Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:44:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:44:56 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Session Class Initialized
DEBUG - 2015-04-14 11:44:56 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:44:56 --> Session routines successfully run
DEBUG - 2015-04-14 11:44:56 --> Controller Class Initialized
DEBUG - 2015-04-14 11:44:56 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:44:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:44:56 --> Email Class Initialized
DEBUG - 2015-04-14 11:44:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:44:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:44:57 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:44:57 --> Model Class Initialized
DEBUG - 2015-04-14 11:44:57 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:44:57 --> Final output sent to browser
DEBUG - 2015-04-14 11:44:57 --> Total execution time: 0.7310
DEBUG - 2015-04-14 11:46:33 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:33 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:46:33 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:46:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:46:33 --> URI Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Router Class Initialized
DEBUG - 2015-04-14 11:46:34 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:46:34 --> Output Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Security Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Input Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:46:34 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Loader Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:46:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:46:34 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Session Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:46:34 --> Session routines successfully run
DEBUG - 2015-04-14 11:46:34 --> Controller Class Initialized
DEBUG - 2015-04-14 11:46:34 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:46:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:46:34 --> Email Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:46:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:46:34 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:46:34 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:34 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:46:34 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:46:34 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:46:34 --> Final output sent to browser
DEBUG - 2015-04-14 11:46:34 --> Total execution time: 0.8790
DEBUG - 2015-04-14 11:46:36 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:36 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:46:36 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:46:36 --> URI Class Initialized
DEBUG - 2015-04-14 11:46:36 --> Router Class Initialized
ERROR - 2015-04-14 11:46:36 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:46:37 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:37 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:46:37 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:46:37 --> URI Class Initialized
DEBUG - 2015-04-14 11:46:37 --> Router Class Initialized
ERROR - 2015-04-14 11:46:38 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:46:38 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:46:38 --> URI Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Router Class Initialized
DEBUG - 2015-04-14 11:46:38 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:46:38 --> Output Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Security Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Input Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:46:38 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Loader Class Initialized
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:46:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:46:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:46:39 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:46:39 --> Session Class Initialized
DEBUG - 2015-04-14 11:46:39 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:46:39 --> Session routines successfully run
DEBUG - 2015-04-14 11:46:39 --> Controller Class Initialized
DEBUG - 2015-04-14 11:46:39 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:46:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:46:39 --> Email Class Initialized
DEBUG - 2015-04-14 11:46:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:46:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:46:39 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:46:39 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:39 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:46:39 --> Final output sent to browser
DEBUG - 2015-04-14 11:46:39 --> Total execution time: 1.2661
DEBUG - 2015-04-14 11:46:53 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:46:53 --> URI Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Router Class Initialized
DEBUG - 2015-04-14 11:46:53 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:46:53 --> Output Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Security Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Input Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:46:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Config Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Loader Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:46:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:46:53 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Session Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:46:53 --> Session routines successfully run
DEBUG - 2015-04-14 11:46:53 --> Controller Class Initialized
DEBUG - 2015-04-14 11:46:53 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:46:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:46:53 --> Email Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:46:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:46:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:46:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:46:53 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:46:54 --> Final output sent to browser
DEBUG - 2015-04-14 11:46:54 --> Total execution time: 0.8480
DEBUG - 2015-04-14 11:47:24 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:47:24 --> URI Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Router Class Initialized
DEBUG - 2015-04-14 11:47:24 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:47:24 --> Output Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Security Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Input Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:47:24 --> Language Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Language Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Loader Class Initialized
DEBUG - 2015-04-14 11:47:24 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:47:24 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:47:24 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:47:24 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:47:25 --> Session Class Initialized
DEBUG - 2015-04-14 11:47:25 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:47:25 --> Session routines successfully run
DEBUG - 2015-04-14 11:47:25 --> Controller Class Initialized
DEBUG - 2015-04-14 11:47:25 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:47:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:47:25 --> Email Class Initialized
DEBUG - 2015-04-14 11:47:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:47:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:47:25 --> Model Class Initialized
DEBUG - 2015-04-14 11:47:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:47:25 --> Model Class Initialized
DEBUG - 2015-04-14 11:47:25 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:47:25 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:47:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:47:25 --> Final output sent to browser
DEBUG - 2015-04-14 11:47:25 --> Total execution time: 0.8070
DEBUG - 2015-04-14 11:47:26 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:26 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:47:26 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:47:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:47:27 --> URI Class Initialized
DEBUG - 2015-04-14 11:47:27 --> Router Class Initialized
ERROR - 2015-04-14 11:47:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:47:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:47:28 --> URI Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Router Class Initialized
ERROR - 2015-04-14 11:47:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:47:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:47:28 --> URI Class Initialized
DEBUG - 2015-04-14 11:47:28 --> Router Class Initialized
DEBUG - 2015-04-14 11:47:29 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:47:29 --> Output Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Security Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Input Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:47:29 --> Language Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Language Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Config Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Loader Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:47:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:47:29 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Session Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:47:29 --> Session routines successfully run
DEBUG - 2015-04-14 11:47:29 --> Controller Class Initialized
DEBUG - 2015-04-14 11:47:29 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:47:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:47:29 --> Email Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:47:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:47:29 --> Model Class Initialized
DEBUG - 2015-04-14 11:47:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:47:29 --> Model Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:47:29 --> Final output sent to browser
DEBUG - 2015-04-14 11:47:29 --> Total execution time: 0.9091
DEBUG - 2015-04-14 11:48:00 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:00 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Router Class Initialized
DEBUG - 2015-04-14 11:48:00 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:48:00 --> Output Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Security Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Input Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:48:00 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Loader Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:48:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:48:00 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Session Class Initialized
DEBUG - 2015-04-14 11:48:00 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:48:00 --> Session routines successfully run
DEBUG - 2015-04-14 11:48:00 --> Controller Class Initialized
DEBUG - 2015-04-14 11:48:00 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:48:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:48:01 --> Email Class Initialized
DEBUG - 2015-04-14 11:48:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:48:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:48:01 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:48:01 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:01 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:48:01 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:48:01 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:48:01 --> Final output sent to browser
DEBUG - 2015-04-14 11:48:01 --> Total execution time: 0.8860
DEBUG - 2015-04-14 11:48:03 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:03 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:03 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:03 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:03 --> Router Class Initialized
ERROR - 2015-04-14 11:48:03 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:48:04 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:04 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:04 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:04 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:04 --> Router Class Initialized
ERROR - 2015-04-14 11:48:04 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:48:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:07 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Router Class Initialized
DEBUG - 2015-04-14 11:48:07 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:48:07 --> Output Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Security Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Input Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:48:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Loader Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:48:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:48:07 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Session Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:48:07 --> Session routines successfully run
DEBUG - 2015-04-14 11:48:07 --> Controller Class Initialized
DEBUG - 2015-04-14 11:48:07 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:48:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:48:07 --> Email Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:48:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:48:07 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:48:07 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:48:07 --> Final output sent to browser
DEBUG - 2015-04-14 11:48:07 --> Total execution time: 0.9551
DEBUG - 2015-04-14 11:48:16 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:16 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Router Class Initialized
DEBUG - 2015-04-14 11:48:16 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:48:16 --> Output Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Security Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Input Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:48:16 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Loader Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:48:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:48:16 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Session Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:48:16 --> Session routines successfully run
DEBUG - 2015-04-14 11:48:16 --> Controller Class Initialized
DEBUG - 2015-04-14 11:48:16 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:48:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:48:16 --> Email Class Initialized
DEBUG - 2015-04-14 11:48:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:48:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:48:16 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:48:16 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:17 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:48:17 --> Final output sent to browser
DEBUG - 2015-04-14 11:48:17 --> Total execution time: 0.6710
DEBUG - 2015-04-14 11:48:52 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:52 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:48:52 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:48:52 --> URI Class Initialized
DEBUG - 2015-04-14 11:48:52 --> Router Class Initialized
DEBUG - 2015-04-14 11:48:52 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:48:52 --> Output Class Initialized
DEBUG - 2015-04-14 11:48:52 --> Security Class Initialized
DEBUG - 2015-04-14 11:48:52 --> Input Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:48:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Language Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Config Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Loader Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:48:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:48:53 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Session Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:48:53 --> Session routines successfully run
DEBUG - 2015-04-14 11:48:53 --> Controller Class Initialized
DEBUG - 2015-04-14 11:48:53 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:48:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:48:53 --> Email Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:48:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:48:53 --> Final output sent to browser
DEBUG - 2015-04-14 11:48:53 --> Total execution time: 0.7380
DEBUG - 2015-04-14 11:49:05 --> Config Class Initialized
DEBUG - 2015-04-14 11:49:05 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:49:05 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:49:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:49:05 --> URI Class Initialized
DEBUG - 2015-04-14 11:49:05 --> Router Class Initialized
DEBUG - 2015-04-14 11:49:05 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:49:05 --> Output Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Security Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Input Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:49:06 --> Language Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Language Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Config Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Loader Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:49:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:49:06 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Session Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:49:06 --> Session routines successfully run
DEBUG - 2015-04-14 11:49:06 --> Controller Class Initialized
DEBUG - 2015-04-14 11:49:06 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:49:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:49:06 --> Email Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:49:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:49:06 --> Model Class Initialized
DEBUG - 2015-04-14 11:49:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:49:06 --> Model Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:49:06 --> Final output sent to browser
DEBUG - 2015-04-14 11:49:06 --> Total execution time: 0.7220
DEBUG - 2015-04-14 11:52:29 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:52:29 --> URI Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Router Class Initialized
DEBUG - 2015-04-14 11:52:29 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:52:29 --> Output Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Security Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Input Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:52:29 --> Language Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Language Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:29 --> Loader Class Initialized
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:52:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:52:30 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:52:30 --> Session Class Initialized
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:52:30 --> Session routines successfully run
DEBUG - 2015-04-14 11:52:30 --> Controller Class Initialized
DEBUG - 2015-04-14 11:52:30 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:52:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:52:30 --> Email Class Initialized
DEBUG - 2015-04-14 11:52:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:52:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:52:30 --> Model Class Initialized
DEBUG - 2015-04-14 11:52:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:52:30 --> Model Class Initialized
DEBUG - 2015-04-14 11:52:30 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:52:30 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-14 11:52:30 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 11:52:30 --> Final output sent to browser
DEBUG - 2015-04-14 11:52:30 --> Total execution time: 0.6330
DEBUG - 2015-04-14 11:52:31 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:31 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:52:31 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:52:31 --> URI Class Initialized
DEBUG - 2015-04-14 11:52:31 --> Router Class Initialized
ERROR - 2015-04-14 11:52:31 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:52:34 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:34 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:52:34 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:52:34 --> URI Class Initialized
DEBUG - 2015-04-14 11:52:34 --> Router Class Initialized
ERROR - 2015-04-14 11:52:34 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 11:52:35 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:52:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:52:35 --> URI Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Router Class Initialized
DEBUG - 2015-04-14 11:52:35 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:52:35 --> Output Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Security Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Input Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:52:35 --> Language Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Language Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Config Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Loader Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:52:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:52:35 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Session Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:52:35 --> Session routines successfully run
DEBUG - 2015-04-14 11:52:35 --> Controller Class Initialized
DEBUG - 2015-04-14 11:52:35 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:52:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:52:35 --> Email Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:52:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:52:35 --> Model Class Initialized
DEBUG - 2015-04-14 11:52:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:52:35 --> Model Class Initialized
DEBUG - 2015-04-14 11:52:35 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:52:36 --> Final output sent to browser
DEBUG - 2015-04-14 11:52:36 --> Total execution time: 0.9411
DEBUG - 2015-04-14 11:54:25 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:54:25 --> URI Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Router Class Initialized
DEBUG - 2015-04-14 11:54:25 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:54:25 --> Output Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Security Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Input Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:54:25 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Loader Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:54:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:54:25 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Session Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:54:25 --> Session routines successfully run
DEBUG - 2015-04-14 11:54:25 --> Controller Class Initialized
DEBUG - 2015-04-14 11:54:25 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:54:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:54:25 --> Email Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:54:25 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:54:25 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:25 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:54:26 --> Final output sent to browser
DEBUG - 2015-04-14 11:54:26 --> Total execution time: 0.6880
DEBUG - 2015-04-14 11:54:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:54:28 --> URI Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Router Class Initialized
DEBUG - 2015-04-14 11:54:28 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:54:28 --> Output Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Security Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Input Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:54:28 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Loader Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:54:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:54:28 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Session Class Initialized
DEBUG - 2015-04-14 11:54:28 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:54:28 --> Session routines successfully run
DEBUG - 2015-04-14 11:54:28 --> Controller Class Initialized
DEBUG - 2015-04-14 11:54:28 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:54:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:54:29 --> Email Class Initialized
DEBUG - 2015-04-14 11:54:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:54:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:54:29 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:54:29 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:29 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:54:29 --> Final output sent to browser
DEBUG - 2015-04-14 11:54:29 --> Total execution time: 0.7750
DEBUG - 2015-04-14 11:54:37 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:54:37 --> URI Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Router Class Initialized
DEBUG - 2015-04-14 11:54:37 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:54:37 --> Output Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Security Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Input Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:54:37 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Loader Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:54:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:54:37 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Session Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:54:37 --> Session routines successfully run
DEBUG - 2015-04-14 11:54:37 --> Controller Class Initialized
DEBUG - 2015-04-14 11:54:37 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:54:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:54:37 --> Email Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:54:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:54:37 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:54:37 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:54:37 --> Final output sent to browser
DEBUG - 2015-04-14 11:54:37 --> Total execution time: 0.7240
DEBUG - 2015-04-14 11:54:39 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:54:39 --> URI Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Router Class Initialized
DEBUG - 2015-04-14 11:54:39 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:54:39 --> Output Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Security Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Input Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:54:39 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Language Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Config Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Loader Class Initialized
DEBUG - 2015-04-14 11:54:39 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:54:39 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:54:39 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:54:39 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:54:39 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:54:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:54:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:54:40 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:54:40 --> Session Class Initialized
DEBUG - 2015-04-14 11:54:40 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:54:40 --> Session routines successfully run
DEBUG - 2015-04-14 11:54:40 --> Controller Class Initialized
DEBUG - 2015-04-14 11:54:40 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:54:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:54:40 --> Email Class Initialized
DEBUG - 2015-04-14 11:54:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:54:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:54:40 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:54:40 --> Model Class Initialized
DEBUG - 2015-04-14 11:54:40 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:54:40 --> Final output sent to browser
DEBUG - 2015-04-14 11:54:40 --> Total execution time: 0.7420
DEBUG - 2015-04-14 11:55:10 --> Config Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:55:10 --> URI Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Router Class Initialized
DEBUG - 2015-04-14 11:55:10 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:55:10 --> Output Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Security Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Input Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:55:10 --> Language Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Language Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Config Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Loader Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:55:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:55:10 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Session Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:55:10 --> Session routines successfully run
DEBUG - 2015-04-14 11:55:10 --> Controller Class Initialized
DEBUG - 2015-04-14 11:55:10 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:55:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:55:10 --> Email Class Initialized
DEBUG - 2015-04-14 11:55:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:55:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:55:10 --> Model Class Initialized
DEBUG - 2015-04-14 11:55:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:55:10 --> Model Class Initialized
DEBUG - 2015-04-14 11:55:11 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:55:11 --> Final output sent to browser
DEBUG - 2015-04-14 11:55:11 --> Total execution time: 1.0031
DEBUG - 2015-04-14 11:55:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Hooks Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Utf8 Class Initialized
DEBUG - 2015-04-14 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 11:55:12 --> URI Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Router Class Initialized
DEBUG - 2015-04-14 11:55:12 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-14 11:55:12 --> Output Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Security Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Input Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 11:55:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Language Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Config Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Loader Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: url_helper
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: form_helper
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: language_helper
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: user_helper
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: date_helper
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 11:55:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 11:55:12 --> Database Driver Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Session Class Initialized
DEBUG - 2015-04-14 11:55:12 --> Helper loaded: string_helper
DEBUG - 2015-04-14 11:55:13 --> Session routines successfully run
DEBUG - 2015-04-14 11:55:13 --> Controller Class Initialized
DEBUG - 2015-04-14 11:55:13 --> User MX_Controller Initialized
DEBUG - 2015-04-14 11:55:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 11:55:13 --> Email Class Initialized
DEBUG - 2015-04-14 11:55:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 11:55:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-14 11:55:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-14 11:55:13 --> Form Validation Class Initialized
DEBUG - 2015-04-14 11:55:13 --> Final output sent to browser
DEBUG - 2015-04-14 11:55:13 --> Total execution time: 0.8100
DEBUG - 2015-04-14 13:50:06 --> Config Class Initialized
DEBUG - 2015-04-14 13:50:06 --> Hooks Class Initialized
DEBUG - 2015-04-14 13:50:06 --> Utf8 Class Initialized
DEBUG - 2015-04-14 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 13:50:06 --> URI Class Initialized
DEBUG - 2015-04-14 13:50:06 --> Router Class Initialized
ERROR - 2015-04-14 13:50:06 --> 404 Page Not Found --> 
DEBUG - 2015-04-14 13:50:40 --> Config Class Initialized
DEBUG - 2015-04-14 13:50:40 --> Hooks Class Initialized
DEBUG - 2015-04-14 13:50:40 --> Utf8 Class Initialized
DEBUG - 2015-04-14 13:50:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 13:50:40 --> URI Class Initialized
DEBUG - 2015-04-14 13:50:40 --> Router Class Initialized
DEBUG - 2015-04-14 13:50:41 --> No URI present. Default controller set.
DEBUG - 2015-04-14 13:50:41 --> Output Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Security Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Input Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 13:50:41 --> Language Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Language Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Config Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Loader Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: url_helper
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: form_helper
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: language_helper
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: user_helper
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: date_helper
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-14 13:50:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-14 13:50:41 --> Database Driver Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Session Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: string_helper
DEBUG - 2015-04-14 13:50:41 --> Session routines successfully run
DEBUG - 2015-04-14 13:50:41 --> Controller Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Login MX_Controller Initialized
DEBUG - 2015-04-14 13:50:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-14 13:50:41 --> Email Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-14 13:50:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-14 13:50:41 --> Model Class Initialized
DEBUG - 2015-04-14 13:50:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-14 13:50:41 --> Model Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Form Validation Class Initialized
DEBUG - 2015-04-14 13:50:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-14 13:50:41 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-14 13:50:42 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-14 13:50:42 --> Final output sent to browser
DEBUG - 2015-04-14 13:50:42 --> Total execution time: 1.5791
DEBUG - 2015-04-14 13:50:42 --> Config Class Initialized
DEBUG - 2015-04-14 13:50:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 13:50:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 13:50:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 13:50:42 --> URI Class Initialized
DEBUG - 2015-04-14 13:50:42 --> Router Class Initialized
ERROR - 2015-04-14 13:50:42 --> 404 Page Not Found --> 
