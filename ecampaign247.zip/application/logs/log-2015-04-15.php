<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-15 05:35:30 --> Config Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 05:35:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 05:35:30 --> URI Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Router Class Initialized
DEBUG - 2015-04-15 05:35:30 --> No URI present. Default controller set.
DEBUG - 2015-04-15 05:35:30 --> Output Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Security Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Input Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 05:35:30 --> Language Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Language Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Config Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Loader Class Initialized
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: user_helper
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: date_helper
DEBUG - 2015-04-15 05:35:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 05:35:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 05:35:30 --> Database Driver Class Initialized
DEBUG - 2015-04-15 05:35:31 --> Session Class Initialized
DEBUG - 2015-04-15 05:35:31 --> Helper loaded: string_helper
DEBUG - 2015-04-15 05:35:31 --> A session cookie was not found.
DEBUG - 2015-04-15 05:35:31 --> Session routines successfully run
DEBUG - 2015-04-15 05:35:31 --> Controller Class Initialized
DEBUG - 2015-04-15 05:35:31 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 05:35:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 05:35:31 --> Email Class Initialized
DEBUG - 2015-04-15 05:35:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 05:35:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 05:35:32 --> Model Class Initialized
DEBUG - 2015-04-15 05:35:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 05:35:32 --> Model Class Initialized
DEBUG - 2015-04-15 05:35:32 --> Form Validation Class Initialized
DEBUG - 2015-04-15 05:35:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 05:35:32 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-15 05:35:32 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-15 05:35:32 --> Final output sent to browser
DEBUG - 2015-04-15 05:35:32 --> Total execution time: 2.2511
DEBUG - 2015-04-15 05:36:44 --> Config Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Hooks Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Utf8 Class Initialized
DEBUG - 2015-04-15 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 05:36:45 --> URI Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Router Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Output Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Security Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Input Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 05:36:45 --> Language Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Language Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Config Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Loader Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: url_helper
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: form_helper
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: language_helper
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: user_helper
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: date_helper
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 05:36:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 05:36:45 --> Database Driver Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Session Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: string_helper
DEBUG - 2015-04-15 05:36:45 --> Session routines successfully run
DEBUG - 2015-04-15 05:36:45 --> Controller Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 05:36:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 05:36:45 --> Email Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 05:36:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 05:36:45 --> Model Class Initialized
DEBUG - 2015-04-15 05:36:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 05:36:45 --> Model Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Form Validation Class Initialized
DEBUG - 2015-04-15 05:36:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 05:36:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-15 05:36:46 --> Config Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 05:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 05:36:46 --> URI Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Router Class Initialized
DEBUG - 2015-04-15 05:36:46 --> No URI present. Default controller set.
DEBUG - 2015-04-15 05:36:46 --> Output Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Security Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Input Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 05:36:46 --> Language Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Language Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Config Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Loader Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: url_helper
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: form_helper
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: language_helper
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: user_helper
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: date_helper
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 05:36:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 05:36:46 --> Database Driver Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Session Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: string_helper
DEBUG - 2015-04-15 05:36:46 --> Session routines successfully run
DEBUG - 2015-04-15 05:36:46 --> Controller Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 05:36:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 05:36:46 --> Email Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 05:36:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 05:36:46 --> Model Class Initialized
DEBUG - 2015-04-15 05:36:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 05:36:46 --> Model Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Form Validation Class Initialized
DEBUG - 2015-04-15 05:36:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 05:36:46 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 05:36:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 05:36:46 --> Final output sent to browser
DEBUG - 2015-04-15 05:36:46 --> Total execution time: 0.6970
DEBUG - 2015-04-15 05:36:47 --> Config Class Initialized
DEBUG - 2015-04-15 05:36:47 --> Hooks Class Initialized
DEBUG - 2015-04-15 05:36:47 --> Utf8 Class Initialized
DEBUG - 2015-04-15 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 05:36:47 --> URI Class Initialized
DEBUG - 2015-04-15 05:36:47 --> Router Class Initialized
ERROR - 2015-04-15 05:36:47 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 06:32:39 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:32:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:32:39 --> URI Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Router Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Output Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Security Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Input Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 06:32:39 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Loader Class Initialized
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 06:32:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 06:32:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 06:32:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 06:32:40 --> Session Class Initialized
DEBUG - 2015-04-15 06:32:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 06:32:40 --> Session routines successfully run
DEBUG - 2015-04-15 06:32:40 --> Controller Class Initialized
DEBUG - 2015-04-15 06:32:40 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 06:32:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 06:32:41 --> Email Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 06:32:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 06:32:41 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 06:32:41 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Form Validation Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 06:32:41 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-04-15 06:32:41 --> File loaded: application/views/../modules_core/login/views/create_user.php
DEBUG - 2015-04-15 06:32:41 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 06:32:41 --> Final output sent to browser
DEBUG - 2015-04-15 06:32:41 --> Total execution time: 1.9641
DEBUG - 2015-04-15 06:32:41 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:32:41 --> URI Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Router Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Output Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Security Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Input Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 06:32:41 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Loader Class Initialized
DEBUG - 2015-04-15 06:32:41 --> Helper loaded: url_helper
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: form_helper
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: language_helper
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: user_helper
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: date_helper
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 06:32:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 06:32:42 --> Database Driver Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Session Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: string_helper
DEBUG - 2015-04-15 06:32:42 --> Session routines successfully run
DEBUG - 2015-04-15 06:32:42 --> Controller Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 06:32:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 06:32:42 --> Email Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 06:32:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 06:32:42 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 06:32:42 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Form Validation Class Initialized
DEBUG - 2015-04-15 06:32:42 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 06:32:42 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 06:32:56 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:32:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:32:56 --> URI Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Router Class Initialized
DEBUG - 2015-04-15 06:32:56 --> No URI present. Default controller set.
DEBUG - 2015-04-15 06:32:56 --> Output Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Security Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Input Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 06:32:56 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Language Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Loader Class Initialized
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: url_helper
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: form_helper
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: language_helper
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 06:32:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 06:32:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 06:32:56 --> Database Driver Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Session Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Helper loaded: string_helper
DEBUG - 2015-04-15 06:32:57 --> Session routines successfully run
DEBUG - 2015-04-15 06:32:57 --> Controller Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 06:32:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 06:32:57 --> Email Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 06:32:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 06:32:57 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 06:32:57 --> Model Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Form Validation Class Initialized
DEBUG - 2015-04-15 06:32:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 06:32:57 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 06:32:57 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 06:32:57 --> Final output sent to browser
DEBUG - 2015-04-15 06:32:57 --> Total execution time: 1.7301
DEBUG - 2015-04-15 06:32:58 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:32:58 --> URI Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Router Class Initialized
ERROR - 2015-04-15 06:32:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 06:32:58 --> Config Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:32:58 --> URI Class Initialized
DEBUG - 2015-04-15 06:32:58 --> Router Class Initialized
ERROR - 2015-04-15 06:32:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 06:33:01 --> Config Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:33:01 --> URI Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Router Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Output Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Security Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Input Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 06:33:01 --> Language Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Language Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Config Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Loader Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: language_helper
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: user_helper
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: date_helper
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 06:33:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 06:33:01 --> Database Driver Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Session Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: string_helper
DEBUG - 2015-04-15 06:33:01 --> Session routines successfully run
DEBUG - 2015-04-15 06:33:01 --> Controller Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 06:33:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 06:33:01 --> Email Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 06:33:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 06:33:01 --> Model Class Initialized
DEBUG - 2015-04-15 06:33:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 06:33:01 --> Model Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Form Validation Class Initialized
DEBUG - 2015-04-15 06:33:01 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 701
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 726
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 728
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Indirect modification of overloaded property Login::$data has no effect C:\xampp\htdocs\ecampaign247\application\modules_core\login\controllers\login.php 734
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
ERROR - 2015-04-15 06:33:01 --> Severity: Notice  --> Undefined property: CI::$data C:\xampp\htdocs\ecampaign247\application\third_party\MX\Controller.php 58
DEBUG - 2015-04-15 06:53:57 --> Config Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Hooks Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Utf8 Class Initialized
DEBUG - 2015-04-15 06:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 06:53:57 --> URI Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Router Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Output Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Security Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Input Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 06:53:57 --> Language Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Language Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Config Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Loader Class Initialized
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: url_helper
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: form_helper
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: language_helper
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: user_helper
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: date_helper
DEBUG - 2015-04-15 06:53:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 06:53:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 06:53:57 --> Database Driver Class Initialized
DEBUG - 2015-04-15 06:53:58 --> Session Class Initialized
DEBUG - 2015-04-15 06:53:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 06:53:58 --> Session routines successfully run
DEBUG - 2015-04-15 06:53:58 --> Controller Class Initialized
DEBUG - 2015-04-15 06:53:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 06:53:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 06:53:59 --> Email Class Initialized
DEBUG - 2015-04-15 06:53:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 06:53:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 06:53:59 --> Model Class Initialized
DEBUG - 2015-04-15 06:53:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 06:53:59 --> Model Class Initialized
DEBUG - 2015-04-15 06:53:59 --> Form Validation Class Initialized
DEBUG - 2015-04-15 06:53:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:02:19 --> Config Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:02:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:02:19 --> URI Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Router Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Output Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Security Class Initialized
DEBUG - 2015-04-15 07:02:19 --> Input Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:02:20 --> Language Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Language Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Config Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Loader Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:02:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:02:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Session Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:02:20 --> Session routines successfully run
DEBUG - 2015-04-15 07:02:20 --> Controller Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:02:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:02:20 --> Email Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:02:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:02:20 --> Model Class Initialized
DEBUG - 2015-04-15 07:02:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:02:20 --> Model Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:02:20 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:02:20 --> File loaded: application/modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:02:20 --> Final output sent to browser
DEBUG - 2015-04-15 07:02:20 --> Total execution time: 0.6210
DEBUG - 2015-04-15 07:07:36 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:07:36 --> URI Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Router Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Output Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Security Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Input Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:07:36 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:36 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Loader Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:07:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:07:37 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Session Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:07:37 --> Session routines successfully run
DEBUG - 2015-04-15 07:07:37 --> Controller Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:07:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:07:37 --> Email Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:07:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:07:37 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:07:37 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:07:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:07:37 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:07:37 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:07:37 --> Final output sent to browser
DEBUG - 2015-04-15 07:07:37 --> Total execution time: 0.6460
DEBUG - 2015-04-15 07:07:38 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:07:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:07:38 --> URI Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Router Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Output Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Security Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Input Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:07:38 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Loader Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:07:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:07:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Session Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:07:38 --> Session routines successfully run
DEBUG - 2015-04-15 07:07:38 --> Controller Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:07:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:07:38 --> Email Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:07:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:07:38 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:07:38 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:07:38 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:07:38 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:07:39 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:07:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:07:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:07:39 --> URI Class Initialized
DEBUG - 2015-04-15 07:07:39 --> Router Class Initialized
DEBUG - 2015-04-15 07:07:39 --> Output Class Initialized
DEBUG - 2015-04-15 07:07:39 --> Security Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Input Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:07:40 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Language Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Config Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Loader Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:07:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:07:40 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Session Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:07:40 --> Session routines successfully run
DEBUG - 2015-04-15 07:07:40 --> Controller Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:07:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:07:40 --> Email Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:07:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:07:40 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:07:40 --> Model Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:07:40 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:07:40 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:09:36 --> Config Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:09:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:09:36 --> URI Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Router Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Output Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Security Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Input Class Initialized
DEBUG - 2015-04-15 07:09:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:09:36 --> Language Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Language Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Config Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Loader Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:09:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:09:37 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Session Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:09:37 --> Session routines successfully run
DEBUG - 2015-04-15 07:09:37 --> Controller Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:09:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:09:37 --> Email Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:09:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:09:37 --> Model Class Initialized
DEBUG - 2015-04-15 07:09:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:09:37 --> Model Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:09:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:09:37 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:09:37 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:09:37 --> Final output sent to browser
DEBUG - 2015-04-15 07:09:37 --> Total execution time: 0.6330
DEBUG - 2015-04-15 07:09:38 --> Config Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:09:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:09:38 --> URI Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Router Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Output Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Security Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Input Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:09:38 --> Language Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Language Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Config Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Loader Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:09:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:09:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Session Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:09:38 --> Session routines successfully run
DEBUG - 2015-04-15 07:09:38 --> Controller Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:09:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:09:38 --> Email Class Initialized
DEBUG - 2015-04-15 07:09:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:09:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:09:38 --> Model Class Initialized
DEBUG - 2015-04-15 07:09:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:09:38 --> Model Class Initialized
DEBUG - 2015-04-15 07:09:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:09:39 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:09:39 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:13:33 --> Config Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:13:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:13:33 --> URI Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Router Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Output Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Security Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Input Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:13:33 --> Language Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Language Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Config Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Loader Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:13:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:13:33 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Session Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:13:33 --> Session routines successfully run
DEBUG - 2015-04-15 07:13:33 --> Controller Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:13:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:13:33 --> Email Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:13:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:13:33 --> Model Class Initialized
DEBUG - 2015-04-15 07:13:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:13:33 --> Model Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:13:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:13:33 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:13:33 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:13:33 --> Final output sent to browser
DEBUG - 2015-04-15 07:13:33 --> Total execution time: 0.4600
DEBUG - 2015-04-15 07:13:34 --> Config Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:13:34 --> URI Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Router Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Output Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Security Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Input Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:13:34 --> Language Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Language Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Config Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Loader Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:13:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:13:34 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Session Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:13:34 --> Session routines successfully run
DEBUG - 2015-04-15 07:13:34 --> Controller Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:13:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:13:34 --> Email Class Initialized
DEBUG - 2015-04-15 07:13:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:13:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:13:34 --> Model Class Initialized
DEBUG - 2015-04-15 07:13:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:13:35 --> Model Class Initialized
DEBUG - 2015-04-15 07:13:35 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:13:35 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:13:35 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:16:52 --> Config Class Initialized
DEBUG - 2015-04-15 07:16:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:16:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:16:53 --> URI Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Router Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Output Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Security Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Input Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:16:53 --> Language Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Language Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Config Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Loader Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:16:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:16:53 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Session Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:16:53 --> Session routines successfully run
DEBUG - 2015-04-15 07:16:53 --> Controller Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:16:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:16:53 --> Email Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:16:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:16:53 --> Model Class Initialized
DEBUG - 2015-04-15 07:16:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:16:53 --> Model Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:16:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:16:53 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:16:53 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:16:53 --> Final output sent to browser
DEBUG - 2015-04-15 07:16:53 --> Total execution time: 0.5770
DEBUG - 2015-04-15 07:16:54 --> Config Class Initialized
DEBUG - 2015-04-15 07:16:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:16:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:16:55 --> URI Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Router Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Output Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Security Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Input Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:16:55 --> Language Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Language Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Config Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Loader Class Initialized
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:16:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:16:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:16:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Session Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:16:56 --> Session routines successfully run
DEBUG - 2015-04-15 07:16:56 --> Controller Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:16:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:16:56 --> Email Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:16:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:16:56 --> Model Class Initialized
DEBUG - 2015-04-15 07:16:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:16:56 --> Model Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:16:56 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:16:56 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:17:30 --> Config Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:17:30 --> URI Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Router Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Output Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Security Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Input Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:17:30 --> Language Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Language Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Config Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Loader Class Initialized
DEBUG - 2015-04-15 07:17:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:17:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:17:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:17:31 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:17:31 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:17:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:17:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:17:31 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Session Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:17:31 --> Session routines successfully run
DEBUG - 2015-04-15 07:17:31 --> Controller Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:17:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:17:31 --> Email Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:17:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:17:31 --> Model Class Initialized
DEBUG - 2015-04-15 07:17:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:17:31 --> Model Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:17:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:17:31 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:17:31 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:17:31 --> Final output sent to browser
DEBUG - 2015-04-15 07:17:31 --> Total execution time: 1.0741
DEBUG - 2015-04-15 07:17:33 --> Config Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:17:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:17:33 --> URI Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Router Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Output Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Security Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Input Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:17:33 --> Language Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Language Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Config Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Loader Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:17:33 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:17:33 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Session Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:17:33 --> Session routines successfully run
DEBUG - 2015-04-15 07:17:33 --> Controller Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:17:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:17:33 --> Email Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:17:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:17:33 --> Model Class Initialized
DEBUG - 2015-04-15 07:17:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:17:33 --> Model Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:17:33 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:17:34 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:20:17 --> Config Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:20:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:20:17 --> URI Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Router Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Output Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Security Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Input Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:20:17 --> Language Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Language Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Config Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Loader Class Initialized
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:20:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:20:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:20:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Session Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:20:18 --> Session routines successfully run
DEBUG - 2015-04-15 07:20:18 --> Controller Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:20:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:20:18 --> Email Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:20:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:20:18 --> Model Class Initialized
DEBUG - 2015-04-15 07:20:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:20:18 --> Model Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:20:18 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:20:18 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:20:18 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:20:18 --> Final output sent to browser
DEBUG - 2015-04-15 07:20:18 --> Total execution time: 0.4650
DEBUG - 2015-04-15 07:20:19 --> Config Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:20:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:20:19 --> URI Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Router Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Output Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Security Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Input Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:20:19 --> Language Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Language Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Config Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Loader Class Initialized
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:20:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:20:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:20:19 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Session Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:20:20 --> Session routines successfully run
DEBUG - 2015-04-15 07:20:20 --> Controller Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:20:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:20:20 --> Email Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:20:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:20:20 --> Model Class Initialized
DEBUG - 2015-04-15 07:20:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:20:20 --> Model Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:20:20 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:20:20 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:30:41 --> Config Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:30:41 --> URI Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Router Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Output Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Security Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Input Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:30:41 --> Language Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Language Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Config Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Loader Class Initialized
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:30:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:30:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:30:42 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Session Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:30:42 --> Session routines successfully run
DEBUG - 2015-04-15 07:30:42 --> Controller Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:30:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:30:42 --> Email Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:30:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:30:42 --> Model Class Initialized
DEBUG - 2015-04-15 07:30:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:30:42 --> Model Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:30:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:30:42 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:30:42 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:30:42 --> Final output sent to browser
DEBUG - 2015-04-15 07:30:42 --> Total execution time: 0.4730
DEBUG - 2015-04-15 07:30:44 --> Config Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:30:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:30:44 --> URI Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Router Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Output Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Security Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Input Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:30:44 --> Language Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Language Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Config Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Loader Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:30:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:30:44 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Session Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:30:44 --> Session routines successfully run
DEBUG - 2015-04-15 07:30:44 --> Controller Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:30:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:30:44 --> Email Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:30:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:30:44 --> Model Class Initialized
DEBUG - 2015-04-15 07:30:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:30:44 --> Model Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:30:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:30:44 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:31:25 --> Config Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:31:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:31:25 --> URI Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Router Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Output Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Security Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Input Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:31:25 --> Language Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Language Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Config Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Loader Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:31:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:31:25 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Session Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:31:25 --> Session routines successfully run
DEBUG - 2015-04-15 07:31:25 --> Controller Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:31:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:31:25 --> Email Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:31:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:31:25 --> Model Class Initialized
DEBUG - 2015-04-15 07:31:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:31:25 --> Model Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:31:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:31:25 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 07:31:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:31:25 --> Final output sent to browser
DEBUG - 2015-04-15 07:31:25 --> Total execution time: 0.4240
DEBUG - 2015-04-15 07:31:26 --> Config Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:31:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:31:26 --> URI Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Router Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Output Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Security Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Input Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:31:26 --> Language Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Language Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Config Class Initialized
DEBUG - 2015-04-15 07:31:26 --> Loader Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:31:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:31:27 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Session Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:31:27 --> Session routines successfully run
DEBUG - 2015-04-15 07:31:27 --> Controller Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:31:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:31:27 --> Email Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:31:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:31:27 --> Model Class Initialized
DEBUG - 2015-04-15 07:31:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:31:27 --> Model Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:31:27 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 07:31:27 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 07:32:41 --> Config Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:32:41 --> URI Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Router Class Initialized
DEBUG - 2015-04-15 07:32:41 --> No URI present. Default controller set.
DEBUG - 2015-04-15 07:32:41 --> Output Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Security Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Input Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 07:32:41 --> Language Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Language Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Config Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Loader Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: url_helper
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: form_helper
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: language_helper
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: user_helper
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: date_helper
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 07:32:41 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 07:32:41 --> Database Driver Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Session Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: string_helper
DEBUG - 2015-04-15 07:32:41 --> Session routines successfully run
DEBUG - 2015-04-15 07:32:41 --> Controller Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 07:32:41 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 07:32:41 --> Email Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 07:32:41 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 07:32:41 --> Model Class Initialized
DEBUG - 2015-04-15 07:32:41 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 07:32:41 --> Model Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Form Validation Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 07:32:41 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 07:32:41 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 07:32:41 --> Final output sent to browser
DEBUG - 2015-04-15 07:32:41 --> Total execution time: 0.5470
DEBUG - 2015-04-15 07:32:41 --> Config Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 07:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 07:32:41 --> URI Class Initialized
DEBUG - 2015-04-15 07:32:41 --> Router Class Initialized
ERROR - 2015-04-15 07:32:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:10:27 --> Config Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:10:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:10:27 --> URI Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Router Class Initialized
DEBUG - 2015-04-15 08:10:27 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:10:27 --> Output Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Security Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Input Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:10:27 --> Language Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Language Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Config Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Loader Class Initialized
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:10:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:10:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:10:27 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Session Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:10:28 --> Session routines successfully run
DEBUG - 2015-04-15 08:10:28 --> Controller Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:10:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:10:28 --> Email Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:10:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:10:28 --> Model Class Initialized
DEBUG - 2015-04-15 08:10:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:10:28 --> Model Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:10:28 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:10:28 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:10:28 --> Final output sent to browser
DEBUG - 2015-04-15 08:10:28 --> Total execution time: 0.9921
DEBUG - 2015-04-15 08:10:28 --> Config Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:10:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:10:28 --> URI Class Initialized
DEBUG - 2015-04-15 08:10:28 --> Router Class Initialized
ERROR - 2015-04-15 08:10:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:17:39 --> Config Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:17:39 --> URI Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Router Class Initialized
DEBUG - 2015-04-15 08:17:39 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:17:39 --> Output Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Security Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Input Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:17:39 --> Language Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Language Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Config Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Loader Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:17:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:17:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Session Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:17:39 --> Session routines successfully run
DEBUG - 2015-04-15 08:17:39 --> Controller Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:17:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:17:39 --> Email Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:17:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:17:39 --> Model Class Initialized
DEBUG - 2015-04-15 08:17:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:17:39 --> Model Class Initialized
DEBUG - 2015-04-15 08:17:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:17:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:17:40 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:17:40 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:17:40 --> Final output sent to browser
DEBUG - 2015-04-15 08:17:40 --> Total execution time: 0.6740
DEBUG - 2015-04-15 08:17:41 --> Config Class Initialized
DEBUG - 2015-04-15 08:17:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:17:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:17:41 --> URI Class Initialized
DEBUG - 2015-04-15 08:17:41 --> Router Class Initialized
ERROR - 2015-04-15 08:17:41 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:17:49 --> Config Class Initialized
DEBUG - 2015-04-15 08:17:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:17:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:17:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:17:49 --> URI Class Initialized
DEBUG - 2015-04-15 08:17:49 --> Router Class Initialized
ERROR - 2015-04-15 08:17:49 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:18:23 --> Config Class Initialized
DEBUG - 2015-04-15 08:18:23 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:18:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:18:24 --> URI Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Router Class Initialized
DEBUG - 2015-04-15 08:18:24 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:18:24 --> Output Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Security Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Input Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:18:24 --> Language Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Language Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Config Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Loader Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:18:24 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:18:24 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Session Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:18:24 --> Session routines successfully run
DEBUG - 2015-04-15 08:18:24 --> Controller Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:18:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:18:24 --> Email Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:18:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:18:24 --> Model Class Initialized
DEBUG - 2015-04-15 08:18:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:18:24 --> Model Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:18:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:18:24 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:18:24 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:18:24 --> Final output sent to browser
DEBUG - 2015-04-15 08:18:24 --> Total execution time: 0.7470
DEBUG - 2015-04-15 08:20:51 --> Config Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:20:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:20:51 --> URI Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Router Class Initialized
DEBUG - 2015-04-15 08:20:51 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:20:51 --> Output Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Security Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Input Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:20:51 --> Language Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Language Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Config Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Loader Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:20:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:20:51 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Session Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:20:51 --> Session routines successfully run
DEBUG - 2015-04-15 08:20:51 --> Controller Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:20:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:20:51 --> Email Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:20:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:20:51 --> Model Class Initialized
DEBUG - 2015-04-15 08:20:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:20:51 --> Model Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:20:51 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:20:51 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:20:51 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:20:51 --> Final output sent to browser
DEBUG - 2015-04-15 08:20:51 --> Total execution time: 0.7210
DEBUG - 2015-04-15 08:20:53 --> Config Class Initialized
DEBUG - 2015-04-15 08:20:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:20:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:20:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:20:53 --> URI Class Initialized
DEBUG - 2015-04-15 08:20:53 --> Router Class Initialized
ERROR - 2015-04-15 08:20:53 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:20:54 --> Config Class Initialized
DEBUG - 2015-04-15 08:20:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:20:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:20:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:20:54 --> URI Class Initialized
DEBUG - 2015-04-15 08:20:54 --> Router Class Initialized
ERROR - 2015-04-15 08:20:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:22:45 --> Config Class Initialized
DEBUG - 2015-04-15 08:22:45 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:22:45 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:22:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:22:45 --> URI Class Initialized
DEBUG - 2015-04-15 08:22:45 --> Router Class Initialized
DEBUG - 2015-04-15 08:22:45 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:22:45 --> Output Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Security Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Input Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:22:46 --> Language Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Language Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Config Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Loader Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:22:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:22:46 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Session Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:22:46 --> Session routines successfully run
DEBUG - 2015-04-15 08:22:46 --> Controller Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:22:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:22:46 --> Email Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:22:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:22:46 --> Model Class Initialized
DEBUG - 2015-04-15 08:22:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:22:46 --> Model Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:22:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:22:46 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:22:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:22:46 --> Final output sent to browser
DEBUG - 2015-04-15 08:22:46 --> Total execution time: 0.9341
DEBUG - 2015-04-15 08:22:47 --> Config Class Initialized
DEBUG - 2015-04-15 08:22:47 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:22:47 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:22:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:22:47 --> URI Class Initialized
DEBUG - 2015-04-15 08:22:48 --> Router Class Initialized
ERROR - 2015-04-15 08:22:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:22:50 --> Config Class Initialized
DEBUG - 2015-04-15 08:22:50 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:22:50 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:22:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:22:50 --> URI Class Initialized
DEBUG - 2015-04-15 08:22:50 --> Router Class Initialized
ERROR - 2015-04-15 08:22:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:24:03 --> Config Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:24:03 --> URI Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Router Class Initialized
DEBUG - 2015-04-15 08:24:03 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:24:03 --> Output Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Security Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Input Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:24:03 --> Language Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Language Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Config Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Loader Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:24:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:24:03 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Session Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:24:03 --> Session routines successfully run
DEBUG - 2015-04-15 08:24:03 --> Controller Class Initialized
DEBUG - 2015-04-15 08:24:03 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:24:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:24:04 --> Email Class Initialized
DEBUG - 2015-04-15 08:24:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:24:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:24:04 --> Model Class Initialized
DEBUG - 2015-04-15 08:24:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:24:04 --> Model Class Initialized
DEBUG - 2015-04-15 08:24:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:24:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:24:04 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:24:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:24:04 --> Final output sent to browser
DEBUG - 2015-04-15 08:24:04 --> Total execution time: 0.6480
DEBUG - 2015-04-15 08:24:05 --> Config Class Initialized
DEBUG - 2015-04-15 08:24:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:24:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:24:05 --> URI Class Initialized
DEBUG - 2015-04-15 08:24:05 --> Router Class Initialized
ERROR - 2015-04-15 08:24:05 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:26:39 --> Config Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:26:39 --> URI Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Router Class Initialized
DEBUG - 2015-04-15 08:26:39 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:26:39 --> Output Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Security Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Input Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:26:39 --> Language Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Language Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Config Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Loader Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:26:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:26:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Session Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:26:39 --> Session routines successfully run
DEBUG - 2015-04-15 08:26:39 --> Controller Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:26:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:26:39 --> Email Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:26:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-15 08:26:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:26:39 --> Model Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:26:39 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:26:39 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:26:39 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:26:39 --> Final output sent to browser
DEBUG - 2015-04-15 08:26:40 --> Total execution time: 0.8430
DEBUG - 2015-04-15 08:26:40 --> Config Class Initialized
DEBUG - 2015-04-15 08:26:40 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:26:40 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:26:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:26:40 --> URI Class Initialized
DEBUG - 2015-04-15 08:26:40 --> Router Class Initialized
ERROR - 2015-04-15 08:26:40 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:26:42 --> Config Class Initialized
DEBUG - 2015-04-15 08:26:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:26:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:26:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:26:42 --> URI Class Initialized
DEBUG - 2015-04-15 08:26:42 --> Router Class Initialized
ERROR - 2015-04-15 08:26:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:28:45 --> Config Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:28:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:28:45 --> URI Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Router Class Initialized
DEBUG - 2015-04-15 08:28:45 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:28:45 --> Output Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Security Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Input Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:28:45 --> Language Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Language Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Config Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Loader Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:28:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:28:45 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Session Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:28:45 --> Session routines successfully run
DEBUG - 2015-04-15 08:28:45 --> Controller Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:28:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:28:45 --> Email Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:28:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:28:45 --> Model Class Initialized
DEBUG - 2015-04-15 08:28:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:28:45 --> Model Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:28:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:28:46 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:28:46 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:28:46 --> Final output sent to browser
DEBUG - 2015-04-15 08:28:46 --> Total execution time: 0.9611
DEBUG - 2015-04-15 08:28:47 --> Config Class Initialized
DEBUG - 2015-04-15 08:28:48 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:28:48 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:28:48 --> URI Class Initialized
DEBUG - 2015-04-15 08:28:48 --> Router Class Initialized
ERROR - 2015-04-15 08:28:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:32:34 --> Config Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:32:34 --> URI Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Router Class Initialized
DEBUG - 2015-04-15 08:32:34 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:32:34 --> Output Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Security Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Input Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:32:34 --> Language Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Language Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Config Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Loader Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:32:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:32:34 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Session Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:32:34 --> Session routines successfully run
DEBUG - 2015-04-15 08:32:34 --> Controller Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:32:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:32:34 --> Email Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:32:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:32:34 --> Model Class Initialized
DEBUG - 2015-04-15 08:32:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:32:34 --> Model Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:32:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:32:34 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:32:34 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:32:34 --> Final output sent to browser
DEBUG - 2015-04-15 08:32:34 --> Total execution time: 0.7490
DEBUG - 2015-04-15 08:32:36 --> Config Class Initialized
DEBUG - 2015-04-15 08:32:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:32:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:32:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:32:36 --> URI Class Initialized
DEBUG - 2015-04-15 08:32:36 --> Router Class Initialized
ERROR - 2015-04-15 08:32:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:38:02 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:02 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Router Class Initialized
DEBUG - 2015-04-15 08:38:02 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:38:02 --> Output Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Security Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Input Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:38:02 --> Language Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Language Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Loader Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:38:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:38:02 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Session Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:38:02 --> Session routines successfully run
DEBUG - 2015-04-15 08:38:02 --> Controller Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:38:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:38:02 --> Email Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:38:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:38:02 --> Model Class Initialized
DEBUG - 2015-04-15 08:38:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:38:02 --> Model Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:38:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:38:03 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:38:03 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:38:03 --> Final output sent to browser
DEBUG - 2015-04-15 08:38:03 --> Total execution time: 0.6640
DEBUG - 2015-04-15 08:38:04 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:04 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:04 --> Router Class Initialized
ERROR - 2015-04-15 08:38:04 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:38:05 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:05 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:05 --> Router Class Initialized
ERROR - 2015-04-15 08:38:05 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:38:20 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:20 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Router Class Initialized
DEBUG - 2015-04-15 08:38:20 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:38:20 --> Output Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Security Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Input Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:38:20 --> Language Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Language Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Loader Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:38:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:38:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Session Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:38:20 --> Session routines successfully run
DEBUG - 2015-04-15 08:38:20 --> Controller Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:38:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:38:20 --> Email Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:38:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:38:20 --> Model Class Initialized
DEBUG - 2015-04-15 08:38:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:38:20 --> Model Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:38:20 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:38:20 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:38:20 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:38:20 --> Final output sent to browser
DEBUG - 2015-04-15 08:38:20 --> Total execution time: 0.6200
DEBUG - 2015-04-15 08:38:21 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:21 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:21 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:21 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:21 --> Router Class Initialized
ERROR - 2015-04-15 08:38:21 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:38:22 --> Config Class Initialized
DEBUG - 2015-04-15 08:38:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:38:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:38:22 --> URI Class Initialized
DEBUG - 2015-04-15 08:38:22 --> Router Class Initialized
ERROR - 2015-04-15 08:38:22 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:46:07 --> Config Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:46:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:46:07 --> URI Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Router Class Initialized
DEBUG - 2015-04-15 08:46:07 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:46:07 --> Output Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Security Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Input Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:46:07 --> Language Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Language Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Config Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Loader Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:46:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:46:07 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Session Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:46:07 --> Session routines successfully run
DEBUG - 2015-04-15 08:46:07 --> Controller Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:46:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:46:07 --> Email Class Initialized
DEBUG - 2015-04-15 08:46:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:46:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:46:08 --> Model Class Initialized
DEBUG - 2015-04-15 08:46:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:46:08 --> Model Class Initialized
DEBUG - 2015-04-15 08:46:08 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:46:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:46:08 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:46:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:46:08 --> Final output sent to browser
DEBUG - 2015-04-15 08:46:08 --> Total execution time: 0.9221
DEBUG - 2015-04-15 08:46:09 --> Config Class Initialized
DEBUG - 2015-04-15 08:46:09 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:46:09 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:46:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:46:09 --> URI Class Initialized
DEBUG - 2015-04-15 08:46:09 --> Router Class Initialized
ERROR - 2015-04-15 08:46:09 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:46:11 --> Config Class Initialized
DEBUG - 2015-04-15 08:46:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:46:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:46:11 --> URI Class Initialized
DEBUG - 2015-04-15 08:46:11 --> Router Class Initialized
ERROR - 2015-04-15 08:46:11 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:47:24 --> Config Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:47:24 --> URI Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Router Class Initialized
DEBUG - 2015-04-15 08:47:24 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:47:24 --> Output Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Security Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Input Class Initialized
DEBUG - 2015-04-15 08:47:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:47:24 --> Language Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Language Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Config Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Loader Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:47:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:47:25 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Session Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:47:25 --> Session routines successfully run
DEBUG - 2015-04-15 08:47:25 --> Controller Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:47:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:47:25 --> Email Class Initialized
DEBUG - 2015-04-15 08:47:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:47:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:47:25 --> Model Class Initialized
DEBUG - 2015-04-15 08:47:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:47:30 --> Model Class Initialized
DEBUG - 2015-04-15 08:47:30 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:47:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:47:31 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:47:31 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:47:31 --> Final output sent to browser
DEBUG - 2015-04-15 08:47:31 --> Total execution time: 6.6304
DEBUG - 2015-04-15 08:47:33 --> Config Class Initialized
DEBUG - 2015-04-15 08:47:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:47:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:47:33 --> URI Class Initialized
DEBUG - 2015-04-15 08:47:33 --> Router Class Initialized
ERROR - 2015-04-15 08:47:33 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:47:34 --> Config Class Initialized
DEBUG - 2015-04-15 08:47:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:47:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:47:34 --> URI Class Initialized
DEBUG - 2015-04-15 08:47:34 --> Router Class Initialized
ERROR - 2015-04-15 08:47:34 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:52:05 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:05 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Router Class Initialized
DEBUG - 2015-04-15 08:52:05 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:52:05 --> Output Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Security Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Input Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:52:05 --> Language Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Language Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Loader Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:52:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Session Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:52:05 --> Session routines successfully run
DEBUG - 2015-04-15 08:52:05 --> Controller Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:52:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:52:05 --> Email Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:52:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:52:05 --> Model Class Initialized
DEBUG - 2015-04-15 08:52:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:52:05 --> Model Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:52:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:52:05 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:52:05 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:52:05 --> Final output sent to browser
DEBUG - 2015-04-15 08:52:06 --> Total execution time: 0.6570
DEBUG - 2015-04-15 08:52:06 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:06 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:07 --> Router Class Initialized
ERROR - 2015-04-15 08:52:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:52:07 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:07 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:07 --> Router Class Initialized
ERROR - 2015-04-15 08:52:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:52:24 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:25 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Router Class Initialized
DEBUG - 2015-04-15 08:52:25 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:52:25 --> Output Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Security Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Input Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:52:25 --> Language Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Language Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Loader Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:52:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:52:25 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Session Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:52:25 --> Session routines successfully run
DEBUG - 2015-04-15 08:52:25 --> Controller Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:52:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:52:25 --> Email Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:52:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:52:25 --> Model Class Initialized
DEBUG - 2015-04-15 08:52:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:52:25 --> Model Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:52:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:52:25 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:52:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:52:25 --> Final output sent to browser
DEBUG - 2015-04-15 08:52:25 --> Total execution time: 0.8250
DEBUG - 2015-04-15 08:52:26 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:26 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:27 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:27 --> Router Class Initialized
ERROR - 2015-04-15 08:52:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:52:27 --> Config Class Initialized
DEBUG - 2015-04-15 08:52:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:52:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:52:27 --> URI Class Initialized
DEBUG - 2015-04-15 08:52:27 --> Router Class Initialized
ERROR - 2015-04-15 08:52:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:58:13 --> Config Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:58:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:58:13 --> URI Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Router Class Initialized
DEBUG - 2015-04-15 08:58:13 --> No URI present. Default controller set.
DEBUG - 2015-04-15 08:58:13 --> Output Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Security Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Input Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 08:58:13 --> Language Class Initialized
DEBUG - 2015-04-15 08:58:13 --> Language Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Config Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Loader Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 08:58:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 08:58:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Session Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 08:58:14 --> Session routines successfully run
DEBUG - 2015-04-15 08:58:14 --> Controller Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 08:58:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 08:58:14 --> Email Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 08:58:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 08:58:14 --> Model Class Initialized
DEBUG - 2015-04-15 08:58:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 08:58:14 --> Model Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Form Validation Class Initialized
DEBUG - 2015-04-15 08:58:14 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 08:58:14 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 08:58:14 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 08:58:14 --> Final output sent to browser
DEBUG - 2015-04-15 08:58:14 --> Total execution time: 1.1981
DEBUG - 2015-04-15 08:58:15 --> Config Class Initialized
DEBUG - 2015-04-15 08:58:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:58:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:58:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:58:15 --> URI Class Initialized
DEBUG - 2015-04-15 08:58:15 --> Router Class Initialized
ERROR - 2015-04-15 08:58:15 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 08:58:18 --> Config Class Initialized
DEBUG - 2015-04-15 08:58:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 08:58:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 08:58:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 08:58:18 --> URI Class Initialized
DEBUG - 2015-04-15 08:58:18 --> Router Class Initialized
ERROR - 2015-04-15 08:58:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:10:42 --> Config Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:10:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:10:42 --> URI Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Router Class Initialized
DEBUG - 2015-04-15 09:10:42 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:10:42 --> Output Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Security Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Input Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:10:42 --> Language Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Language Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Config Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Loader Class Initialized
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:10:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:10:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:10:43 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Session Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:10:43 --> Session routines successfully run
DEBUG - 2015-04-15 09:10:43 --> Controller Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:10:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:10:43 --> Email Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:10:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:10:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:10:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:10:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:10:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:10:43 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:10:43 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:10:43 --> Final output sent to browser
DEBUG - 2015-04-15 09:10:43 --> Total execution time: 0.8080
DEBUG - 2015-04-15 09:10:45 --> Config Class Initialized
DEBUG - 2015-04-15 09:10:45 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:10:45 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:10:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:10:45 --> URI Class Initialized
DEBUG - 2015-04-15 09:10:45 --> Router Class Initialized
ERROR - 2015-04-15 09:10:45 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:11:19 --> Config Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:11:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:11:19 --> URI Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Router Class Initialized
DEBUG - 2015-04-15 09:11:19 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:11:19 --> Output Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Security Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Input Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:11:19 --> Language Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Language Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Config Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Loader Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:11:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:11:19 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Session Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:11:19 --> Session routines successfully run
DEBUG - 2015-04-15 09:11:19 --> Controller Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:11:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:11:19 --> Email Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:11:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:11:19 --> Model Class Initialized
DEBUG - 2015-04-15 09:11:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:11:19 --> Model Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:11:19 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:11:19 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:11:20 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:11:20 --> Final output sent to browser
DEBUG - 2015-04-15 09:11:20 --> Total execution time: 0.8570
DEBUG - 2015-04-15 09:12:05 --> Config Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:12:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:12:05 --> URI Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Router Class Initialized
DEBUG - 2015-04-15 09:12:05 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:12:05 --> Output Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Security Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Input Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:12:05 --> Language Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Language Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Config Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Loader Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:12:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:12:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Session Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:12:05 --> Session routines successfully run
DEBUG - 2015-04-15 09:12:05 --> Controller Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:12:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:12:05 --> Email Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:12:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:12:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:12:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:12:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:12:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:12:05 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:12:05 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:12:05 --> Final output sent to browser
DEBUG - 2015-04-15 09:12:06 --> Total execution time: 0.8020
DEBUG - 2015-04-15 09:12:07 --> Config Class Initialized
DEBUG - 2015-04-15 09:12:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:12:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:12:07 --> URI Class Initialized
DEBUG - 2015-04-15 09:12:07 --> Router Class Initialized
ERROR - 2015-04-15 09:12:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:14:58 --> Config Class Initialized
DEBUG - 2015-04-15 09:14:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:14:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:14:59 --> URI Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Router Class Initialized
DEBUG - 2015-04-15 09:14:59 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:14:59 --> Output Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Security Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Input Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:14:59 --> Language Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Language Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Config Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Loader Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:14:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:14:59 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Session Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:14:59 --> Session routines successfully run
DEBUG - 2015-04-15 09:14:59 --> Controller Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:14:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:14:59 --> Email Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:14:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:14:59 --> Model Class Initialized
DEBUG - 2015-04-15 09:14:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:14:59 --> Model Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:14:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:14:59 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:14:59 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:14:59 --> Final output sent to browser
DEBUG - 2015-04-15 09:14:59 --> Total execution time: 0.9531
DEBUG - 2015-04-15 09:15:01 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:01 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:01 --> Router Class Initialized
ERROR - 2015-04-15 09:15:01 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:15:20 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:20 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Router Class Initialized
DEBUG - 2015-04-15 09:15:20 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:15:20 --> Output Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Security Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Input Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:15:20 --> Language Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Language Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Loader Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:15:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:15:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Session Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:15:20 --> Session routines successfully run
DEBUG - 2015-04-15 09:15:20 --> Controller Class Initialized
DEBUG - 2015-04-15 09:15:20 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:15:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:15:21 --> Email Class Initialized
DEBUG - 2015-04-15 09:15:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:15:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:15:21 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:15:21 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:21 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:15:21 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:15:21 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:15:21 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:15:21 --> Final output sent to browser
DEBUG - 2015-04-15 09:15:21 --> Total execution time: 0.7660
DEBUG - 2015-04-15 09:15:22 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:22 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:22 --> Router Class Initialized
ERROR - 2015-04-15 09:15:22 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:16:08 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:09 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:09 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:16:09 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:09 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:16:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:16:09 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:09 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:09 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:16:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:16:09 --> Email Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:16:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:16:09 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:16:09 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:09 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:16:09 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:16:09 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:16:09 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:09 --> Total execution time: 0.8831
DEBUG - 2015-04-15 09:16:11 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:11 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:11 --> Router Class Initialized
ERROR - 2015-04-15 09:16:11 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:16:56 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:56 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:56 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:16:56 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:56 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:16:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:16:56 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:56 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:56 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:16:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:16:56 --> Email Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:16:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:16:56 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:16:56 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:16:56 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:16:56 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:16:56 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:56 --> Total execution time: 0.6520
DEBUG - 2015-04-15 09:16:58 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:58 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:58 --> Router Class Initialized
ERROR - 2015-04-15 09:16:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:17:22 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:17:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:17:22 --> URI Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Router Class Initialized
DEBUG - 2015-04-15 09:17:22 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:17:22 --> Output Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Security Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Input Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:17:22 --> Language Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Language Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Loader Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:17:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:17:22 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Session Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:17:22 --> Session routines successfully run
DEBUG - 2015-04-15 09:17:22 --> Controller Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:17:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:17:22 --> Email Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:17:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:17:22 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:17:22 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:22 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:17:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:17:23 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:17:23 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:17:23 --> Final output sent to browser
DEBUG - 2015-04-15 09:17:23 --> Total execution time: 0.7320
DEBUG - 2015-04-15 09:17:24 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:17:24 --> URI Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Router Class Initialized
ERROR - 2015-04-15 09:17:24 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:17:24 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:17:24 --> URI Class Initialized
DEBUG - 2015-04-15 09:17:24 --> Router Class Initialized
ERROR - 2015-04-15 09:17:24 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:21:04 --> Config Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:21:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:21:04 --> URI Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Router Class Initialized
DEBUG - 2015-04-15 09:21:04 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:21:04 --> Output Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Security Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Input Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:21:04 --> Language Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Language Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Config Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Loader Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:21:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:21:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Session Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:21:04 --> Session routines successfully run
DEBUG - 2015-04-15 09:21:04 --> Controller Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:21:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:21:04 --> Email Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:21:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:21:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:21:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:21:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:21:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:21:05 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:21:05 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:21:05 --> Final output sent to browser
DEBUG - 2015-04-15 09:21:05 --> Total execution time: 0.9261
DEBUG - 2015-04-15 09:21:06 --> Config Class Initialized
DEBUG - 2015-04-15 09:21:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:21:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:21:06 --> URI Class Initialized
DEBUG - 2015-04-15 09:21:06 --> Router Class Initialized
ERROR - 2015-04-15 09:21:06 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:23:14 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:23:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:23:14 --> URI Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Router Class Initialized
DEBUG - 2015-04-15 09:23:14 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:23:14 --> Output Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Security Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Input Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:23:14 --> Language Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Language Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Loader Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:23:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:23:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Session Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:23:14 --> Session routines successfully run
DEBUG - 2015-04-15 09:23:14 --> Controller Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:23:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:23:14 --> Email Class Initialized
DEBUG - 2015-04-15 09:23:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:23:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:23:14 --> Model Class Initialized
DEBUG - 2015-04-15 09:23:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:23:14 --> Model Class Initialized
DEBUG - 2015-04-15 09:23:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:23:15 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:23:15 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:23:15 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:23:15 --> Final output sent to browser
DEBUG - 2015-04-15 09:23:15 --> Total execution time: 0.6850
DEBUG - 2015-04-15 09:23:16 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:23:16 --> URI Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Router Class Initialized
ERROR - 2015-04-15 09:23:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:23:16 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:23:16 --> URI Class Initialized
DEBUG - 2015-04-15 09:23:16 --> Router Class Initialized
ERROR - 2015-04-15 09:23:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:23:52 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:23:52 --> URI Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Router Class Initialized
DEBUG - 2015-04-15 09:23:52 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:23:52 --> Output Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Security Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Input Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:23:52 --> Language Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Language Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Loader Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:23:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:23:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Session Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:23:52 --> Session routines successfully run
DEBUG - 2015-04-15 09:23:52 --> Controller Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:23:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:23:52 --> Email Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:23:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:23:52 --> Model Class Initialized
DEBUG - 2015-04-15 09:23:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:23:52 --> Model Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:23:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:23:52 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:23:52 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:23:52 --> Final output sent to browser
DEBUG - 2015-04-15 09:23:52 --> Total execution time: 0.8040
DEBUG - 2015-04-15 09:23:53 --> Config Class Initialized
DEBUG - 2015-04-15 09:23:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:23:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:23:53 --> URI Class Initialized
DEBUG - 2015-04-15 09:23:53 --> Router Class Initialized
ERROR - 2015-04-15 09:23:53 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:28:55 --> Config Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:28:55 --> URI Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Router Class Initialized
DEBUG - 2015-04-15 09:28:55 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:28:55 --> Output Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Security Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Input Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:28:55 --> Language Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Language Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Config Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Loader Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:28:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:28:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Session Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:28:55 --> Session routines successfully run
DEBUG - 2015-04-15 09:28:55 --> Controller Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:28:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:28:55 --> Email Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:28:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:28:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:28:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:28:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:28:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:28:56 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:28:56 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:28:56 --> Final output sent to browser
DEBUG - 2015-04-15 09:28:56 --> Total execution time: 0.7430
DEBUG - 2015-04-15 09:28:58 --> Config Class Initialized
DEBUG - 2015-04-15 09:28:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:28:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:28:58 --> URI Class Initialized
DEBUG - 2015-04-15 09:28:58 --> Router Class Initialized
ERROR - 2015-04-15 09:28:58 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 09:34:04 --> Config Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:34:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:34:04 --> URI Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Router Class Initialized
DEBUG - 2015-04-15 09:34:04 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:34:04 --> Output Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Security Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Input Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:34:04 --> Language Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Language Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Config Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Loader Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: language_helper
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: user_helper
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: date_helper
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 09:34:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 09:34:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Session Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:34:04 --> Session routines successfully run
DEBUG - 2015-04-15 09:34:04 --> Controller Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 09:34:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 09:34:04 --> Email Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 09:34:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 09:34:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:34:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 09:34:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:34:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 09:34:04 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 09:34:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 09:34:04 --> Final output sent to browser
DEBUG - 2015-04-15 09:34:04 --> Total execution time: 0.7990
DEBUG - 2015-04-15 09:34:07 --> Config Class Initialized
DEBUG - 2015-04-15 09:34:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:34:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:34:07 --> URI Class Initialized
DEBUG - 2015-04-15 09:34:07 --> Router Class Initialized
ERROR - 2015-04-15 09:34:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:12:07 --> Config Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:12:08 --> URI Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Router Class Initialized
DEBUG - 2015-04-15 11:12:08 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:12:08 --> Output Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Security Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Input Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:12:08 --> Language Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Language Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Config Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Loader Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:12:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:12:08 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Session Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:12:08 --> Session routines successfully run
DEBUG - 2015-04-15 11:12:08 --> Controller Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:12:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:12:08 --> Email Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:12:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:12:08 --> Model Class Initialized
DEBUG - 2015-04-15 11:12:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:12:08 --> Model Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:12:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:12:09 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:12:09 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:12:09 --> Final output sent to browser
DEBUG - 2015-04-15 11:12:09 --> Total execution time: 1.1221
DEBUG - 2015-04-15 11:12:12 --> Config Class Initialized
DEBUG - 2015-04-15 11:12:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:12:12 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:12:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:12:12 --> URI Class Initialized
DEBUG - 2015-04-15 11:12:12 --> Router Class Initialized
ERROR - 2015-04-15 11:12:12 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:12:22 --> Config Class Initialized
DEBUG - 2015-04-15 11:12:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:12:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:12:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:12:22 --> URI Class Initialized
DEBUG - 2015-04-15 11:12:22 --> Router Class Initialized
ERROR - 2015-04-15 11:12:22 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:30:25 --> Config Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:30:25 --> URI Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Router Class Initialized
DEBUG - 2015-04-15 11:30:25 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:30:25 --> Output Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Security Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Input Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:30:25 --> Language Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Language Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Config Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Loader Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:30:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:30:25 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Session Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:30:25 --> Session routines successfully run
DEBUG - 2015-04-15 11:30:25 --> Controller Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:30:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:30:25 --> Email Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:30:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:30:25 --> Model Class Initialized
DEBUG - 2015-04-15 11:30:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:30:25 --> Model Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:30:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:30:25 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:30:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:30:25 --> Final output sent to browser
DEBUG - 2015-04-15 11:30:25 --> Total execution time: 0.9321
DEBUG - 2015-04-15 11:30:27 --> Config Class Initialized
DEBUG - 2015-04-15 11:30:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:30:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:30:27 --> URI Class Initialized
DEBUG - 2015-04-15 11:30:27 --> Router Class Initialized
ERROR - 2015-04-15 11:30:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:31:25 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:25 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:31:25 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:31:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:31:25 --> URI Class Initialized
DEBUG - 2015-04-15 11:31:25 --> Router Class Initialized
DEBUG - 2015-04-15 11:31:25 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:31:25 --> Output Class Initialized
DEBUG - 2015-04-15 11:31:25 --> Security Class Initialized
DEBUG - 2015-04-15 11:31:25 --> Input Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:31:26 --> Language Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Language Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Loader Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:31:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:31:26 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Session Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:31:26 --> Session routines successfully run
DEBUG - 2015-04-15 11:31:26 --> Controller Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:31:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:31:26 --> Email Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:31:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:31:26 --> Model Class Initialized
DEBUG - 2015-04-15 11:31:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:31:26 --> Model Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:31:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:31:26 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:31:26 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:31:26 --> Final output sent to browser
DEBUG - 2015-04-15 11:31:26 --> Total execution time: 0.6770
DEBUG - 2015-04-15 11:31:27 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:31:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:31:27 --> URI Class Initialized
DEBUG - 2015-04-15 11:31:27 --> Router Class Initialized
ERROR - 2015-04-15 11:31:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:31:39 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:31:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:31:39 --> URI Class Initialized
DEBUG - 2015-04-15 11:31:39 --> Router Class Initialized
DEBUG - 2015-04-15 11:31:39 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:31:39 --> Output Class Initialized
DEBUG - 2015-04-15 11:31:39 --> Security Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Input Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:31:40 --> Language Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Language Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Loader Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:31:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:31:40 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Session Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:31:40 --> Session routines successfully run
DEBUG - 2015-04-15 11:31:40 --> Controller Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:31:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:31:40 --> Email Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:31:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:31:40 --> Model Class Initialized
DEBUG - 2015-04-15 11:31:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:31:40 --> Model Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:31:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:31:40 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:31:40 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:31:40 --> Final output sent to browser
DEBUG - 2015-04-15 11:31:40 --> Total execution time: 0.6610
DEBUG - 2015-04-15 11:31:41 --> Config Class Initialized
DEBUG - 2015-04-15 11:31:41 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:31:41 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:31:41 --> URI Class Initialized
DEBUG - 2015-04-15 11:31:41 --> Router Class Initialized
ERROR - 2015-04-15 11:31:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:45:03 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:04 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Router Class Initialized
DEBUG - 2015-04-15 11:45:04 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:45:04 --> Output Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Security Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Input Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:45:04 --> Language Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Language Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Loader Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:45:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:45:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Session Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:45:04 --> Session routines successfully run
DEBUG - 2015-04-15 11:45:04 --> Controller Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:45:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:45:04 --> Email Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:45:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:45:04 --> Model Class Initialized
DEBUG - 2015-04-15 11:45:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:45:04 --> Model Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:45:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:45:04 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:45:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:45:04 --> Final output sent to browser
DEBUG - 2015-04-15 11:45:04 --> Total execution time: 0.9661
DEBUG - 2015-04-15 11:45:05 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:06 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:06 --> Router Class Initialized
ERROR - 2015-04-15 11:45:06 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:45:07 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:07 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:07 --> Router Class Initialized
ERROR - 2015-04-15 11:45:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:45:34 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:34 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Router Class Initialized
DEBUG - 2015-04-15 11:45:34 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:45:34 --> Output Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Security Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Input Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:45:34 --> Language Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Language Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Loader Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:45:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:45:34 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Session Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:45:34 --> Session routines successfully run
DEBUG - 2015-04-15 11:45:34 --> Controller Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:45:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:45:34 --> Email Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:45:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:45:34 --> Model Class Initialized
DEBUG - 2015-04-15 11:45:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:45:34 --> Model Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:45:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:45:34 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:45:34 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:45:34 --> Final output sent to browser
DEBUG - 2015-04-15 11:45:34 --> Total execution time: 0.7900
DEBUG - 2015-04-15 11:45:35 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:35 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:35 --> Router Class Initialized
ERROR - 2015-04-15 11:45:35 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:45:37 --> Config Class Initialized
DEBUG - 2015-04-15 11:45:37 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:45:37 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:45:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:45:37 --> URI Class Initialized
DEBUG - 2015-04-15 11:45:37 --> Router Class Initialized
ERROR - 2015-04-15 11:45:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 11:46:31 --> Config Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:46:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:46:31 --> URI Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Router Class Initialized
DEBUG - 2015-04-15 11:46:31 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:46:31 --> Output Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Security Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Input Class Initialized
DEBUG - 2015-04-15 11:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:46:31 --> Language Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Language Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Config Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Loader Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:46:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:46:32 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Session Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:46:32 --> Session routines successfully run
DEBUG - 2015-04-15 11:46:32 --> Controller Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:46:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:46:32 --> Email Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:46:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:46:32 --> Model Class Initialized
DEBUG - 2015-04-15 11:46:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:46:32 --> Model Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:46:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:46:32 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:46:32 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:46:32 --> Final output sent to browser
DEBUG - 2015-04-15 11:46:32 --> Total execution time: 1.0811
DEBUG - 2015-04-15 11:47:10 --> Config Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:47:10 --> URI Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Router Class Initialized
DEBUG - 2015-04-15 11:47:10 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:47:10 --> Output Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Security Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Input Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:47:10 --> Language Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Language Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Config Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Loader Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:47:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:47:10 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Session Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:47:10 --> Session routines successfully run
DEBUG - 2015-04-15 11:47:10 --> Controller Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:47:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:47:10 --> Email Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:47:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:47:10 --> Model Class Initialized
DEBUG - 2015-04-15 11:47:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:47:10 --> Model Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:47:10 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:47:10 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:47:10 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:47:10 --> Final output sent to browser
DEBUG - 2015-04-15 11:47:10 --> Total execution time: 0.7890
DEBUG - 2015-04-15 11:51:58 --> Config Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 11:51:58 --> URI Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Router Class Initialized
DEBUG - 2015-04-15 11:51:58 --> No URI present. Default controller set.
DEBUG - 2015-04-15 11:51:58 --> Output Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Security Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Input Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 11:51:58 --> Language Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Language Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Config Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Loader Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 11:51:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 11:51:58 --> Database Driver Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Session Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 11:51:58 --> Session routines successfully run
DEBUG - 2015-04-15 11:51:58 --> Controller Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 11:51:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 11:51:58 --> Email Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 11:51:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 11:51:58 --> Model Class Initialized
DEBUG - 2015-04-15 11:51:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 11:51:58 --> Model Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Form Validation Class Initialized
DEBUG - 2015-04-15 11:51:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 11:51:58 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 11:51:58 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 11:51:58 --> Final output sent to browser
DEBUG - 2015-04-15 11:51:58 --> Total execution time: 0.8040
DEBUG - 2015-04-15 12:07:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:07:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:07:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Router Class Initialized
DEBUG - 2015-04-15 12:07:08 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:07:08 --> Output Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Security Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Input Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:07:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Loader Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:07:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:07:08 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Session Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:07:08 --> Session routines successfully run
DEBUG - 2015-04-15 12:07:08 --> Controller Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:07:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:07:08 --> Email Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:07:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:07:08 --> Model Class Initialized
DEBUG - 2015-04-15 12:07:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:07:08 --> Model Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:07:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:07:08 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:07:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:07:08 --> Final output sent to browser
DEBUG - 2015-04-15 12:07:08 --> Total execution time: 0.5990
DEBUG - 2015-04-15 12:09:03 --> Config Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:09:03 --> URI Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Router Class Initialized
DEBUG - 2015-04-15 12:09:03 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:09:03 --> Output Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Security Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Input Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:09:03 --> Language Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Language Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Config Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Loader Class Initialized
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:09:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:09:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:09:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Session Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:09:04 --> Session routines successfully run
DEBUG - 2015-04-15 12:09:04 --> Controller Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:09:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:09:04 --> Email Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:09:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:09:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:09:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:09:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:09:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:09:04 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:09:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:09:04 --> Final output sent to browser
DEBUG - 2015-04-15 12:09:04 --> Total execution time: 0.6390
DEBUG - 2015-04-15 12:10:04 --> Config Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:10:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:10:04 --> URI Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Router Class Initialized
DEBUG - 2015-04-15 12:10:04 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:10:04 --> Output Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Security Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Input Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:10:04 --> Language Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Language Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Config Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Loader Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:10:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:10:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Session Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:10:04 --> Session routines successfully run
DEBUG - 2015-04-15 12:10:04 --> Controller Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:10:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:10:04 --> Email Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:10:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:10:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:10:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:10:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:10:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:10:04 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:10:04 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:10:04 --> Final output sent to browser
DEBUG - 2015-04-15 12:10:04 --> Total execution time: 0.6330
DEBUG - 2015-04-15 12:13:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:13:16 --> URI Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Router Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Output Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Security Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Input Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:13:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Loader Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:13:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:13:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Session Class Initialized
DEBUG - 2015-04-15 12:13:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:13:16 --> Session routines successfully run
DEBUG - 2015-04-15 12:13:16 --> Controller Class Initialized
DEBUG - 2015-04-15 12:13:17 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:13:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:13:17 --> Email Class Initialized
DEBUG - 2015-04-15 12:13:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:13:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:13:17 --> Model Class Initialized
DEBUG - 2015-04-15 12:13:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:13:17 --> Model Class Initialized
DEBUG - 2015-04-15 12:13:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:13:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:13:17 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:13:17 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:13:17 --> Final output sent to browser
DEBUG - 2015-04-15 12:13:17 --> Total execution time: 1.2481
DEBUG - 2015-04-15 12:13:18 --> Config Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:13:18 --> URI Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Router Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Output Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Security Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Input Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:13:18 --> Language Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Language Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Config Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Loader Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:13:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:13:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Session Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:13:18 --> Session routines successfully run
DEBUG - 2015-04-15 12:13:18 --> Controller Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:13:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:13:18 --> Email Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:13:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:13:18 --> Model Class Initialized
DEBUG - 2015-04-15 12:13:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:13:18 --> Model Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:13:18 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:13:18 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:18:05 --> Config Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:18:05 --> URI Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Router Class Initialized
DEBUG - 2015-04-15 12:18:05 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:18:05 --> Output Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Security Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Input Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:18:05 --> Language Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Language Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Config Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Loader Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:18:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:18:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Session Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:18:05 --> Session routines successfully run
DEBUG - 2015-04-15 12:18:05 --> Controller Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:18:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:18:05 --> Email Class Initialized
DEBUG - 2015-04-15 12:18:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:18:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:18:05 --> Model Class Initialized
DEBUG - 2015-04-15 12:18:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:18:06 --> Model Class Initialized
DEBUG - 2015-04-15 12:18:06 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:18:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:18:06 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:18:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:18:06 --> Final output sent to browser
DEBUG - 2015-04-15 12:18:06 --> Total execution time: 1.1351
DEBUG - 2015-04-15 12:18:06 --> Config Class Initialized
DEBUG - 2015-04-15 12:18:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:18:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:18:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:18:06 --> URI Class Initialized
DEBUG - 2015-04-15 12:18:06 --> Router Class Initialized
ERROR - 2015-04-15 12:18:06 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:18:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:18:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:18:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:18:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:18:08 --> Router Class Initialized
ERROR - 2015-04-15 12:18:08 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:19:35 --> Config Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:19:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:19:35 --> URI Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Router Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Output Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Security Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Input Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:19:35 --> Language Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Language Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Config Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Loader Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:19:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:19:35 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Session Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:19:35 --> Session routines successfully run
DEBUG - 2015-04-15 12:19:35 --> Controller Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:19:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:19:35 --> Email Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:19:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 12:19:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:19:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:19:35 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:19:35 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:19:35 --> Final output sent to browser
DEBUG - 2015-04-15 12:19:35 --> Total execution time: 0.8380
DEBUG - 2015-04-15 12:19:37 --> Config Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:19:37 --> URI Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Router Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Output Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Security Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Input Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:19:37 --> Language Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Language Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Config Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Loader Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:19:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:19:37 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Session Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:19:37 --> Session routines successfully run
DEBUG - 2015-04-15 12:19:37 --> Controller Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:19:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:19:37 --> Email Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:19:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 12:19:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:19:37 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:19:38 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:24:28 --> Config Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:24:28 --> URI Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Router Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Output Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Security Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Input Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:24:28 --> Language Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Language Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Config Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Loader Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:24:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:24:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Session Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:24:28 --> Session routines successfully run
DEBUG - 2015-04-15 12:24:28 --> Controller Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:24:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:24:28 --> Email Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:24:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:24:28 --> Model Class Initialized
DEBUG - 2015-04-15 12:24:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:24:28 --> Model Class Initialized
DEBUG - 2015-04-15 12:24:28 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:24:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:24:29 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:24:29 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:24:29 --> Final output sent to browser
DEBUG - 2015-04-15 12:24:29 --> Total execution time: 1.0841
DEBUG - 2015-04-15 12:24:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:24:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:24:30 --> URI Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Router Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Output Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Security Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Input Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:24:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Loader Class Initialized
DEBUG - 2015-04-15 12:24:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:24:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:24:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:24:31 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Session Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:24:31 --> Session routines successfully run
DEBUG - 2015-04-15 12:24:31 --> Controller Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:24:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:24:31 --> Email Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:24:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:24:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:24:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:24:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:24:31 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:24:31 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:28:01 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:28:01 --> URI Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Router Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Output Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Security Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Input Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:28:01 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:01 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Loader Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:28:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:28:02 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Session Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:28:02 --> Session routines successfully run
DEBUG - 2015-04-15 12:28:02 --> Controller Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:28:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:28:02 --> Email Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:28:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:28:02 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:28:02 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:28:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:28:02 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:28:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:28:02 --> Final output sent to browser
DEBUG - 2015-04-15 12:28:02 --> Total execution time: 0.6560
DEBUG - 2015-04-15 12:28:03 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:28:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:28:03 --> URI Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Router Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Output Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Security Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Input Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:28:03 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Loader Class Initialized
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:28:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:28:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:28:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Session Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:28:04 --> Session routines successfully run
DEBUG - 2015-04-15 12:28:04 --> Controller Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:28:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:28:04 --> Email Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:28:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:28:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:28:04 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:28:04 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:28:04 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:28:57 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:28:57 --> URI Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Router Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Output Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Security Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Input Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:28:57 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:57 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Loader Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:28:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:28:58 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Session Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:28:58 --> Session routines successfully run
DEBUG - 2015-04-15 12:28:58 --> Controller Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:28:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:28:58 --> Email Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:28:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:28:58 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:28:58 --> Model Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:28:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:28:58 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:28:58 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:28:58 --> Final output sent to browser
DEBUG - 2015-04-15 12:28:58 --> Total execution time: 0.7650
DEBUG - 2015-04-15 12:28:59 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:28:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:28:59 --> URI Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Router Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Output Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Security Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Input Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:28:59 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Language Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Config Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Loader Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:28:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:28:59 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Session Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:28:59 --> Session routines successfully run
DEBUG - 2015-04-15 12:28:59 --> Controller Class Initialized
DEBUG - 2015-04-15 12:28:59 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:29:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:29:00 --> Email Class Initialized
DEBUG - 2015-04-15 12:29:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:29:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:29:00 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:29:00 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:00 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:29:00 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:29:00 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:29:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:29:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:29:30 --> URI Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Router Class Initialized
DEBUG - 2015-04-15 12:29:30 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:29:30 --> Output Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Security Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Input Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:29:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Loader Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:29:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:29:30 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Session Class Initialized
DEBUG - 2015-04-15 12:29:30 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:29:30 --> Session routines successfully run
DEBUG - 2015-04-15 12:29:30 --> Controller Class Initialized
DEBUG - 2015-04-15 12:29:31 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:29:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:29:31 --> Email Class Initialized
DEBUG - 2015-04-15 12:29:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:29:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:29:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:29:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:31 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:29:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:29:31 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:29:31 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:29:31 --> Final output sent to browser
DEBUG - 2015-04-15 12:29:31 --> Total execution time: 0.8911
DEBUG - 2015-04-15 12:29:32 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:32 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:29:32 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:29:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:29:32 --> URI Class Initialized
DEBUG - 2015-04-15 12:29:32 --> Router Class Initialized
ERROR - 2015-04-15 12:29:32 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:29:52 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:29:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:29:52 --> URI Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Router Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Output Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Security Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Input Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:29:52 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Loader Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:29:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:29:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Session Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:29:52 --> Session routines successfully run
DEBUG - 2015-04-15 12:29:52 --> Controller Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:29:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:29:52 --> Email Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:29:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:29:52 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:29:52 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:29:52 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:29:52 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-04-15 12:29:52 --> File loaded: application/views/../modules_core/login/views/create_user.php
DEBUG - 2015-04-15 12:29:52 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:29:52 --> Final output sent to browser
DEBUG - 2015-04-15 12:29:52 --> Total execution time: 0.6440
DEBUG - 2015-04-15 12:29:53 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:29:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:29:53 --> URI Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Router Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Output Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Security Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Input Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:29:53 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Language Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Config Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Loader Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:29:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:29:53 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Session Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:29:53 --> Session routines successfully run
DEBUG - 2015-04-15 12:29:53 --> Controller Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:29:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:29:53 --> Email Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:29:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:29:53 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:29:53 --> Model Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:29:53 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:29:53 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:31:20 --> Config Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:31:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:31:20 --> URI Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Router Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Output Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Security Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Input Class Initialized
DEBUG - 2015-04-15 12:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:31:21 --> Language Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Language Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Config Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Loader Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:31:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:31:21 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Session Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:31:21 --> Session routines successfully run
DEBUG - 2015-04-15 12:31:21 --> Controller Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:31:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:31:21 --> Email Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-15 12:31:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:31:21 --> Model Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:31:21 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:31:21 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-04-15 12:31:21 --> File loaded: application/views/../modules_core/login/views/create_user.php
DEBUG - 2015-04-15 12:31:21 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:31:21 --> Final output sent to browser
DEBUG - 2015-04-15 12:31:21 --> Total execution time: 0.7710
DEBUG - 2015-04-15 12:31:22 --> Config Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:31:22 --> URI Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Router Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Output Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Security Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Input Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Language Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Config Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Loader Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:31:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:31:22 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Session Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:31:22 --> Session routines successfully run
DEBUG - 2015-04-15 12:31:22 --> Controller Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:31:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:31:22 --> Email Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:31:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-15 12:31:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:31:22 --> Model Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:31:22 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:31:22 --> 404 Page Not Found --> login/avatar
DEBUG - 2015-04-15 12:32:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:15 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Router Class Initialized
DEBUG - 2015-04-15 12:32:15 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:32:15 --> Output Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Security Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Input Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:32:15 --> Language Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Language Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Loader Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:32:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:32:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Session Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:32:15 --> Session routines successfully run
DEBUG - 2015-04-15 12:32:15 --> Controller Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:32:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:32:15 --> Email Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:32:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:32:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:32:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:32:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:32:15 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:32:16 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:32:16 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:32:16 --> Final output sent to browser
DEBUG - 2015-04-15 12:32:16 --> Total execution time: 0.7710
DEBUG - 2015-04-15 12:32:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:16 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:16 --> Router Class Initialized
ERROR - 2015-04-15 12:32:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:32:17 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:17 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:17 --> Router Class Initialized
ERROR - 2015-04-15 12:32:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:32:21 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:22 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Router Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Output Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Security Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Input Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:32:22 --> Language Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Language Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Loader Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:32:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:32:22 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Session Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:32:22 --> Session routines successfully run
DEBUG - 2015-04-15 12:32:22 --> Controller Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:32:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:32:22 --> Email Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:32:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:32:22 --> Model Class Initialized
DEBUG - 2015-04-15 12:32:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:32:22 --> Model Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:32:22 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-04-15 12:32:22 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-04-15 12:32:22 --> File loaded: application/views/../modules_core/login/views/create_user.php
DEBUG - 2015-04-15 12:32:22 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:32:22 --> Final output sent to browser
DEBUG - 2015-04-15 12:32:22 --> Total execution time: 0.9261
DEBUG - 2015-04-15 12:32:23 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:23 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:23 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:23 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:23 --> Router Class Initialized
ERROR - 2015-04-15 12:32:23 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:32:23 --> Config Class Initialized
DEBUG - 2015-04-15 12:32:23 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:32:23 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:32:24 --> URI Class Initialized
DEBUG - 2015-04-15 12:32:24 --> Router Class Initialized
ERROR - 2015-04-15 12:32:24 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:33:46 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:46 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:46 --> Router Class Initialized
ERROR - 2015-04-15 12:33:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:33:49 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:49 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:49 --> Router Class Initialized
ERROR - 2015-04-15 12:33:49 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:33:50 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:50 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:50 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:50 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:50 --> Router Class Initialized
ERROR - 2015-04-15 12:33:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:33:52 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:52 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Router Class Initialized
DEBUG - 2015-04-15 12:33:52 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:33:52 --> Output Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Security Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Input Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:33:52 --> Language Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Language Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Loader Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:33:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:33:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Session Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:33:52 --> Session routines successfully run
DEBUG - 2015-04-15 12:33:52 --> Controller Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:33:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:33:52 --> Email Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:33:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:33:52 --> Model Class Initialized
DEBUG - 2015-04-15 12:33:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:33:52 --> Model Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:33:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:33:53 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:33:53 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:33:53 --> Final output sent to browser
DEBUG - 2015-04-15 12:33:53 --> Total execution time: 0.9701
DEBUG - 2015-04-15 12:33:54 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:54 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:54 --> Router Class Initialized
ERROR - 2015-04-15 12:33:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:33:58 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:58 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Router Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Output Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Security Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Input Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:33:58 --> Language Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Language Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Loader Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:33:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:33:58 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Session Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:33:58 --> Session routines successfully run
DEBUG - 2015-04-15 12:33:58 --> Controller Class Initialized
DEBUG - 2015-04-15 12:33:58 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:33:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:33:59 --> Email Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:33:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:33:59 --> Model Class Initialized
DEBUG - 2015-04-15 12:33:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:33:59 --> Model Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:33:59 --> File loaded: application/views/../modules_core/login/views/create_group.php
DEBUG - 2015-04-15 12:33:59 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:33:59 --> Final output sent to browser
DEBUG - 2015-04-15 12:33:59 --> Total execution time: 1.0271
DEBUG - 2015-04-15 12:33:59 --> Config Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:33:59 --> URI Class Initialized
DEBUG - 2015-04-15 12:33:59 --> Router Class Initialized
ERROR - 2015-04-15 12:33:59 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:34:00 --> Config Class Initialized
DEBUG - 2015-04-15 12:34:00 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:34:00 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:34:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:34:00 --> URI Class Initialized
DEBUG - 2015-04-15 12:34:00 --> Router Class Initialized
ERROR - 2015-04-15 12:34:00 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:01 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:01 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:01 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:35:01 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:01 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:01 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:01 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:01 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:35:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:01 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:01 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:01 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:35:02 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:35:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:35:02 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:02 --> Total execution time: 0.7190
DEBUG - 2015-04-15 12:35:02 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:02 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:02 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:02 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:02 --> Router Class Initialized
ERROR - 2015-04-15 12:35:02 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:03 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:03 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:03 --> Router Class Initialized
ERROR - 2015-04-15 12:35:03 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:06 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:06 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:06 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:35:06 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:06 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:07 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:07 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:07 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:35:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:07 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:35:07 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:35:07 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:35:07 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:07 --> Total execution time: 1.0381
DEBUG - 2015-04-15 12:35:07 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:08 --> Router Class Initialized
ERROR - 2015-04-15 12:35:08 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:08 --> Router Class Initialized
ERROR - 2015-04-15 12:35:08 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:11 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:11 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:11 --> No URI present. Default controller set.
DEBUG - 2015-04-15 12:35:11 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:11 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:12 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:12 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:12 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 12:35:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:12 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:12 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:12 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 12:35:12 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 12:35:12 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 12:35:12 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:12 --> Total execution time: 0.9321
DEBUG - 2015-04-15 12:35:13 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:13 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:13 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:13 --> Router Class Initialized
ERROR - 2015-04-15 12:35:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:16 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:16 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:16 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:16 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:16 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:17 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:35:17 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:35:17 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:17 --> Total execution time: 1.2731
DEBUG - 2015-04-15 12:35:17 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:18 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Router Class Initialized
ERROR - 2015-04-15 12:35:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:18 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:18 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Router Class Initialized
ERROR - 2015-04-15 12:35:18 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:18 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:18 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:18 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:18 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:19 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:19 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:19 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:19 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:19 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:19 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:19 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:19 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:19 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:19 --> Total execution time: 0.6000
DEBUG - 2015-04-15 12:35:24 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:24 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:24 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:24 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:24 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:24 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:24 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:24 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:24 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:24 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:25 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:25 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:25 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:25 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:25 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:25 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:25 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:25 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:25 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:25 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:25 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:25 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:25 --> Total execution time: 0.5960
DEBUG - 2015-04-15 12:35:33 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:33 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:33 --> Router Class Initialized
ERROR - 2015-04-15 12:35:33 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:35 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:35 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:35 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:36 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:36 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:36 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:36 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:36 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:36 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:36 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:36 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:36 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:36 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:36 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:36 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:36 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:35:36 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:35:36 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:36 --> Total execution time: 0.9361
DEBUG - 2015-04-15 12:35:37 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:37 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:37 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:37 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:37 --> Router Class Initialized
ERROR - 2015-04-15 12:35:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:42 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:42 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:42 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:42 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:42 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-15 12:35:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:42 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:42 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:42 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:42 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:42 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:42 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:42 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:42 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:42 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:42 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:42 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:42 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:42 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:42 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:42 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:42 --> Total execution time: 0.7670
DEBUG - 2015-04-15 12:35:43 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:43 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:43 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:43 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:43 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:43 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:43 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:43 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:43 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:43 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:43 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:43 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:43 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:43 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:43 --> Total execution time: 0.8090
DEBUG - 2015-04-15 12:35:46 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:46 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:46 --> Router Class Initialized
ERROR - 2015-04-15 12:35:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:49 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:49 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:49 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:49 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:49 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:49 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:50 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:50 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:50 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:50 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:50 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:50 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:50 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:50 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:50 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:50 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:35:50 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:35:50 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:50 --> Total execution time: 1.0161
DEBUG - 2015-04-15 12:35:51 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:51 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:51 --> Router Class Initialized
ERROR - 2015-04-15 12:35:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:35:55 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:55 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:55 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:55 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:55 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:55 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:55 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:55 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:55 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:55 --> Total execution time: 0.5790
DEBUG - 2015-04-15 12:35:56 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:35:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:35:56 --> URI Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Router Class Initialized
DEBUG - 2015-04-15 12:35:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:35:56 --> Output Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Security Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Input Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:35:56 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Language Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Config Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Loader Class Initialized
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:35:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:35:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:35:57 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Session Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:35:57 --> Session routines successfully run
DEBUG - 2015-04-15 12:35:57 --> Controller Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:35:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:35:57 --> Email Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:35:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:35:57 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:35:57 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:35:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:35:57 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:35:57 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:35:57 --> Model Class Initialized
DEBUG - 2015-04-15 12:35:57 --> Final output sent to browser
DEBUG - 2015-04-15 12:35:57 --> Total execution time: 0.8180
DEBUG - 2015-04-15 12:36:05 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:05 --> URI Class Initialized
DEBUG - 2015-04-15 12:36:05 --> Router Class Initialized
ERROR - 2015-04-15 12:36:05 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:36:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Router Class Initialized
DEBUG - 2015-04-15 12:36:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:36:08 --> Output Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Security Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Input Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:36:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Loader Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:36:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:36:08 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Session Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:36:08 --> Session routines successfully run
DEBUG - 2015-04-15 12:36:08 --> Controller Class Initialized
DEBUG - 2015-04-15 12:36:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:36:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:36:09 --> Email Class Initialized
DEBUG - 2015-04-15 12:36:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:36:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:36:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:36:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:09 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:36:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:36:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:36:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:36:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:36:09 --> Final output sent to browser
DEBUG - 2015-04-15 12:36:09 --> Total execution time: 1.1001
DEBUG - 2015-04-15 12:36:09 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:09 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:09 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:09 --> URI Class Initialized
DEBUG - 2015-04-15 12:36:09 --> Router Class Initialized
ERROR - 2015-04-15 12:36:09 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:36:14 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:14 --> URI Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Router Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:14 --> URI Class Initialized
ERROR - 2015-04-15 12:36:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:36:14 --> Router Class Initialized
DEBUG - 2015-04-15 12:36:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:36:14 --> Output Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Security Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Input Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:36:14 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Loader Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:36:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:36:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Session Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:36:14 --> Session routines successfully run
DEBUG - 2015-04-15 12:36:14 --> Controller Class Initialized
DEBUG - 2015-04-15 12:36:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:36:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:36:15 --> Email Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:36:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:36:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:36:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:36:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:36:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:36:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:36:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Final output sent to browser
DEBUG - 2015-04-15 12:36:15 --> Total execution time: 0.6270
DEBUG - 2015-04-15 12:36:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:36:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:36:15 --> URI Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Router Class Initialized
DEBUG - 2015-04-15 12:36:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:36:15 --> Output Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Security Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Input Class Initialized
DEBUG - 2015-04-15 12:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:36:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Language Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Config Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Loader Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:36:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:36:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Session Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:36:16 --> Session routines successfully run
DEBUG - 2015-04-15 12:36:16 --> Controller Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:36:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:36:16 --> Email Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:36:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:36:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:36:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:36:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:36:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:36:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:36:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:36:16 --> Final output sent to browser
DEBUG - 2015-04-15 12:36:16 --> Total execution time: 0.9161
DEBUG - 2015-04-15 12:51:07 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:51:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:51:07 --> URI Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Router Class Initialized
DEBUG - 2015-04-15 12:51:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:51:07 --> Output Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Security Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Input Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:51:07 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Loader Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:51:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:51:07 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Session Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:51:07 --> Session routines successfully run
DEBUG - 2015-04-15 12:51:07 --> Controller Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:51:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:51:07 --> Email Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:51:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:51:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:51:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:07 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:51:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:51:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:51:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:51:07 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:51:08 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:51:08 --> Final output sent to browser
DEBUG - 2015-04-15 12:51:08 --> Total execution time: 1.1621
DEBUG - 2015-04-15 12:51:10 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:51:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:51:10 --> URI Class Initialized
DEBUG - 2015-04-15 12:51:10 --> Router Class Initialized
ERROR - 2015-04-15 12:51:10 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:51:14 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:51:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:51:14 --> URI Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:51:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:51:14 --> Router Class Initialized
DEBUG - 2015-04-15 12:51:14 --> URI Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Router Class Initialized
ERROR - 2015-04-15 12:51:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:51:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:51:14 --> Output Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Security Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Input Class Initialized
DEBUG - 2015-04-15 12:51:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:51:14 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Loader Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:51:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:51:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Session Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:51:15 --> Session routines successfully run
DEBUG - 2015-04-15 12:51:15 --> Controller Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:51:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:51:15 --> Email Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:51:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:51:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:51:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:51:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:51:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:51:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:51:15 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Final output sent to browser
DEBUG - 2015-04-15 12:51:15 --> Total execution time: 0.7880
DEBUG - 2015-04-15 12:51:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:51:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:51:15 --> URI Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Router Class Initialized
DEBUG - 2015-04-15 12:51:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:51:15 --> Output Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Security Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Input Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:51:15 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Language Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Config Class Initialized
DEBUG - 2015-04-15 12:51:15 --> Loader Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:51:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:51:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Session Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:51:16 --> Session routines successfully run
DEBUG - 2015-04-15 12:51:16 --> Controller Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:51:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:51:16 --> Email Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:51:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:51:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:51:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:51:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:51:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:51:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:51:16 --> Model Class Initialized
DEBUG - 2015-04-15 12:51:16 --> Final output sent to browser
DEBUG - 2015-04-15 12:51:16 --> Total execution time: 1.0141
DEBUG - 2015-04-15 12:52:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:52:08 --> URI Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Router Class Initialized
DEBUG - 2015-04-15 12:52:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:52:08 --> Output Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Security Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Input Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:52:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Loader Class Initialized
DEBUG - 2015-04-15 12:52:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:52:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:52:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:52:09 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:52:09 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:52:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:52:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:52:09 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:52:09 --> Session Class Initialized
DEBUG - 2015-04-15 12:52:09 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:52:09 --> Session routines successfully run
DEBUG - 2015-04-15 12:52:09 --> Controller Class Initialized
DEBUG - 2015-04-15 12:52:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:52:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:52:09 --> Email Class Initialized
DEBUG - 2015-04-15 12:52:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:52:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:52:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:52:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:09 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:52:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:52:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:52:09 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:52:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:52:09 --> Final output sent to browser
DEBUG - 2015-04-15 12:52:09 --> Total execution time: 0.9371
DEBUG - 2015-04-15 12:52:10 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:52:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:52:10 --> URI Class Initialized
DEBUG - 2015-04-15 12:52:10 --> Router Class Initialized
ERROR - 2015-04-15 12:52:10 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:52:12 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:52:12 --> URI Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Router Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Utf8 Class Initialized
ERROR - 2015-04-15 12:52:12 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:52:12 --> URI Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Router Class Initialized
DEBUG - 2015-04-15 12:52:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:52:12 --> Output Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Security Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Input Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:52:12 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Loader Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Session Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:52:12 --> Session routines successfully run
DEBUG - 2015-04-15 12:52:12 --> Controller Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:52:12 --> Email Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:12 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:52:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:52:13 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:52:13 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:52:13 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:13 --> Final output sent to browser
DEBUG - 2015-04-15 12:52:13 --> Total execution time: 0.7960
DEBUG - 2015-04-15 12:52:17 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:52:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:52:17 --> URI Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Router Class Initialized
DEBUG - 2015-04-15 12:52:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:52:17 --> Output Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Security Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Input Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:52:17 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Language Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Config Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Loader Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:52:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:52:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Session Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:52:17 --> Session routines successfully run
DEBUG - 2015-04-15 12:52:17 --> Controller Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:52:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:52:17 --> Email Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:52:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:52:17 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:52:17 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:52:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:52:18 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:52:18 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:52:18 --> Model Class Initialized
DEBUG - 2015-04-15 12:52:18 --> Final output sent to browser
DEBUG - 2015-04-15 12:52:18 --> Total execution time: 0.6280
DEBUG - 2015-04-15 12:54:22 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:54:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:54:22 --> URI Class Initialized
DEBUG - 2015-04-15 12:54:22 --> Router Class Initialized
DEBUG - 2015-04-15 12:54:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:54:23 --> Output Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Security Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Input Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:54:23 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Loader Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:54:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:54:23 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Session Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:54:23 --> Session routines successfully run
DEBUG - 2015-04-15 12:54:23 --> Controller Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:54:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:54:23 --> Email Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:54:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:54:23 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:54:23 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:23 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:54:23 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:54:23 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:54:23 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 12:54:23 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 12:54:23 --> Final output sent to browser
DEBUG - 2015-04-15 12:54:23 --> Total execution time: 0.8260
DEBUG - 2015-04-15 12:54:24 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:24 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:54:24 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:54:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:54:24 --> URI Class Initialized
DEBUG - 2015-04-15 12:54:24 --> Router Class Initialized
ERROR - 2015-04-15 12:54:24 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:54:29 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:29 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:54:29 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:54:29 --> URI Class Initialized
DEBUG - 2015-04-15 12:54:29 --> Router Class Initialized
ERROR - 2015-04-15 12:54:29 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 12:54:29 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:29 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:54:29 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:54:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:54:29 --> URI Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Router Class Initialized
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:54:30 --> Output Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Security Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Input Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:54:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Loader Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:54:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:54:30 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Session Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:54:30 --> Session routines successfully run
DEBUG - 2015-04-15 12:54:30 --> Controller Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:54:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:54:30 --> Email Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:54:30 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 12:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:54:30 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:30 --> URI Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Router Class Initialized
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:54:30 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Output Class Initialized
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:54:30 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:54:30 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Security Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Input Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 12:54:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Language Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Config Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Loader Class Initialized
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: user_helper
DEBUG - 2015-04-15 12:54:30 --> Final output sent to browser
DEBUG - 2015-04-15 12:54:30 --> Total execution time: 1.3431
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: date_helper
DEBUG - 2015-04-15 12:54:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 12:54:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 12:54:31 --> Database Driver Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Session Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Helper loaded: string_helper
DEBUG - 2015-04-15 12:54:31 --> Session routines successfully run
DEBUG - 2015-04-15 12:54:31 --> Controller Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 12:54:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 12:54:31 --> Email Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 12:54:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 12:54:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 12:54:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Form Validation Class Initialized
DEBUG - 2015-04-15 12:54:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 12:54:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 12:54:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 12:54:31 --> Model Class Initialized
DEBUG - 2015-04-15 12:54:31 --> Final output sent to browser
DEBUG - 2015-04-15 12:54:31 --> Total execution time: 0.8801
DEBUG - 2015-04-15 13:00:44 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:00:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:00:44 --> URI Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Router Class Initialized
DEBUG - 2015-04-15 13:00:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:00:44 --> Output Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Security Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Input Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:00:44 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Loader Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:00:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:00:44 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Session Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:00:44 --> Session routines successfully run
DEBUG - 2015-04-15 13:00:44 --> Controller Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:00:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:00:44 --> Email Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:00:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:00:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:00:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:44 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:00:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:00:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:00:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:00:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:00:45 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:00:45 --> Final output sent to browser
DEBUG - 2015-04-15 13:00:45 --> Total execution time: 0.9031
DEBUG - 2015-04-15 13:00:46 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:00:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:00:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:00:46 --> URI Class Initialized
DEBUG - 2015-04-15 13:00:46 --> Router Class Initialized
ERROR - 2015-04-15 13:00:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:00:51 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:00:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:00:51 --> URI Class Initialized
DEBUG - 2015-04-15 13:00:51 --> Router Class Initialized
ERROR - 2015-04-15 13:00:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:00:52 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:00:52 --> URI Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Router Class Initialized
DEBUG - 2015-04-15 13:00:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:00:52 --> Output Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Security Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Input Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:00:52 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Loader Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:00:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:00:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Session Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:00:52 --> Session routines successfully run
DEBUG - 2015-04-15 13:00:52 --> Controller Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:00:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:00:52 --> Email Class Initialized
DEBUG - 2015-04-15 13:00:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:00:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:00:52 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:00:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:00:53 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Final output sent to browser
DEBUG - 2015-04-15 13:00:53 --> Total execution time: 1.1051
DEBUG - 2015-04-15 13:00:53 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:00:53 --> URI Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Router Class Initialized
DEBUG - 2015-04-15 13:00:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:00:53 --> Output Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Security Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Input Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:00:53 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:53 --> Language Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Loader Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:00:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:00:54 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Session Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:00:54 --> Session routines successfully run
DEBUG - 2015-04-15 13:00:54 --> Controller Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:00:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:00:54 --> Email Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:00:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:00:54 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:00:54 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:00:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:00:54 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:00:54 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:00:54 --> Model Class Initialized
DEBUG - 2015-04-15 13:00:54 --> Final output sent to browser
DEBUG - 2015-04-15 13:00:54 --> Total execution time: 0.6890
DEBUG - 2015-04-15 13:03:27 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:03:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:03:28 --> URI Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Router Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:03:28 --> Output Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Security Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Input Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:03:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Loader Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:03:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:03:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Session Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:03:28 --> Session routines successfully run
DEBUG - 2015-04-15 13:03:28 --> Controller Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:03:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:03:28 --> Email Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:03:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:03:28 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:03:28 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:28 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:03:28 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:03:28 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:03:28 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:03:28 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:03:28 --> Final output sent to browser
DEBUG - 2015-04-15 13:03:28 --> Total execution time: 1.0070
DEBUG - 2015-04-15 13:03:30 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:03:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:03:30 --> URI Class Initialized
DEBUG - 2015-04-15 13:03:30 --> Router Class Initialized
ERROR - 2015-04-15 13:03:30 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:03:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:03:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:03:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:03:34 --> URI Class Initialized
DEBUG - 2015-04-15 13:03:34 --> URI Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Router Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Router Class Initialized
DEBUG - 2015-04-15 13:03:34 --> File loaded: application/modules_core/sites/config/routes.php
ERROR - 2015-04-15 13:03:34 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:03:34 --> Output Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Security Class Initialized
DEBUG - 2015-04-15 13:03:34 --> Input Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:03:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Loader Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:03:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:03:35 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Session Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:03:35 --> Session routines successfully run
DEBUG - 2015-04-15 13:03:35 --> Controller Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:03:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:03:35 --> Email Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:03:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:03:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:03:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:03:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:03:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:03:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:03:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:35 --> Final output sent to browser
DEBUG - 2015-04-15 13:03:35 --> Total execution time: 0.9981
DEBUG - 2015-04-15 13:03:36 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:03:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:03:36 --> URI Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Router Class Initialized
DEBUG - 2015-04-15 13:03:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:03:36 --> Output Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Security Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Input Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:03:36 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Language Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Config Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Loader Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:03:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:03:36 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Session Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:03:36 --> Session routines successfully run
DEBUG - 2015-04-15 13:03:36 --> Controller Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:03:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:03:36 --> Email Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:03:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:03:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:03:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:36 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:03:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:03:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:03:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:03:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:03:37 --> Final output sent to browser
DEBUG - 2015-04-15 13:03:37 --> Total execution time: 0.6640
DEBUG - 2015-04-15 13:04:51 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:04:51 --> URI Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Router Class Initialized
DEBUG - 2015-04-15 13:04:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:04:51 --> Output Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Security Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Input Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:04:51 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Loader Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:04:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:04:51 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Session Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:04:51 --> Session routines successfully run
DEBUG - 2015-04-15 13:04:51 --> Controller Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:04:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:04:51 --> Email Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:04:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:04:51 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:04:51 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:51 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:04:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:04:51 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:04:51 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:04:51 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:04:52 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:04:52 --> Final output sent to browser
DEBUG - 2015-04-15 13:04:52 --> Total execution time: 1.1300
DEBUG - 2015-04-15 13:04:53 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:04:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:04:53 --> URI Class Initialized
DEBUG - 2015-04-15 13:04:53 --> Router Class Initialized
ERROR - 2015-04-15 13:04:53 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:04:57 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:57 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:04:57 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:04:57 --> URI Class Initialized
DEBUG - 2015-04-15 13:04:57 --> Router Class Initialized
ERROR - 2015-04-15 13:04:57 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:04:57 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:57 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:04:57 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:04:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:04:58 --> URI Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Router Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:04:58 --> Output Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Security Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Input Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:04:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Loader Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:04:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:04:58 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Session Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:04:58 --> Session routines successfully run
DEBUG - 2015-04-15 13:04:58 --> Controller Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:04:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:04:58 --> Email Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:04:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:04:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:04:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:04:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:04:58 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:04:58 --> URI Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Final output sent to browser
DEBUG - 2015-04-15 13:04:58 --> Total execution time: 0.9421
DEBUG - 2015-04-15 13:04:58 --> Router Class Initialized
DEBUG - 2015-04-15 13:04:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:04:58 --> Output Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Security Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Input Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:04:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Config Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Loader Class Initialized
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:04:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:04:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:04:59 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Session Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:04:59 --> Session routines successfully run
DEBUG - 2015-04-15 13:04:59 --> Controller Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:04:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:04:59 --> Email Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:04:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:04:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:04:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:04:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:04:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:04:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:04:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:04:59 --> Final output sent to browser
DEBUG - 2015-04-15 13:04:59 --> Total execution time: 1.1831
DEBUG - 2015-04-15 13:06:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:06:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:06:10 --> URI Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Router Class Initialized
DEBUG - 2015-04-15 13:06:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:06:10 --> Output Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Security Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Input Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:06:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Loader Class Initialized
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:06:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:06:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:06:11 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:06:11 --> Session Class Initialized
DEBUG - 2015-04-15 13:06:11 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:06:11 --> Session routines successfully run
DEBUG - 2015-04-15 13:06:11 --> Controller Class Initialized
DEBUG - 2015-04-15 13:06:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:06:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:06:11 --> Email Class Initialized
DEBUG - 2015-04-15 13:06:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:06:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:06:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:06:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:11 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:06:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:06:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:06:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:06:11 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:06:11 --> Final output sent to browser
DEBUG - 2015-04-15 13:06:11 --> Total execution time: 0.8650
DEBUG - 2015-04-15 13:06:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:06:12 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:06:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:06:12 --> URI Class Initialized
DEBUG - 2015-04-15 13:06:12 --> Router Class Initialized
ERROR - 2015-04-15 13:06:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:06:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:06:16 --> URI Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Router Class Initialized
DEBUG - 2015-04-15 13:06:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:06:16 --> Output Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Security Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Input Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:06:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Loader Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:06:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:06:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Session Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:06:17 --> Session routines successfully run
DEBUG - 2015-04-15 13:06:17 --> Controller Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:06:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:06:17 --> Email Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:06:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:06:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:06:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:06:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:06:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:06:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Final output sent to browser
DEBUG - 2015-04-15 13:06:17 --> Total execution time: 0.7670
DEBUG - 2015-04-15 13:06:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:06:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:06:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Router Class Initialized
DEBUG - 2015-04-15 13:06:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:06:17 --> Output Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Security Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Input Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:06:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Loader Class Initialized
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:06:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:06:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:06:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Session Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:06:18 --> Session routines successfully run
DEBUG - 2015-04-15 13:06:18 --> Controller Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:06:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:06:18 --> Email Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:06:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:06:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:06:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:06:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:06:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:06:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:06:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:06:18 --> Final output sent to browser
DEBUG - 2015-04-15 13:06:18 --> Total execution time: 0.6890
DEBUG - 2015-04-15 13:08:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:08:12 --> URI Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Router Class Initialized
DEBUG - 2015-04-15 13:08:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:08:12 --> Output Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Security Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Input Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:08:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Loader Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:08:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:08:12 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Session Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:08:12 --> Session routines successfully run
DEBUG - 2015-04-15 13:08:12 --> Controller Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:08:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:08:12 --> Email Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:08:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:08:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:08:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:12 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:08:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:08:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:08:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:08:13 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:08:13 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:08:13 --> Final output sent to browser
DEBUG - 2015-04-15 13:08:13 --> Total execution time: 0.9190
DEBUG - 2015-04-15 13:08:15 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:08:15 --> URI Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Router Class Initialized
ERROR - 2015-04-15 13:08:15 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:08:15 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:08:15 --> URI Class Initialized
DEBUG - 2015-04-15 13:08:15 --> Router Class Initialized
DEBUG - 2015-04-15 13:08:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:08:16 --> Output Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Security Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Input Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:08:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Loader Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:08:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:08:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Session Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:08:16 --> Session routines successfully run
DEBUG - 2015-04-15 13:08:16 --> Controller Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:08:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:08:16 --> Email Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:08:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:08:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:08:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:08:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:08:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:08:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:08:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:16 --> Final output sent to browser
DEBUG - 2015-04-15 13:08:16 --> Total execution time: 0.5430
DEBUG - 2015-04-15 13:08:20 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:08:20 --> URI Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Router Class Initialized
DEBUG - 2015-04-15 13:08:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:08:20 --> Output Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Security Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Input Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:08:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Config Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Loader Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:08:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:08:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Session Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:08:20 --> Session routines successfully run
DEBUG - 2015-04-15 13:08:20 --> Controller Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:08:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:08:20 --> Email Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:08:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:08:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:08:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:08:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:08:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:08:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:08:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:08:21 --> Final output sent to browser
DEBUG - 2015-04-15 13:08:21 --> Total execution time: 0.8080
DEBUG - 2015-04-15 13:09:01 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:09:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:09:01 --> URI Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Router Class Initialized
DEBUG - 2015-04-15 13:09:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:09:01 --> Output Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Security Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Input Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:09:01 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Loader Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:09:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:09:01 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Session Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:09:01 --> Session routines successfully run
DEBUG - 2015-04-15 13:09:01 --> Controller Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:09:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:09:01 --> Email Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:09:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:09:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:09:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:01 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:09:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:09:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:09:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:09:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:09:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:09:02 --> Final output sent to browser
DEBUG - 2015-04-15 13:09:02 --> Total execution time: 0.9030
DEBUG - 2015-04-15 13:09:03 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:09:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:09:03 --> URI Class Initialized
DEBUG - 2015-04-15 13:09:03 --> Router Class Initialized
ERROR - 2015-04-15 13:09:03 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:09:06 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:09:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:09:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:09:06 --> URI Class Initialized
DEBUG - 2015-04-15 13:09:06 --> Router Class Initialized
DEBUG - 2015-04-15 13:09:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:09:07 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:09:07 --> URI Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Output Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Router Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Security Class Initialized
ERROR - 2015-04-15 13:09:07 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:09:07 --> Input Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:09:07 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Loader Class Initialized
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:09:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:09:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:09:07 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Session Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:09:08 --> Session routines successfully run
DEBUG - 2015-04-15 13:09:08 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Controller Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:09:08 --> URI Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:09:08 --> Router Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:09:08 --> Email Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:09:08 --> Output Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Security Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:09:08 --> Input Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:09:08 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:09:08 --> Language Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Config Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Loader Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:09:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:09:08 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Session Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:09:08 --> Session routines successfully run
DEBUG - 2015-04-15 13:09:08 --> Controller Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:09:08 --> Email Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:09:08 --> Final output sent to browser
DEBUG - 2015-04-15 13:09:08 --> Total execution time: 1.7541
DEBUG - 2015-04-15 13:09:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:09:08 --> Model Class Initialized
DEBUG - 2015-04-15 13:09:08 --> Final output sent to browser
DEBUG - 2015-04-15 13:09:08 --> Total execution time: 0.7310
DEBUG - 2015-04-15 13:10:58 --> Config Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:10:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:10:58 --> URI Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Router Class Initialized
DEBUG - 2015-04-15 13:10:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:10:58 --> Output Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Security Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Input Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:10:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Language Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Config Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Loader Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:10:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:10:58 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Session Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:10:58 --> Session routines successfully run
DEBUG - 2015-04-15 13:10:58 --> Controller Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:10:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:10:58 --> Email Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:10:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:10:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:10:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:10:58 --> Model Class Initialized
DEBUG - 2015-04-15 13:10:58 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:10:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:10:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:10:59 --> Model Class Initialized
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:10:59 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:10:59 --> Final output sent to browser
DEBUG - 2015-04-15 13:10:59 --> Total execution time: 0.8410
DEBUG - 2015-04-15 13:11:00 --> Config Class Initialized
DEBUG - 2015-04-15 13:11:00 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:11:00 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:11:00 --> URI Class Initialized
DEBUG - 2015-04-15 13:11:00 --> Router Class Initialized
ERROR - 2015-04-15 13:11:00 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:11:04 --> Config Class Initialized
DEBUG - 2015-04-15 13:11:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:11:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:11:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:11:04 --> URI Class Initialized
DEBUG - 2015-04-15 13:11:04 --> Router Class Initialized
DEBUG - 2015-04-15 13:11:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:11:05 --> Output Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Security Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Input Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:11:05 --> Language Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Language Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Config Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Loader Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:11:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:11:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Session Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:11:05 --> Session routines successfully run
DEBUG - 2015-04-15 13:11:05 --> Controller Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:11:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:11:05 --> Email Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:11:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:11:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:11:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:11:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:11:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:11:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:11:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:05 --> Final output sent to browser
DEBUG - 2015-04-15 13:11:05 --> Total execution time: 1.3271
DEBUG - 2015-04-15 13:11:06 --> Config Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:11:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:11:06 --> URI Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Router Class Initialized
DEBUG - 2015-04-15 13:11:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:11:06 --> Output Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Security Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Input Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:11:06 --> Language Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Language Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Config Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Loader Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:11:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:11:06 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Session Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:11:06 --> Session routines successfully run
DEBUG - 2015-04-15 13:11:06 --> Controller Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:11:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:11:06 --> Email Class Initialized
DEBUG - 2015-04-15 13:11:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:11:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:11:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:11:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:07 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:11:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:11:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:11:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:11:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:11:07 --> Final output sent to browser
DEBUG - 2015-04-15 13:11:07 --> Total execution time: 1.2441
DEBUG - 2015-04-15 13:12:11 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:12:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:12:11 --> URI Class Initialized
DEBUG - 2015-04-15 13:12:11 --> Router Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:12:12 --> Output Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Security Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Input Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:12:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Loader Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:12:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:12:12 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Session Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:12:12 --> Session routines successfully run
DEBUG - 2015-04-15 13:12:12 --> Controller Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:12:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:12:12 --> Email Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:12:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:12:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:12:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:12 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:12:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:12:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:12:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:12:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:12:12 --> Final output sent to browser
DEBUG - 2015-04-15 13:12:12 --> Total execution time: 1.0901
DEBUG - 2015-04-15 13:12:13 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:12:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:12:14 --> URI Class Initialized
DEBUG - 2015-04-15 13:12:14 --> Router Class Initialized
ERROR - 2015-04-15 13:12:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:12:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:12:18 --> URI Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Router Class Initialized
DEBUG - 2015-04-15 13:12:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:12:18 --> Output Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Security Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Input Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:12:18 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Loader Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:12:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:12:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Session Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:12:18 --> Session routines successfully run
DEBUG - 2015-04-15 13:12:18 --> Controller Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:12:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:12:18 --> Email Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:12:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:12:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:12:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:12:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:12:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:12:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:12:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:18 --> Final output sent to browser
DEBUG - 2015-04-15 13:12:18 --> Total execution time: 0.8811
DEBUG - 2015-04-15 13:12:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:12:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:12:19 --> URI Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Router Class Initialized
DEBUG - 2015-04-15 13:12:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:12:19 --> Output Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Security Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Input Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:12:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Loader Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:12:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:12:19 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Session Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:12:19 --> Session routines successfully run
DEBUG - 2015-04-15 13:12:19 --> Controller Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:12:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:12:19 --> Email Class Initialized
DEBUG - 2015-04-15 13:12:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:12:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:12:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:12:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:12:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:12:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:12:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:12:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:12:20 --> Final output sent to browser
DEBUG - 2015-04-15 13:12:21 --> Total execution time: 1.0091
DEBUG - 2015-04-15 13:13:13 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:13:13 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:13:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:13:13 --> URI Class Initialized
DEBUG - 2015-04-15 13:13:13 --> Router Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:13:14 --> Output Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Security Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Input Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:13:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Loader Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:13:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:13:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Session Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:13:14 --> Session routines successfully run
DEBUG - 2015-04-15 13:13:14 --> Controller Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:13:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:13:14 --> Email Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:13:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:13:14 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:13:14 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:14 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:13:14 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:13:14 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:13:14 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:13:14 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:13:15 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:13:15 --> Final output sent to browser
DEBUG - 2015-04-15 13:13:15 --> Total execution time: 1.1781
DEBUG - 2015-04-15 13:13:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:13:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:13:16 --> URI Class Initialized
DEBUG - 2015-04-15 13:13:16 --> Router Class Initialized
ERROR - 2015-04-15 13:13:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:13:20 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:13:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:13:20 --> URI Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Router Class Initialized
DEBUG - 2015-04-15 13:13:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:13:20 --> Output Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Security Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Input Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:13:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Loader Class Initialized
DEBUG - 2015-04-15 13:13:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:13:21 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:13:21 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Session Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:13:21 --> Session routines successfully run
DEBUG - 2015-04-15 13:13:21 --> Controller Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:13:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:13:21 --> Email Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:13:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:13:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:13:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:13:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:13:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:13:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:21 --> URI Class Initialized
DEBUG - 2015-04-15 13:13:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:13:21 --> Router Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Final output sent to browser
DEBUG - 2015-04-15 13:13:21 --> Total execution time: 1.5381
DEBUG - 2015-04-15 13:13:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:13:21 --> Output Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Security Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Input Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:13:21 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Language Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Config Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Loader Class Initialized
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:13:21 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:13:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:13:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:13:22 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Session Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:13:22 --> Session routines successfully run
DEBUG - 2015-04-15 13:13:22 --> Controller Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:13:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:13:22 --> Email Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:13:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:13:22 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:13:22 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:13:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:13:22 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:13:22 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:13:22 --> Model Class Initialized
DEBUG - 2015-04-15 13:13:22 --> Final output sent to browser
DEBUG - 2015-04-15 13:13:22 --> Total execution time: 0.9321
DEBUG - 2015-04-15 13:14:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:14:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:14:10 --> URI Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Router Class Initialized
DEBUG - 2015-04-15 13:14:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:14:10 --> Output Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Security Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Input Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:14:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Loader Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:14:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:14:10 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Session Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:14:10 --> Session routines successfully run
DEBUG - 2015-04-15 13:14:10 --> Controller Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:14:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:14:10 --> Email Class Initialized
DEBUG - 2015-04-15 13:14:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:14:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:14:10 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:14:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:11 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:14:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:14:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:14:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:14:11 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:14:11 --> Final output sent to browser
DEBUG - 2015-04-15 13:14:11 --> Total execution time: 0.9140
DEBUG - 2015-04-15 13:14:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:14:12 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:14:12 --> URI Class Initialized
DEBUG - 2015-04-15 13:14:12 --> Router Class Initialized
ERROR - 2015-04-15 13:14:12 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:14:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:14:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Router Class Initialized
DEBUG - 2015-04-15 13:14:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:14:17 --> Output Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Security Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:14:17 --> Input Class Initialized
DEBUG - 2015-04-15 13:14:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:14:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Router Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Config Class Initialized
ERROR - 2015-04-15 13:14:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:14:17 --> Loader Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:14:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:14:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Session Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:14:17 --> Session routines successfully run
DEBUG - 2015-04-15 13:14:17 --> Controller Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:14:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:14:17 --> Email Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:14:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:14:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:14:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:14:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:14:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:14:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:14:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Final output sent to browser
DEBUG - 2015-04-15 13:14:18 --> Total execution time: 1.0841
DEBUG - 2015-04-15 13:14:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:14:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:14:18 --> URI Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Router Class Initialized
DEBUG - 2015-04-15 13:14:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:14:18 --> Output Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Security Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Input Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:14:18 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Language Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Config Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Loader Class Initialized
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:14:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:14:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:14:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Session Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:14:19 --> Session routines successfully run
DEBUG - 2015-04-15 13:14:19 --> Controller Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:14:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:14:19 --> Email Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:14:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:14:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:14:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:14:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:14:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:14:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:14:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:14:19 --> Final output sent to browser
DEBUG - 2015-04-15 13:14:19 --> Total execution time: 1.2801
DEBUG - 2015-04-15 13:16:57 --> Config Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:16:57 --> URI Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Router Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:16:57 --> Output Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Security Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Input Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:16:57 --> Language Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Language Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Config Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Loader Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:16:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:16:57 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Session Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:16:57 --> Session routines successfully run
DEBUG - 2015-04-15 13:16:57 --> Controller Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:16:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:16:57 --> Email Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:16:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:16:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:16:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:16:57 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:16:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:16:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:16:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:16:57 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:16:58 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:16:58 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:16:58 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:16:58 --> Final output sent to browser
DEBUG - 2015-04-15 13:16:58 --> Total execution time: 0.9130
DEBUG - 2015-04-15 13:16:59 --> Config Class Initialized
DEBUG - 2015-04-15 13:16:59 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:16:59 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:16:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:16:59 --> URI Class Initialized
DEBUG - 2015-04-15 13:16:59 --> Router Class Initialized
ERROR - 2015-04-15 13:16:59 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:17:03 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:03 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:04 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:04 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Router Class Initialized
ERROR - 2015-04-15 13:17:04 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:17:04 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:17:04 --> Output Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Security Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Input Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:17:04 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Loader Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:17:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:17:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Session Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:17:04 --> Session routines successfully run
DEBUG - 2015-04-15 13:17:04 --> Controller Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:17:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:17:04 --> Email Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:17:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:17:04 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:17:04 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:17:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:17:04 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:17:04 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:17:04 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:04 --> Final output sent to browser
DEBUG - 2015-04-15 13:17:04 --> Total execution time: 1.2471
DEBUG - 2015-04-15 13:17:05 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:05 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:17:05 --> Output Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Security Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Input Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:17:05 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Loader Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:17:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:17:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Session Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:17:05 --> Session routines successfully run
DEBUG - 2015-04-15 13:17:05 --> Controller Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:17:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:17:05 --> Email Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:17:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:17:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:05 --> Final output sent to browser
DEBUG - 2015-04-15 13:17:05 --> Total execution time: 0.5940
DEBUG - 2015-04-15 13:17:48 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:48 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:48 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:48 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:48 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:17:48 --> Output Class Initialized
DEBUG - 2015-04-15 13:17:48 --> Security Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Input Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:17:49 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Loader Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:17:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:17:49 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Session Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:17:49 --> Session routines successfully run
DEBUG - 2015-04-15 13:17:49 --> Controller Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:17:49 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:17:49 --> Email Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:17:49 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:49 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:17:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:17:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:17:49 --> Final output sent to browser
DEBUG - 2015-04-15 13:17:49 --> Total execution time: 0.8900
DEBUG - 2015-04-15 13:17:50 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:50 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:50 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:50 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:50 --> Router Class Initialized
ERROR - 2015-04-15 13:17:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:17:55 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:55 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:17:55 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:55 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Output Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Security Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Input Class Initialized
ERROR - 2015-04-15 13:17:55 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:17:55 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Loader Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:17:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:17:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Session Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:17:55 --> Session routines successfully run
DEBUG - 2015-04-15 13:17:55 --> Controller Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:17:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:17:55 --> Email Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:17:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:17:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:17:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:17:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:17:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:17:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:17:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:17:56 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:56 --> URI Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Router Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Final output sent to browser
DEBUG - 2015-04-15 13:17:56 --> Total execution time: 1.6841
DEBUG - 2015-04-15 13:17:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:17:56 --> Output Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Security Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Input Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:17:56 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Language Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Config Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Loader Class Initialized
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:17:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:17:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:17:56 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Session Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:17:57 --> Session routines successfully run
DEBUG - 2015-04-15 13:17:57 --> Controller Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:17:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:17:57 --> Email Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:17:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:17:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:17:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:17:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:17:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:17:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:17:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:17:57 --> Final output sent to browser
DEBUG - 2015-04-15 13:17:57 --> Total execution time: 0.9471
DEBUG - 2015-04-15 13:19:28 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:19:28 --> URI Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Router Class Initialized
DEBUG - 2015-04-15 13:19:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:19:28 --> Output Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Security Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Input Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:19:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Loader Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:19:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:19:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Session Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:19:28 --> Session routines successfully run
DEBUG - 2015-04-15 13:19:28 --> Controller Class Initialized
DEBUG - 2015-04-15 13:19:28 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:19:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:19:29 --> Email Class Initialized
DEBUG - 2015-04-15 13:19:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:19:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:19:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:19:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:29 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:19:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:19:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:19:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:19:29 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:19:29 --> Final output sent to browser
DEBUG - 2015-04-15 13:19:29 --> Total execution time: 0.9320
DEBUG - 2015-04-15 13:19:31 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:31 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:19:31 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:19:31 --> URI Class Initialized
DEBUG - 2015-04-15 13:19:31 --> Router Class Initialized
ERROR - 2015-04-15 13:19:31 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:19:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:19:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:19:34 --> URI Class Initialized
DEBUG - 2015-04-15 13:19:34 --> Router Class Initialized
DEBUG - 2015-04-15 13:19:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:19:35 --> Output Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Security Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Input Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:19:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Loader Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:19:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:19:35 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Session Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:19:35 --> Session routines successfully run
DEBUG - 2015-04-15 13:19:35 --> Controller Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:19:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:19:35 --> Email Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:19:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:19:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:19:35 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:35 --> Final output sent to browser
DEBUG - 2015-04-15 13:19:35 --> Total execution time: 1.0601
DEBUG - 2015-04-15 13:19:36 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:19:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:19:36 --> URI Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Router Class Initialized
DEBUG - 2015-04-15 13:19:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:19:36 --> Output Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Security Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Input Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:19:36 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Language Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Config Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Loader Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:19:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:19:36 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Session Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:19:36 --> Session routines successfully run
DEBUG - 2015-04-15 13:19:36 --> Controller Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:19:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:19:36 --> Email Class Initialized
DEBUG - 2015-04-15 13:19:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:19:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:37 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:19:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:19:37 --> Model Class Initialized
DEBUG - 2015-04-15 13:19:37 --> Final output sent to browser
DEBUG - 2015-04-15 13:19:37 --> Total execution time: 1.3541
DEBUG - 2015-04-15 13:20:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:20:16 --> URI Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Router Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:20:16 --> Output Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Security Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Input Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:20:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Loader Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:20:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:20:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Session Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:20:16 --> Session routines successfully run
DEBUG - 2015-04-15 13:20:16 --> Controller Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:20:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:20:16 --> Email Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:20:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:20:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:20:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:20:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:20:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:20:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:20:16 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:20:16 --> Final output sent to browser
DEBUG - 2015-04-15 13:20:16 --> Total execution time: 0.8300
DEBUG - 2015-04-15 13:20:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:20:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:20:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:20:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:20:17 --> Router Class Initialized
ERROR - 2015-04-15 13:20:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:20:22 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:20:22 --> URI Class Initialized
DEBUG - 2015-04-15 13:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:20:22 --> URI Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Router Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Router Class Initialized
ERROR - 2015-04-15 13:20:22 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:20:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:20:22 --> Output Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Security Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Input Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:20:22 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Loader Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:20:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:20:22 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Session Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:20:22 --> Session routines successfully run
DEBUG - 2015-04-15 13:20:22 --> Controller Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:20:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:20:22 --> Email Class Initialized
DEBUG - 2015-04-15 13:20:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:20:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:20:23 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:20:23 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:20:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:20:23 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:20:23 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:20:23 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Final output sent to browser
DEBUG - 2015-04-15 13:20:23 --> Total execution time: 1.0651
DEBUG - 2015-04-15 13:20:23 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:20:23 --> URI Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Router Class Initialized
DEBUG - 2015-04-15 13:20:23 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:20:23 --> Output Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Security Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Input Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:20:23 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Language Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Config Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Loader Class Initialized
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:20:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:20:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:20:23 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Session Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:20:24 --> Session routines successfully run
DEBUG - 2015-04-15 13:20:24 --> Controller Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:20:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:20:24 --> Email Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:20:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:20:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:20:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:20:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:20:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:20:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:20:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:20:24 --> Final output sent to browser
DEBUG - 2015-04-15 13:20:24 --> Total execution time: 0.9661
DEBUG - 2015-04-15 13:21:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:21:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:21:38 --> URI Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Router Class Initialized
DEBUG - 2015-04-15 13:21:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:21:38 --> Output Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Security Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Input Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:21:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Loader Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:21:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:21:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Session Class Initialized
DEBUG - 2015-04-15 13:21:38 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:21:38 --> Session routines successfully run
DEBUG - 2015-04-15 13:21:38 --> Controller Class Initialized
DEBUG - 2015-04-15 13:21:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:21:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:21:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:21:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:21:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:21:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:21:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:21:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:21:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:21:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:21:39 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:21:39 --> Final output sent to browser
DEBUG - 2015-04-15 13:21:39 --> Total execution time: 0.9030
DEBUG - 2015-04-15 13:21:40 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:40 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:21:40 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:21:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:21:40 --> URI Class Initialized
DEBUG - 2015-04-15 13:21:40 --> Router Class Initialized
ERROR - 2015-04-15 13:21:40 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:21:44 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:21:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:21:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:21:44 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:21:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:21:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:21:45 --> URI Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Router Class Initialized
ERROR - 2015-04-15 13:21:45 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:21:45 --> URI Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Router Class Initialized
DEBUG - 2015-04-15 13:21:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:21:45 --> Output Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Security Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Input Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:21:45 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Loader Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:21:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:21:45 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Session Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:21:45 --> Session routines successfully run
DEBUG - 2015-04-15 13:21:45 --> Controller Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:21:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:21:45 --> Email Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:21:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:21:45 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:21:45 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:21:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:21:45 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:21:45 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:21:45 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:45 --> Final output sent to browser
DEBUG - 2015-04-15 13:21:45 --> Total execution time: 0.9881
DEBUG - 2015-04-15 13:21:46 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:21:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:21:46 --> URI Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Router Class Initialized
DEBUG - 2015-04-15 13:21:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:21:46 --> Output Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Security Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Input Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:21:46 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Language Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Config Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Loader Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:21:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:21:46 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Session Class Initialized
DEBUG - 2015-04-15 13:21:46 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:21:47 --> Session routines successfully run
DEBUG - 2015-04-15 13:21:47 --> Controller Class Initialized
DEBUG - 2015-04-15 13:21:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:21:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:21:47 --> Email Class Initialized
DEBUG - 2015-04-15 13:21:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:21:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:21:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:21:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:47 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:21:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:21:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:21:48 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:21:48 --> Model Class Initialized
DEBUG - 2015-04-15 13:21:48 --> Final output sent to browser
DEBUG - 2015-04-15 13:21:48 --> Total execution time: 1.7691
DEBUG - 2015-04-15 13:22:28 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:22:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:22:28 --> URI Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Router Class Initialized
DEBUG - 2015-04-15 13:22:28 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:22:28 --> Output Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Security Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Input Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:22:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Loader Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:22:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:22:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Session Class Initialized
DEBUG - 2015-04-15 13:22:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:22:29 --> Session routines successfully run
DEBUG - 2015-04-15 13:22:29 --> Controller Class Initialized
DEBUG - 2015-04-15 13:22:29 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:22:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:22:29 --> Email Class Initialized
DEBUG - 2015-04-15 13:22:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:22:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:22:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:22:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:29 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:22:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:22:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:22:29 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:22:29 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:22:29 --> Final output sent to browser
DEBUG - 2015-04-15 13:22:29 --> Total execution time: 1.2361
DEBUG - 2015-04-15 13:22:31 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:31 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:22:31 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:22:31 --> URI Class Initialized
DEBUG - 2015-04-15 13:22:31 --> Router Class Initialized
ERROR - 2015-04-15 13:22:31 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:22:33 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:22:33 --> URI Class Initialized
DEBUG - 2015-04-15 13:22:33 --> URI Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Router Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Router Class Initialized
ERROR - 2015-04-15 13:22:33 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:22:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:22:33 --> URI Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Output Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Security Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Router Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Input Class Initialized
DEBUG - 2015-04-15 13:22:33 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:22:33 --> Output Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Security Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Input Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:22:34 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:33 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Language Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Loader Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Loader Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:22:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:22:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:22:34 --> Session Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:22:34 --> Session routines successfully run
DEBUG - 2015-04-15 13:22:34 --> Controller Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:22:34 --> Session Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:22:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:22:34 --> Session routines successfully run
DEBUG - 2015-04-15 13:22:34 --> Controller Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:22:34 --> Email Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:22:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Email Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:22:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> Final output sent to browser
DEBUG - 2015-04-15 13:22:34 --> Total execution time: 1.5471
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:22:34 --> Model Class Initialized
DEBUG - 2015-04-15 13:22:35 --> Final output sent to browser
DEBUG - 2015-04-15 13:22:35 --> Total execution time: 2.3181
DEBUG - 2015-04-15 13:23:53 --> Config Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:23:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:23:53 --> URI Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Router Class Initialized
DEBUG - 2015-04-15 13:23:53 --> No URI present. Default controller set.
DEBUG - 2015-04-15 13:23:53 --> Output Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Security Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Input Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:23:53 --> Language Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Language Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Config Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Loader Class Initialized
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:23:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:23:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:23:53 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Session Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:23:55 --> Session routines successfully run
DEBUG - 2015-04-15 13:23:55 --> Controller Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 13:23:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:23:55 --> Email Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:23:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:23:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:23:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:23:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:23:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 13:23:55 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 13:23:55 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 13:23:55 --> Final output sent to browser
DEBUG - 2015-04-15 13:23:55 --> Total execution time: 2.1460
DEBUG - 2015-04-15 13:24:00 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:24:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:24:00 --> URI Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Router Class Initialized
DEBUG - 2015-04-15 13:24:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:24:00 --> Output Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Security Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Input Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:24:00 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Loader Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:24:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:24:00 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Session Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:24:00 --> Session routines successfully run
DEBUG - 2015-04-15 13:24:00 --> Controller Class Initialized
DEBUG - 2015-04-15 13:24:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:24:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:24:01 --> Email Class Initialized
DEBUG - 2015-04-15 13:24:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:24:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:24:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:24:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:01 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:24:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:24:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:24:01 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:24:01 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:24:01 --> Final output sent to browser
DEBUG - 2015-04-15 13:24:01 --> Total execution time: 0.8150
DEBUG - 2015-04-15 13:24:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:24:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:24:38 --> URI Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Router Class Initialized
DEBUG - 2015-04-15 13:24:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:24:38 --> Output Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Security Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Input Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:24:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Loader Class Initialized
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:24:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:24:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:24:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:24:39 --> Session Class Initialized
DEBUG - 2015-04-15 13:24:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:24:39 --> Session routines successfully run
DEBUG - 2015-04-15 13:24:39 --> Controller Class Initialized
DEBUG - 2015-04-15 13:24:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:24:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:24:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:24:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:24:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:24:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:24:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:24:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:24:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:24:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:24:39 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:24:39 --> Final output sent to browser
DEBUG - 2015-04-15 13:24:39 --> Total execution time: 1.0601
DEBUG - 2015-04-15 13:24:42 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:24:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:24:42 --> URI Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Router Class Initialized
ERROR - 2015-04-15 13:24:42 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:24:42 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:24:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:24:42 --> URI Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Router Class Initialized
DEBUG - 2015-04-15 13:24:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:24:42 --> Output Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Security Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Input Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:24:42 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Loader Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:24:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:24:42 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Session Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:24:42 --> Session routines successfully run
DEBUG - 2015-04-15 13:24:42 --> Controller Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:24:42 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:24:42 --> Email Class Initialized
DEBUG - 2015-04-15 13:24:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:24:42 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:24:42 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:42 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:24:42 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:24:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:24:43 --> URI Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Router Class Initialized
DEBUG - 2015-04-15 13:24:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:24:43 --> Output Class Initialized
DEBUG - 2015-04-15 13:24:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:24:43 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:24:43 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Security Class Initialized
DEBUG - 2015-04-15 13:24:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:24:43 --> Input Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:24:43 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Language Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Config Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Loader Class Initialized
DEBUG - 2015-04-15 13:24:43 --> Final output sent to browser
DEBUG - 2015-04-15 13:24:43 --> Total execution time: 1.6381
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:24:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:24:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:24:43 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Session Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:24:44 --> Session routines successfully run
DEBUG - 2015-04-15 13:24:44 --> Controller Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:24:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:24:44 --> Email Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:24:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:24:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:24:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:24:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:24:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:24:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:24:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:24:44 --> Final output sent to browser
DEBUG - 2015-04-15 13:24:44 --> Total execution time: 0.8801
DEBUG - 2015-04-15 13:27:32 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:27:32 --> URI Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Router Class Initialized
DEBUG - 2015-04-15 13:27:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:27:32 --> Output Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Security Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Input Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:27:32 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Loader Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:27:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:27:32 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Session Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:27:32 --> Session routines successfully run
DEBUG - 2015-04-15 13:27:32 --> Controller Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:27:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:27:32 --> Email Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:27:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:27:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:27:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:32 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:27:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:27:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:27:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:27:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:27:33 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:27:33 --> Final output sent to browser
DEBUG - 2015-04-15 13:27:33 --> Total execution time: 0.8640
DEBUG - 2015-04-15 13:27:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:27:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:27:34 --> URI Class Initialized
DEBUG - 2015-04-15 13:27:34 --> Router Class Initialized
ERROR - 2015-04-15 13:27:34 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:27:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:27:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:27:38 --> URI Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Router Class Initialized
DEBUG - 2015-04-15 13:27:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:27:38 --> Output Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Security Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Input Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:27:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Loader Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:27:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:27:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Session Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:27:38 --> Session routines successfully run
DEBUG - 2015-04-15 13:27:38 --> Controller Class Initialized
DEBUG - 2015-04-15 13:27:38 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:27:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:27:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:27:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:27:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:27:39 --> URI Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Router Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:27:39 --> Output Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Security Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Input Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:27:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Loader Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:27:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Session Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Session routines successfully run
DEBUG - 2015-04-15 13:27:39 --> Controller Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:27:39 --> Final output sent to browser
DEBUG - 2015-04-15 13:27:39 --> Total execution time: 1.3231
DEBUG - 2015-04-15 13:27:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:27:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:27:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:27:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:27:40 --> Final output sent to browser
DEBUG - 2015-04-15 13:27:40 --> Total execution time: 0.9681
DEBUG - 2015-04-15 13:28:06 --> Config Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:28:06 --> URI Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Router Class Initialized
DEBUG - 2015-04-15 13:28:06 --> No URI present. Default controller set.
DEBUG - 2015-04-15 13:28:06 --> Output Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Security Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Input Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:28:06 --> Language Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Language Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Config Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Loader Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:28:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:28:06 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Session Class Initialized
DEBUG - 2015-04-15 13:28:06 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:28:06 --> Session routines successfully run
DEBUG - 2015-04-15 13:28:06 --> Controller Class Initialized
DEBUG - 2015-04-15 13:28:07 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 13:28:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:28:07 --> Email Class Initialized
DEBUG - 2015-04-15 13:28:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:28:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:28:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:28:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:28:07 --> Model Class Initialized
DEBUG - 2015-04-15 13:28:07 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:28:07 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 13:28:07 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 13:28:07 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 13:28:07 --> Final output sent to browser
DEBUG - 2015-04-15 13:28:07 --> Total execution time: 1.0601
DEBUG - 2015-04-15 13:29:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:29:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:29:10 --> URI Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Router Class Initialized
DEBUG - 2015-04-15 13:29:10 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:29:10 --> Output Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Security Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Input Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:29:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:10 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Loader Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:29:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:29:11 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Session Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:29:11 --> Session routines successfully run
DEBUG - 2015-04-15 13:29:11 --> Controller Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:29:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:29:11 --> Email Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:29:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:29:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:29:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:11 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:29:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:29:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:29:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:29:11 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:29:11 --> Final output sent to browser
DEBUG - 2015-04-15 13:29:11 --> Total execution time: 0.9391
DEBUG - 2015-04-15 13:29:13 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:29:13 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:29:13 --> URI Class Initialized
DEBUG - 2015-04-15 13:29:13 --> Router Class Initialized
ERROR - 2015-04-15 13:29:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:29:15 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:29:15 --> URI Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Router Class Initialized
ERROR - 2015-04-15 13:29:15 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:29:15 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:29:15 --> URI Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Router Class Initialized
DEBUG - 2015-04-15 13:29:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:29:15 --> Output Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Security Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Input Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:29:15 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Loader Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:29:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:29:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Session Class Initialized
DEBUG - 2015-04-15 13:29:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:29:15 --> Session routines successfully run
DEBUG - 2015-04-15 13:29:15 --> Controller Class Initialized
DEBUG - 2015-04-15 13:29:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:29:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:29:16 --> Email Class Initialized
DEBUG - 2015-04-15 13:29:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:29:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:29:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:29:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:29:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:29:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:29:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:29:16 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:16 --> Final output sent to browser
DEBUG - 2015-04-15 13:29:16 --> Total execution time: 1.7851
DEBUG - 2015-04-15 13:29:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:29:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:29:19 --> URI Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Router Class Initialized
DEBUG - 2015-04-15 13:29:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:29:19 --> Output Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Security Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Input Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:29:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Loader Class Initialized
DEBUG - 2015-04-15 13:29:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:29:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:29:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:29:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:29:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:29:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:29:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:29:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Session Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:29:20 --> Session routines successfully run
DEBUG - 2015-04-15 13:29:20 --> Controller Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:29:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:29:20 --> Email Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:29:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:29:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:29:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:29:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:29:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:29:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:29:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:29:20 --> Final output sent to browser
DEBUG - 2015-04-15 13:29:20 --> Total execution time: 0.8000
DEBUG - 2015-04-15 13:30:31 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:31 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:31 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:31 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:32 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:32 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:32 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:32 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:32 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:32 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:32 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:32 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:30:32 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:30:32 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:32 --> Total execution time: 1.1111
DEBUG - 2015-04-15 13:30:34 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:34 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:34 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:34 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:34 --> Router Class Initialized
ERROR - 2015-04-15 13:30:34 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:30:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:38 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:38 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:38 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:39 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:39 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:39 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:39 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:39 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:39 --> Total execution time: 1.3581
DEBUG - 2015-04-15 13:30:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:40 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:40 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:40 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:40 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:40 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:40 --> Total execution time: 1.2501
DEBUG - 2015-04-15 13:30:48 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:48 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:48 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:48 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:48 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:48 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:48 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:48 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:49 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:49 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:30:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:30:49 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:49 --> Total execution time: 1.1911
DEBUG - 2015-04-15 13:30:49 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:49 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:50 --> Router Class Initialized
ERROR - 2015-04-15 13:30:50 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:30:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:54 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Utf8 Class Initialized
ERROR - 2015-04-15 13:30:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:54 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:54 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:54 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:54 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:54 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:54 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:54 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:54 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:55 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:55 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:55 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:55 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:55 --> Total execution time: 1.1081
DEBUG - 2015-04-15 13:30:56 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:30:56 --> URI Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Router Class Initialized
DEBUG - 2015-04-15 13:30:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:30:56 --> Output Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Security Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Input Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:30:56 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Language Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Config Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Loader Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:30:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:30:56 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Session Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:30:56 --> Session routines successfully run
DEBUG - 2015-04-15 13:30:56 --> Controller Class Initialized
DEBUG - 2015-04-15 13:30:56 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:30:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:30:56 --> Email Class Initialized
DEBUG - 2015-04-15 13:30:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:30:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:30:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:30:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:57 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:30:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:30:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:30:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:30:57 --> Model Class Initialized
DEBUG - 2015-04-15 13:30:57 --> Final output sent to browser
DEBUG - 2015-04-15 13:30:57 --> Total execution time: 1.3221
DEBUG - 2015-04-15 13:32:47 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:32:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:32:47 --> URI Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Router Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:32:47 --> Output Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Security Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Input Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:32:47 --> Language Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Language Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Loader Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:32:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:32:47 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Session Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:32:47 --> Session routines successfully run
DEBUG - 2015-04-15 13:32:47 --> Controller Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:32:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:32:47 --> Email Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:32:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:32:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:32:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:47 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:32:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:32:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:32:47 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:32:47 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:32:48 --> Final output sent to browser
DEBUG - 2015-04-15 13:32:48 --> Total execution time: 0.8911
DEBUG - 2015-04-15 13:32:49 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:32:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:32:49 --> URI Class Initialized
DEBUG - 2015-04-15 13:32:49 --> Router Class Initialized
ERROR - 2015-04-15 13:32:49 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:32:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:32:54 --> URI Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Router Class Initialized
ERROR - 2015-04-15 13:32:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:32:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:32:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:32:54 --> URI Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Router Class Initialized
DEBUG - 2015-04-15 13:32:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:32:54 --> Output Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Security Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Input Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:32:54 --> Language Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Language Class Initialized
DEBUG - 2015-04-15 13:32:54 --> Config Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Loader Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:32:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:32:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Session Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:32:55 --> Session routines successfully run
DEBUG - 2015-04-15 13:32:55 --> Controller Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:32:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:32:55 --> Email Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:32:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:32:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:32:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:32:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:32:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:32:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:32:55 --> Model Class Initialized
DEBUG - 2015-04-15 13:32:55 --> Final output sent to browser
DEBUG - 2015-04-15 13:32:55 --> Total execution time: 0.8150
DEBUG - 2015-04-15 13:35:04 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:35:04 --> URI Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Router Class Initialized
DEBUG - 2015-04-15 13:35:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:35:04 --> Output Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Security Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Input Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:35:04 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Loader Class Initialized
DEBUG - 2015-04-15 13:35:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:35:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:35:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:35:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:35:05 --> Session Class Initialized
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:35:05 --> Session routines successfully run
DEBUG - 2015-04-15 13:35:05 --> Controller Class Initialized
DEBUG - 2015-04-15 13:35:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:35:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:35:05 --> Email Class Initialized
DEBUG - 2015-04-15 13:35:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:35:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:35:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:35:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:35:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:35:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:35:05 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:35:05 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:35:05 --> Final output sent to browser
DEBUG - 2015-04-15 13:35:05 --> Total execution time: 1.3221
DEBUG - 2015-04-15 13:35:08 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:35:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:35:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:35:08 --> URI Class Initialized
DEBUG - 2015-04-15 13:35:08 --> Router Class Initialized
ERROR - 2015-04-15 13:35:08 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:35:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:35:12 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:35:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:35:14 --> URI Class Initialized
DEBUG - 2015-04-15 13:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:35:14 --> URI Class Initialized
DEBUG - 2015-04-15 13:35:14 --> URI Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Router Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Router Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Router Class Initialized
ERROR - 2015-04-15 13:35:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:35:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:35:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:35:14 --> Output Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Security Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Output Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Input Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:35:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Security Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Loader Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:35:14 --> Input Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:35:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Language Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Config Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Loader Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:35:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:35:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:35:14 --> Session Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:35:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:35:14 --> Session routines successfully run
DEBUG - 2015-04-15 13:35:14 --> Controller Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Session Class Initialized
DEBUG - 2015-04-15 13:35:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:35:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:35:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:35:15 --> Session routines successfully run
DEBUG - 2015-04-15 13:35:15 --> Controller Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:35:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:35:15 --> Email Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:35:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Email Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:35:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:15 --> Final output sent to browser
DEBUG - 2015-04-15 13:35:15 --> Total execution time: 1.6941
DEBUG - 2015-04-15 13:35:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:35:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:35:15 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:35:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:35:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:35:17 --> Final output sent to browser
DEBUG - 2015-04-15 13:35:17 --> Total execution time: 4.6993
DEBUG - 2015-04-15 13:37:08 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:37:08 --> URI Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Router Class Initialized
DEBUG - 2015-04-15 13:37:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:37:08 --> Output Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Security Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Input Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:37:08 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Loader Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:37:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:37:08 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Session Class Initialized
DEBUG - 2015-04-15 13:37:08 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:37:08 --> Session routines successfully run
DEBUG - 2015-04-15 13:37:09 --> Controller Class Initialized
DEBUG - 2015-04-15 13:37:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:37:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:37:09 --> Email Class Initialized
DEBUG - 2015-04-15 13:37:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:37:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:37:09 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:37:09 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:09 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:37:09 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:37:09 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:37:09 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:37:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:37:10 --> Final output sent to browser
DEBUG - 2015-04-15 13:37:10 --> Total execution time: 1.7771
DEBUG - 2015-04-15 13:37:11 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:37:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:37:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:37:11 --> URI Class Initialized
DEBUG - 2015-04-15 13:37:11 --> Router Class Initialized
ERROR - 2015-04-15 13:37:11 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:37:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:37:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:37:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Router Class Initialized
ERROR - 2015-04-15 13:37:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:37:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:37:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:37:17 --> URI Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Router Class Initialized
DEBUG - 2015-04-15 13:37:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:37:17 --> Output Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Security Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Input Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:37:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Loader Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:37:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:37:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Session Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:37:17 --> Session routines successfully run
DEBUG - 2015-04-15 13:37:17 --> Controller Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:37:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:37:17 --> Email Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:37:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:37:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:37:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:37:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:37:17 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:37:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:37:18 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:18 --> Final output sent to browser
DEBUG - 2015-04-15 13:37:18 --> Total execution time: 0.8150
DEBUG - 2015-04-15 13:37:18 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:18 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:37:18 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:37:18 --> URI Class Initialized
DEBUG - 2015-04-15 13:37:18 --> Router Class Initialized
DEBUG - 2015-04-15 13:37:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:37:19 --> Output Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Security Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Input Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:37:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Language Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Loader Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:37:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:37:19 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Session Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:37:19 --> Session routines successfully run
DEBUG - 2015-04-15 13:37:19 --> Controller Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:37:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:37:19 --> Email Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:37:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:37:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:37:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:37:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:37:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:37:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:37:19 --> Model Class Initialized
DEBUG - 2015-04-15 13:37:19 --> Final output sent to browser
DEBUG - 2015-04-15 13:37:19 --> Total execution time: 1.1261
DEBUG - 2015-04-15 13:39:49 --> Config Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:39:49 --> URI Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Router Class Initialized
DEBUG - 2015-04-15 13:39:49 --> No URI present. Default controller set.
DEBUG - 2015-04-15 13:39:49 --> Output Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Security Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Input Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:39:49 --> Language Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Language Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Config Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Loader Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:39:49 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:39:49 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Session Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:39:49 --> Session routines successfully run
DEBUG - 2015-04-15 13:39:49 --> Controller Class Initialized
DEBUG - 2015-04-15 13:39:49 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 13:39:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:39:50 --> Email Class Initialized
DEBUG - 2015-04-15 13:39:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:39:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:39:50 --> Model Class Initialized
DEBUG - 2015-04-15 13:39:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:39:50 --> Model Class Initialized
DEBUG - 2015-04-15 13:39:50 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:39:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 13:39:50 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 13:39:51 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 13:39:51 --> Final output sent to browser
DEBUG - 2015-04-15 13:39:51 --> Total execution time: 2.1081
DEBUG - 2015-04-15 13:39:52 --> Config Class Initialized
DEBUG - 2015-04-15 13:39:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:39:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:39:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:39:52 --> URI Class Initialized
DEBUG - 2015-04-15 13:39:52 --> Router Class Initialized
ERROR - 2015-04-15 13:39:52 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:39:53 --> Config Class Initialized
DEBUG - 2015-04-15 13:39:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:39:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:39:53 --> URI Class Initialized
DEBUG - 2015-04-15 13:39:53 --> Router Class Initialized
ERROR - 2015-04-15 13:39:53 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:50:23 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:23 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Router Class Initialized
DEBUG - 2015-04-15 13:50:23 --> No URI present. Default controller set.
DEBUG - 2015-04-15 13:50:23 --> Output Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Security Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Input Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:50:23 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Loader Class Initialized
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:50:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:50:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:50:23 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Session Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:50:24 --> Session routines successfully run
DEBUG - 2015-04-15 13:50:24 --> Controller Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 13:50:24 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:50:24 --> Email Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:50:24 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:50:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:24 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:50:24 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:50:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 13:50:24 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 13:50:24 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 13:50:24 --> Final output sent to browser
DEBUG - 2015-04-15 13:50:24 --> Total execution time: 1.0811
DEBUG - 2015-04-15 13:50:25 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:25 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:25 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:25 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:26 --> Router Class Initialized
ERROR - 2015-04-15 13:50:26 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:50:27 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:27 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:27 --> Router Class Initialized
ERROR - 2015-04-15 13:50:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:50:35 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:35 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Router Class Initialized
DEBUG - 2015-04-15 13:50:35 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:50:35 --> Output Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Security Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Input Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:50:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Loader Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:50:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:50:35 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Session Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:50:35 --> Session routines successfully run
DEBUG - 2015-04-15 13:50:35 --> Controller Class Initialized
DEBUG - 2015-04-15 13:50:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:50:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:50:35 --> Email Class Initialized
DEBUG - 2015-04-15 13:50:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:50:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:50:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:50:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:36 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:50:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:50:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:50:36 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:50:36 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:50:36 --> Final output sent to browser
DEBUG - 2015-04-15 13:50:36 --> Total execution time: 1.2341
DEBUG - 2015-04-15 13:50:37 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:37 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:37 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:37 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:37 --> Router Class Initialized
ERROR - 2015-04-15 13:50:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:50:38 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:38 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:38 --> Router Class Initialized
ERROR - 2015-04-15 13:50:38 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:50:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:39 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Router Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:50:39 --> Output Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Security Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Input Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:50:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Loader Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:50:39 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:50:39 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Session Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:50:39 --> Session routines successfully run
DEBUG - 2015-04-15 13:50:39 --> Controller Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:50:39 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:50:39 --> Email Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:50:39 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:50:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:50:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:50:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:50:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:50:39 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:50:39 --> URI Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Final output sent to browser
DEBUG - 2015-04-15 13:50:39 --> Total execution time: 0.8691
DEBUG - 2015-04-15 13:50:39 --> Router Class Initialized
DEBUG - 2015-04-15 13:50:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:50:39 --> Output Class Initialized
DEBUG - 2015-04-15 13:50:39 --> Security Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Input Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:50:40 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Language Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Config Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Loader Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:50:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:50:40 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Session Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:50:40 --> Session routines successfully run
DEBUG - 2015-04-15 13:50:40 --> Controller Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:50:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:50:40 --> Email Class Initialized
DEBUG - 2015-04-15 13:50:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:50:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:50:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:50:40 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:41 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:50:41 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:50:41 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:41 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:50:41 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:41 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:50:41 --> Model Class Initialized
DEBUG - 2015-04-15 13:50:41 --> Final output sent to browser
DEBUG - 2015-04-15 13:50:41 --> Total execution time: 1.4511
DEBUG - 2015-04-15 13:52:11 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:52:11 --> URI Class Initialized
DEBUG - 2015-04-15 13:52:11 --> Router Class Initialized
DEBUG - 2015-04-15 13:52:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:52:11 --> Output Class Initialized
DEBUG - 2015-04-15 13:52:11 --> Security Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Input Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:52:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Language Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Loader Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Session Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:52:12 --> Session routines successfully run
DEBUG - 2015-04-15 13:52:12 --> Controller Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:52:12 --> Email Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:12 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:52:12 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:52:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:52:13 --> Final output sent to browser
DEBUG - 2015-04-15 13:52:13 --> Total execution time: 1.2101
DEBUG - 2015-04-15 13:52:13 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:13 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:52:13 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:52:14 --> URI Class Initialized
DEBUG - 2015-04-15 13:52:14 --> Router Class Initialized
ERROR - 2015-04-15 13:52:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:52:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:52:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:52:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:52:19 --> URI Class Initialized
DEBUG - 2015-04-15 13:52:19 --> Router Class Initialized
ERROR - 2015-04-15 13:52:19 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:52:19 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:52:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:52:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:52:19 --> URI Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Router Class Initialized
DEBUG - 2015-04-15 13:52:20 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:52:20 --> Output Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Security Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Input Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:52:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Language Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Config Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Loader Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:52:20 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:52:20 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Session Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:52:20 --> Session routines successfully run
DEBUG - 2015-04-15 13:52:20 --> Controller Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:52:20 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:52:20 --> Email Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:52:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:52:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:52:20 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:20 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:52:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:52:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:52:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:52:21 --> Model Class Initialized
DEBUG - 2015-04-15 13:52:21 --> Final output sent to browser
DEBUG - 2015-04-15 13:52:21 --> Total execution time: 1.2801
DEBUG - 2015-04-15 13:54:43 --> Config Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:54:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:54:43 --> URI Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Router Class Initialized
DEBUG - 2015-04-15 13:54:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:54:43 --> Output Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Security Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Input Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:54:43 --> Language Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Language Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Config Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Loader Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:54:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:54:43 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Session Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:54:43 --> Session routines successfully run
DEBUG - 2015-04-15 13:54:43 --> Controller Class Initialized
DEBUG - 2015-04-15 13:54:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:54:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:54:43 --> Email Class Initialized
DEBUG - 2015-04-15 13:54:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:54:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:54:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:54:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:54:44 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:54:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:54:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:54:44 --> Model Class Initialized
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 13:54:44 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 13:54:44 --> Final output sent to browser
DEBUG - 2015-04-15 13:54:44 --> Total execution time: 1.9221
DEBUG - 2015-04-15 13:54:46 --> Config Class Initialized
DEBUG - 2015-04-15 13:54:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:54:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:54:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:54:46 --> URI Class Initialized
DEBUG - 2015-04-15 13:54:46 --> Router Class Initialized
ERROR - 2015-04-15 13:54:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:56:27 --> Config Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:56:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:56:27 --> URI Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Router Class Initialized
DEBUG - 2015-04-15 13:56:27 --> No URI present. Default controller set.
DEBUG - 2015-04-15 13:56:27 --> Output Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Security Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Input Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:56:27 --> Language Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Language Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Config Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Loader Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:56:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:56:27 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Session Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:56:27 --> Session routines successfully run
DEBUG - 2015-04-15 13:56:27 --> Controller Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 13:56:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:56:27 --> Email Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:56:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:56:27 --> Model Class Initialized
DEBUG - 2015-04-15 13:56:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:56:27 --> Model Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:56:27 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 13:56:27 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 13:56:28 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 13:56:28 --> Final output sent to browser
DEBUG - 2015-04-15 13:56:28 --> Total execution time: 1.0231
DEBUG - 2015-04-15 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:57:01 --> URI Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Router Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:57:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:57:01 --> URI Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Output Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Router Class Initialized
ERROR - 2015-04-15 13:57:01 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 13:57:01 --> Security Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Input Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Language Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Config Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Loader Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:57:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:57:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:57:01 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:57:01 --> Session Class Initialized
DEBUG - 2015-04-15 13:57:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:57:02 --> Session routines successfully run
DEBUG - 2015-04-15 13:57:02 --> Controller Class Initialized
DEBUG - 2015-04-15 13:57:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:57:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:57:02 --> Email Class Initialized
DEBUG - 2015-04-15 13:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:57:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:57:02 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:02 --> Final output sent to browser
DEBUG - 2015-04-15 13:57:02 --> Total execution time: 0.8010
DEBUG - 2015-04-15 13:57:11 --> Config Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Hooks Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Utf8 Class Initialized
DEBUG - 2015-04-15 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 13:57:11 --> URI Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Router Class Initialized
DEBUG - 2015-04-15 13:57:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 13:57:11 --> Output Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Security Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Input Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 13:57:11 --> Language Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Language Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Config Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Loader Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: url_helper
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: form_helper
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: language_helper
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: user_helper
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: date_helper
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 13:57:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 13:57:11 --> Database Driver Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Session Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: string_helper
DEBUG - 2015-04-15 13:57:11 --> Session routines successfully run
DEBUG - 2015-04-15 13:57:11 --> Controller Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 13:57:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 13:57:11 --> Email Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 13:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:11 --> Form Validation Class Initialized
DEBUG - 2015-04-15 13:57:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 13:57:11 --> Model Class Initialized
DEBUG - 2015-04-15 13:57:12 --> Final output sent to browser
DEBUG - 2015-04-15 13:57:12 --> Total execution time: 0.7510
DEBUG - 2015-04-15 14:05:02 --> Config Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:05:02 --> URI Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Router Class Initialized
DEBUG - 2015-04-15 14:05:02 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:05:02 --> Output Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Security Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Input Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:05:02 --> Language Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Language Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Config Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Loader Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:05:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:05:02 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Session Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:05:02 --> Session routines successfully run
DEBUG - 2015-04-15 14:05:02 --> Controller Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:05:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:05:02 --> Email Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:05:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:05:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:05:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:05:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:05:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:05:02 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:05:02 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:05:02 --> Final output sent to browser
DEBUG - 2015-04-15 14:05:02 --> Total execution time: 0.7460
DEBUG - 2015-04-15 14:06:02 --> Config Class Initialized
DEBUG - 2015-04-15 14:06:02 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:06:02 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:06:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:06:02 --> URI Class Initialized
DEBUG - 2015-04-15 14:06:02 --> Router Class Initialized
DEBUG - 2015-04-15 14:06:02 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:06:02 --> Output Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Security Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Input Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:06:03 --> Language Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Language Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Config Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Loader Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:06:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:06:03 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Session Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:06:03 --> Session routines successfully run
DEBUG - 2015-04-15 14:06:03 --> Controller Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:06:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:06:03 --> Email Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:06:03 --> Model Class Initialized
DEBUG - 2015-04-15 14:06:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:06:03 --> Model Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:06:03 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:06:03 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:06:03 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:06:03 --> Final output sent to browser
DEBUG - 2015-04-15 14:06:03 --> Total execution time: 0.6990
DEBUG - 2015-04-15 14:06:40 --> Config Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:06:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:06:40 --> URI Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Router Class Initialized
DEBUG - 2015-04-15 14:06:40 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:06:40 --> Output Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Security Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Input Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:06:40 --> Language Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Language Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Config Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Loader Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:06:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:06:40 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Session Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:06:40 --> Session routines successfully run
DEBUG - 2015-04-15 14:06:40 --> Controller Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:06:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:06:40 --> Email Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:06:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:06:40 --> Model Class Initialized
DEBUG - 2015-04-15 14:06:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:06:40 --> Model Class Initialized
DEBUG - 2015-04-15 14:06:40 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:06:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:06:41 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:06:41 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:06:41 --> Final output sent to browser
DEBUG - 2015-04-15 14:06:41 --> Total execution time: 1.0521
DEBUG - 2015-04-15 14:08:05 --> Config Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:08:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:08:05 --> URI Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Router Class Initialized
DEBUG - 2015-04-15 14:08:05 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:08:05 --> Output Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Security Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Input Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:08:05 --> Language Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Language Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Config Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Loader Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:08:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:08:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Session Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:08:05 --> Session routines successfully run
DEBUG - 2015-04-15 14:08:05 --> Controller Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:08:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:08:05 --> Email Class Initialized
DEBUG - 2015-04-15 14:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:08:05 --> Model Class Initialized
DEBUG - 2015-04-15 14:08:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:08:05 --> Model Class Initialized
DEBUG - 2015-04-15 14:08:06 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:08:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:08:06 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:08:06 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:08:06 --> Final output sent to browser
DEBUG - 2015-04-15 14:08:06 --> Total execution time: 0.8090
DEBUG - 2015-04-15 14:09:27 --> Config Class Initialized
DEBUG - 2015-04-15 14:09:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:09:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:09:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:09:27 --> URI Class Initialized
DEBUG - 2015-04-15 14:09:27 --> Router Class Initialized
DEBUG - 2015-04-15 14:09:27 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:09:27 --> Output Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Security Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Input Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:09:28 --> Language Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Language Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Config Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Loader Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:09:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:09:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Session Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:09:28 --> Session routines successfully run
DEBUG - 2015-04-15 14:09:28 --> Controller Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:09:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:09:28 --> Email Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:09:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:09:28 --> Model Class Initialized
DEBUG - 2015-04-15 14:09:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:09:28 --> Model Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:09:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:09:29 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:09:29 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:09:29 --> Final output sent to browser
DEBUG - 2015-04-15 14:09:29 --> Total execution time: 1.2811
DEBUG - 2015-04-15 14:10:08 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:08 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Router Class Initialized
DEBUG - 2015-04-15 14:10:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:10:08 --> Output Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Security Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Input Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:10:08 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Loader Class Initialized
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:10:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:10:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:10:09 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:10:09 --> Session Class Initialized
DEBUG - 2015-04-15 14:10:09 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:10:09 --> Session routines successfully run
DEBUG - 2015-04-15 14:10:09 --> Controller Class Initialized
DEBUG - 2015-04-15 14:10:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:10:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:10:09 --> Email Class Initialized
DEBUG - 2015-04-15 14:10:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:10:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:10:09 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:10:09 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:09 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:10:09 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:10:09 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:10:09 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:10:09 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:10:09 --> Final output sent to browser
DEBUG - 2015-04-15 14:10:09 --> Total execution time: 1.1091
DEBUG - 2015-04-15 14:10:10 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:10 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:10 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:10 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:10 --> Router Class Initialized
ERROR - 2015-04-15 14:10:10 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:10:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:14 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Router Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:10:14 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Output Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Router Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Security Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Input Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:10:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Config Class Initialized
ERROR - 2015-04-15 14:10:14 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:10:14 --> Loader Class Initialized
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:10:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:10:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:10:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Session Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:10:15 --> Session routines successfully run
DEBUG - 2015-04-15 14:10:15 --> Controller Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:10:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:10:15 --> Email Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:10:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:10:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:10:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:10:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:10:15 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:10:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Router Class Initialized
DEBUG - 2015-04-15 14:10:15 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:10:15 --> Output Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Final output sent to browser
DEBUG - 2015-04-15 14:10:15 --> Security Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Total execution time: 0.9381
DEBUG - 2015-04-15 14:10:15 --> Input Class Initialized
DEBUG - 2015-04-15 14:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:10:15 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Loader Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:10:16 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:10:16 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Session Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:10:16 --> Session routines successfully run
DEBUG - 2015-04-15 14:10:16 --> Controller Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:10:16 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:10:16 --> Email Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:10:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:10:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:10:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:10:16 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:10:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:16 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:10:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:16 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:10:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:16 --> Final output sent to browser
DEBUG - 2015-04-15 14:10:16 --> Total execution time: 1.4601
DEBUG - 2015-04-15 14:10:25 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:25 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Router Class Initialized
DEBUG - 2015-04-15 14:10:25 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:10:25 --> Output Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Security Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Input Class Initialized
DEBUG - 2015-04-15 14:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:10:26 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Language Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Loader Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:10:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:10:26 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Session Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:10:26 --> Session routines successfully run
DEBUG - 2015-04-15 14:10:26 --> Controller Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:10:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:10:26 --> Email Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:10:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:10:26 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:10:26 --> Model Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:10:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:10:26 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:10:26 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:10:26 --> Final output sent to browser
DEBUG - 2015-04-15 14:10:26 --> Total execution time: 1.3431
DEBUG - 2015-04-15 14:10:27 --> Config Class Initialized
DEBUG - 2015-04-15 14:10:27 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:10:27 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:10:27 --> URI Class Initialized
DEBUG - 2015-04-15 14:10:27 --> Router Class Initialized
ERROR - 2015-04-15 14:10:27 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:12:26 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:12:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:12:26 --> URI Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Router Class Initialized
DEBUG - 2015-04-15 14:12:26 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:12:26 --> Output Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Security Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Input Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:12:26 --> Language Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Language Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Loader Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:12:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:12:26 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Session Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:12:26 --> Session routines successfully run
DEBUG - 2015-04-15 14:12:26 --> Controller Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:12:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:12:26 --> Email Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:12:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:12:26 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:12:26 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:12:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:12:26 --> File loaded: application/views/../modules_core/login/views/index.php
DEBUG - 2015-04-15 14:12:27 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:12:27 --> Final output sent to browser
DEBUG - 2015-04-15 14:12:27 --> Total execution time: 0.6460
DEBUG - 2015-04-15 14:12:28 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:12:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:12:28 --> URI Class Initialized
DEBUG - 2015-04-15 14:12:28 --> Router Class Initialized
ERROR - 2015-04-15 14:12:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:12:29 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:29 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:12:29 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:12:29 --> URI Class Initialized
DEBUG - 2015-04-15 14:12:29 --> Router Class Initialized
ERROR - 2015-04-15 14:12:29 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:12:58 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:58 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:12:58 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:12:58 --> URI Class Initialized
DEBUG - 2015-04-15 14:12:58 --> Router Class Initialized
DEBUG - 2015-04-15 14:12:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:12:58 --> Output Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Security Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Input Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:12:59 --> Language Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Language Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Loader Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:12:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:12:59 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Session Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:12:59 --> Session routines successfully run
DEBUG - 2015-04-15 14:12:59 --> Controller Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:12:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:12:59 --> Email Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:12:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:12:59 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:12:59 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:12:59 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:12:59 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:12:59 --> Model Class Initialized
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:12:59 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:12:59 --> Final output sent to browser
DEBUG - 2015-04-15 14:12:59 --> Total execution time: 0.7930
DEBUG - 2015-04-15 14:12:59 --> Config Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:12:59 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:00 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Router Class Initialized
ERROR - 2015-04-15 14:13:00 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:13:00 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:00 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:13:00 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:00 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:00 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:00 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:00 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:13:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:00 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:00 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:00 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:00 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:13:01 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:13:01 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:13:01 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:01 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:01 --> Total execution time: 0.9111
DEBUG - 2015-04-15 14:13:01 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:13:01 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:01 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:02 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:02 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:02 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:13:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:02 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:13:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:13:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:13:02 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:02 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:02 --> Total execution time: 1.2191
DEBUG - 2015-04-15 14:13:16 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:16 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:16 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:16 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:17 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:17 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:13:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:17 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:13:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:17 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:17 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:13:17 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:18 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:18 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:18 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:13:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:18 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:18 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:18 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:18 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:13:18 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-15 14:13:18 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-15 14:13:18 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:18 --> Total execution time: 0.8230
DEBUG - 2015-04-15 14:13:37 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:37 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:37 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:37 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:37 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:37 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:13:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:37 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:37 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:37 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:13:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-15 14:13:38 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:38 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:38 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-15 14:13:38 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:38 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:38 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:38 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:38 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Services MX_Controller Initialized
DEBUG - 2015-04-15 14:13:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:38 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:38 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:38 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:38 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:38 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-15 14:13:38 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:13:38 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:38 --> Total execution time: 0.6290
DEBUG - 2015-04-15 14:13:38 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:39 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:39 --> Router Class Initialized
ERROR - 2015-04-15 14:13:39 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:13:44 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:44 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:44 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-15 14:13:44 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:44 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:44 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:44 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:44 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Services MX_Controller Initialized
DEBUG - 2015-04-15 14:13:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:44 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:44 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:44 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:44 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:44 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-15 14:13:44 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:13:44 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:44 --> Total execution time: 0.6040
DEBUG - 2015-04-15 14:13:44 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:45 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:45 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:45 --> Router Class Initialized
ERROR - 2015-04-15 14:13:45 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:13:50 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:50 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:50 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-15 14:13:50 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:51 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:51 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:51 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:51 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Services MX_Controller Initialized
DEBUG - 2015-04-15 14:13:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:51 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:51 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-15 14:13:51 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:13:51 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:51 --> Total execution time: 0.7030
DEBUG - 2015-04-15 14:13:51 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:51 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:51 --> Router Class Initialized
ERROR - 2015-04-15 14:13:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:13:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:53 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:13:53 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:53 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:53 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:53 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:13:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:53 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:53 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:54 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:13:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:13:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:13:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:13:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:13:54 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:54 --> Total execution time: 0.9521
DEBUG - 2015-04-15 14:13:54 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:54 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:54 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:54 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:54 --> Router Class Initialized
ERROR - 2015-04-15 14:13:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:13:55 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:55 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:13:55 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:55 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:55 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:55 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:13:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:55 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:55 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:55 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:13:55 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:13:55 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:13:55 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:55 --> Total execution time: 0.5990
DEBUG - 2015-04-15 14:13:55 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:13:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:13:55 --> URI Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Router Class Initialized
DEBUG - 2015-04-15 14:13:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:13:55 --> Output Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Security Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Input Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:13:55 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Language Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Config Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Loader Class Initialized
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:13:55 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:13:56 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:13:56 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:13:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:13:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:13:56 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Session Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:13:56 --> Session routines successfully run
DEBUG - 2015-04-15 14:13:56 --> Controller Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:13:56 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:13:56 --> Email Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:13:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:13:56 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:13:56 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:13:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:13:56 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:13:56 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:13:56 --> Model Class Initialized
DEBUG - 2015-04-15 14:13:56 --> Final output sent to browser
DEBUG - 2015-04-15 14:13:56 --> Total execution time: 0.8620
DEBUG - 2015-04-15 14:19:36 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:19:36 --> URI Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Router Class Initialized
DEBUG - 2015-04-15 14:19:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:19:36 --> Output Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Security Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Input Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:19:36 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Loader Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:19:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:19:36 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Session Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:19:36 --> Session routines successfully run
DEBUG - 2015-04-15 14:19:36 --> Controller Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:19:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:19:36 --> Email Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:19:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:19:36 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:19:36 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:36 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:19:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:19:36 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:19:36 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:19:36 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:37 --> DB Transaction Failure
ERROR - 2015-04-15 14:19:37 --> Query error: Unknown column 'users_id' in 'where clause'
DEBUG - 2015-04-15 14:19:37 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-04-15 14:19:50 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:19:50 --> URI Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Router Class Initialized
DEBUG - 2015-04-15 14:19:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:19:50 --> Output Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Security Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Input Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:19:50 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Loader Class Initialized
DEBUG - 2015-04-15 14:19:50 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:19:50 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:19:50 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:19:50 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:19:51 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:19:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:19:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:19:51 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:19:51 --> Session Class Initialized
DEBUG - 2015-04-15 14:19:51 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:19:51 --> Session routines successfully run
DEBUG - 2015-04-15 14:19:51 --> Controller Class Initialized
DEBUG - 2015-04-15 14:19:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:19:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:19:51 --> Email Class Initialized
DEBUG - 2015-04-15 14:19:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:19:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:19:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:19:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:51 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:19:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:19:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:19:51 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:19:51 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:19:51 --> Final output sent to browser
DEBUG - 2015-04-15 14:19:51 --> Total execution time: 0.9340
DEBUG - 2015-04-15 14:19:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:19:53 --> URI Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Router Class Initialized
DEBUG - 2015-04-15 14:19:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:19:53 --> Output Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Security Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:19:53 --> URI Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Router Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Input Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:19:53 --> URI Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Router Class Initialized
DEBUG - 2015-04-15 14:19:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:19:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Output Class Initialized
ERROR - 2015-04-15 14:19:53 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:19:53 --> Security Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Input Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:19:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Loader Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:19:53 --> Language Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Config Class Initialized
DEBUG - 2015-04-15 14:19:53 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:19:54 --> Loader Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:19:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:19:54 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:19:54 --> Session Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:19:54 --> Session routines successfully run
DEBUG - 2015-04-15 14:19:54 --> Controller Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:19:54 --> Session Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:19:54 --> Session routines successfully run
DEBUG - 2015-04-15 14:19:54 --> Controller Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:19:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:19:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:19:54 --> Email Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Email Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:19:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:19:54 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:19:54 --> Model Class Initialized
DEBUG - 2015-04-15 14:19:54 --> Final output sent to browser
DEBUG - 2015-04-15 14:19:54 --> Total execution time: 1.1571
DEBUG - 2015-04-15 14:19:54 --> Final output sent to browser
DEBUG - 2015-04-15 14:19:54 --> Total execution time: 1.5281
DEBUG - 2015-04-15 14:21:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:21:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:21:14 --> URI Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Router Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:21:14 --> Output Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Security Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Input Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:21:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Loader Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:21:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:21:14 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Session Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:21:14 --> Session routines successfully run
DEBUG - 2015-04-15 14:21:14 --> Controller Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:21:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:21:14 --> Email Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:21:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:21:14 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:21:14 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:14 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:21:14 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:21:14 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:21:14 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:21:14 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:21:14 --> Final output sent to browser
DEBUG - 2015-04-15 14:21:14 --> Total execution time: 0.7970
DEBUG - 2015-04-15 14:21:16 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:21:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:21:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:21:16 --> URI Class Initialized
DEBUG - 2015-04-15 14:21:16 --> Router Class Initialized
ERROR - 2015-04-15 14:21:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:21:16 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:21:17 --> URI Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Router Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:21:17 --> Output Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Security Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Input Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:21:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Loader Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:21:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:21:17 --> URI Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Router Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:21:17 --> Output Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Security Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Input Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:21:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:21:17 --> Language Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Config Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:21:17 --> Loader Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:21:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:21:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:21:17 --> Session Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:21:17 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Session routines successfully run
DEBUG - 2015-04-15 14:21:17 --> Controller Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Session Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:21:17 --> Session routines successfully run
DEBUG - 2015-04-15 14:21:17 --> Controller Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:21:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:21:17 --> Email Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:21:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:21:17 --> Email Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:21:17 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:17 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:21:17 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:18 --> Final output sent to browser
DEBUG - 2015-04-15 14:21:18 --> Total execution time: 0.7480
DEBUG - 2015-04-15 14:21:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:21:18 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:21:18 --> Model Class Initialized
DEBUG - 2015-04-15 14:21:18 --> Final output sent to browser
DEBUG - 2015-04-15 14:21:18 --> Total execution time: 1.5401
DEBUG - 2015-04-15 14:22:44 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:44 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:22:44 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:22:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:22:44 --> URI Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Router Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:22:45 --> Output Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Security Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Input Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:22:45 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Loader Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:22:45 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:22:45 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Session Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:22:45 --> Session routines successfully run
DEBUG - 2015-04-15 14:22:45 --> Controller Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:22:45 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:22:45 --> Email Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:22:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:22:45 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:22:45 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:45 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:22:45 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:22:45 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:22:45 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:22:45 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:22:45 --> Final output sent to browser
DEBUG - 2015-04-15 14:22:45 --> Total execution time: 0.8390
DEBUG - 2015-04-15 14:22:46 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:46 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:22:46 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:22:46 --> URI Class Initialized
DEBUG - 2015-04-15 14:22:46 --> Router Class Initialized
ERROR - 2015-04-15 14:22:46 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:22:46 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:22:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:22:47 --> URI Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Router Class Initialized
DEBUG - 2015-04-15 14:22:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:22:47 --> Output Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Security Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Input Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:22:47 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:22:47 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:47 --> URI Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Loader Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Router Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:22:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:22:47 --> Output Class Initialized
DEBUG - 2015-04-15 14:22:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:22:47 --> Security Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Input Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:22:48 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Language Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Session Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:22:48 --> Config Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Session routines successfully run
DEBUG - 2015-04-15 14:22:48 --> Loader Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Controller Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:22:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:22:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:22:48 --> Email Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:22:48 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Session Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Session routines successfully run
DEBUG - 2015-04-15 14:22:48 --> Final output sent to browser
DEBUG - 2015-04-15 14:22:48 --> Controller Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Total execution time: 1.5691
DEBUG - 2015-04-15 14:22:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:22:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:22:48 --> Email Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:22:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:22:48 --> Model Class Initialized
DEBUG - 2015-04-15 14:22:48 --> Final output sent to browser
DEBUG - 2015-04-15 14:22:48 --> Total execution time: 1.2441
DEBUG - 2015-04-15 14:23:28 --> Config Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:23:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:23:28 --> URI Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Router Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Output Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Security Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Input Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:23:28 --> Language Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Language Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Config Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Loader Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:23:28 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:23:28 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Session Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:23:28 --> Session routines successfully run
DEBUG - 2015-04-15 14:23:28 --> Controller Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:23:28 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:23:28 --> Email Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:23:28 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:23:28 --> Model Class Initialized
DEBUG - 2015-04-15 14:23:28 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:23:28 --> Model Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:23:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:23:29 --> Config Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:23:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:23:29 --> URI Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Router Class Initialized
DEBUG - 2015-04-15 14:23:29 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:23:29 --> Output Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Security Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Input Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:23:29 --> Language Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Language Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Config Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Loader Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:23:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:23:29 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Session Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:23:29 --> Session routines successfully run
DEBUG - 2015-04-15 14:23:29 --> Controller Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:23:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:23:29 --> Email Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:23:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:23:29 --> Model Class Initialized
DEBUG - 2015-04-15 14:23:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:23:29 --> Model Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:23:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:23:29 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-15 14:23:29 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-15 14:23:29 --> Final output sent to browser
DEBUG - 2015-04-15 14:23:29 --> Total execution time: 0.5880
DEBUG - 2015-04-15 14:24:29 --> Config Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:24:29 --> URI Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Router Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Output Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Security Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Input Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:24:29 --> Language Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Language Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Config Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Loader Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:24:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:24:29 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Session Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:24:29 --> Session routines successfully run
DEBUG - 2015-04-15 14:24:29 --> Controller Class Initialized
DEBUG - 2015-04-15 14:24:29 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:24:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:24:30 --> Email Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:24:30 --> Model Class Initialized
DEBUG - 2015-04-15 14:24:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:24:30 --> Model Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-15 14:24:30 --> Config Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:24:30 --> URI Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Router Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Output Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Security Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Input Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:24:30 --> Language Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Language Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Config Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Loader Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:24:30 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Session Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:24:30 --> Session routines successfully run
DEBUG - 2015-04-15 14:24:30 --> Controller Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:24:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:24:30 --> Email Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:24:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:24:30 --> Model Class Initialized
DEBUG - 2015-04-15 14:24:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:24:30 --> Model Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:24:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:24:30 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-15 14:24:30 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-15 14:24:30 --> Final output sent to browser
DEBUG - 2015-04-15 14:24:30 --> Total execution time: 0.5120
DEBUG - 2015-04-15 14:25:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:14 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Router Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Output Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Security Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Input Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:25:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Loader Class Initialized
DEBUG - 2015-04-15 14:25:14 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:25:14 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:25:14 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:25:14 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:25:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:25:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Session Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:25:15 --> Session routines successfully run
DEBUG - 2015-04-15 14:25:15 --> Controller Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:25:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:25:15 --> Email Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:25:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:25:15 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:25:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-15 14:25:15 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:15 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Router Class Initialized
DEBUG - 2015-04-15 14:25:15 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-15 14:25:15 --> Output Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Security Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Input Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:25:15 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Loader Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:25:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:25:15 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Session Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:25:15 --> Session routines successfully run
DEBUG - 2015-04-15 14:25:15 --> Controller Class Initialized
DEBUG - 2015-04-15 14:25:15 --> Services MX_Controller Initialized
DEBUG - 2015-04-15 14:25:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:25:16 --> Email Class Initialized
DEBUG - 2015-04-15 14:25:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:25:16 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:25:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:16 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:25:16 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:16 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:25:16 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-15 14:25:16 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-15 14:25:16 --> Final output sent to browser
DEBUG - 2015-04-15 14:25:16 --> Total execution time: 0.5280
DEBUG - 2015-04-15 14:25:16 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:16 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:16 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:16 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:16 --> Router Class Initialized
ERROR - 2015-04-15 14:25:16 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:25:19 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:19 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Router Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-15 14:25:19 --> Output Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Security Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Input Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:25:19 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Loader Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:25:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:25:19 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Session Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:25:19 --> Session routines successfully run
DEBUG - 2015-04-15 14:25:19 --> Controller Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-15 14:25:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:25:19 --> Email Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:25:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:25:19 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:25:19 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:19 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-15 14:25:19 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-15 14:25:19 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-15 14:25:19 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-15 14:25:19 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-15 14:25:20 --> Final output sent to browser
DEBUG - 2015-04-15 14:25:20 --> Total execution time: 0.7930
DEBUG - 2015-04-15 14:25:20 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:20 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Router Class Initialized
ERROR - 2015-04-15 14:25:20 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:25:20 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:20 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:20 --> Router Class Initialized
ERROR - 2015-04-15 14:25:20 --> 404 Page Not Found --> 
DEBUG - 2015-04-15 14:25:51 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:51 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Router Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Output Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Security Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Input Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:25:51 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Loader Class Initialized
DEBUG - 2015-04-15 14:25:51 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:25:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:25:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Session Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:25:52 --> Session routines successfully run
DEBUG - 2015-04-15 14:25:52 --> Controller Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:25:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:25:52 --> Email Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:25:52 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:25:52 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:25:52 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Hooks Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Utf8 Class Initialized
DEBUG - 2015-04-15 14:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 14:25:52 --> URI Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Router Class Initialized
DEBUG - 2015-04-15 14:25:52 --> No URI present. Default controller set.
DEBUG - 2015-04-15 14:25:52 --> Output Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Security Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Input Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 14:25:52 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Language Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Config Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Loader Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: url_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: form_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: language_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: user_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: date_helper
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-15 14:25:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-15 14:25:52 --> Database Driver Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Session Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: string_helper
DEBUG - 2015-04-15 14:25:52 --> Session routines successfully run
DEBUG - 2015-04-15 14:25:52 --> Controller Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-15 14:25:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-15 14:25:52 --> Email Class Initialized
DEBUG - 2015-04-15 14:25:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-15 14:25:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-15 14:25:52 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-15 14:25:52 --> Model Class Initialized
DEBUG - 2015-04-15 14:25:53 --> Form Validation Class Initialized
DEBUG - 2015-04-15 14:25:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-15 14:25:53 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-15 14:25:53 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-15 14:25:53 --> Final output sent to browser
DEBUG - 2015-04-15 14:25:53 --> Total execution time: 0.5310
