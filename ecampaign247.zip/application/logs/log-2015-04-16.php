<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-16 05:35:21 --> Config Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Hooks Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Utf8 Class Initialized
DEBUG - 2015-04-16 05:35:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 05:35:21 --> URI Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Router Class Initialized
DEBUG - 2015-04-16 05:35:21 --> No URI present. Default controller set.
DEBUG - 2015-04-16 05:35:21 --> Output Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Security Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Input Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 05:35:21 --> Language Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Language Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Config Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Loader Class Initialized
DEBUG - 2015-04-16 05:35:21 --> Helper loaded: url_helper
DEBUG - 2015-04-16 05:35:21 --> Helper loaded: form_helper
DEBUG - 2015-04-16 05:35:21 --> Helper loaded: language_helper
DEBUG - 2015-04-16 05:35:21 --> Helper loaded: user_helper
DEBUG - 2015-04-16 05:35:22 --> Helper loaded: date_helper
DEBUG - 2015-04-16 05:35:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 05:35:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 05:35:22 --> Database Driver Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Session Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Helper loaded: string_helper
DEBUG - 2015-04-16 05:35:23 --> A session cookie was not found.
DEBUG - 2015-04-16 05:35:23 --> Session routines successfully run
DEBUG - 2015-04-16 05:35:23 --> Controller Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 05:35:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 05:35:23 --> Email Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 05:35:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 05:35:23 --> Model Class Initialized
DEBUG - 2015-04-16 05:35:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 05:35:23 --> Model Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Form Validation Class Initialized
DEBUG - 2015-04-16 05:35:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 05:35:24 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-16 05:35:24 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-16 05:35:24 --> Final output sent to browser
DEBUG - 2015-04-16 05:35:24 --> Total execution time: 3.1140
DEBUG - 2015-04-16 08:05:46 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:46 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:46 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:46 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:46 --> A session cookie was not found.
DEBUG - 2015-04-16 08:05:46 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:46 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:46 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 08:05:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:47 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 08:05:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-16 08:05:47 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:47 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:47 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 08:05:47 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:47 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:47 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:47 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:47 --> Services MX_Controller Initialized
DEBUG - 2015-04-16 08:05:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:48 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:48 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:48 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-16 08:05:48 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 08:05:48 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:48 --> Total execution time: 0.6810
DEBUG - 2015-04-16 08:05:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:48 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:48 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:48 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:48 --> Router Class Initialized
ERROR - 2015-04-16 08:05:48 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 08:05:50 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:50 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:50 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:50 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:50 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:50 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:50 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:50 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:50 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:50 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:50 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:50 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:50 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:50 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:50 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:50 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:50 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 08:05:50 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-16 08:05:51 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 08:05:51 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 08:05:51 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-16 08:05:51 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 08:05:51 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:51 --> Total execution time: 0.8941
DEBUG - 2015-04-16 08:05:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:51 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Router Class Initialized
ERROR - 2015-04-16 08:05:51 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 08:05:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:51 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:51 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:51 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:51 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:51 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:51 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:52 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:52 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:52 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:52 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:52 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:52 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:52 --> Total execution time: 0.9211
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:52 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:53 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:53 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:53 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:53 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:53 --> Total execution time: 1.5571
DEBUG - 2015-04-16 08:05:54 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:54 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:54 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:54 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:55 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:55 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:55 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:55 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:55 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:55 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:55 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:55 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:55 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:55 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 08:05:55 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 08:05:55 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:55 --> Total execution time: 1.2731
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:56 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:56 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:56 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:56 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:56 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:56 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:56 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:57 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:57 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:57 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:57 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:57 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:57 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:57 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:57 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:57 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:57 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:57 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:57 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:58 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:58 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:58 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-16 08:05:58 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:58 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:58 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:58 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:58 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:58 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:58 --> Total execution time: 2.3601
DEBUG - 2015-04-16 08:05:58 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:05:58 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:59 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Input Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:05:59 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:05:59 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:59 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:59 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:59 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:05:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Email Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:59 --> Loader Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:05:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:05:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:05:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:05:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:05:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:05:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Session Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Helper loaded: string_helper
ERROR - 2015-04-16 08:05:59 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-16 08:05:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Final output sent to browser
DEBUG - 2015-04-16 08:05:59 --> Session routines successfully run
DEBUG - 2015-04-16 08:05:59 --> Controller Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:59 --> Total execution time: 2.9762
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:05:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:05:59 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:00 --> Total execution time: 3.1472
DEBUG - 2015-04-16 08:06:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:00 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:00 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:01 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Total execution time: 3.3132
DEBUG - 2015-04-16 08:06:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:01 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:01 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:01 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:01 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:01 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:01 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:01 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:01 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:01 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:01 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:02 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:02 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:02 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:02 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:02 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:02 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:02 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:02 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:02 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:02 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:02 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:02 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:02 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:02 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Total execution time: 3.4542
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:02 --> Total execution time: 5.6363
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:02 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:02 --> Total execution time: 3.8472
DEBUG - 2015-04-16 08:06:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:03 --> Total execution time: 3.8992
DEBUG - 2015-04-16 08:06:03 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:03 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:03 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:03 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:03 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:03 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:03 --> Total execution time: 2.3141
DEBUG - 2015-04-16 08:06:03 --> Total execution time: 2.4091
DEBUG - 2015-04-16 08:06:03 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:03 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:03 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:03 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:03 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:03 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:03 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:03 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:03 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:03 --> Total execution time: 4.2952
DEBUG - 2015-04-16 08:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:03 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:03 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:03 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:03 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:04 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:04 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:04 --> Total execution time: 3.2622
DEBUG - 2015-04-16 08:06:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:04 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:06:04 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:04 --> URI Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:04 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:04 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:04 --> Router Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:06:04 --> Output Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Security Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:04 --> Input Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:06:04 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:04 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Loader Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:06:04 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:04 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:04 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:06:04 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:06:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:04 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:06:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:04 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:04 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:06:04 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:06:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:04 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Session Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:05 --> Session routines successfully run
DEBUG - 2015-04-16 08:06:05 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Controller Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:06:05 --> Email Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:06:05 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Model Class Initialized
DEBUG - 2015-04-16 08:06:05 --> Total execution time: 2.3571
DEBUG - 2015-04-16 08:06:05 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:05 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:06 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:06 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:06 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:06 --> Final output sent to browser
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 2.4131
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 1.6941
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 4.8763
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 6.3554
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 4.9013
DEBUG - 2015-04-16 08:06:06 --> Total execution time: 4.8873
DEBUG - 2015-04-16 08:07:53 --> Config Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:07:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:07:53 --> URI Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Router Class Initialized
DEBUG - 2015-04-16 08:07:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:07:53 --> Output Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Security Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Input Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:07:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Config Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Loader Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:07:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:07:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Session Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:07:53 --> Session routines successfully run
DEBUG - 2015-04-16 08:07:53 --> Controller Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:07:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:07:53 --> Email Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:07:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:07:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:07:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:07:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:07:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:07:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:07:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:07:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:07:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:07:53 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 08:07:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 08:07:54 --> Final output sent to browser
DEBUG - 2015-04-16 08:07:54 --> Total execution time: 1.0580
DEBUG - 2015-04-16 08:11:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:48 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:48 --> Output Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Security Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Input Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:11:48 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Loader Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:11:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:11:48 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Session Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:11:48 --> Session routines successfully run
DEBUG - 2015-04-16 08:11:48 --> Controller Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:11:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:11:48 --> Email Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:11:48 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 08:11:49 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 08:11:49 --> Final output sent to browser
DEBUG - 2015-04-16 08:11:49 --> Total execution time: 1.1490
DEBUG - 2015-04-16 08:11:50 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:50 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:50 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:50 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:51 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:51 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:51 --> Output Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Security Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Output Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Input Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Security Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:11:51 --> Input Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:11:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Loader Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Loader Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:11:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:11:51 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:11:51 --> Session Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:11:51 --> Session routines successfully run
DEBUG - 2015-04-16 08:11:51 --> Controller Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:11:51 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-16 08:11:51 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Session Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:11:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:11:51 --> Session routines successfully run
DEBUG - 2015-04-16 08:11:51 --> Controller Class Initialized
DEBUG - 2015-04-16 08:11:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:11:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:11:52 --> Email Class Initialized
DEBUG - 2015-04-16 08:11:52 --> Email Class Initialized
DEBUG - 2015-04-16 08:11:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:11:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:11:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:11:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:11:52 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
DEBUG - 2015-04-16 08:11:52 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:11:52 --> Model Class Initialized
ERROR - 2015-04-16 08:11:52 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-16 08:11:52 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:11:52 --> Final output sent to browser
DEBUG - 2015-04-16 08:11:52 --> Total execution time: 2.3281
DEBUG - 2015-04-16 08:11:58 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:58 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:11:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:11:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:11:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:11:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:00 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:00 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:00 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:00 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:00 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:00 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:00 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:00 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:00 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:00 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Total execution time: 2.4401
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:01 --> Total execution time: 2.2961
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:01 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:01 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:01 --> Total execution time: 1.7851
DEBUG - 2015-04-16 08:12:01 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:01 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:01 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:01 --> Total execution time: 2.5441
DEBUG - 2015-04-16 08:12:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Total execution time: 2.5801
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:02 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:02 --> Total execution time: 2.8402
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:02 --> Total execution time: 3.7622
DEBUG - 2015-04-16 08:12:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:02 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:02 --> Total execution time: 2.4931
DEBUG - 2015-04-16 08:12:02 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:02 --> Total execution time: 3.3292
DEBUG - 2015-04-16 08:12:03 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:03 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:03 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:03 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:03 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:04 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:04 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:04 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:04 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:04 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:04 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:04 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:04 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:04 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:05 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:05 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:05 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:05 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:05 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:05 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:05 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:05 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:06 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:06 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:06 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:06 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:06 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:06 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:06 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:06 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:06 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:06 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:06 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:06 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:06 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:06 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:06 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:06 --> Total execution time: 2.5211
DEBUG - 2015-04-16 08:12:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:07 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:07 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:07 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:07 --> Total execution time: 2.3451
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Total execution time: 3.5732
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:07 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:07 --> Total execution time: 3.0302
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:07 --> Total execution time: 3.4102
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:07 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:07 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:08 --> Total execution time: 4.3872
DEBUG - 2015-04-16 08:12:08 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:08 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:12:08 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:08 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:08 --> URI Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:08 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Router Class Initialized
DEBUG - 2015-04-16 08:12:08 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:12:09 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:09 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:09 --> Output Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Security Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Input Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:12:09 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Language Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Config Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:09 --> Loader Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:12:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:09 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:09 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:12:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:12:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:09 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:09 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:10 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:10 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Session Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:12:10 --> Session routines successfully run
DEBUG - 2015-04-16 08:12:10 --> Controller Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:12:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Email Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:10 --> Total execution time: 1.9291
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:10 --> Total execution time: 1.8751
DEBUG - 2015-04-16 08:12:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:12:10 --> Model Class Initialized
DEBUG - 2015-04-16 08:12:10 --> Final output sent to browser
DEBUG - 2015-04-16 08:12:10 --> Total execution time: 2.0271
DEBUG - 2015-04-16 08:18:34 --> Config Class Initialized
DEBUG - 2015-04-16 08:18:34 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:18:34 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:18:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:18:34 --> URI Class Initialized
DEBUG - 2015-04-16 08:18:34 --> Router Class Initialized
DEBUG - 2015-04-16 08:18:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:18:35 --> Output Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Security Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Input Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:18:35 --> Language Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Language Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Config Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Loader Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:18:35 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:18:35 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Session Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:18:35 --> Session routines successfully run
DEBUG - 2015-04-16 08:18:35 --> Controller Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:18:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:18:35 --> Email Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:18:35 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:18:35 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:18:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:18:35 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:18:35 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:18:35 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:18:35 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:18:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:18:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:18:48 --> URI Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Router Class Initialized
DEBUG - 2015-04-16 08:18:48 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:18:48 --> Output Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Security Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Input Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:18:48 --> Language Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Language Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Loader Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:18:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:18:48 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Session Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:18:48 --> Session routines successfully run
DEBUG - 2015-04-16 08:18:48 --> Controller Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:18:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:18:48 --> Email Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:18:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:18:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:18:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:18:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:18:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:18:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:18:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:23:47 --> Config Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:23:47 --> URI Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Router Class Initialized
DEBUG - 2015-04-16 08:23:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:23:47 --> Output Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Security Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Input Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:23:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:23:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Config Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Loader Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:23:48 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:23:48 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Session Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:23:48 --> Session routines successfully run
DEBUG - 2015-04-16 08:23:48 --> Controller Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:23:48 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:23:48 --> Email Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:23:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:23:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:23:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:23:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:23:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:23:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:23:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:23:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:23:48 --> Model Class Initialized
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:23:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:24:21 --> Config Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:24:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:24:21 --> URI Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Router Class Initialized
DEBUG - 2015-04-16 08:24:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:24:21 --> Output Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Security Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Input Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:24:21 --> Language Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Language Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Config Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Loader Class Initialized
DEBUG - 2015-04-16 08:24:21 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:24:21 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:24:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:24:22 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Session Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:24:22 --> Session routines successfully run
DEBUG - 2015-04-16 08:24:22 --> Controller Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:24:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:24:22 --> Email Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:24:22 --> Model Class Initialized
DEBUG - 2015-04-16 08:24:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:24:22 --> Model Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:24:22 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:24:22 --> Model Class Initialized
DEBUG - 2015-04-16 08:24:22 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:24:22 --> Model Class Initialized
DEBUG - 2015-04-16 08:24:22 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:24:22 --> Model Class Initialized
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:24:22 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:25:34 --> Config Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:25:34 --> URI Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Router Class Initialized
DEBUG - 2015-04-16 08:25:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:25:34 --> Output Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Security Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Input Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:25:34 --> Language Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Language Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Config Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Loader Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:25:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:25:34 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Session Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:25:34 --> Session routines successfully run
DEBUG - 2015-04-16 08:25:34 --> Controller Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:25:34 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:25:34 --> Email Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:25:34 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:25:34 --> Model Class Initialized
DEBUG - 2015-04-16 08:25:34 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:25:34 --> Model Class Initialized
DEBUG - 2015-04-16 08:25:34 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:25:34 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:25:34 --> Model Class Initialized
DEBUG - 2015-04-16 08:25:34 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:25:34 --> Model Class Initialized
DEBUG - 2015-04-16 08:25:34 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:25:34 --> Model Class Initialized
DEBUG - 2015-04-16 08:25:35 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:25:35 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:26:26 --> Config Class Initialized
DEBUG - 2015-04-16 08:26:26 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:26:26 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:26:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:26:26 --> URI Class Initialized
DEBUG - 2015-04-16 08:26:26 --> Router Class Initialized
DEBUG - 2015-04-16 08:26:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:26:27 --> Output Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Security Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Input Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:26:27 --> Language Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Language Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Config Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Loader Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:26:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:26:27 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Session Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:26:27 --> Session routines successfully run
DEBUG - 2015-04-16 08:26:27 --> Controller Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:26:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:26:27 --> Email Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:26:27 --> Model Class Initialized
DEBUG - 2015-04-16 08:26:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:26:27 --> Model Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:26:27 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:26:27 --> Model Class Initialized
DEBUG - 2015-04-16 08:26:27 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:26:27 --> Model Class Initialized
DEBUG - 2015-04-16 08:26:27 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:26:27 --> Model Class Initialized
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:26:27 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:29:45 --> Config Class Initialized
DEBUG - 2015-04-16 08:29:45 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:29:45 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:29:46 --> URI Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Router Class Initialized
DEBUG - 2015-04-16 08:29:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:29:46 --> Output Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Security Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Input Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:29:46 --> Language Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Language Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Config Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Loader Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:29:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:29:46 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Session Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:29:46 --> Session routines successfully run
DEBUG - 2015-04-16 08:29:46 --> Controller Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:29:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:29:46 --> Email Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:29:46 --> Model Class Initialized
DEBUG - 2015-04-16 08:29:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:29:46 --> Model Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:29:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:29:46 --> Model Class Initialized
DEBUG - 2015-04-16 08:29:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:29:46 --> Model Class Initialized
DEBUG - 2015-04-16 08:29:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:29:46 --> Model Class Initialized
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:29:46 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:32:12 --> Config Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:32:12 --> URI Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Router Class Initialized
DEBUG - 2015-04-16 08:32:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:32:12 --> Output Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Security Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Input Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:32:12 --> Language Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Language Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Config Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Loader Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:32:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:32:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Session Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:32:12 --> Session routines successfully run
DEBUG - 2015-04-16 08:32:12 --> Controller Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:32:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:32:12 --> Email Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:32:12 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:32:12 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:32:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:32:12 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:32:12 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:32:12 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:32:12 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:32:12 --> Severity: Warning  --> chmod(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 701
ERROR - 2015-04-16 08:32:12 --> Severity: Warning  --> mkdir(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 704
ERROR - 2015-04-16 08:32:12 --> Severity: Warning  --> fopen(./tmp/2/blog.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
ERROR - 2015-04-16 08:32:13 --> Severity: Warning  --> fopen(./tmp/2/index.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
DEBUG - 2015-04-16 08:32:50 --> Config Class Initialized
DEBUG - 2015-04-16 08:32:50 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:32:50 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:32:50 --> URI Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Router Class Initialized
DEBUG - 2015-04-16 08:32:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:32:51 --> Output Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Security Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Input Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:32:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Language Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Config Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Loader Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:32:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:32:51 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Session Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:32:51 --> Session routines successfully run
DEBUG - 2015-04-16 08:32:51 --> Controller Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:32:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:32:51 --> Email Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:32:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:32:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:32:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:32:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:32:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:32:51 --> Model Class Initialized
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:32:51 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:32:52 --> Severity: Warning  --> chmod(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 701
ERROR - 2015-04-16 08:32:52 --> Severity: Warning  --> mkdir(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 704
ERROR - 2015-04-16 08:32:52 --> Severity: Warning  --> fopen(./tmp/2/blog.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
ERROR - 2015-04-16 08:32:52 --> Severity: Warning  --> fopen(./tmp/2/index.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
DEBUG - 2015-04-16 08:33:46 --> Config Class Initialized
DEBUG - 2015-04-16 08:33:46 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:33:46 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:33:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:33:46 --> URI Class Initialized
DEBUG - 2015-04-16 08:33:46 --> Router Class Initialized
DEBUG - 2015-04-16 08:33:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:33:46 --> Output Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Security Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Input Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:33:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Language Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Config Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Loader Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:33:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:33:47 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Session Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:33:47 --> Session routines successfully run
DEBUG - 2015-04-16 08:33:47 --> Controller Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:33:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:33:47 --> Email Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:33:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:33:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:33:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:33:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:33:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:33:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:33:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:33:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:33:47 --> Model Class Initialized
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:33:47 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:33:47 --> Severity: Warning  --> chmod(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 701
ERROR - 2015-04-16 08:33:47 --> Severity: Warning  --> mkdir(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 704
DEBUG - 2015-04-16 08:34:43 --> Config Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:34:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:34:43 --> URI Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Router Class Initialized
DEBUG - 2015-04-16 08:34:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:34:43 --> Output Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Security Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Input Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:34:43 --> Language Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Language Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Config Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Loader Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:34:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:34:43 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Session Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:34:43 --> Session routines successfully run
DEBUG - 2015-04-16 08:34:43 --> Controller Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:34:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:34:43 --> Email Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:34:43 --> Model Class Initialized
DEBUG - 2015-04-16 08:34:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:34:43 --> Model Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:34:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:34:43 --> Model Class Initialized
DEBUG - 2015-04-16 08:34:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:34:43 --> Model Class Initialized
DEBUG - 2015-04-16 08:34:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:34:43 --> Model Class Initialized
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:34:43 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:34:44 --> Severity: Warning  --> chmod(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 701
ERROR - 2015-04-16 08:34:44 --> Severity: Warning  --> mkdir(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 704
DEBUG - 2015-04-16 08:35:43 --> Config Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:35:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:35:43 --> URI Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Router Class Initialized
DEBUG - 2015-04-16 08:35:43 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:35:43 --> Output Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Security Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Input Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:35:43 --> Language Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Language Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Config Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Loader Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:35:43 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:35:43 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Session Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:35:43 --> Session routines successfully run
DEBUG - 2015-04-16 08:35:43 --> Controller Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:35:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:35:43 --> Email Class Initialized
DEBUG - 2015-04-16 08:35:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:35:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:35:44 --> Model Class Initialized
DEBUG - 2015-04-16 08:35:44 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:35:44 --> Model Class Initialized
DEBUG - 2015-04-16 08:35:44 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:35:44 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:35:44 --> Model Class Initialized
DEBUG - 2015-04-16 08:35:44 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:35:44 --> Model Class Initialized
DEBUG - 2015-04-16 08:35:44 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:35:44 --> Model Class Initialized
DEBUG - 2015-04-16 08:35:44 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:35:44 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:35:44 --> Severity: Warning  --> chmod(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 701
ERROR - 2015-04-16 08:35:44 --> Severity: Warning  --> mkdir(): No such file or directory C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 704
DEBUG - 2015-04-16 08:36:53 --> Config Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:36:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:36:53 --> URI Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Router Class Initialized
DEBUG - 2015-04-16 08:36:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:36:53 --> Output Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Security Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Input Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:36:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Config Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Loader Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:36:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:36:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Session Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:36:53 --> Session routines successfully run
DEBUG - 2015-04-16 08:36:53 --> Controller Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:36:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:36:53 --> Email Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:36:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:36:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:36:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:36:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:36:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:36:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:36:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:36:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:36:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:36:53 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:36:54 --> Severity: Warning  --> fopen(./etmp/2/blog.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
ERROR - 2015-04-16 08:36:54 --> Severity: Warning  --> fopen(./etmp/2/index.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
DEBUG - 2015-04-16 08:37:31 --> Config Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:37:31 --> URI Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Router Class Initialized
DEBUG - 2015-04-16 08:37:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:37:31 --> Output Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Security Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Input Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:37:31 --> Language Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Language Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Config Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Loader Class Initialized
DEBUG - 2015-04-16 08:37:31 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:37:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:37:32 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:37:32 --> Session Class Initialized
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:37:32 --> Session routines successfully run
DEBUG - 2015-04-16 08:37:32 --> Controller Class Initialized
DEBUG - 2015-04-16 08:37:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:37:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:37:32 --> Email Class Initialized
DEBUG - 2015-04-16 08:37:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:37:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:37:32 --> Model Class Initialized
DEBUG - 2015-04-16 08:37:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:37:32 --> Model Class Initialized
DEBUG - 2015-04-16 08:37:32 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:37:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:37:33 --> Model Class Initialized
DEBUG - 2015-04-16 08:37:33 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:37:33 --> Model Class Initialized
DEBUG - 2015-04-16 08:37:33 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:37:33 --> Model Class Initialized
DEBUG - 2015-04-16 08:37:33 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:37:33 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:37:33 --> Severity: Warning  --> fopen(./etmp/2/blog.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
ERROR - 2015-04-16 08:37:33 --> Severity: Warning  --> fopen(./etmp/2/index.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
DEBUG - 2015-04-16 08:39:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:39:59 --> URI Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Router Class Initialized
DEBUG - 2015-04-16 08:39:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:39:59 --> Output Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Security Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Input Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:39:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Language Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Config Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Loader Class Initialized
DEBUG - 2015-04-16 08:39:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:39:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:39:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:39:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:40:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:40:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Session Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:40:00 --> Session routines successfully run
DEBUG - 2015-04-16 08:40:00 --> Controller Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:40:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:40:00 --> Email Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:40:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:40:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:40:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:40:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:40:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:40:00 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:40:00 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:40:00 --> Severity: Warning  --> fopen(./etmp/2/blog.html): failed to open stream: No such file or directory C:\xampp\htdocs\ecampaign247\system\helpers\file_helper.php 91
DEBUG - 2015-04-16 08:40:18 --> Config Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:40:18 --> URI Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Router Class Initialized
DEBUG - 2015-04-16 08:40:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:40:18 --> Output Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Security Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Input Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:40:18 --> Language Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Language Class Initialized
DEBUG - 2015-04-16 08:40:18 --> Config Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Loader Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:40:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:40:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Session Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:40:19 --> Session routines successfully run
DEBUG - 2015-04-16 08:40:19 --> Controller Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:40:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:40:19 --> Email Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:40:19 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:40:19 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:40:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:40:19 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:40:19 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:40:19 --> Model Class Initialized
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:40:19 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:42:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:42:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:42:05 --> URI Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Router Class Initialized
DEBUG - 2015-04-16 08:42:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:42:05 --> Output Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Security Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Input Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:42:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Language Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Config Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Loader Class Initialized
DEBUG - 2015-04-16 08:42:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:42:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:42:06 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Session Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:42:06 --> Session routines successfully run
DEBUG - 2015-04-16 08:42:06 --> Controller Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:42:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:42:06 --> Email Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:42:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:42:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:42:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:42:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:42:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:42:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:42:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:42:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:42:06 --> Model Class Initialized
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:42:06 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:50:26 --> Config Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:50:26 --> URI Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Router Class Initialized
DEBUG - 2015-04-16 08:50:26 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:50:26 --> Output Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Security Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Input Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:50:26 --> Language Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Language Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Config Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Loader Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:50:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:50:26 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Session Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:50:26 --> Session routines successfully run
DEBUG - 2015-04-16 08:50:26 --> Controller Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:50:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:50:26 --> Email Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:50:26 --> Model Class Initialized
DEBUG - 2015-04-16 08:50:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:50:26 --> Model Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:50:26 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:50:26 --> Model Class Initialized
DEBUG - 2015-04-16 08:50:26 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:50:26 --> Model Class Initialized
DEBUG - 2015-04-16 08:50:26 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:50:26 --> Model Class Initialized
DEBUG - 2015-04-16 08:50:26 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:50:27 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:58:36 --> Config Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:58:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:58:36 --> URI Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Router Class Initialized
DEBUG - 2015-04-16 08:58:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:58:36 --> Output Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Security Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Input Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:58:36 --> Language Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Language Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Config Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Loader Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:58:36 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:58:36 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Session Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:58:36 --> Session routines successfully run
DEBUG - 2015-04-16 08:58:36 --> Controller Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:58:36 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:58:36 --> Email Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:58:36 --> Model Class Initialized
DEBUG - 2015-04-16 08:58:36 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:58:36 --> Model Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:58:36 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:58:36 --> Model Class Initialized
DEBUG - 2015-04-16 08:58:36 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:58:36 --> Model Class Initialized
DEBUG - 2015-04-16 08:58:36 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:58:36 --> Model Class Initialized
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:58:36 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:58:37 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 750
DEBUG - 2015-04-16 08:58:37 --> Final output sent to browser
DEBUG - 2015-04-16 08:58:37 --> Total execution time: 1.0611
DEBUG - 2015-04-16 08:59:36 --> Config Class Initialized
DEBUG - 2015-04-16 08:59:36 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:59:36 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:59:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:59:36 --> URI Class Initialized
DEBUG - 2015-04-16 08:59:36 --> Router Class Initialized
DEBUG - 2015-04-16 08:59:36 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:59:37 --> Output Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Security Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Input Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:59:37 --> Language Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Language Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Config Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Loader Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:59:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:59:37 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Session Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:59:37 --> Session routines successfully run
DEBUG - 2015-04-16 08:59:37 --> Controller Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:59:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:59:37 --> Email Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:59:37 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:59:37 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:59:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:59:37 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:59:37 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:59:37 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:59:37 --> Helper loaded: directory_helper
ERROR - 2015-04-16 08:59:37 --> Severity: Notice  --> Undefined index:  C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 751
DEBUG - 2015-04-16 08:59:37 --> Final output sent to browser
DEBUG - 2015-04-16 08:59:37 --> Total execution time: 0.8711
DEBUG - 2015-04-16 08:59:52 --> Config Class Initialized
DEBUG - 2015-04-16 08:59:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 08:59:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 08:59:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 08:59:52 --> URI Class Initialized
DEBUG - 2015-04-16 08:59:52 --> Router Class Initialized
DEBUG - 2015-04-16 08:59:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 08:59:53 --> Output Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Security Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Input Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 08:59:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Language Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Config Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Loader Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 08:59:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 08:59:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Session Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 08:59:53 --> Session routines successfully run
DEBUG - 2015-04-16 08:59:53 --> Controller Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 08:59:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 08:59:53 --> Email Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 08:59:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 08:59:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 08:59:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 08:59:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 08:59:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 08:59:53 --> Model Class Initialized
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: file_helper
DEBUG - 2015-04-16 08:59:53 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 08:59:53 --> Final output sent to browser
DEBUG - 2015-04-16 08:59:53 --> Total execution time: 0.9091
DEBUG - 2015-04-16 09:00:59 --> Config Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:00:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:00:59 --> URI Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Router Class Initialized
DEBUG - 2015-04-16 09:00:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:00:59 --> Output Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Security Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Input Class Initialized
DEBUG - 2015-04-16 09:00:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:00:59 --> Language Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Language Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Config Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Loader Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:01:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:01:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Session Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:01:00 --> Session routines successfully run
DEBUG - 2015-04-16 09:01:00 --> Controller Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:01:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:01:00 --> Email Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:01:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:01:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:01:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:01:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:01:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:01:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:01:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:01:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:01:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:01:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:01:00 --> Model Class Initialized
ERROR - 2015-04-16 09:01:00 --> 404 Page Not Found --> sites/index.html
DEBUG - 2015-04-16 09:05:45 --> Config Class Initialized
DEBUG - 2015-04-16 09:05:45 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:05:45 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:05:45 --> URI Class Initialized
DEBUG - 2015-04-16 09:05:45 --> Router Class Initialized
DEBUG - 2015-04-16 09:05:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:05:46 --> Output Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Security Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Input Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:05:46 --> Language Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Language Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Config Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Loader Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:05:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:05:46 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Session Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:05:46 --> Session routines successfully run
DEBUG - 2015-04-16 09:05:46 --> Controller Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:05:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:05:46 --> Email Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:05:46 --> Model Class Initialized
DEBUG - 2015-04-16 09:05:46 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:05:46 --> Model Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:05:46 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:05:46 --> Model Class Initialized
DEBUG - 2015-04-16 09:05:46 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:05:46 --> Model Class Initialized
DEBUG - 2015-04-16 09:05:46 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:05:46 --> Model Class Initialized
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: file_helper
DEBUG - 2015-04-16 09:05:46 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 09:05:47 --> Final output sent to browser
DEBUG - 2015-04-16 09:05:47 --> Total execution time: 1.4421
DEBUG - 2015-04-16 09:06:11 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:11 --> URI Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Router Class Initialized
DEBUG - 2015-04-16 09:06:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:06:11 --> Output Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Security Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Input Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:06:11 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Loader Class Initialized
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:06:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:06:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:06:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Session Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:06:12 --> Session routines successfully run
DEBUG - 2015-04-16 09:06:12 --> Controller Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:06:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:06:12 --> Email Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:06:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:06:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:06:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:06:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:06:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:06:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-16 09:06:12 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 09:06:12 --> Final output sent to browser
DEBUG - 2015-04-16 09:06:12 --> Total execution time: 0.9991
DEBUG - 2015-04-16 09:06:12 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:12 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:13 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:13 --> URI Class Initialized
DEBUG - 2015-04-16 09:06:13 --> Router Class Initialized
ERROR - 2015-04-16 09:06:13 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 09:06:17 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:17 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:17 --> URI Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Router Class Initialized
DEBUG - 2015-04-16 09:06:17 --> URI Class Initialized
ERROR - 2015-04-16 09:06:17 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 09:06:17 --> Router Class Initialized
DEBUG - 2015-04-16 09:06:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:06:17 --> Output Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Security Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Input Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:06:17 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Loader Class Initialized
DEBUG - 2015-04-16 09:06:17 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:06:17 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:06:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:06:18 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Session Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:06:18 --> Session routines successfully run
DEBUG - 2015-04-16 09:06:18 --> Controller Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:06:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:06:18 --> Email Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:06:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:06:18 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:06:18 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:06:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:06:18 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:06:18 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:06:18 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:18 --> Final output sent to browser
DEBUG - 2015-04-16 09:06:18 --> Total execution time: 1.0071
DEBUG - 2015-04-16 09:06:19 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:19 --> URI Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Router Class Initialized
DEBUG - 2015-04-16 09:06:19 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:06:19 --> Output Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Security Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Input Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:06:19 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Loader Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:06:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:06:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Session Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:06:19 --> Session routines successfully run
DEBUG - 2015-04-16 09:06:19 --> Controller Class Initialized
DEBUG - 2015-04-16 09:06:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:06:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:06:20 --> Email Class Initialized
DEBUG - 2015-04-16 09:06:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:06:20 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:06:20 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:20 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:06:20 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:20 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:06:20 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:06:20 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:20 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:06:20 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:20 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:06:20 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:20 --> Final output sent to browser
DEBUG - 2015-04-16 09:06:20 --> Total execution time: 0.9571
DEBUG - 2015-04-16 09:06:51 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:06:51 --> URI Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Router Class Initialized
DEBUG - 2015-04-16 09:06:51 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:06:51 --> Output Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Security Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Input Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:06:51 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Language Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Config Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Loader Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:06:51 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:06:51 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Session Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:06:51 --> Session routines successfully run
DEBUG - 2015-04-16 09:06:51 --> Controller Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:06:51 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:06:51 --> Email Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:06:51 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:51 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:06:51 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:06:51 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:06:51 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:51 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:06:51 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:51 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:06:51 --> Model Class Initialized
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: file_helper
DEBUG - 2015-04-16 09:06:51 --> Helper loaded: directory_helper
ERROR - 2015-04-16 09:06:51 --> Severity: Notice  --> Undefined index: siteID C:\xampp\htdocs\ecampaign247\application\modules_core\sites\controllers\sites.php 691
DEBUG - 2015-04-16 09:09:54 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:09:54 --> URI Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Router Class Initialized
DEBUG - 2015-04-16 09:09:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:09:54 --> Output Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Security Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Input Class Initialized
DEBUG - 2015-04-16 09:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:09:54 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Loader Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:09:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:09:55 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Session Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:09:55 --> Session routines successfully run
DEBUG - 2015-04-16 09:09:55 --> Controller Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:09:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:09:55 --> Email Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:09:55 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:09:55 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:09:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:09:55 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:55 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:09:55 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:55 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:09:55 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:55 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 09:09:56 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 09:09:56 --> Final output sent to browser
DEBUG - 2015-04-16 09:09:56 --> Total execution time: 1.3301
DEBUG - 2015-04-16 09:09:56 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:56 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:09:56 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:09:57 --> URI Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Router Class Initialized
DEBUG - 2015-04-16 09:09:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:09:57 --> Output Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Security Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Input Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:09:57 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Loader Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:09:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:09:57 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:09:57 --> URI Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:09:57 --> Router Class Initialized
DEBUG - 2015-04-16 09:09:57 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:09:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:09:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Session Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:09:58 --> Output Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Security Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Input Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:09:58 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Language Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Session routines successfully run
DEBUG - 2015-04-16 09:09:58 --> Controller Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Config Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-16 09:09:58 --> Loader Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:09:58 --> Email Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:09:58 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:09:58 --> Final output sent to browser
DEBUG - 2015-04-16 09:09:58 --> Total execution time: 1.5281
DEBUG - 2015-04-16 09:09:58 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Session Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:09:58 --> Session routines successfully run
DEBUG - 2015-04-16 09:09:58 --> Controller Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:09:58 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:09:58 --> Email Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
DEBUG - 2015-04-16 09:09:58 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:09:58 --> Model Class Initialized
ERROR - 2015-04-16 09:09:58 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:03 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:03 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:03 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:03 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:03 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:03 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:03 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:03 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:03 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:03 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:03 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:03 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:04 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:04 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:04 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:04 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:04 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:04 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:04 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:04 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:04 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:04 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:04 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:04 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:04 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:04 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:04 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:04 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:05 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:05 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:05 --> Total execution time: 1.9911
DEBUG - 2015-04-16 09:10:05 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:05 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:05 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Total execution time: 2.6021
DEBUG - 2015-04-16 09:10:05 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:05 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:05 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:05 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:05 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:05 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:05 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:06 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:06 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:06 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:06 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:06 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:06 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:06 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:06 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:07 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:07 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:07 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:07 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:07 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:08 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:08 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:08 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:09 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:09 --> Total execution time: 5.9863
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:09 --> Total execution time: 5.8513
DEBUG - 2015-04-16 09:10:09 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Total execution time: 5.6553
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:09 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:09 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Total execution time: 5.9453
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:09 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:09 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:09 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:09 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:09 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Total execution time: 4.7913
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:10 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:10 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:10 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:11 --> Total execution time: 4.1852
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:11 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:11 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:11 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:11 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:11 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:11 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:11 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:11 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:11 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:11 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:11 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:11 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:11 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:12 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Total execution time: 6.5114
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:13 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Total execution time: 2.3001
DEBUG - 2015-04-16 09:10:13 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:13 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:13 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 7.7104
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 6.5534
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 6.4984
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 6.5364
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 7.9525
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 6.6834
DEBUG - 2015-04-16 09:10:14 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:10:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:10:14 --> URI Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Router Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:10:14 --> Output Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Security Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Input Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:10:14 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:14 --> Language Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:14 --> Config Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:14 --> Loader Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:10:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:10:14 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:10:14 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:14 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:10:14 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Session Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:10:14 --> Session routines successfully run
DEBUG - 2015-04-16 09:10:14 --> Controller Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:10:14 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:10:14 --> Email Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:10:14 --> Model Class Initialized
DEBUG - 2015-04-16 09:10:14 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 0.7290
DEBUG - 2015-04-16 09:10:14 --> Final output sent to browser
DEBUG - 2015-04-16 09:10:14 --> Total execution time: 1.0931
DEBUG - 2015-04-16 09:11:47 --> Config Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:11:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:11:47 --> URI Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Router Class Initialized
DEBUG - 2015-04-16 09:11:47 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:11:47 --> Output Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Security Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Input Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:11:47 --> Language Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Language Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Config Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Loader Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:11:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:11:47 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Session Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:11:47 --> Session routines successfully run
DEBUG - 2015-04-16 09:11:47 --> Controller Class Initialized
DEBUG - 2015-04-16 09:11:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:11:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:11:48 --> Email Class Initialized
DEBUG - 2015-04-16 09:11:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:11:48 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 09:11:48 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 09:11:48 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:11:48 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 09:11:48 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 09:11:48 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:11:48 --> Model Class Initialized
DEBUG - 2015-04-16 09:11:48 --> Helper loaded: file_helper
DEBUG - 2015-04-16 09:11:48 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 09:13:59 --> Config Class Initialized
DEBUG - 2015-04-16 09:13:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 09:13:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 09:13:59 --> URI Class Initialized
DEBUG - 2015-04-16 09:13:59 --> Router Class Initialized
DEBUG - 2015-04-16 09:13:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 09:13:59 --> Output Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Security Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Input Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 09:14:00 --> Language Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Language Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Config Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Loader Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 09:14:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 09:14:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Session Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 09:14:00 --> Session routines successfully run
DEBUG - 2015-04-16 09:14:00 --> Controller Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 09:14:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 09:14:00 --> Email Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:14:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 09:14:00 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:14:00 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:14:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 09:14:00 --> Model Class Initialized
DEBUG - 2015-04-16 09:14:00 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 09:14:01 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-16 09:14:01 --> Final output sent to browser
DEBUG - 2015-04-16 09:14:01 --> Total execution time: 1.2111
DEBUG - 2015-04-16 11:40:06 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:06 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:06 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:06 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:06 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:06 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:06 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:06 --> A session cookie was not found.
DEBUG - 2015-04-16 11:40:06 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:06 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:06 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:06 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:06 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:07 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:07 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:08 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:08 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:08 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 11:40:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:08 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 11:40:08 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-16 11:40:08 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-16 11:40:08 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:08 --> Total execution time: 0.7280
DEBUG - 2015-04-16 11:40:26 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:26 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:26 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:26 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:26 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:26 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:26 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 11:40:26 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:26 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:26 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:26 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:26 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:26 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 11:40:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-16 11:40:27 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:27 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:27 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 11:40:27 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:27 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:27 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:27 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:27 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Services MX_Controller Initialized
DEBUG - 2015-04-16 11:40:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:27 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:27 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:27 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:28 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:28 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-16 11:40:28 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 11:40:28 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:28 --> Total execution time: 0.6800
DEBUG - 2015-04-16 11:40:28 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:28 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:28 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:28 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:28 --> Router Class Initialized
ERROR - 2015-04-16 11:40:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 11:40:31 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:31 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:31 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:31 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:31 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:31 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:31 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:31 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:31 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:31 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:31 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:31 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:31 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:31 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:31 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:31 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:31 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:31 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-16 11:40:32 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 11:40:32 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:32 --> Total execution time: 1.2861
DEBUG - 2015-04-16 11:40:32 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:32 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:32 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:32 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:32 --> Router Class Initialized
ERROR - 2015-04-16 11:40:32 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 11:40:37 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:37 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Utf8 Class Initialized
ERROR - 2015-04-16 11:40:37 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:37 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:37 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:37 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:37 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:37 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:37 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:37 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:37 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:37 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:37 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:37 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:37 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:37 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:37 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:37 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:37 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:37 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:37 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:37 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:37 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:37 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:37 --> Total execution time: 0.6560
DEBUG - 2015-04-16 11:40:38 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:38 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:38 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:38 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:38 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:38 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:38 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:38 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:38 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:38 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:38 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:38 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:38 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:38 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:38 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:38 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:38 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:38 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:38 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:38 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:39 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:39 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:39 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:39 --> Total execution time: 0.6240
DEBUG - 2015-04-16 11:40:44 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:44 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:44 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:44 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:44 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:44 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:44 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:44 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:44 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:44 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:44 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:45 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:45 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:45 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:45 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:45 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:45 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:45 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:45 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 11:40:45 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 11:40:45 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:45 --> Total execution time: 1.3081
DEBUG - 2015-04-16 11:40:46 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:46 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:46 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:46 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:46 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:46 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:46 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:46 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:46 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:47 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:47 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:47 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-16 11:40:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:47 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:47 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:47 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:47 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:47 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:47 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:47 --> Total execution time: 1.3701
DEBUG - 2015-04-16 11:40:47 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:47 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:47 --> Model Class Initialized
ERROR - 2015-04-16 11:40:47 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-16 11:40:52 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:52 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:52 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:52 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:52 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:52 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:52 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:52 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:52 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:52 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:53 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:53 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:53 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:53 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:53 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:53 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:53 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:53 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:53 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:53 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:53 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:53 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:53 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:53 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:53 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:54 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:54 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:54 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:54 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:54 --> Total execution time: 2.2871
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:54 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:54 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:54 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:54 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:54 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:54 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:54 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:54 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:54 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:54 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:55 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:55 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:55 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:55 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:55 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:55 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:55 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:55 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:55 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:55 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:55 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:55 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:55 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:55 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:55 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:55 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:55 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:55 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:55 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:55 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:56 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:56 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:56 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 4.0682
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 1.0891
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 4.5503
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 4.2352
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 4.4963
DEBUG - 2015-04-16 11:40:56 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:56 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 4.0822
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:56 --> Total execution time: 2.4241
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:56 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:57 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:57 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:57 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:57 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:57 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:57 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:57 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:57 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:57 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:57 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:57 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:57 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:57 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:57 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:57 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:57 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:40:57 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Final output sent to browser
DEBUG - 2015-04-16 11:40:57 --> Total execution time: 1.5961
DEBUG - 2015-04-16 11:40:57 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:57 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:57 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:57 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:58 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:58 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:58 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:58 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:58 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:58 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:58 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:58 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:58 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:58 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:58 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:58 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:58 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:58 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:58 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:59 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:59 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:59 --> URI Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:59 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:59 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:59 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:59 --> Security Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:59 --> Input Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Router Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:59 --> Email Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:40:59 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:40:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:59 --> Language Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Loader Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Session Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:59 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:59 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:40:59 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:40:59 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:59 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:40:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:59 --> Session routines successfully run
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:40:59 --> Controller Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:40:59 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:40:59 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:40:59 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:59 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:40:59 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:40:59 --> Model Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:40:59 --> Output Class Initialized
DEBUG - 2015-04-16 11:40:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:40:59 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:00 --> Security Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Input Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:41:00 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:00 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:00 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:00 --> Total execution time: 2.3531
DEBUG - 2015-04-16 11:41:00 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:00 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:41:00 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:00 --> URI Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Router Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:00 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:41:00 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Output Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:00 --> Security Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:00 --> Input Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:41:00 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Loader Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:41:00 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Loader Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:41:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:41:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:00 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:00 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:00 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:00 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:00 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:01 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:01 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:01 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:01 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:01 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:02 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:02 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 3.2892
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 3.0392
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 1.8021
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 4.1112
DEBUG - 2015-04-16 11:41:03 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:41:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:41:03 --> URI Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Router Class Initialized
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:41:03 --> Output Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Security Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 3.6862
DEBUG - 2015-04-16 11:41:03 --> Input Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 2.7452
DEBUG - 2015-04-16 11:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:41:03 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Loader Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:03 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:41:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:41:03 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:03 --> URI Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:03 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:03 --> Router Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:41:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:03 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Output Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:03 --> Security Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Input Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:41:03 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:03 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Loader Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:03 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:03 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:03 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:03 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:03 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:03 --> Total execution time: 0.7810
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:03 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:03 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:03 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:03 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:03 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:04 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:04 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:04 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:04 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:04 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:04 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:04 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:04 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:04 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:04 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:04 --> Final output sent to browser
DEBUG - 2015-04-16 11:41:04 --> Total execution time: 0.9691
DEBUG - 2015-04-16 11:41:39 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:41:39 --> URI Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Router Class Initialized
DEBUG - 2015-04-16 11:41:39 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:41:39 --> Output Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Security Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Input Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:41:39 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Language Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Config Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Loader Class Initialized
DEBUG - 2015-04-16 11:41:39 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:41:39 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:41:39 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:41:39 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:41:39 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:41:40 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:41:40 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:41:40 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Session Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:41:40 --> Session routines successfully run
DEBUG - 2015-04-16 11:41:40 --> Controller Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:41:40 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:41:40 --> Email Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:41:40 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:41:40 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:40 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:41:40 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:41:40 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:41:40 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:40 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:41:40 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:40 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:41:40 --> Model Class Initialized
DEBUG - 2015-04-16 11:41:40 --> Helper loaded: file_helper
DEBUG - 2015-04-16 11:41:40 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:52:01 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:01 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:01 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:01 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:01 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:01 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:01 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:01 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:02 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:02 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/views/partials/pagedata.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/views/../modules_core/sites/views/sites/create.php
DEBUG - 2015-04-16 11:52:02 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 11:52:02 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:02 --> Total execution time: 1.1470
DEBUG - 2015-04-16 11:52:04 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:04 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:04 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:04 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:04 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:04 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:04 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:04 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:04 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:05 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:05 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:05 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:05 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:05 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:05 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:05 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:05 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:05 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:05 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:05 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:05 --> Getelements MX_Controller Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:05 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:05 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:05 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:05 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:05 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:05 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:05 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:05 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:05 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:05 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:05 --> Total execution time: 1.6261
DEBUG - 2015-04-16 11:52:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:05 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:06 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:06 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:06 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:06 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:06 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:06 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:06 --> Model Class Initialized
ERROR - 2015-04-16 11:52:06 --> 404 Page Not Found --> sites/avatar
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:11 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:11 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:11 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:11 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:12 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:12 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:12 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:12 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:12 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:12 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:12 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:12 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:12 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:12 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:12 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:12 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:12 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:13 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:13 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:13 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:13 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:13 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:13 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:13 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:13 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:13 --> Total execution time: 2.8342
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:13 --> Total execution time: 2.0641
DEBUG - 2015-04-16 11:52:13 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:13 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:13 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Total execution time: 2.1511
DEBUG - 2015-04-16 11:52:13 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:13 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:13 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:14 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:14 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:13 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:14 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:14 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:14 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:14 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:14 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:14 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:14 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:14 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:14 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:13 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:14 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:14 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:14 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:14 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:14 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:14 --> Total execution time: 3.1012
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:14 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:14 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:14 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:14 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:15 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:15 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Total execution time: 3.9812
DEBUG - 2015-04-16 11:52:15 --> Total execution time: 0.8380
DEBUG - 2015-04-16 11:52:15 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:15 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:15 --> Total execution time: 3.5652
DEBUG - 2015-04-16 11:52:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:15 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:15 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:15 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:15 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:15 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:15 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:15 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:15 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:15 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:15 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:15 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:15 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:15 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:15 --> Total execution time: 1.3701
DEBUG - 2015-04-16 11:52:15 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:15 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:15 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:15 --> Total execution time: 1.3311
DEBUG - 2015-04-16 11:52:16 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:16 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:16 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:16 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:16 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:16 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:16 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:16 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:17 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:17 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:17 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:17 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:17 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:17 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:17 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:17 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:17 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:17 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:17 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:17 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:18 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:18 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:18 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:18 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:18 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:18 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:18 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:18 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:18 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:18 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:18 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:18 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:18 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:18 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:18 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Total execution time: 1.7591
DEBUG - 2015-04-16 11:52:18 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:18 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:18 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:18 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:19 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:19 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:19 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:19 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:19 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:19 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:19 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:19 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:19 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:19 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:19 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:19 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:19 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:19 --> Total execution time: 2.4341
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:19 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:19 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:19 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:19 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:19 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:19 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:20 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:21 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:21 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:21 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:21 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:21 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:21 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:21 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:21 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:21 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:21 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:21 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:21 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:21 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:21 --> Total execution time: 4.2192
DEBUG - 2015-04-16 11:52:21 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:22 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:22 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:52:22 --> URI Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Router Class Initialized
DEBUG - 2015-04-16 11:52:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:52:22 --> Output Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Security Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Input Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:52:22 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:22 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:22 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:22 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Language Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Config Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Loader Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:52:22 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:52:22 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:52:22 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:52:22 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:52:22 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:22 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:52:22 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:22 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:22 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:23 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:23 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:23 --> Session Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:23 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:23 --> Session routines successfully run
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:23 --> Total execution time: 5.3753
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:23 --> Controller Class Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:52:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:52:23 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:23 --> Total execution time: 6.4414
DEBUG - 2015-04-16 11:52:23 --> Email Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:23 --> Total execution time: 5.9603
DEBUG - 2015-04-16 11:52:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:23 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:23 --> Total execution time: 1.4731
DEBUG - 2015-04-16 11:52:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:24 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:24 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:24 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:24 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:24 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:24 --> Total execution time: 2.8162
DEBUG - 2015-04-16 11:52:24 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:52:24 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:52:24 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:24 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:25 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-16 11:52:25 --> Final output sent to browser
DEBUG - 2015-04-16 11:52:25 --> Total execution time: 4.2042
DEBUG - 2015-04-16 11:53:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:53:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:53:11 --> URI Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Router Class Initialized
DEBUG - 2015-04-16 11:53:11 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:53:11 --> Output Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Security Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Input Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:53:11 --> Language Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Language Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Config Class Initialized
DEBUG - 2015-04-16 11:53:11 --> Loader Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:53:12 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:53:12 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Session Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:53:12 --> Session routines successfully run
DEBUG - 2015-04-16 11:53:12 --> Controller Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:53:12 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:53:12 --> Email Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:53:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:12 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:53:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:53:12 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:53:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:12 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:53:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:12 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:53:12 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: file_helper
DEBUG - 2015-04-16 11:53:12 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:53:12 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-16 11:53:46 --> Config Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:53:46 --> URI Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Router Class Initialized
DEBUG - 2015-04-16 11:53:46 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:53:46 --> Output Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Security Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Input Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:53:46 --> Language Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Language Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Config Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Loader Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:53:46 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:53:46 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Session Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:53:46 --> Session routines successfully run
DEBUG - 2015-04-16 11:53:46 --> Controller Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:53:46 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:53:46 --> Email Class Initialized
DEBUG - 2015-04-16 11:53:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:53:47 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:53:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:47 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:53:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:47 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:53:47 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:53:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:47 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:53:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:47 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:53:47 --> Model Class Initialized
DEBUG - 2015-04-16 11:53:47 --> Helper loaded: file_helper
DEBUG - 2015-04-16 11:53:47 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:53:47 --> File loaded: application/modules_core/sites/views/partials/error.php
DEBUG - 2015-04-16 11:56:07 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:07 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:07 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:07 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:07 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:07 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:07 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:08 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:08 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:08 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:08 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:08 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:08 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:08 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:08 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:08 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:56:08 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-16 11:56:08 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:08 --> Total execution time: 0.8660
DEBUG - 2015-04-16 11:56:22 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:22 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:22 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:22 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:22 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:22 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:23 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:23 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:23 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:23 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:23 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:23 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:23 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:23 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:23 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:23 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:23 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:23 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:23 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:23 --> Total execution time: 0.7050
DEBUG - 2015-04-16 11:56:30 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:30 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:30 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:30 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:30 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:30 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:30 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:30 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:30 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:30 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:30 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:30 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:30 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:30 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:30 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:30 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:30 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:30 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:30 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:30 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:30 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:30 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:31 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:31 --> Total execution time: 0.5800
DEBUG - 2015-04-16 11:56:32 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:32 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:32 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:32 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:32 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:32 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:32 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:32 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:32 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:32 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:32 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:32 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:32 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:32 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:32 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:32 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:32 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:32 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:32 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:32 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:32 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:32 --> Total execution time: 0.8830
DEBUG - 2015-04-16 11:56:34 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:34 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:34 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:34 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:34 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:34 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:34 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:34 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:34 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:34 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:35 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:35 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:35 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:35 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:35 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:35 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:35 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:35 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:35 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:35 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:35 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:35 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:35 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:35 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:35 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:35 --> Total execution time: 0.7700
DEBUG - 2015-04-16 11:56:42 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Hooks Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Utf8 Class Initialized
DEBUG - 2015-04-16 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 11:56:42 --> URI Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Router Class Initialized
DEBUG - 2015-04-16 11:56:42 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 11:56:42 --> Output Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Security Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Input Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 11:56:42 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Language Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Config Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Loader Class Initialized
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: url_helper
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: form_helper
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: language_helper
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: user_helper
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: date_helper
DEBUG - 2015-04-16 11:56:42 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 11:56:42 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 11:56:43 --> Database Driver Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Session Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Helper loaded: string_helper
DEBUG - 2015-04-16 11:56:43 --> Session routines successfully run
DEBUG - 2015-04-16 11:56:43 --> Controller Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 11:56:43 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 11:56:43 --> Email Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 11:56:43 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 11:56:43 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 11:56:43 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Form Validation Class Initialized
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 11:56:43 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 11:56:43 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 11:56:43 --> Model Class Initialized
DEBUG - 2015-04-16 11:56:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/sites/views/partials/success.php
DEBUG - 2015-04-16 11:56:43 --> Helper loaded: directory_helper
DEBUG - 2015-04-16 11:56:43 --> File loaded: application/modules_core/sites/views/partials/sitedata.php
DEBUG - 2015-04-16 11:56:43 --> Final output sent to browser
DEBUG - 2015-04-16 11:56:43 --> Total execution time: 0.9270
DEBUG - 2015-04-16 13:13:53 --> Config Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:13:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:13:53 --> URI Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Router Class Initialized
DEBUG - 2015-04-16 13:13:53 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 13:13:53 --> Output Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Security Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Input Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:13:53 --> Language Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Language Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Config Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Loader Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:13:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:13:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Session Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:13:53 --> Session routines successfully run
DEBUG - 2015-04-16 13:13:53 --> Controller Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 13:13:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:13:53 --> Email Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:13:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:13:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:13:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:13:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:13:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:13:53 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 13:13:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:13:53 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 13:13:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:13:53 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 13:13:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_sitesettings.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_account.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/modules_core/sites/views/shared/modal_deletesite.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/modules_core/sites/views/shared/js_sitesettings.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/modules_core/sites/views/shared/js_account.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/views/../modules_core/sites/views/sites/sites.php
DEBUG - 2015-04-16 13:13:54 --> File loaded: application/views/templates/sites.php
DEBUG - 2015-04-16 13:13:54 --> Final output sent to browser
DEBUG - 2015-04-16 13:13:54 --> Total execution time: 0.9340
DEBUG - 2015-04-16 13:13:55 --> Config Class Initialized
DEBUG - 2015-04-16 13:13:55 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:13:55 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:13:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:13:55 --> URI Class Initialized
DEBUG - 2015-04-16 13:13:55 --> Router Class Initialized
ERROR - 2015-04-16 13:13:56 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:14:00 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:00 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:00 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 13:14:00 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:00 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:01 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:01 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:01 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:01 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:01 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:01 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 13:14:01 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:01 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:01 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:01 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:01 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:01 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:01 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 13:14:01 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:01 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 13:14:01 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:01 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 13:14:01 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:01 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:01 --> Total execution time: 0.7580
DEBUG - 2015-04-16 13:14:02 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:02 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:02 --> File loaded: application/modules_core/sites/config/routes.php
DEBUG - 2015-04-16 13:14:02 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:02 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:02 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:02 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Sites MX_Controller Initialized
DEBUG - 2015-04-16 13:14:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:02 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:02 --> File loaded: application/modules_core/sites/models/sitemodel.php
DEBUG - 2015-04-16 13:14:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:02 --> File loaded: application/modules_core/sites/models/usermodel.php
DEBUG - 2015-04-16 13:14:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:02 --> File loaded: application/modules_core/sites/models/pagemodel.php
DEBUG - 2015-04-16 13:14:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:03 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:03 --> Total execution time: 0.7320
DEBUG - 2015-04-16 13:14:07 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:07 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:07 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 13:14:07 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:07 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:07 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:07 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:07 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:07 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:07 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:08 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:08 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:08 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:08 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:08 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:08 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:14:08 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:08 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:08 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:08 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:08 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:08 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:08 --> File loaded: application/views/../modules_core/services/views/user/index.php
DEBUG - 2015-04-16 13:14:08 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:14:08 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:08 --> Total execution time: 0.6290
DEBUG - 2015-04-16 13:14:08 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:08 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:08 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 13:14:08 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:08 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:09 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:09 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:09 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:09 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:09 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Services MX_Controller Initialized
DEBUG - 2015-04-16 13:14:09 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:09 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:09 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:09 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:09 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:09 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:09 --> Form Validation Class Initialized
ERROR - 2015-04-16 13:14:09 --> 404 Page Not Found --> services/avatar
DEBUG - 2015-04-16 13:14:10 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:10 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:10 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 13:14:10 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:10 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:10 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:10 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:10 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:10 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:10 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:14:10 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:10 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:10 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:10 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:10 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:10 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:10 --> Form Validation Class Initialized
ERROR - 2015-04-16 13:14:11 --> Unable to load the requested class: grid
DEBUG - 2015-04-16 13:14:24 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:24 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:24 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:14:24 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:24 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:24 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:25 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:25 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:25 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:25 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:25 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:14:25 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:25 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:25 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:25 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:25 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:25 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:25 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:25 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-16 13:14:25 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:14:25 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:25 --> Total execution time: 0.5970
DEBUG - 2015-04-16 13:14:26 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:26 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:26 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:26 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:26 --> Router Class Initialized
ERROR - 2015-04-16 13:14:26 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:14:28 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:28 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:28 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:28 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:28 --> Router Class Initialized
ERROR - 2015-04-16 13:14:28 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:14:29 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:29 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:29 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:14:29 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:29 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:29 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:29 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:29 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:29 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:29 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:14:29 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:29 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:29 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:29 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:29 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:29 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:29 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:30 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:30 --> Total execution time: 0.8060
DEBUG - 2015-04-16 13:14:52 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:52 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:52 --> No URI present. Default controller set.
DEBUG - 2015-04-16 13:14:52 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:52 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:52 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:52 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:52 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:52 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 13:14:52 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:52 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:52 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:52 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:52 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:52 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 13:14:53 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:53 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Router Class Initialized
DEBUG - 2015-04-16 13:14:53 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 13:14:53 --> Output Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Security Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Input Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:14:53 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Language Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Loader Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:14:53 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:14:53 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Session Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:14:53 --> Session routines successfully run
DEBUG - 2015-04-16 13:14:53 --> Controller Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Services MX_Controller Initialized
DEBUG - 2015-04-16 13:14:53 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:14:53 --> Email Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:14:53 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:14:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:53 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:14:53 --> Model Class Initialized
DEBUG - 2015-04-16 13:14:53 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:14:54 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-16 13:14:54 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:14:54 --> Final output sent to browser
DEBUG - 2015-04-16 13:14:54 --> Total execution time: 0.6410
DEBUG - 2015-04-16 13:14:54 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:54 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:54 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:54 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:54 --> Router Class Initialized
ERROR - 2015-04-16 13:14:54 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:14:55 --> Config Class Initialized
DEBUG - 2015-04-16 13:14:55 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:14:55 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:14:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:14:55 --> URI Class Initialized
DEBUG - 2015-04-16 13:14:55 --> Router Class Initialized
ERROR - 2015-04-16 13:14:55 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:17:17 --> Config Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:17:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:17:17 --> URI Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Router Class Initialized
DEBUG - 2015-04-16 13:17:17 --> File loaded: application/modules_core/services/config/routes.php
DEBUG - 2015-04-16 13:17:17 --> Output Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Security Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Input Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:17:17 --> Language Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Language Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Config Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Loader Class Initialized
DEBUG - 2015-04-16 13:17:17 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:17:18 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:17:18 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:17:18 --> Session Class Initialized
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:17:18 --> Session routines successfully run
DEBUG - 2015-04-16 13:17:18 --> Controller Class Initialized
DEBUG - 2015-04-16 13:17:18 --> Services MX_Controller Initialized
DEBUG - 2015-04-16 13:17:18 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:17:18 --> Email Class Initialized
DEBUG - 2015-04-16 13:17:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:17:18 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:17:18 --> Model Class Initialized
DEBUG - 2015-04-16 13:17:18 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:17:18 --> Model Class Initialized
DEBUG - 2015-04-16 13:17:18 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:17:18 --> File loaded: application/views/../modules_core/services/views/services/index.php
DEBUG - 2015-04-16 13:17:18 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:17:18 --> Final output sent to browser
DEBUG - 2015-04-16 13:17:18 --> Total execution time: 0.5740
DEBUG - 2015-04-16 13:18:01 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:01 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:01 --> Router Class Initialized
ERROR - 2015-04-16 13:18:01 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:18:08 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:08 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:08 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:08 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:08 --> Router Class Initialized
ERROR - 2015-04-16 13:18:08 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:18:14 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:14 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:14 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:14 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:14 --> Router Class Initialized
DEBUG - 2015-04-16 13:18:14 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:18:15 --> Output Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Security Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Input Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:18:15 --> Language Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Language Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Loader Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:18:15 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:18:15 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Session Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:18:15 --> Session routines successfully run
DEBUG - 2015-04-16 13:18:15 --> Controller Class Initialized
DEBUG - 2015-04-16 13:18:15 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:18:15 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:18:15 --> Email Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:18:15 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:18:15 --> Model Class Initialized
DEBUG - 2015-04-16 13:18:15 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:18:15 --> Model Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:18:15 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-16 13:18:15 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:18:15 --> Final output sent to browser
DEBUG - 2015-04-16 13:18:15 --> Total execution time: 0.6330
DEBUG - 2015-04-16 13:18:15 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:15 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:15 --> Router Class Initialized
ERROR - 2015-04-16 13:18:15 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:18:59 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:59 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Router Class Initialized
ERROR - 2015-04-16 13:18:59 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:18:59 --> Config Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:18:59 --> URI Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Router Class Initialized
DEBUG - 2015-04-16 13:18:59 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:18:59 --> Output Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Security Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Input Class Initialized
DEBUG - 2015-04-16 13:18:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:18:59 --> Language Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Language Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Config Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Loader Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:19:00 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:19:00 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Session Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:19:00 --> Session routines successfully run
DEBUG - 2015-04-16 13:19:00 --> Controller Class Initialized
DEBUG - 2015-04-16 13:19:00 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:19:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:19:00 --> Email Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:19:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:19:00 --> Model Class Initialized
DEBUG - 2015-04-16 13:19:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:19:00 --> Model Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:19:00 --> Final output sent to browser
DEBUG - 2015-04-16 13:19:00 --> Total execution time: 0.7450
DEBUG - 2015-04-16 13:24:27 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:24:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:24:27 --> URI Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Router Class Initialized
DEBUG - 2015-04-16 13:24:27 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:24:27 --> Output Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Security Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Input Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:24:27 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Loader Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:24:27 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:24:27 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Session Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:24:27 --> Session routines successfully run
DEBUG - 2015-04-16 13:24:27 --> Controller Class Initialized
DEBUG - 2015-04-16 13:24:27 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:24:27 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:24:27 --> Email Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:24:27 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:24:27 --> Model Class Initialized
DEBUG - 2015-04-16 13:24:27 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:24:27 --> Model Class Initialized
DEBUG - 2015-04-16 13:24:27 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:24:27 --> File loaded: application/views/../modules_core/user/views/index.php
DEBUG - 2015-04-16 13:24:28 --> File loaded: application/views/templates/main.php
DEBUG - 2015-04-16 13:24:28 --> Final output sent to browser
DEBUG - 2015-04-16 13:24:28 --> Total execution time: 0.6470
DEBUG - 2015-04-16 13:24:29 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:29 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:24:29 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:24:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:24:29 --> URI Class Initialized
DEBUG - 2015-04-16 13:24:29 --> Router Class Initialized
ERROR - 2015-04-16 13:24:29 --> 404 Page Not Found --> 
DEBUG - 2015-04-16 13:24:32 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:24:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:24:32 --> URI Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Router Class Initialized
DEBUG - 2015-04-16 13:24:32 --> File loaded: application/modules_core/user/config/routes.php
DEBUG - 2015-04-16 13:24:32 --> Output Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Security Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Input Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:24:32 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Loader Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:24:32 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:24:32 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Session Class Initialized
DEBUG - 2015-04-16 13:24:32 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:24:32 --> Session routines successfully run
DEBUG - 2015-04-16 13:24:32 --> Controller Class Initialized
DEBUG - 2015-04-16 13:24:32 --> User MX_Controller Initialized
DEBUG - 2015-04-16 13:24:33 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:24:33 --> Email Class Initialized
DEBUG - 2015-04-16 13:24:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:24:33 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:24:33 --> Model Class Initialized
DEBUG - 2015-04-16 13:24:33 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:24:33 --> Model Class Initialized
DEBUG - 2015-04-16 13:24:33 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:24:33 --> Final output sent to browser
DEBUG - 2015-04-16 13:24:33 --> Total execution time: 1.2611
DEBUG - 2015-04-16 13:24:59 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:24:59 --> URI Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Router Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Output Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Security Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Input Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:24:59 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Language Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Config Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Loader Class Initialized
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:24:59 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:24:59 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:24:59 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Session Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:25:00 --> Session routines successfully run
DEBUG - 2015-04-16 13:25:00 --> Controller Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 13:25:00 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:25:00 --> Email Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:25:00 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:25:00 --> Model Class Initialized
DEBUG - 2015-04-16 13:25:00 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:25:00 --> Model Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:25:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 13:25:01 --> Config Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Hooks Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Utf8 Class Initialized
DEBUG - 2015-04-16 13:25:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-16 13:25:01 --> URI Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Router Class Initialized
DEBUG - 2015-04-16 13:25:01 --> No URI present. Default controller set.
DEBUG - 2015-04-16 13:25:01 --> Output Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Security Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Input Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-16 13:25:01 --> Language Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Language Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Config Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Loader Class Initialized
DEBUG - 2015-04-16 13:25:01 --> Helper loaded: url_helper
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: form_helper
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: language_helper
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: user_helper
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: date_helper
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: breadcrumb_helper
DEBUG - 2015-04-16 13:25:02 --> Language file loaded: language/english/builderlite_lang.php
DEBUG - 2015-04-16 13:25:02 --> Database Driver Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Session Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: string_helper
DEBUG - 2015-04-16 13:25:02 --> Session routines successfully run
DEBUG - 2015-04-16 13:25:02 --> Controller Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Login MX_Controller Initialized
DEBUG - 2015-04-16 13:25:02 --> Config file loaded: application/config/ion_auth.php
DEBUG - 2015-04-16 13:25:02 --> Email Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-04-16 13:25:02 --> Helper loaded: cookie_helper
DEBUG - 2015-04-16 13:25:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:25:02 --> File loaded: application/modules_core/login/models/ion_auth_model.php
DEBUG - 2015-04-16 13:25:02 --> Model Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Form Validation Class Initialized
DEBUG - 2015-04-16 13:25:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-04-16 13:25:02 --> File loaded: application/views/../modules_core/login/views/login_form.php
DEBUG - 2015-04-16 13:25:02 --> File loaded: application/views/templates/guest.php
DEBUG - 2015-04-16 13:25:02 --> Final output sent to browser
DEBUG - 2015-04-16 13:25:02 --> Total execution time: 1.6261
