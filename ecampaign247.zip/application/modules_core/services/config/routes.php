<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions
| for services modules
|
*/

$route['module_name'] = "services";
$route['default_controller'] = 'services';
$route['user'] = "services/user/index";