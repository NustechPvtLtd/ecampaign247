<div class="content-inner">
<!-- Start .row -->
    <div class="col-lg-4 col-md-4">
        <div class="panel_new">
        <div class="login-wrapper">
        <a href="<?php echo site_url('sites');?>">
                    <div id="user-info">
                    <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/web_cover.jpg" alt="user-image">
                        <h4 class="headline">Web Page</h4>
                        </div>
                        </a>
                        <!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
                        <!--                         <div class="form-group"> -->
                        <!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
                        <!-- col-lg-12 start here -->
                        <!--                                 <label class="checkbox">
                        <div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
                        </label> -->
                        <!--                             </div> -->
                        <!-- col-lg-12 end here -->
                        <!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
                        <!-- col-lg-12 start here -->
                        <!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
                        <!--                             </div> -->
                        <!-- col-lg-12 end here -->
                        <!--                         </div> -->
                        <!--                     </form> -->
                            </div>
                                </div>
                                </div>
        <div class="col-lg-4 col-md-4">
        <div class="panel_new">
        <div class="login-wrapper">
        <a href="<?php echo site_url('services');?>">
            <div id="user-info">
            <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/campaign.jpg" alt="user-image">
            <h4 class="headline">Email Campaign</h4>
            </div>
                    </a>
<!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
<!--                         <div class="form-group"> -->
<!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
    <!-- col-lg-12 start here -->
    <!--                                 <label class="checkbox">
    <div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
    </label> -->
    <!--                             </div> -->
    <!-- col-lg-12 end here -->
    <!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
    <!-- col-lg-12 start here -->
    <!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
    <!--                             </div> -->
    <!-- col-lg-12 end here -->
    <!--                         </div> -->
    <!--                     </form> -->
    </div>
    </div>
    </div>
    <div class="col-lg-4 col-md-4">
    <div class="panel_new">
        <div class="login-wrapper">
            <a href="<?php echo site_url('services');?>">
            <div id="user-info">
                <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/social_media.jpg" alt="user-image">
                    <h4 class="headline">Social Media</h4>
                    </div>
                    </a>
<!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
<!--                         <div class="form-group"> -->
<!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
<!-- col-lg-12 start here -->
<!--                                 <label class="checkbox">
<div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
                                </label> -->
<!--                             </div> -->
<!-- col-lg-12 end here -->
<!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
<!-- col-lg-12 start here -->
<!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
<!--                             </div> -->
<!-- col-lg-12 end here -->
<!--                         </div> -->
<!--                     </form> -->
    </div>
    </div>
    </div>
    <div class="col-lg-4 col-md-4">
    <div class="panel_new">
    <div class="login-wrapper">
    <a href="<?php echo site_url('services');?>">
    <div id="user-info">
    <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/build_your_database.jpg" alt="user-image">
    <h4 class="headline">Build Your Database</h4>
                    </div>
                    </a>
                    <!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
                    <!--                         <div class="form-group"> -->
                    <!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
                    <!-- col-lg-12 start here -->
<!--                                 <label class="checkbox">
<div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
                                </label> -->
<!--                             </div> -->
                            <!-- col-lg-12 end here -->
<!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
<!-- col-lg-12 start here -->
<!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
<!--                             </div> -->
<!-- col-lg-12 end here -->
<!--                         </div> -->
<!--                     </form> -->
</div>
</div>
</div>
<div class="col-lg-4 col-md-4">
    <div class="panel_new">
        <div class="login-wrapper">
        <a href="<?php echo site_url('services');?>">
        <div id="user-info">
        <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/report.jpg" alt="user-image">
        <h4 class="headline">Report</h4>
            </div>
            </a>
<!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
<!--                         <div class="form-group"> -->
<!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
<!-- col-lg-12 start here -->
<!--                                 <label class="checkbox">
<div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
</label> -->
<!--                             </div> -->
                            <!-- col-lg-12 end here -->
<!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
<!-- col-lg-12 start here -->
<!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
<!--                             </div> -->
    <!-- col-lg-12 end here -->
    <!--                         </div> -->
    <!--                     </form> -->
</div>
</div>
</div>
<div class="col-lg-4 col-md-4">
<div class="panel_new">
<div class="login-wrapper">
<a href="<?php echo site_url('services');?>">
                    <div id="user-info">
                    <img class="cover img-responsive" src="<?php echo base_url();?>assets/customer/img/crm.jpg" alt="user-image">
                        <h4 class="headline">CRM</h4>
                        </div>
                        </a>
                        <!--                     <form role="form" id="webpage-form" action="index.html" class="form-horizontal services-form mt10 p15" novalidate="novalidate"> -->
                        <!--                         <div class="form-group"> -->
                        <!--                             <div class="col-lg-8 col-md-6 col-sm-6 col-xs-8"> -->
                        <!-- col-lg-12 start here -->
                        <!--                                 <label class="checkbox">
                        <div style="position: relative;" class="icheckbox_minimal-teal"><div class="icheckbox_minimal-teal" style="position: relative;"><input type="checkbox" style="position: absolute; opacity: 0;" name="remember" id="remember" value="option"><ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;"></ins></div><ins style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 0px none; opacity: 0;" class="iCheck-helper"></ins></div>http://xxx.ecampaign.com
                            </label> -->
                            <!--                             </div> -->
                            <!-- col-lg-12 end here -->
<!--                             <div class="col-lg-4 col-md-6 col-sm-6 col-xs-4"> -->
                            <!-- col-lg-12 start here -->
                            <!--                                 <button type="submit" class="btn btn-default pull-right">Edit</button> -->
<!--                             </div> -->
                                <!-- col-lg-12 end here -->
                                <!--                         </div> -->
                                <!--                     </form> -->
                                </div>
                                </div>
        </div>                     <!-- End .row -->
</div>