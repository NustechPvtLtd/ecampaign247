<div class="alert alert-error">
	<button type="button" class="close fui-cross"></button>
	<h4><?php echo $data['header'];?></h4>
	<div><?php echo $data['content']?></div>
</div>