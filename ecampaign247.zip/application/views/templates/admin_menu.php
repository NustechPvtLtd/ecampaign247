<li class="treeview"><a href="javascript:;"><i class="glyphicon glyphicon-user"></i> <span>Users</span><i class="fa fa-angle-left pull-right"></i></a>
<ul class="treeview-menu">
<li><a href="<?php echo site_url('/');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right glyphicon glyphicon-user"></i>User</a></li>
<li><a href="<?php echo site_url('group');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right glyphicon-group"></i>Group</a></li>
</ul>
</li>
<li><a href="<?php echo site_url('sites');?>"><i class="glyphicon glyphicon-file"></i> <span>Web Sites</span></a></li>
<li><a href="<?php echo site_url('/');?>"><i class="glyphicon glyphicon-envelope"></i> <span>Campaigns</span></a></li>
<li class="treeview"><a href="javascript:;"><i class="glyphicon glyphicon-text-width"></i> <span>Templates</span><i class="fa fa-angle-left pull-right"></i></a>
<ul class="treeview-menu">
<li><a href="<?php echo site_url('/');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>My templates</a></li>
<li><a href="<?php echo site_url('/');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Gallery</a></li>
</ul>
</li>