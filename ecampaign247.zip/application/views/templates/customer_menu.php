<li><a href="<?php echo site_url('user');?>"><i class="glyphicon glyphicon-user"></i> <span>Users</span></a></li>
<li class="treeview"><a href="javascript:;"><i class="glyphicon glyphicon-transfer"></i> <span>Servers</span><i class="fa fa-angle-left pull-right"></i></a>
<ul class="treeview-menu">
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Delivery servers</a></li>
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Bounce servers</a></li>
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Feedback loop servers</a></li>
</ul>
</li>