<li class=""><a href="<?php echo site_url('services');?>"><i class="glyphicon glyphicon-dashboard"></i> <span>Services</span></a></li>
<li class="treeview"><a href="javascript:;"><i class="glyphicon glyphicon-list-alt"></i> <span>Lists</span><i class="fa fa-angle-left pull-right"></i></a>
<ul class="treeview-menu">
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Lists</a></li>
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Tools</a></li>
</ul>
</li>
<li><a href="<?php echo site_url('services');?>"><i class="glyphicon glyphicon-envelope"></i> <span>Campaigns</span></a></li>
<li class="treeview"><a href="javascript:;"><i class="glyphicon glyphicon-text-width"></i> <span>Templates</span><i class="fa fa-angle-left pull-right"></i></a>
<ul class="treeview-menu">
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>My templates</a></li>
<li><a href="<?php echo site_url('services');?>" style="margin-left: 10px;"><i class="fa fa-angle-double-right"></i>Gallery</a></li>
</ul>
</li>